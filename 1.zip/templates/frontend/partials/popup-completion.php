<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div id="rp-completion-overlay" style="display:none;">
    <div class="rp-comp-box">
        <h3><?php esc_html_e('تکمیل اطلاعات', 'reyhan-panel'); ?></h3>
        <p><?php esc_html_e('لطفاً نام خود را وارد کنید.', 'reyhan-panel'); ?></p>
        <form id="rp-completion-form">
            <input type="text" id="rp_comp_fname" class="rp-comp-input" placeholder="<?php esc_attr_e('نام', 'reyhan-panel'); ?>" required>
            <input type="text" id="rp_comp_lname" class="rp-comp-input" placeholder="<?php esc_attr_e('نام خانوادگی', 'reyhan-panel'); ?>" required>
            <button type="submit" class="rp-comp-btn"><?php esc_html_e('ذخیره', 'reyhan-panel'); ?></button>
        </form>
    </div>
</div>