<?php if ( ! defined( 'ABSPATH' ) ) { exit; } 
$status = get_post_meta( $t->ID, '_ticket_status', true );
$st_label = ($status=='open')?__('باز', 'reyhan-panel'):(($status=='answered')?__('پاسخ داده', 'reyhan-panel'):__('بسته', 'reyhan-panel'));
?>
<tr>
    <td>#<?php echo $t->ID; ?></td>
    <td><?php echo esc_html($t->post_title); ?></td>
    <td><span class="rp-badge rp-status-<?php echo esc_attr($status); ?>"><?php echo esc_html($st_label); ?></span></td>
    <td><?php echo get_the_date('Y/m/d', $t); ?></td>
    <td><button class="t-view-link" onclick="window.loadTicketConversation(<?php echo $t->ID; ?>)"><?php esc_html_e('مشاهده', 'reyhan-panel'); ?></button></td>
</tr>