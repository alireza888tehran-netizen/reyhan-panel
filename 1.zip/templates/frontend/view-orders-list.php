<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<?php if ( empty( $orders ) ) : ?>
    <div class="rp-empty-state"><?php esc_html_e('سفارشی یافت نشد.', 'reyhan-panel'); ?></div>
<?php else : ?>
    <table class="rp-ticket-table">
        <thead>
            <tr>
                <th>#</th>
                <th><?php esc_html_e('تاریخ', 'reyhan-panel'); ?></th>
                <th><?php esc_html_e('وضعیت', 'reyhan-panel'); ?></th>
                <th><?php esc_html_e('مبلغ', 'reyhan-panel'); ?></th>
                <th><?php esc_html_e('عملیات', 'reyhan-panel'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($orders as $order): ?>
                <tr>
                    <td>#<?php echo esc_html( $order->get_order_number() ); ?></td>
                    <td><?php echo date_i18n( get_option('date_format'), $order->get_date_created()->getTimestamp() ); ?></td>
                    <td>
                        <span class="rp-badge status-<?php echo esc_attr( $order->get_status() ); ?>">
                            <?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?>
                        </span>
                    </td>
                    <td><?php echo $order->get_formatted_order_total(); // قیمت فرمت شده خود دارای HTML امن است ?></td>
                    <td>
                        <button type="button" class="button" onclick="loadSingleOrder(<?php echo esc_attr( $order->get_id() ); ?>)">
                            <?php esc_html_e('مشاهده', 'reyhan-panel'); ?>
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>