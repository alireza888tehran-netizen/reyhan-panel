<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<style>
    /* استایل اختصاصی صفحه تیکت */
    .rp-single-ticket-wrap {
        display: flex;
        flex-direction: column;
        gap: 20px;
        height: 100%;
    }
    
    .rp-chat-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 15px;
        background: #fff;
        border-radius: 12px;
        border: 1px solid #eee;
        box-shadow: 0 2px 10px rgba(0,0,0,0.03);
    }
    
    .rp-chat-title h3 { margin: 0; font-size: 16px; color: #333; }
    .rp-chat-meta { font-size: 12px; color: #888; margin-top: 4px; }
    
    .rp-chat-actions { display: flex; gap: 10px; }
    
    .rp-chat-box {
        background: #f8f9fa;
        border: 1px solid #eee;
        border-radius: 12px;
        padding: 20px;
        max-height: 500px;
        overflow-y: auto;
        display: flex;
        flex-direction: column;
        gap: 20px; /* فاصله بین پیام‌ها */
    }
    
    /* استایل ناحیه پاسخ */
    .rp-reply-area {
        background: #fff;
        border: 1px solid #eee;
        border-radius: 12px;
        padding: 15px;
        position: relative;
    }
    
    .rp-reply-textarea {
        width: 100%;
        border: none;
        resize: none;
        min-height: 80px;
        padding: 10px;
        font-family: inherit;
        outline: none;
        background: transparent;
    }
    
    .rp-reply-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-top: 1px solid #f0f0f0;
        padding-top: 10px;
        margin-top: 5px;
    }
    
    .rp-attach-btn {
        color: #666;
        cursor: pointer;
        padding: 5px 10px;
        border-radius: 5px;
        transition: 0.2s;
        display: flex;
        align-items: center;
        gap: 5px;
        font-size: 12px;
    }
    .rp-attach-btn:hover { background: #f0f0f0; color: #333; }
    
    /* استایل وضعیت بسته */
    .rp-ticket-closed-notice {
        text-align: center;
        padding: 20px;
        background: #fff3e0;
        color: #e65100;
        border-radius: 10px;
        font-weight: bold;
    }
</style>

<div class="rp-single-ticket-wrap">
    
    <div class="rp-chat-header">
        <div class="rp-chat-title">
            <h3><?php echo esc_html($ticket->post_title); ?> <span style="font-weight:normal; opacity:0.5;">#<?php echo $ticket->ID; ?></span></h3>
            <div class="rp-chat-meta">
                <?php 
                $dept = get_post_meta($ticket->ID, '_ticket_department', true);
                if($dept) echo esc_html($dept) . ' | ';
                echo get_the_date('j F Y ساعت H:i', $ticket);
                ?>
            </div>
        </div>
        <div class="rp-chat-actions">
            <?php if($status !== 'closed'): ?>
                <button onclick="closeTicketByUser(<?php echo $ticket->ID; ?>)" class="rp-btn-secondary" style="color:#d32f2f; border-color:#d32f2f; background:transparent;">
                    <span class="dashicons dashicons-no"></span> <?php esc_html_e('بستن تیکت', 'reyhan-panel'); ?>
                </button>
            <?php endif; ?>
            <button onclick="loadUserTickets()" class="rp-btn-secondary">
                <span class="dashicons dashicons-arrow-left-alt"></span> <?php esc_html_e('بازگشت', 'reyhan-panel'); ?>
            </button>
        </div>
    </div>

    <div class="rp-chat-box">
        <?php 
        // پیام اول (متن تیکت)
        $comment = $ticket; 
        $is_user = true; 
        $is_first_msg = true; 
        $display_name = get_user_meta($ticket->post_author, 'first_name', true) ?: __('شما', 'reyhan-panel');
        $avatar = get_user_meta($ticket->post_author, 'reyhan_user_avatar', true);
        
        include REYHAN_DIR . 'templates/frontend/partials/chat-message.php';
        
        // پاسخ‌ها
        unset($is_first_msg);
        foreach($comments as $c) {
            $is_user = ($c->user_id == $ticket->post_author);
            $display_name = $is_user ? (get_user_meta($c->user_id, 'first_name', true) ?: __('شما', 'reyhan-panel')) : __('پشتیبانی', 'reyhan-panel');
            $avatar = $is_user ? get_user_meta($c->user_id, 'reyhan_user_avatar', true) : REYHAN_URL . 'assets/images/support.png';
            $comment = $c;
            include REYHAN_DIR . 'templates/frontend/partials/chat-message.php';
        } 
        ?>
    </div>

    <?php if($status !== 'closed'): ?>
        <form id="rp-reply-form" class="rp-reply-area">
            <input type="hidden" name="ticket_id" value="<?php echo $ticket->ID; ?>">
            <textarea name="reply_message" class="rp-reply-textarea" placeholder="<?php esc_attr_e('پاسخ خود را اینجا بنویسید...', 'reyhan-panel'); ?>" required></textarea>
            
            <div class="rp-reply-footer">
                <div>
                    <input type="file" name="reply_attachment" id="rp-reply-file" style="display:none;">
                    <label for="rp-reply-file" class="rp-attach-btn">
                        <span class="dashicons dashicons-paperclip"></span> <?php esc_html_e('پیوست فایل', 'reyhan-panel'); ?>
                    </label>
                    <span id="rp-file-name" style="font-size:11px; color:#4caf50; margin-right:10px;"></span>
                </div>

                <button type="submit" class="rp-btn-new-ticket" style="padding:8px 25px; margin:0;">
                    <?php esc_html_e('ارسال پاسخ', 'reyhan-panel'); ?>
                </button>
            </div>
        </form>
        <script>
            // نمایش نام فایل انتخاب شده
            jQuery('#rp-reply-file').change(function() {
                var fileName = this.files[0] ? this.files[0].name : '';
                jQuery('#rp-file-name').text(fileName);
            });
        </script>
    <?php else: ?>
        <div class="rp-ticket-closed-notice">
            <span class="dashicons dashicons-lock"></span> <?php esc_html_e('این تیکت بسته شده است و امکان ارسال پاسخ وجود ندارد.', 'reyhan-panel'); ?>
        </div>
    <?php endif; ?>

</div>