<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<?php if ( empty( $tickets ) ) : ?>
    <div class="rp-empty-state"><?php esc_html_e('تیکتی یافت نشد.', 'reyhan-panel'); ?></div>
<?php else : ?>
    <table class="rp-ticket-table">
        <thead>
            <tr>
                <th>#</th>
                <th><?php esc_html_e('موضوع', 'reyhan-panel'); ?></th>
                <th><?php esc_html_e('وضعیت', 'reyhan-panel'); ?></th>
                <th><?php esc_html_e('تاریخ', 'reyhan-panel'); ?></th>
                <th><?php esc_html_e('عملیات', 'reyhan-panel'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach( $tickets as $t ) : ?>
                <?php 
                // فراخوانی پارشیال برای هر ردیف
                // متغیر $t در حلقه تعریف شده و در فایل اینکلود شده در دسترس خواهد بود
                if ( file_exists( REYHAN_DIR . 'templates/frontend/partials/row-ticket.php' ) ) {
                    include REYHAN_DIR . 'templates/frontend/partials/row-ticket.php';
                }
                ?>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>