<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<textarea id="rp-notif-initial-data" style="display:none;"><?php echo wp_json_encode( array_values( $notifications ?? [] ) ); ?></textarea>

<div class="wrap reyhanpanel-wrap">
    <div class="rp-title-area">
        <h1><span class="dashicons dashicons-email-alt"></span> <?php esc_html_e('اطلاعیه های سراسری', 'reyhan-panel'); ?></h1>
        <p style="color:#777; margin-top:5px; font-size:12px;"><?php esc_html_e('در این بخش میتوانید اطلاعیه های خود را ثبت، ویرایش یا حذف کنید.', 'reyhan-panel'); ?></p>
    </div>
    
    <?php 
    if ( isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true' ) {
        echo '<div id="reyhan-toast-msg" class="rp-modern-toast"><span class="dashicons dashicons-saved"></span> <span>'.esc_html__('تغییرات با موفقیت ذخیره شد.', 'reyhan-panel').'</span></div>';
    }
    ?>
    
    <form method="post" action="options.php" id="rp-notif-main-form">
        <?php settings_fields('reyhan_master_group'); ?>
        
        <textarea name="reyhan_options[global_notifications_json]" id="rp_notif_data_json" style="display:none;"></textarea>
        
        <div class="rp-notif-container">
            <div class="rp-notif-top-bar">
                <div class="rp-top-info">
                    <h2><?php esc_html_e('لیست پیام‌ها', 'reyhan-panel'); ?></h2>
                    <p><?php esc_html_e('این پیام‌ها در داشبورد کاربران نمایش داده می‌شوند.', 'reyhan-panel'); ?></p>
                </div>
                <button type="button" id="rp-btn-add-new" class="rp-btn-primary-large">
                    <span class="dashicons dashicons-plus"></span> <?php esc_html_e('ایجاد اطلاعیه جدید', 'reyhan-panel'); ?>
                </button>
            </div>

            <div id="rp-editor-wrapper" class="rp-editor-wrapper" style="display:none;">
                <div class="rp-editor-card">
                    <div class="rp-editor-header">
                        <div class="rp-ed-head-title">
                            <span class="dashicons dashicons-edit"></span> <span id="rp-editor-title"><?php esc_html_e('افزودن اطلاعیه', 'reyhan-panel'); ?></span>
                        </div>
                        <button type="button" id="rp-btn-cancel" class="rp-btn-close" title="<?php esc_attr_e('بستن', 'reyhan-panel'); ?>"><span class="dashicons dashicons-no-alt"></span></button>
                    </div>
                    <div class="rp-editor-body">
                        <div class="rp-row-grid-modern">
                            <div class="rp-field-group title-group">
                                <label><?php esc_html_e('عنوان پیام', 'reyhan-panel'); ?></label>
                                <div class="rp-input-icon-wrap">
                                    <span class="dashicons dashicons-heading"></span>
                                    <input type="text" id="edit-title" class="rp-input-modern" placeholder="<?php esc_attr_e('مثال: جشنواره نوروزی...', 'reyhan-panel'); ?>">
                                </div>
                            </div>
                            <div class="rp-field-group type-group">
                                <label><?php esc_html_e('رنگ و نوع', 'reyhan-panel'); ?></label>
                                <div class="rp-select-wrap">
                                    <select id="edit-type" class="rp-input-modern">
                                        <option value="info"><?php esc_html_e('🔵 آبی (اطلاع‌رسانی)', 'reyhan-panel'); ?></option>
                                        <option value="success"><?php esc_html_e('🟢 سبز (موفقیت)', 'reyhan-panel'); ?></option>
                                        <option value="warning"><?php esc_html_e('🟡 زرد (هشدار)', 'reyhan-panel'); ?></option>
                                        <option value="danger"><?php esc_html_e('🔴 قرمز (خطر)', 'reyhan-panel'); ?></option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="rp-field-group">
                            <label><?php esc_html_e('متن کامل پیام', 'reyhan-panel'); ?></label>
                            <textarea id="edit-msg" rows="5" class="rp-input-modern" placeholder="<?php esc_attr_e('متن پیام خود را اینجا بنویسید...', 'reyhan-panel'); ?>"></textarea>
                        </div>
                    </div>
                    <div class="rp-editor-footer">
                        <button type="button" id="rp-btn-save-item" class="rp-btn-save">
                            <span class="dashicons dashicons-saved"></span> <?php esc_html_e('ثبت در لیست', 'reyhan-panel'); ?>
                        </button>
                        <span class="rp-hint"><span class="dashicons dashicons-info"></span> <?php printf( esc_html__('پس از ثبت در لیست، حتماً دکمه %s پایین صفحه را بزنید.', 'reyhan-panel'), '<strong>'.__('ذخیره تغییرات نهایی', 'reyhan-panel').'</strong>' ); ?></span>
                    </div>
                </div>
            </div>

            <div id="rp-notif-grid" class="rp-notif-grid"></div>
            
            <div id="rp-empty-state" style="display:none;">
                <div class="rp-empty-icon"><span class="dashicons dashicons-megaphone"></span></div>
                <h3><?php esc_html_e('هیچ اطلاعیه‌ای وجود ندارد', 'reyhan-panel'); ?></h3>
                <p><?php esc_html_e('با زدن دکمه بالا، اولین پیام خود را بسازید.', 'reyhan-panel'); ?></p>
            </div>
        </div>

        <div class="rp-sticky-save-bar">
            <div class="rp-save-info"><?php esc_html_e('تغییرات شما آماده ذخیره سازی است.', 'reyhan-panel'); ?></div>
            <?php submit_button(__('ذخیره تغییرات نهایی', 'reyhan-panel'), 'primary', 'submit', false); ?>
        </div>
    </form>
</div>