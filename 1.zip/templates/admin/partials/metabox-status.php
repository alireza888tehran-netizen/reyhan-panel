<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<select name="ticket_status" style="width:100%">
    <option value="open" <?php selected($status, 'open'); ?>><?php esc_html_e('باز (در انتظار بررسی)', 'reyhan-panel'); ?></option>
    <option value="processing" <?php selected($status, 'processing'); ?>><?php esc_html_e('در حال رسیدگی', 'reyhan-panel'); ?></option> 
    <option value="answered" <?php selected($status, 'answered'); ?>><?php esc_html_e('پاسخ داده شده', 'reyhan-panel'); ?></option>
    <option value="closed" <?php selected($status, 'closed'); ?>><?php esc_html_e('بسته شده', 'reyhan-panel'); ?></option>
</select>