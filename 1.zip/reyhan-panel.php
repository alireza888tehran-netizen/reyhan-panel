<?php
/*
Plugin Name: ریحان پنل
Description: یک سیستم جامع پنل کاربری با امکاناتی فوق العاده به همراه یک سیستم اختصاصی تیکتینگ برای پاسخگویی به کاربرانتان. رابط کاربری آسان | کاربردی | سبک
Version: 1.2
Author: AliREYHANI
Author URI: https://example.com
Text Domain: reyhan-panel
Domain Path: /languages
*/

use ReyhanPanel\Core\Assets;
use ReyhanPanel\Core\PostTypes;
use ReyhanPanel\Core\AuthRedirects;
use ReyhanPanel\Admin\Settings;
use ReyhanPanel\Admin\Wizard;
use ReyhanPanel\Frontend\Controller as FrontendController;
use ReyhanPanel\Core\License;

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'REYHAN_VERSION', '1.2' );
define( 'REYHAN_DIR', plugin_dir_path( __FILE__ ) );
define( 'REYHAN_URL', plugin_dir_url( __FILE__ ) );

spl_autoload_register(function ($class) {
    $prefix = 'ReyhanPanel\\';
    $base_dir = REYHAN_DIR . 'src/';
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) return;
    $relative_class = substr($class, $len);
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';
    if (file_exists($file)) require $file;
});

final class ReyhanPlugin {

    private static $instance = null;

    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'plugins_loaded', [ $this, 'load_textdomain' ] );
        add_action( 'admin_notices', [ $this, 'check_license_notice' ] );

        $this->init_core();
        
        if ( License::is_active() ) {
            $this->init_admin();
        } else {

            if ( is_admin() ) {
                new Wizard();
            }
        }

        $this->init_frontend();
        $this->init_ajax();
    }

    public function load_textdomain() {
        load_plugin_textdomain( 'reyhan-panel', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
    }

    public function check_license_notice() {
        if ( isset($_GET['page']) && $_GET['page'] === 'reyhan-setup' ) return;

        if ( ! License::is_active() ) {
            ?>
            <div class="notice notice-error is-dismissible">
                <p>
                    <strong><?php _e('هشدار مهم:', 'reyhan-panel'); ?></strong> 
                    <?php _e('لایسنس افزونه "ریحان پنل" فعال نشده است. لطفا لایسنس معتبر را وارد کنید', 'reyhan-panel'); ?>
                    <a href="<?php echo admin_url('index.php?page=reyhan-setup'); ?>" class="button button-primary" style="margin-right: 10px;"><?php _e('فعال‌سازی لایسنس', 'reyhan-panel'); ?></a>
                </p>
            </div>
            <?php
        }
    }

    private function init_core() {
        new Assets();
        new PostTypes();
        new AuthRedirects();

        if ( ! class_exists( 'ReyhanPanel\Core\License' ) ) {
            require_once REYHAN_DIR . 'src/Core/License.php';
        }
    }

    private function init_admin() {
        if ( is_admin() ) {
            new Settings();
            
            new Wizard(); 
        }
    }

    private function init_frontend() {
        new FrontendController();
    }
    
    private function init_ajax() {
        new \ReyhanPanel\Ajax\Auth();
        new \ReyhanPanel\Ajax\UserTicket();
        if ( is_admin() ) new \ReyhanPanel\Ajax\AdminTicket();
    }

    public static function activate() {
        add_option( 'reyhan_do_activation_redirect', true );
    }
}

function reyhan_panel() { return ReyhanPlugin::instance(); }
add_action( 'plugins_loaded', 'reyhan_panel' );
register_activation_hook( __FILE__, [ 'ReyhanPlugin', 'activate' ] );