jQuery(document).ready(function ($) {
    "use strict";

    /* =======================================================
        تنظیمات اولیه و ثابت‌ها
    ======================================================= */
    // بررسی وجود آبجکت لوکالایز شده برای جلوگیری از خطا
    const LocalData = (typeof reyhan_admin_ajax !== 'undefined') ? reyhan_admin_ajax : { ajax_url: ajaxurl, nonce: '', canned_responses: [] };
    const DEFAULT_AVATAR = (typeof rp_default_avatar !== 'undefined') ? rp_default_avatar : '';

    /* =======================================================
        1. ابزارهای کمکی و UI عمومی (Tabs & Toggles)
    ======================================================= */
    function safeStorage(key, value = null) {
        try {
            if (value !== null) localStorage.setItem(key, value);
            else return localStorage.getItem(key);
        } catch (e) { return null; }
    }

    function switchTab(targetId) {
        var $target = $('#' + targetId);
        if ($target.length === 0) return false;
        $('.rp-tab-pane').hide().removeClass('active');
        $target.fadeIn(200).addClass('active');
        $('.rp-tabs-nav li').removeClass('active');
        $('.rp-tabs-nav li[data-tab="' + targetId + '"]').addClass('active');
        safeStorage('reyhan_active_tab', targetId);
        return true;
    }

    // لود تب ذخیره شده یا پیش‌فرض
    if ($('.rp-tabs-nav').length > 0) {
        $(document).on('click', '.rp-tabs-nav li', function (e) {
            e.preventDefault();
            var target = $(this).data('tab');
            if (target) switchTab(target);
        });

        var savedTab = safeStorage('reyhan_active_tab');
        if (!savedTab || !switchTab(savedTab)) {
            var firstTabId = $('.rp-tabs-nav li:first-child').data('tab');
            switchTab(firstTabId);
        }
    }

    // تاگل‌های نمایش/مخفی کردن بخش‌ها
    $(document).on('change', '.rp-section-toggle', function () {
        var targetId = $(this).data('target');
        if ($(this).is(':checked')) $('#' + targetId).slideDown();
        else $('#' + targetId).slideUp();
    });
    $('.rp-section-toggle').trigger('change'); // بررسی وضعیت اولیه

    // اصلاح عرض جداول در حالت تمام صفحه
    function fixFullWidthElements() {
        var fullWidthClasses = ['#rp-menu-builder-wrap', '.rp-section-header', '.rp-menu-builder-wrap', '.rp-agent-manager-wrapper'];
        $.each(fullWidthClasses, function (index, selector) {
            $(selector).each(function () {
                var $td = $(this).closest('td');
                if ($td.length) {
                    $td.closest('tr').find('th').hide();
                    $td.attr('colspan', '2').css({ 'padding': '0', 'width': '100%' });
                }
            });
        });
    }
    fixFullWidthElements();

    /* =======================================================
        2. مدیریت مدیا و آپلودر (با محدودیت فرمت)
    ======================================================= */
    $(document).on('click', '.rp-upload-btn-modern, .rp-preview-circle, .rp-media-upload-btn', function (e) {
        e.preventDefault();
        var $button = $(this);
        var wrap = $button.closest('.rp-media-upload-modern-wrap, .rp-image-uploader-area');
        var isMenuIcon = $button.hasClass('rp-media-upload-btn'); // آیکون منو
        var isProfile = wrap.find('.rp-preview-img').length > 0; // تشخیص پروفایل

        var custom_uploader = wp.media({
            title: isMenuIcon ? 'انتخاب آیکون SVG' : 'انتخاب تصویر',
            button: { text: 'استفاده از این فایل' },
            library: { type: isMenuIcon ? 'image/svg+xml' : 'image' }, // فیلتر اولیه
            multiple: false
        });

        custom_uploader.on('select', function () {
            var attachment = custom_uploader.state().get('selection').first().toJSON();

            // 1. محدودیت فرمت برای پروفایل
            if (isProfile && !isMenuIcon) {
                var allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];
                if (allowedTypes.indexOf(attachment.mime) === -1) {
                    alert('خطا: فقط فرمت‌های JPG, JPEG, PNG, WEBP مجاز هستند.');
                    return; // توقف عملیات
                }
            }

            // 2. محدودیت SVG برای منو
            if (isMenuIcon && attachment.mime !== 'image/svg+xml') {
                alert('لطفاً فقط فایل SVG انتخاب کنید.');
                return;
            }

            // ذخیره آدرس فایل
            wrap.find('input[type="text"], input[type="hidden"]').first().val(attachment.url).trigger('change');

            // آپدیت پیش‌نمایش
            var preview = wrap.find('img');
            if (preview.length) {
                preview.attr('src', attachment.url);
                wrap.addClass('has-image');
            }

            // تغییر متن دکمه برای منو
            if (isMenuIcon) {
                $button.text('تغییر فایل (' + attachment.filename + ')').css({ 'background': '#e8f5e9', 'color': '#2e7d32', 'border-color': '#c8e6c9' });
            }

            // نمایش دکمه حذف
            wrap.find('.rp-remove-btn-modern').fadeIn();
        });

        custom_uploader.open();
    });

    // دکمه حذف (بازگردانی به پیش‌فرض)
    $(document).on('click', '.rp-remove-btn-modern', function (e) {
        e.preventDefault();
        var wrap = $(this).closest('.rp-media-upload-modern-wrap');

        // خالی کردن اینپوت (تا در دیتابیس ذخیره نشود)
        wrap.find('.rp-media-input').val('').trigger('change');

        // بازگرداندن تصویر به حالت پیش‌فرض (user.png)
        var img = wrap.find('.rp-preview-img');
        var defaultSrc = img.data('default');

        if (defaultSrc) {
            img.attr('src', defaultSrc);
        }

        // مخفی کردن دکمه حذف
        $(this).fadeOut();
        wrap.removeClass('has-image');
    });

    /* =======================================================
        3. سیستم ناتیفیکیشن بیلدر (Notification Builder)
    ======================================================= */
    var notifData = [];
    var editIndex = -1;
    var $notifJson = $('#rp_notif_data_json');

    if ($('#rp-notif-grid').length > 0) {
        try { notifData = JSON.parse($('#rp-notif-initial-data').val() || '[]'); } catch (e) { notifData = []; }
        renderNotifGrid();
    }

    function renderNotifGrid() {
        var html = '';
        var container = $('#rp-notif-grid');
        var emptyState = $('#rp-empty-state');

        if (notifData.length === 0) {
            container.hide(); emptyState.fadeIn();
        } else {
            emptyState.hide(); container.css('display', 'grid');
            $.each(notifData, function (i, item) {
                var title = item.title || '(بدون عنوان)';
                var msg = (item.msg || '').substring(0, 80) + '...';
                html += `<div class="rp-notif-card rp-card-${item.type || 'info'}">
                    <div class="rp-card-header"><span class="rp-card-title">${title}</span></div>
                    <div class="rp-card-msg">${msg}</div>
                    <div class="rp-card-actions">
                        <button type="button" class="rp-btn-sm edit-notif" data-index="${i}">ویرایش</button>
                        <button type="button" class="rp-btn-sm delete-notif" data-index="${i}">حذف</button>
                    </div></div>`;
            });
            container.html(html);
        }
        $notifJson.val(JSON.stringify(notifData));
    }

    $('#rp-btn-add-new').click(function (e) {
        e.preventDefault(); editIndex = -1;
        $('#edit-title, #edit-msg').val(''); $('#edit-type').val('info');
        $('#rp-editor-title').text('افزودن اطلاعیه جدید');
        $('#rp-editor-wrapper').slideDown();
    });

    $('#rp-btn-cancel').click(function () { $('#rp-editor-wrapper').slideUp(); });

    $(document).on('click', '.edit-notif', function (e) {
        e.preventDefault(); editIndex = $(this).data('index');
        var item = notifData[editIndex];
        $('#edit-title').val(item.title); $('#edit-type').val(item.type); $('#edit-msg').val(item.msg);
        $('#rp-editor-title').text('ویرایش اطلاعیه');
        $('#rp-editor-wrapper').slideDown();
    });

    $(document).on('click', '.delete-notif', function (e) {
        e.preventDefault();
        if (confirm('آیا مطمئن هستید؟')) {
            notifData.splice($(this).data('index'), 1);
            renderNotifGrid();
            $('.rp-sticky-save-bar').addClass('visible');
        }
    });

    $('#rp-btn-save-item').click(function (e) {
        e.preventDefault();
        var newItem = { title: $('#edit-title').val(), type: $('#edit-type').val(), msg: $('#edit-msg').val(), active: '1' };
        if (editIndex === -1) notifData.unshift(newItem); else notifData[editIndex] = newItem;
        renderNotifGrid();
        $('#rp-editor-wrapper').slideUp();
        $('.rp-sticky-save-bar').addClass('visible');
    });

    /* =======================================================
        4. ساخت برگه و ابزارها (Tools & AJAX Actions)
    ======================================================= */
    // ساخت برگه لاگین
    $('#rp-create-page-ajax-btn').on('click', function (e) {
        e.preventDefault();
        var $btn = $(this);
        var $spinner = $('#rp-create-page-spinner');
        $btn.prop('disabled', true).addClass('disabled'); $spinner.addClass('is-active');

        $.post(LocalData.ajax_url, {
            action: 'reyhan_create_login_page_ajax', security: LocalData.nonce
        }, function (res) {
            $spinner.removeClass('is-active');
            if (res.success) {
                $btn.hide();
                $('#rp-create-page-success').text(res.data.msg || 'ساخته شد!').show().delay(3000).fadeOut();
                var $dropdown = $('#rp_login_page_dropdown');
                if ($dropdown.length) {
                    if ($dropdown.find('option[value="' + res.data.id + '"]').length === 0) {
                        $dropdown.append(new Option(res.data.title, res.data.id));
                    }
                    $dropdown.val(res.data.id);
                }
            } else {
                alert(res.data); $btn.prop('disabled', false).removeClass('disabled');
            }
        }).fail(function () {
            $spinner.removeClass('is-active'); alert('خطای ارتباط با سرور'); $btn.prop('disabled', false).removeClass('disabled');
        });
    });

    // اجرای ابزارهای سیستم (Reset, Nuke, Test)
    $('.rp-run-tool').click(function () {
        var btn = $(this);
        var action = btn.data('action');
        if (['factory_reset', 'nuke_tickets', 'nuke_users'].includes(action) && !confirm('این عملیات غیرقابل بازگشت است. ادامه می‌دهید؟')) return;

        btn.prop('disabled', true).text('در حال پردازش...');
        var data = { action: 'reyhan_tool_action', security: LocalData.nonce, tool_action: action };
        if (action === 'test_sms') data.mobile = $('#test_mobile_input').val();
        if (action === 'test_email') data.email = $('#test_email_input').val();

        $.post(LocalData.ajax_url, data, function (res) {
            btn.prop('disabled', false).text('اجرا');
            if (res.success) {
                alert(res.data);
                if (action === 'factory_reset') location.reload();
                if (action.includes('test')) $('#rp-test-result').html('<strong style="color:green">' + res.data + '</strong>');
            } else {
                alert('خطا: ' + res.data);
                $('#rp-test-result').html('<strong style="color:red">خطا: ' + res.data + '</strong>');
            }
        });
    });

    /* =======================================================
        5. مدیریت کارشناسان (Agent Manager)
    ======================================================= */
    var agentSearchTimer;
    var agentsData = [];
    var currentEditingAgent = null;

    if ($('#rp_agents_data_json').length > 0) {
        try { agentsData = JSON.parse($('#rp_agents_data_json').val()); } catch (e) { agentsData = []; }
        renderAgentsGrid();
    }

    function renderAgentsGrid() {
        var html = '';
        if (agentsData.length === 0) {
            html = '<div class="rp-empty-agent-state"><span class="dashicons dashicons-admin-users"></span><div>هنوز هیچ کارشناسی تعریف نشده است.</div></div>';
        } else {
            $.each(agentsData, function (i, agent) {
                var deptText = agent.all_depts ? '<span class="rp-badge success">مدیر کل (دسترسی کامل)</span>' :
                    (agent.depts && agent.depts.length > 0) ? 'دسترسی به: ' + agent.depts.join('، ') : '<span class="rp-badge error">بدون دسترسی</span>';

                html += `<div class="rp-agent-card ${agent.all_depts ? 'full-access' : 'limited'}">
                    <div class="rp-agent-avatar"><img src="${agent.avatar || DEFAULT_AVATAR}" alt="${agent.name}"></div>
                    <div class="rp-agent-info"><h4>${agent.name}</h4><span class="rp-agent-depts">${deptText}</span></div>
                    <div class="rp-agent-actions">
                        <button type="button" class="rp-btn-icon edit-agent" data-index="${i}"><span class="dashicons dashicons-edit"></span></button>
                        <button type="button" class="rp-btn-icon remove-agent" data-index="${i}"><span class="dashicons dashicons-trash"></span></button>
                    </div>
                </div>`;
            });
        }
        $('#rp-agents-grid').html(html);
        $('#rp_agents_data_json').val(JSON.stringify(agentsData));
    }

    /* جستجوی زنده کاربر */
    $('#rp-user-search-input').on('keyup', function () {
        var term = $(this).val();
        var resBox = $('#rp-search-results');
        clearTimeout(agentSearchTimer);

        if (term.length < 2) { resBox.hide(); return; }

        agentSearchTimer = setTimeout(function () {
            resBox.show().html('<div class="rp-search-loading"><span class="dashicons dashicons-update spin"></span> در حال جستجو...</div>');

            $.post(LocalData.ajax_url, {
                action: 'reyhan_search_users',
                security: LocalData.nonce,
                term: term
            }, function (res) {
                if (res.success && res.data.length > 0) {
                    var html = '<ul>';
                    $.each(res.data, function (i, user) {
                        // بررسی اینکه آیا قبلا اضافه شده است
                        var isAdded = agentsData.find(a => a.id == user.id);

                        // ساخت آیتم لیست (بدون نمایش عکس، اما دیتا-آواتار را نگه می‌داریم برای بعد)
                        html += `
                        <li class="${isAdded ? 'added' : 'rp-result-item'}" 
                            data-id="${user.id}" 
                            data-text="${user.text}" 
                            data-avatar="${user.avatar}">
                            
                            <div class="rp-res-info-text">
                                <span class="rp-res-name">${user.text}</span>
                            </div>
                            
                            ${isAdded
                                ? '<span class="dashicons dashicons-yes-alt" style="color:#4CAF50;"></span>'
                                : '<span class="dashicons dashicons-plus-alt2" style="color:#FF5722;"></span>'}
                        </li>`;
                    });
                    resBox.html(html + '</ul>');
                } else {
                    resBox.html('<div class="rp-search-empty">کاربری با این مشخصات یافت نشد.</div>');
                }
            }).fail(function () {
                resBox.html('<div class="rp-search-error">خطا در ارتباط با سرور.</div>');
            });
        }, 500);
    });
    // کلیک روی نتیجه جستجو
    $(document).on('click', '.rp-result-item', function () {
        var finalAvatar = $(this).data('avatar') || DEFAULT_AVATAR;
        currentEditingAgent = { id: $(this).data('id'), name: $(this).data('text'), avatar: finalAvatar, all_depts: false, depts: [], is_new: true };
        $('#modal-agent-avatar').attr('src', finalAvatar);
        openDeptModal();
        $('#rp-search-results').hide(); $('#rp-user-search-input').val('');
    });

    // باز کردن مودال
    function openDeptModal() {
        $('#modal-agent-name').text(currentEditingAgent.name);
        var deptContainer = $('#dept-list-container');
        var deptAllCheckbox = $('#dept-all');
        var hasDepts = (typeof rp_departments_list !== 'undefined' && rp_departments_list.length > 0);

        if (hasDepts) {
            var html = '';
            rp_departments_list.forEach(function (dept) {
                var checked = (currentEditingAgent.depts && currentEditingAgent.depts.includes(dept)) ? 'checked' : '';
                html += `<label class="rp-access-option"><input type="checkbox" class="dept-check" value="${dept}" ${checked}> <span>${dept}</span></label>`;
            });
            deptContainer.html(html).show();
            $('.rp-divider').show();
            deptAllCheckbox.prop('disabled', false).prop('checked', currentEditingAgent.all_depts);
        } else {
            deptContainer.html('<div class="rp-alert-warning">دپارتمانی تعریف نشده، دسترسی کامل اجباری است.</div>').show();
            deptAllCheckbox.prop('checked', true).prop('disabled', true);
            currentEditingAgent.all_depts = true;
        }

        updateAllAccessStyle();
        toggleDeptChecks();
        $('#rp-dept-modal').addClass('active').css('display', 'flex');
    }

    // ذخیره ایجنت
    $('#btn-save-agent').off('click').on('click', function (e) {
        e.preventDefault();
        currentEditingAgent.all_depts = $('#dept-all').is(':checked');
        currentEditingAgent.depts = [];
        if (!currentEditingAgent.all_depts) {
            $('.dept-check:checked').each(function () { currentEditingAgent.depts.push($(this).val()); });
        }

        if (currentEditingAgent.is_new) {
            delete currentEditingAgent.is_new; agentsData.push(currentEditingAgent);
        } else {
            agentsData[currentEditingAgent.index] = currentEditingAgent;
        }

        renderAgentsGrid();
        $('#rp-dept-modal').removeClass('active').fadeOut();
    });

    // مدیریت چک‌باکس‌ها
    $('#dept-all').change(function () { toggleDeptChecks(); updateAllAccessStyle(); });
    function toggleDeptChecks() {
        var isAll = $('#dept-all').is(':checked');
        if (typeof rp_departments_list !== 'undefined' && rp_departments_list.length > 0) {
            $('.dept-check').prop('disabled', isAll);
            if (isAll) $('.dept-check').prop('checked', true).closest('.rp-access-option').addClass('checked').css('opacity', '0.6');
            else $('.dept-check').closest('.rp-access-option').css('opacity', '1').removeClass('checked').find('input').prop('checked', false);
        }
    }
    function updateAllAccessStyle() {
        var chk = $('#dept-all');
        chk.closest('.rp-access-option').toggleClass('checked', chk.is(':checked'));
    }

    $(document).on('click', '.edit-agent', function () {
        var idx = $(this).data('index');
        currentEditingAgent = JSON.parse(JSON.stringify(agentsData[idx]));
        currentEditingAgent.index = idx; currentEditingAgent.is_new = false;
        $('#modal-agent-avatar').attr('src', currentEditingAgent.avatar || DEFAULT_AVATAR);
        openDeptModal();
    });

    $(document).on('click', '.remove-agent', function () {
        if (confirm('حذف شود؟')) { agentsData.splice($(this).data('index'), 1); renderAgentsGrid(); }
    });

    $('.close-modal, .rp-modal-close').click(function () { $('#rp-dept-modal').removeClass('active').fadeOut(); });

    /* =======================================================
        6. تیکت‌های ادمین (Admin Tickets) - اصلاح شده
    ======================================================= */
    if ($('#ticket-list-container').length) {
        var ticketContainer = $('#ticket-list-container');
        var chatBox = $('#conversation-content');
        var infoBar = $('#ticket-info-bar');
        var currentTicketId = null;

        function loadAdminTickets(status) {
            $.post(LocalData.ajax_url, { action: 'reyhan_admin_load_tickets', security: LocalData.nonce, status: status || 'active' }, function (res) {
                if (res.success) ticketContainer.html(res.data);
            });
        }

        // *** اصلاح مهم: تغییر سلکتور به کلاسی که در HTML استفاده شده ***
        $('.rp-mod-filter-btn').click(function (e) {
            e.preventDefault();
            $('.rp-mod-filter-btn').removeClass('active');
            $(this).addClass('active');
            loadAdminTickets($(this).data('status'));
        });

        $(document).on('click', '.ticket-list-item', function () {
            $('.ticket-list-item').removeClass('selected'); $(this).addClass('selected');
            currentTicketId = $(this).data('id');
            if ($(this).data('status') === 'closed') $('.rp-reply-area').slideUp(); else $('.rp-reply-area').slideDown();

            chatBox.html('<div class="rp-loading-state">در حال بارگذاری...</div>');
            infoBar.hide().empty();
            $('#delete-ticket-btn').show().data('id', currentTicketId);

            $.post(LocalData.ajax_url, { action: 'reyhan_admin_load_conv', security: LocalData.nonce, ticket_id: currentTicketId }, function (res) {
                if (res.success) {
                    infoBar.html(res.data.info).fadeIn();
                    chatBox.html(res.data.chat);
                    setTimeout(() => chatBox.scrollTop(chatBox[0].scrollHeight), 100);
                }
            });
        });

        $('#send-reply-btn').click(function () {
            if (!currentTicketId) return;
            var msg = $('#reply-text').val();
            var file = $('#reply-file')[0].files[0];
            var isClose = $('#close-ticket-check').is(':checked');
            var btn = $(this);

            if (!msg && !file) { alert('متن یا فایل الزامی است.'); return; }
            btn.prop('disabled', true).text('ارسال...');

            var fd = new FormData();
            fd.append('action', 'reyhan_admin_reply'); fd.append('security', LocalData.nonce); fd.append('ticket_id', currentTicketId); fd.append('message', msg); fd.append('status', isClose ? 'closed' : 'answered'); if (file) fd.append('reply_file', file);

            $.ajax({
                url: LocalData.ajax_url, type: 'POST', data: fd, contentType: false, processData: false,
                success: function (res) {
                    btn.prop('disabled', false).html('ارسال پاسخ <span class="dashicons dashicons-arrow-left-alt"></span>');
                    if (res.success) {
                        if (isClose) { $('.ticket-list-item[data-id="' + currentTicketId + '"]').fadeOut(); $('.rp-reply-area').slideUp(); chatBox.empty(); infoBar.hide(); } else { $('.ticket-list-item[data-id="' + currentTicketId + '"]').click(); }
                        $('#reply-text').val(''); $('#reply-file').val(''); $('#file-name-display').text('');
                    } else alert(res.data);
                }
            });
        });

        $('#reply-file').change(function () { $('#file-name-display').text(this.files[0] ? this.files[0].name : ''); });

        $('#delete-ticket-btn').click(function () {
            if (!currentTicketId || !confirm('مطمئن هستید؟')) return;
            $.post(LocalData.ajax_url, { action: 'reyhan_tool_action', security: LocalData.nonce, tool_action: 'nuke_tickets_single', id: currentTicketId }, function () {
                $('.ticket-list-item[data-id="' + currentTicketId + '"]').fadeOut(); chatBox.empty(); infoBar.hide();
            });
        });

        $('#canned-search-input').on('keyup focus', function () {
            var term = $(this).val().toLowerCase(); var box = $('#canned-results');
            if (term.length < 1) { box.hide(); return; }
            if (LocalData.canned_responses) {
                var hits = Object.values(LocalData.canned_responses).filter(r => (r.title || '').toLowerCase().includes(term) || (r.content || '').toLowerCase().includes(term));
                if (hits.length) { var html = ''; hits.forEach(r => { html += `<div class="rp-canned-item" data-content="${(r.content || '').replace(/"/g, '&quot;')}"><strong>${r.title}</strong><br><small>${(r.content || '').substring(0, 50)}...</small></div>`; }); box.html(html).show(); } else box.hide();
            }
        });

        $(document).on('click', '.rp-canned-item', function () {
            var txt = $('#reply-text'); txt.val(txt.val() + (txt.val() ? '\n' : '') + $(this).data('content')); $('#canned-results').hide();
        });

        loadAdminTickets('active');
        // اصلاح اینتروال برای کلاس جدید
        setInterval(() => loadAdminTickets($('.rp-mod-filter-btn.active').data('status')), 30000);
    }

    /* =======================================================
        7. منو ساز (Menu Builder)
    ======================================================= */
    if ($('#rp-menu-builder-wrap').length) {
        var $list = $('.rp-menu-list');
        $list.sortable({ handle: '.rp-sort-handle', placeholder: 'rp-sort-placeholder', items: '.rp-menu-item-row:not(.rp-locked-item)', cancel: '.rp-locked-item' });

        $('.rp-add-menu-item').on('click', function (e) {
            e.preventDefault();
            var $clone = $list.find('.rp-menu-item-row:not(.rp-locked-item)').first().clone();
            if (!$clone.length) $clone = $list.find('.rp-menu-item-row').first().clone(); // Fallback

            $clone.addClass('closed').removeClass('rp-locked-item');
            $clone.find('.rp-item-title').text('(آیتم جدید)');
            $clone.find('.rp-item-type-badge').text('link');
            $clone.find('input, textarea').val('');
            $clone.find('select').val('link').prop('disabled', false).css({ 'pointer-events': 'auto', 'opacity': '1' });
            $clone.find('.rp-icon-input').val('dashicons-marker');
            $clone.find('.preview-icon').attr('class', 'dashicons dashicons-marker preview-icon');

            // اصلاح هندل‌ها
            $clone.find('.rp-sort-handle, .rp-lock-icon, .rp-remove-row').remove();
            $clone.find('.rp-item-header').prepend('<span class="dashicons dashicons-move rp-sort-handle"></span>');
            $clone.find('.rp-header-controls').append('<button type="button" class="rp-remove-row"><span class="dashicons dashicons-trash"></span></button>');

            // ایندکس جدید
            var newIdx = new Date().getTime();
            $clone.find('input, select, textarea').each(function () {
                var name = $(this).attr('name');
                if (name) $(this).attr('name', name.replace(/\[\d+\]/, '[' + newIdx + ']'));
            });

            $clone.find('.rp-item-body').hide();
            var $logoutItem = $list.find('.rp-menu-item-row[data-action="logout"]');
            if ($logoutItem.length) $clone.insertBefore($logoutItem); else $list.append($clone);
        });

        $(document).on('click', '.rp-toggle-item', function () {
            var row = $(this).closest('.rp-menu-item-row');
            row.find('.rp-item-body').slideToggle();
            row.toggleClass('closed');
        });

        $(document).on('keyup', '.rp-live-title', function () { $(this).closest('.rp-menu-item-row').find('.rp-item-title').text($(this).val()); });

        $(document).on('change', '.rp-menu-action-select', function () {
            var val = $(this).val();
            var row = $(this).closest('.rp-menu-item-row');
            row.find('.rp-item-type-badge').text(val);
            row.find('.rp-menu-link-row').toggle(val === 'link');
            row.find('.rp-menu-shortcode-row').toggle(val === 'content');
        });
    }

    // انتخابگر آیکون (مشترک)
    $(document).on('change', '.rp-icon-type-radio', function () {
        var $row = $(this).closest('.rp-icon-settings-box');
        if ($(this).val() === 'icon') {
            $row.find('.rp-icon-picker-area').slideDown(200); $row.find('.rp-image-uploader-area').slideUp(200);
        } else {
            $row.find('.rp-icon-picker-area').slideUp(200); $row.find('.rp-image-uploader-area').slideDown(200);
        }
    });

    $(document).on('click', '.rp-icon-select-btn', function (e) {
        e.preventDefault(); e.stopPropagation();
        var $dropdown = $(this).siblings('.rp-icon-dropdown');
        $('.rp-icon-dropdown').not($dropdown).removeClass('show');

        if ($dropdown.children().length === 0) {
            var icons = ['dashicons-dashboard', 'dashicons-admin-post', 'dashicons-admin-media', 'dashicons-admin-users', 'dashicons-admin-settings', 'dashicons-email', 'dashicons-phone', 'dashicons-cart', 'dashicons-tickets-alt']; // (لیست خلاصه شده برای نمونه)
            var html = ''; icons.forEach(icon => { html += `<div class="rp-icon-option" data-icon="${icon}"><span class="dashicons ${icon}"></span></div>`; });
            $dropdown.html(html);
        }
        $dropdown.toggleClass('show');
    });

    $(document).on('click', '.rp-icon-option', function (e) {
        e.stopPropagation();
        var icon = $(this).data('icon');
        var wrap = $(this).closest('.rp-icon-picker-wrap');
        wrap.find('.rp-icon-input').val(icon);
        wrap.find('.preview-icon').attr('class', 'dashicons ' + icon + ' preview-icon');
        wrap.find('.rp-icon-dropdown').removeClass('show');
    });

    $(document).click(function (e) { if (!$(e.target).closest('.rp-icon-picker-wrap').length) $('.rp-icon-dropdown').removeClass('show'); });

    /* =======================================================
        8. ریپیتر (Repeater) - اصلاح شده برای دکمه جدید
    ======================================================= */
    // هندلر قدیمی (برای تنظیمات اصلی)
    $(document).on('click', '.rp-add-row', function () {
        var wrap = $(this).closest('.rp-repeater-wrap');
        var list = wrap.find('.rp-repeater-list');
        var id = wrap.data('id');
        var fields = $(this).data('fields');
        var idx = new Date().getTime();

        var html = '<div class="rp-repeater-item" style="display:none;"><div class="rp-repeater-inputs">';
        $.each(fields, function (key, label) {
            var name = 'reyhan_options[' + id + '][' + idx + '][' + key + ']';
            html += `<div class="rp-input-group-row"><label class="rp-input-label">${label}</label>`;
            if (['content', 'a'].includes(key)) html += `<textarea name="${name}" rows="2" class="rp-full-width"></textarea>`;
            else html += `<input type="text" name="${name}" class="rp-full-width">`;
            html += '</div>';
        });
        html += '</div><div class="rp-repeater-actions"><button type="button" class="button rp-remove-row"><span class="dashicons dashicons-no"></span></button></div></div>';
        list.append(html); list.find('.rp-repeater-item:last').fadeIn();
    });

    // هندلر جدید (مدرن - مخصوص پروفایل)
    $(document).on('click', '.rp-add-row-modern', function (e) {
        e.preventDefault();
        var wrap = $(this).closest('.rp-repeater-wrap');
        var list = wrap.find('.rp-repeater-list');
        var id = wrap.data('id'); // rp_user_canned_responses
        var idx = new Date().getTime();

        // ساختار HTML دقیقاً مطابق با فایل ویو
        var html = `
        <div class="rp-canned-item" style="display:none;">
            <div class="rp-drag-handle"><span class="dashicons dashicons-move"></span></div>
            <div class="rp-canned-inputs">
                <div>
                    <input type="text" name="reyhan_options[${id}][${idx}][title]" class="rp-mod-input-sm" placeholder="عنوان پاسخ">
                </div>
                <div>
                    <textarea name="reyhan_options[${id}][${idx}][content]" class="rp-mod-input-sm" placeholder="متن کامل پاسخ"></textarea>
                </div>
            </div>
            <button type="button" class="rp-btn-delete rp-remove-row-circle" title="حذف">
                <span class="dashicons dashicons-trash"></span>
            </button>
        </div>`;

        list.append(html);
        list.find('.rp-canned-item:last').fadeIn();
    });

    // هندلر حذف برای هر دو نوع
    $(document).on('click', '.rp-remove-row, .rp-remove-row-circle', function (e) {
        e.preventDefault();
        if (confirm('آیا مطمئن هستید؟')) {
            $(this).closest('.rp-repeater-item, .rp-canned-item').slideUp(200, function () { $(this).remove(); });
        }
    });

    if ($.fn.sortable) $('.rp-repeater-list').sortable({ handle: '.rp-item-header, .rp-drag-handle', placeholder: "ui-state-highlight", opacity: 0.8 });

    /* =======================================================
        9. سیستم شهرها و Select2 (Cities & Locations)
    ======================================================= */
    const iranCities = {
        'Alborz': ['کرج', 'هشتگرد', 'طالقان'], 'Tehran': ['تهران', 'شهریار', 'اسلامشهر'], 'Isfahan': ['اصفهان', 'کاشان'], 'Fars': ['شیراز', 'مرودشت'], 'Razavi Khorasan': ['مشهد', 'نیشابور'], // لیست خلاصه شده
        // ... (بقیه شهرها را در صورت نیاز اینجا اضافه کنید یا در فایل جداگانه نگه دارید)
    };

    if ($.fn.select2) {
        $('.rp-select2').select2({
            width: '100%',
            dir: "rtl",
            language: { noResults: () => "یافت نشد" },
            dropdownCssClass: 'rp-select2-drop', // <--- کلاس اختصاصی برای دراپ‌داون
            containerCssClass: 'rp-select2-container' // <--- کلاس اختصاصی برای خود فیلد
        });
    }

    $('#rp_admin_state').on('change', function () {
        var state = $(this).val();
        var citySelect = $('#rp_admin_city');
        citySelect.empty().append('<option value="">انتخاب شهر...</option>');
        if (state && iranCities[state]) {
            iranCities[state].forEach(city => { citySelect.append(`<option value="${city}">${city}</option>`); });
        }
        citySelect.trigger('change');
    });

    // لود شهر پیش‌فرض
    var savedCity = $('#rp_admin_city').data('default');
    var currentState = $('#rp_admin_state').val();
    if (savedCity && currentState && iranCities[currentState]) {
        iranCities[currentState].forEach(city => {
            $('#rp_admin_city').append(`<option value="${city}" ${city === savedCity ? 'selected' : ''}>${city}</option>`);
        });
        $('#rp_admin_city').trigger('change');
    }

    // بررسی تکراری بودن اطلاعات (موبایل/ایمیل)
    $('.rp-check-duplicate').on('blur', function () {
        var input = $(this);
        var value = input.val();
        if (value.length < 3) return;

        var msgBox = input.siblings('.rp-validation-msg');
        var submitBtn = $('#submit');

        msgBox.html('<span class="dashicons dashicons-update spin"></span> در حال بررسی...');

        $.post(LocalData.ajax_url, {
            action: 'rp_check_duplicate_data', type: input.data('type'), value: value, user_id: input.closest('.rp-modern-dashboard').data('user-id')
        }, function (res) {
            if (res.success) {
                msgBox.html('<span style="color:green; font-size:11px;">✔ تایید شد</span>');
                setTimeout(() => msgBox.empty(), 2000);
                input.removeClass('rp-error-border');
                submitBtn.prop('disabled', false);
            } else {
                msgBox.html('<span class="dashicons dashicons-warning"></span> ' + res.data);
                input.addClass('rp-error-border');
                submitBtn.prop('disabled', true);
            }
        });
    });

    /* =======================================================
        10. سیستم OTP یکپارچه (Integrated OTP System)
    ======================================================= */
    var currentOtpType = '';

    // باز کردن مودال OTP
    $('.rp-btn-trigger-otp').on('click', function (e) {
        e.preventDefault();
        currentOtpType = $(this).data('type');
        var title = (currentOtpType === 'mobile') ? 'شماره همراه جدید' : 'ایمیل جدید';
        $('#rp-otp-label').text('لطفاً ' + title + ' را وارد کنید:');
        $('#rp-new-value-input').val('').focus();
        $('#rp-step-1').show(); $('#rp-step-2').hide();
        $('#rp-otp-modal-wrap').fadeIn(200);
    });

    $('.rp-close-modal, .rp-otp-overlay').on('click', function () { $('#rp-otp-modal-wrap').fadeOut(200); });

    // مرحله 1: ارسال درخواست کد
    $('#rp-send-otp-ajax').on('click', function () {
        var val = $('#rp-new-value-input').val();
        var btn = $(this);
        if (!val) return alert('لطفاً مقدار را وارد کنید.');

        btn.addClass('updating-message').prop('disabled', true);

        $.post(LocalData.ajax_url, {
            action: 'rp_send_otp_request', type: currentOtpType, value: val, security: LocalData.nonce
        }, function (res) {
            btn.removeClass('updating-message').prop('disabled', false);
            if (res.success) {
                $('#rp-step-1').slideUp(200);
                $('#rp-step-2').slideDown(200);
                startOtpTimer(120);
                $('#rp-otp-code-input').focus();
                // اگر محیط تست است، کد را نشان بده (فقط برای دیباگ)
                if (res.data && res.data.includes && res.data.includes('تست')) console.log(res.data);
            } else {
                alert(res.data);
            }
        }).fail(function () { btn.prop('disabled', false); alert('خطا در سرور'); });
    });

    // مرحله 2: تایید نهایی
    $('#rp-verify-otp-ajax').on('click', function () {
        var code = $('#rp-otp-code-input').val();
        var btn = $(this);
        if (code.length < 4) return alert('کد تایید معتبر نیست.');

        btn.addClass('updating-message').prop('disabled', true);

        $.post(LocalData.ajax_url, {
            action: 'rp_verify_contact_final', type: currentOtpType, code: code, security: LocalData.nonce
        }, function (res) {
            if (res.success) {
                alert('تغییرات با موفقیت ذخیره شد.');
                location.reload();
            } else {
                alert(res.data);
                btn.removeClass('updating-message').prop('disabled', false);
            }
        });
    });

    $('#rp-back-step-1').click(function (e) {
        e.preventDefault();
        $('#rp-step-2').hide(); $('#rp-step-1').show();
    });

    function startOtpTimer(duration) {
        var timer = duration, seconds;
        var display = $('#rp-timer');
        var interval = setInterval(function () {
            seconds = parseInt(timer % 60, 10);
            display.text(seconds);
            if (--timer < 0) {
                clearInterval(interval);
                display.text("منقضی");
                $('#rp-otp-resend').fadeIn(); // فرض بر وجود دکمه ارسال مجدد
            }
        }, 1000);
    }

    // تب‌های پیامک
    $('.rp-mini-tabs-nav li').click(function () {
        var method = $(this).data('method');
        var wrap = $(this).closest('.rp-mini-tabs-wrapper');
        wrap.find('li').removeClass('active'); $(this).addClass('active');
        wrap.find('.rp-mini-tab-content').hide(); wrap.find('.content-' + method).fadeIn();
        var inp = wrap.closest('.rp-conditional-block').find('.rp-sms-method-input');
        if (!inp.length) inp = $('#rp_sms_method_input');
        inp.val(method);
    });

    // فعال‌سازی Color Picker
    if ($.fn.wpColorPicker) $('.rp-color-field').wpColorPicker();

    /* =======================================================
       11. تست اتصال پیامک (SMS Connection Test)
    ======================================================= */
    $('#btn-check-sms-connection').click(function (e) {
        e.preventDefault();
        var $btn = $(this);
        var $display = $('#rp-sms-balance-display');
        var $icon = $btn.find('.dashicons');

        // حالت لودینگ
        $btn.prop('disabled', true).css('opacity', '0.7');
        $icon.addClass('spin'); // کلاس spin باید در CSS باشد یا از انیمیشن پیشفرض استفاده کنیم
        $display.html('<span style="color:#0277bd;">درحال برقراری ارتباط با سرور پیامک...</span>');

        $.post(LocalData.ajax_url, {
            action: 'reyhan_check_sms_credit',
            security: LocalData.nonce // مطمئن شوید نانس در LocalData موجود است
        }, function (res) {
            $btn.prop('disabled', false).css('opacity', '1');
            $icon.removeClass('spin');

            if (res.success) {
                // نمایش موفقیت با استایل زیبا
                $display.html(`
                    <div style="display:flex; align-items:center; gap:8px; margin-top:5px;">
                        <span class="dashicons dashicons-yes-alt" style="color:#4CAF50; font-size:24px;"></span>
                        <div>
                            <strong style="color:#333; display:block;">اتصال برقرار است</strong>
                            <span style="color:#4CAF50; font-size:14px;">${res.data.msg}</span>
                        </div>
                    </div>
                `);
                // تغییر رنگ باکس به سبز ملایم
                $('.rp-sms-status-widget').css({ 'background': '#e8f5e9', 'border-color': '#a5d6a7' });
            } else {
                // نمایش خطا
                $display.html(`
                    <div style="display:flex; align-items:center; gap:8px; margin-top:5px;">
                        <span class="dashicons dashicons-warning" style="color:#f44336; font-size:24px;"></span>
                        <div>
                            <strong style="color:#c62828; display:block;">خطا در اتصال</strong>
                            <span style="color:#d32f2f;">${res.data}</span>
                        </div>
                    </div>
                `);
                // تغییر رنگ باکس به قرمز ملایم
                $('.rp-sms-status-widget').css({ 'background': '#ffebee', 'border-color': '#ffcdd2' });
            }
        }).fail(function () {
            $btn.prop('disabled', false);
            $icon.removeClass('spin');
            $display.html('<span style="color:red;">خطای ارتباط با سرور سایت.</span>');
        });
    });

});