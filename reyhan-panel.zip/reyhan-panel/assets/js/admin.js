jQuery(document).ready(function ($) {
    "use strict";

    /* =======================================================
       1. مدیریت تب‌ها
    ======================================================= */

    function safeStorage(key, value = null) {
        try {
            if (value !== null) {
                localStorage.setItem(key, value);
            } else {
                return localStorage.getItem(key);
            }
        } catch (e) {
            return null;
        }
    }

    function getPageContext() {
        if ($('#tab-login').length > 0) return 'general';
        if ($('#tab-style-login').length > 0) return 'style';
        return 'other';
    }

    function switchTab(targetId) {
        var $target = $('#' + targetId);
        if ($target.length === 0) return false;

        $('.rp-tab-pane').hide();
        $('.rp-tab-pane').removeClass('active');
        $target.fadeIn(200);
        $target.addClass('active');

        $('.rp-tabs-nav li').removeClass('active');
        $('.rp-tabs-nav li[data-tab="' + targetId + '"]').addClass('active');
        safeStorage('reyhan_active_tab_' + getPageContext(), targetId);

        return true;
    }

    $(document).on('click', '.rp-tabs-nav li', function (e) {
        e.preventDefault();
        var target = $(this).data('tab');
        if (target) switchTab(target);
    });

    if ($('.rp-tabs-nav').length > 0) {
        var context = getPageContext();
        var savedTab = safeStorage('reyhan_active_tab_' + context);
        var isLoaded = false;
        if (savedTab) isLoaded = switchTab(savedTab);
        if (!isLoaded) {
            var firstTabId = $('.rp-tabs-nav li:first-child').data('tab');
            if (firstTabId) switchTab(firstTabId);
        }
    }

    $('#rp-back-to-menu').click(function (e) {
        e.preventDefault();
        if ($('#tab-login').length > 0) switchTab('tab-login');
    });


    /* =======================================================
       2. مدیریت تب‌های پیامک و تاگل‌ها (نسخه اصلاح شده)
    ======================================================= */
    $(document).on('click', '.rp-mini-tabs-nav li', function () {
        var $this = $(this);
        var method = $this.data('method');
        var $wrapper = $this.closest('.rp-mini-tabs-wrapper');

        // 1. تغییر کلاس اکتیو تب‌ها
        $wrapper.find('.rp-mini-tabs-nav li').removeClass('active');
        $this.addClass('active');

        // 2. مخفی کردن همه محتواها و نمایش محتوای انتخاب شده در همین باکس
        $wrapper.find('.rp-mini-tab-content').hide();

        // هندل کردن نمایش محتوا (هم برای ساختار قدیم با ID و هم ساختار جدید با Class)
        var contentDiv = $wrapper.find('.content-' + method);
        if (contentDiv.length > 0) {
            contentDiv.fadeIn(200);
        } else {
            // فال‌بک برای ساختار قدیمی
            $wrapper.find('#content-' + method).fadeIn(200);
        }

        // 3. آپدیت کردن اینپوت مخفی
        var hiddenInput = $wrapper.parent().find('.rp-sms-method-input');
        if (hiddenInput.length > 0) {
            hiddenInput.val(method);
        } else {
            $('#rp_sms_method_input').val(method);
        }
    });

    $(document).on('change', '.rp-section-toggle', function () {
        var targetId = $(this).data('target');
        if ($(this).is(':checked')) { $('#' + targetId).fadeIn(); }
        else { $('#' + targetId).hide(); }
    });
    $('.rp-section-toggle').each(function () { $(this).trigger('change'); });


    /* =======================================================
       3. ابزارهای UI و آپلودر (نسخه مدرن)
    ======================================================= */

    // انتخابگر رنگ (اگر وجود داشته باشد)
    if ($.fn.wpColorPicker) {
        $('.rp-color-picker').wpColorPicker({
            clear: function () { $(this).val('').trigger('change'); }
        });
    }

    var toast = $('#reyhan-toast-msg');
    if (toast.length > 0) {
        // کمی مکث برای لود کامل صفحه، سپس نمایش
        setTimeout(function () {
            toast.addClass('show');
        }, 100);

        // مخفی کردن بعد از 4 ثانیه
        setTimeout(function () {
            toast.removeClass('show'); // حذف کلاس برای انیمیشن خروج
            setTimeout(function () {
                toast.remove(); // حذف کامل از DOM
            }, 500);
        }, 4000);
    }

    // --- هندلر جدید برای دکمه آپلود مدرن + کلیک روی خود عکس ---
    $(document).on('click', '.rp-upload-btn-modern, .rp-preview-circle', function (e) {
        e.preventDefault();
        var clickedEl = $(this);
        var wrap = clickedEl.closest('.rp-media-upload-modern-wrap'); // پیدا کردن والد مشترک
        var input = wrap.find('.rp-media-input');
        var preview = wrap.find('.rp-preview-img');
        var removeBtn = wrap.find('.rp-remove-btn-modern');

        // باز کردن مدیا آپلودر وردپرس
        var custom_uploader = wp.media({
            title: 'انتخاب تصویر پروفایل',
            button: { text: 'استفاده از این تصویر' },
            library: { type: 'image' },
            multiple: false
        });

        custom_uploader.on('select', function () {
            var attachment = custom_uploader.state().get('selection').first().toJSON();
            // ذخیره آدرس در اینپوت مخفی
            input.val(attachment.url).trigger('change');
            // نمایش تصویر جدید
            preview.attr('src', attachment.url);
            // نمایش دکمه حذف و تغییر استایل بردر
            removeBtn.fadeIn();
            wrap.addClass('has-image');
        });

        custom_uploader.open();
    });

    // --- هندلر جدید برای دکمه حذف مدرن ---
    $(document).on('click', '.rp-remove-btn-modern', function (e) {
        e.preventDefault();
        var btn = $(this);
        var wrap = btn.closest('.rp-media-upload-modern-wrap');
        var input = wrap.find('.rp-media-input');
        var preview = wrap.find('.rp-preview-img');

        // دریافت تصویر پیش‌فرض از اتریبیوت دیتا
        var defaultImg = preview.data('default');

        // خالی کردن مقدار اینپوت
        input.val('').trigger('change');
        // بازنشانی تصویر به پیش‌فرض
        preview.attr('src', defaultImg);
        // مخفی کردن دکمه حذف
        btn.fadeOut();
        wrap.removeClass('has-image');
    });


    /* =======================================================
       4. منوساز
    ======================================================= */
    const dashiconsList = [
        'dashicons-dashboard', 'dashicons-admin-home', 'dashicons-admin-users', 'dashicons-email-alt', 'dashicons-cart',
        'dashicons-products', 'dashicons-star-filled', 'dashicons-heart', 'dashicons-yes', 'dashicons-warning',
        'dashicons-info', 'dashicons-bell', 'dashicons-calendar', 'dashicons-clock', 'dashicons-lock', 'dashicons-shield',
        'dashicons-category', 'dashicons-tag', 'dashicons-location', 'dashicons-images-alt', 'dashicons-video-alt2',
        'dashicons-format-aside', 'dashicons-welcome-write-blog', 'dashicons-megaphone', 'dashicons-phone',
        'dashicons-tickets-alt', 'dashicons-admin-settings', 'dashicons-admin-appearance', 'dashicons-admin-plugins',
        'dashicons-admin-tools', 'dashicons-smartphone', 'dashicons-tablet', 'dashicons-desktop', 'dashicons-sos',
        'dashicons-search', 'dashicons-slides', 'dashicons-analytics', 'dashicons-chart-pie', 'dashicons-chart-bar',
        'dashicons-chart-line', 'dashicons-chart-area', 'dashicons-groups', 'dashicons-businessman', 'dashicons-id',
        'dashicons-id-alt', 'dashicons-awards', 'dashicons-forms', 'dashicons-portfolio', 'dashicons-book',
        'dashicons-book-alt', 'dashicons-download', 'dashicons-upload', 'dashicons-backup', 'dashicons-cloud',
        'dashicons-external', 'dashicons-arrow-left-alt', 'dashicons-arrow-right-alt', 'dashicons-menu'
    ];

    function initIconPickers() {
        $('.rp-icon-dropdown').each(function () {
            var box = $(this);
            if (box.children().length === 0) {
                var html = '';
                dashiconsList.forEach(function (icon) {
                    html += '<span class="dashicons ' + icon + ' rp-icon-option" data-icon="' + icon + '" style="cursor:pointer; padding:8px; font-size:20px; margin:1px;" title="' + icon + '"></span>';
                });
                box.html(html);
            }
        });
    }

    $(document).on('click', '.rp-icon-select-btn', function (e) {
        e.preventDefault();
        e.stopPropagation();

        var btn = $(this);
        var currentRow = btn.closest('.rp-menu-item-row');
        var currentDropdown = btn.siblings('.rp-icon-dropdown');

        // اگر لیست خالی است پر شود
        if (currentDropdown.children().length === 0) initIconPickers();

        // بستن تمام دراپ‌داون‌های دیگر و حذف کلاس z-index از سایر ردیف‌ها
        $('.rp-icon-dropdown').not(currentDropdown).hide();
        $('.rp-menu-item-row').not(currentRow).removeClass('row-active-z');

        // باز/بسته کردن دراپ‌داون جاری
        if (currentDropdown.is(':visible')) {
            currentDropdown.fadeOut(200);
            currentRow.removeClass('row-active-z'); // حذف اولویت بالا
        } else {
            // اضافه کردن کلاس به ردیف والد برای اینکه بیاید روی همه کارت‌ها
            currentRow.addClass('row-active-z');
            currentDropdown.fadeIn(200).css('display', 'grid');
        }
    });

    $(document).on('click', '.rp-icon-option', function (e) {
        e.stopPropagation();
        var icon = $(this).data('icon');
        var wrap = $(this).closest('.rp-icon-picker-wrap');
        var row = $(this).closest('.rp-menu-item-row');

        wrap.find('.preview-icon').attr('class', 'dashicons ' + icon + ' preview-icon');
        wrap.find('.rp-icon-input').val(icon).trigger('change');

        // بستن منو و حذف کلاس z-index
        wrap.find('.rp-icon-dropdown').fadeOut(200);
        row.removeClass('row-active-z');
    });

    $(document).on('click', function (e) {
        if (!$(e.target).closest('.rp-icon-picker-wrap').length) {
            $('.rp-icon-dropdown').fadeOut(200);
            // حذف کلاس اولویت از همه ردیف‌ها
            $('.rp-menu-item-row').removeClass('row-active-z');
        }
    });

    $(document).on('click', '.rp-item-header', function (e) {
        if ($(e.target).closest('.rp-remove-row, .rp-sort-handle').length) return;

        var row = $(this).closest('.rp-menu-item-row');
        var body = row.find('.rp-item-body');
        var toggleBtn = row.find('.rp-toggle-item');

        if (body.is(':visible')) {
            body.slideUp(200);
            row.removeClass('open').addClass('closed');
            toggleBtn.html('<span class="dashicons dashicons-arrow-down-alt2"></span>');
        } else {
            body.slideDown(200);
            row.addClass('open').removeClass('closed');
            toggleBtn.html('<span class="dashicons dashicons-arrow-up-alt2"></span>');
        }
    });

    $(document).on('input', '.rp-live-title', function () {
        var val = $(this).val();
        $(this).closest('.rp-menu-item-row').find('.rp-item-title').text(val ? val : '(بدون عنوان)');
    });

    $(document).on('change', '.rp-icon-type-radio', function () {
        var box = $(this).closest('.rp-icon-settings-box');
        if ($(this).val() === 'icon') {
            box.find('.rp-icon-picker-area').show();
            box.find('.rp-image-uploader-area').hide();
        } else {
            box.find('.rp-icon-picker-area').hide();
            box.find('.rp-image-uploader-area').show();
        }
    });

    $(document).on('click', '.rp-media-upload-btn', function (e) {
        e.preventDefault();
        var btn = $(this);
        var input = btn.siblings('.rp-image-url');
        var preview = btn.closest('.rp-image-uploader-area').find('.rp-image-preview');

        var menuIconFrame = wp.media({
            title: 'انتخاب آیکون/تصویر',
            library: { type: 'image' },
            multiple: false
        });

        menuIconFrame.on('select', function () {
            var attachment = menuIconFrame.state().get('selection').first().toJSON();
            input.val(attachment.url);
            preview.html('<img src="' + attachment.url + '" style="height:40px; width:auto;">');
        });

        menuIconFrame.open();
    });

    $(document).on('click', '.rp-add-menu-item', function (e) {
        e.preventDefault();
        var list = $('.rp-menu-list');
        var baseId = $('#rp-menu-builder-wrap').data('id');
        var idx = new Date().getTime();
        var html = `
            <div class="rp-repeater-item rp-menu-item-row open" style="display:none;">
                <div class="rp-item-header">
                    <span class="dashicons dashicons-move rp-sort-handle"></span>
                    <span class="rp-item-title">آیتم جدید</span>
                    <div class="rp-header-controls">
                        <span class="rp-item-type-badge">لینک</span>
                        <button type="button" class="rp-toggle-item"><span class="dashicons dashicons-arrow-up-alt2"></span></button>
                        <button type="button" class="rp-remove-row"><span class="dashicons dashicons-trash"></span></button>
                    </div>
                </div>
                <div class="rp-item-body">
                    <div class="rp-row-flex">
                        <div class="rp-col-half">
                            <label>عنوان منو</label>
                            <input type="text" name="reyhan_options[${baseId}][${idx}][label]" class="rp-full-input rp-live-title" placeholder="عنوان...">
                        </div>
                        <div class="rp-col-half">
                            <label>عملکرد</label>
                            <select name="reyhan_options[${baseId}][${idx}][action]" class="rp-full-input rp-menu-action-select">
                                <option value="dashboard">🏠 داشبورد</option>
                                <option value="tickets">📩 تیکت‌ها</option>
                                <option value="orders">🛍️ سفارشات</option>
                                <option value="profile">👤 ویرایش حساب</option>
                                <option value="content">📝 محتوای شورت‌کد</option>
                                <option value="link" selected>🔗 لینک خارجی</option>
                                <option value="logout">🚪 خروج</option>
                            </select>
                        </div>
                    </div>
                    <div class="rp-icon-settings-box">
                        <div class="rp-icon-type-switch">
                            <label><input type="radio" name="reyhan_options[${baseId}][${idx}][icon_type]" value="icon" class="rp-icon-type-radio" checked> آیکون</label>
                            <label><input type="radio" name="reyhan_options[${baseId}][${idx}][icon_type]" value="image" class="rp-icon-type-radio"> تصویر</label>
                        </div>
                        <div class="rp-icon-picker-area">
                            <div class="rp-icon-picker-wrap">
                                <button type="button" class="button rp-icon-select-btn"><span class="dashicons dashicons-marker preview-icon"></span> انتخاب آیکون</button>
                                <input type="hidden" name="reyhan_options[${baseId}][${idx}][icon]" value="dashicons-marker" class="rp-icon-input">
                                <div class="rp-icon-dropdown"></div>
                            </div>
                        </div>
                        <div class="rp-image-uploader-area" style="display:none;">
                            <div style="display:flex; gap:10px;">
                                <input type="text" name="reyhan_options[${baseId}][${idx}][custom_image]" class="regular-text rp-image-url" dir="ltr" placeholder="آدرس تصویر...">
                                <button type="button" class="button rp-media-upload-btn">انتخاب</button>
                            </div>
                            <div class="rp-image-preview" style="margin-top:10px;"></div>
                        </div>
                    </div>
                    <div class="rp-menu-extra-settings">
                        <div class="rp-menu-link-row">
                            <label>لینک:</label>
                            <input type="text" name="reyhan_options[${baseId}][${idx}][link]" class="rp-full-input" dir="ltr">
                        </div>
                        <div class="rp-menu-shortcode-row" style="display:none;">
                            <label>شورت‌کد:</label>
                            <textarea name="reyhan_options[${baseId}][${idx}][shortcode]" class="rp-full-input" rows="3" dir="ltr"></textarea>
                        </div>
                    </div>
                </div>
            </div>`;
        list.append(html);
        list.find('.rp-menu-item-row:last').fadeIn();
        initIconPickers();
    });

    $(document).on('change', '.rp-menu-action-select', function () {
        var row = $(this).closest('.rp-menu-item-row');
        var val = $(this).val();
        var badge = row.find('.rp-item-type-badge');
        row.find('.rp-menu-link-row, .rp-menu-shortcode-row').hide();
        if (val === 'link') {
            row.find('.rp-menu-link-row').slideDown();
            badge.text('لینک');
        } else if (val === 'content') {
            row.find('.rp-menu-shortcode-row').slideDown();
            badge.text('محتوا');
        } else {
            badge.text('سیستمی');
        }
    });

    if ($.fn.sortable) {
        $('.rp-menu-list').sortable({
            handle: '.rp-sort-handle',
            placeholder: "ui-state-highlight",
            cursor: 'move',
            opacity: 0.8,
            update: function () {
                $('#rp-menu-builder-wrap').find('.rp-menu-item-row').each(function (index) {
                    $(this).find('input, select, textarea').each(function () {
                        var name = $(this).attr('name');
                        if (name) {
                            $(this).attr('name', name.replace(/\[\d+\](\[[^\]]+\])$/, '[' + index + ']$1'));
                        }
                    });
                });
            }
        });
    }

    /* =======================================================
       5. سایر بخش‌ها
    ======================================================= */
    $('.rp-add-row').click(function () {
        var wrap = $(this).closest('.rp-repeater-wrap');
        var list = wrap.find('.rp-repeater-list');
        var id = wrap.data('id');
        var fields = $(this).data('fields');
        var count = new Date().getTime();
        var html = '<div class="rp-repeater-item" style="display:none;">';
        $.each(fields, function (key, label) {
            var name = 'reyhan_options[' + id + '][' + count + '][' + key + ']';
            if (key === 'content' || key === 'a') {
                html += '<textarea name="' + name + '" placeholder="' + label + '" rows="2"></textarea>';
            } else {
                html += '<input type="text" name="' + name + '" placeholder="' + label + '">';
            }
        });
        html += '<button type="button" class="button rp-remove-row"><span class="dashicons dashicons-no"></span></button></div>';
        list.append(html);
        list.find('.rp-repeater-item:last').fadeIn();
    });

    $(document).on('click', '.rp-remove-row', function (e) {
        e.preventDefault();
        e.stopPropagation();
        if (confirm('آیا برای حذف مطمئن هستید؟')) {
            $(this).closest('.rp-repeater-item').slideUp(200, function () { $(this).remove(); });
        }
    });

    // جستجوی کاربر
    var searchTimer;
    $('#rp-user-search-input').on('keyup', function () {
        var term = $(this).val();
        var resBox = $('#rp-search-results');
        clearTimeout(searchTimer);
        if (term.length < 2) { resBox.hide(); return; }

        searchTimer = setTimeout(function () {
            resBox.show().html('<div style="padding:10px;">در حال جستجو...</div>');
            // تغییر نام آبجکت
            if (typeof reyhan_admin_ajax === 'undefined') return;
            $.post(reyhan_admin_ajax.ajax_url, {
                action: 'reyhan_search_users', // Renamed
                security: reyhan_admin_ajax.nonce,
                term: term
            }, function (res) {
                if (res.success && res.data.length > 0) {
                    var html = '<ul>';
                    $.each(res.data, function (i, u) {
                        html += '<li data-id="' + u.id + '" data-text="' + u.text + '">' + u.text + '</li>';
                    });
                    html += '</ul>';
                    resBox.html(html);
                } else {
                    resBox.html('<div style="padding:10px;">کاربری یافت نشد</div>');
                }
            });
        }, 500);
    });

    $(document).on('click', '.rp-remove-agent', function () {
        $(this).parent().remove();
    });

    // ابزارها
    // ابزارها
    $('.rp-run-tool').click(function () {
        var btn = $(this);
        var action = btn.data('action');
        var originalText = btn.text();

        if (['factory_reset', 'nuke_tickets', 'nuke_users'].includes(action) && !confirm('این عملیات غیرقابل بازگشت است. آیا مطمئن هستید؟')) return;
        if (typeof reyhan_admin_ajax === 'undefined') return;

        var data = { action: 'reyhan_tool_action', security: reyhan_admin_ajax.nonce, tool_action: action };

        // دریافت دقیق مقادیر برای تست
        if (action === 'test_sms') {
            var mob = $('#test_mobile_input').val();
            if (!mob) { alert('لطفاً شماره موبایل را وارد کنید.'); return; }
            data.mobile = mob;
        }
        if (action === 'test_email') {
            var eml = $('#test_email_input').val();
            if (!eml) { alert('لطفاً ایمیل را وارد کنید.'); return; }
            data.email = eml;
        }

        btn.prop('disabled', true).text('در حال پردازش...');

        $.post(reyhan_admin_ajax.ajax_url, data, function (res) {
            btn.prop('disabled', false).text(originalText);

            if (res.success) {
                alert(res.data);
                if (action === 'factory_reset') location.reload();
                if (action === 'test_sms' || action === 'test_email') {
                    $('#rp-test-result').html('<strong style="color:green">' + res.data + '</strong>');
                }
            } else {
                alert('خطا: ' + res.data);
                $('#rp-test-result').html('<strong style="color:red">خطا: ' + res.data + '</strong>');
            }
        }).fail(function () {
            btn.prop('disabled', false).text(originalText);
            alert('خطا در ارتباط با سرور (500 Internal Server Error). لطفاً تنظیمات پیامک را بررسی کنید.');
        });
    });

    /* --- تیکت‌ها --- */
    var managerApp = $('#reyhan-manager-app'); // ID updated
    var loadAdminTickets = function (status = null) {
        if (!status) status = $('.filter-pill.active').data('status') || 'active';
        var selectedId = $('.ticket-list-item.selected').data('id');
        if (typeof reyhan_admin_ajax === 'undefined') return;
        $.post(reyhan_admin_ajax.ajax_url, {
            action: 'reyhan_admin_load_tickets', // Renamed
            security: reyhan_admin_ajax.nonce,
            status: status
        }, function (res) {
            if (res.success) {
                $('#ticket-list-container').html(res.data);
                if (selectedId) {
                    var item = $('.ticket-list-item[data-id="' + selectedId + '"]');
                    if (item.length) item.addClass('selected');
                }
            }
        });
    };

    if (managerApp.length) {
        var chatBox = $('#conversation-content');
        var infoBar = $('#ticket-info-bar');
        var currentTicketId = null;

        $('.filter-pill').click(function (e) {
            e.preventDefault();
            $('.filter-pill').removeClass('active');
            $(this).addClass('active');
            loadAdminTickets($(this).data('status'));
        });

        $(document).on('click', '.ticket-list-item', function () {
            $('.ticket-list-item').removeClass('selected');
            $(this).addClass('selected');
            currentTicketId = $(this).data('id');
            var currentStatus = $(this).data('status');

            if (currentStatus === 'closed') $('.rp-reply-area').slideUp();
            else $('.rp-reply-area').slideDown();

            chatBox.html('<div class="rp-loading-state"><span class="spinner is-active" style="float:none;"></span> در حال بارگذاری...</div>');
            infoBar.hide().empty();
            $('#delete-ticket-btn').show().data('id', currentTicketId);

            $.post(reyhan_admin_ajax.ajax_url, {
                action: 'reyhan_admin_load_conv', // Renamed
                security: reyhan_admin_ajax.nonce,
                ticket_id: currentTicketId
            }, function (res) {
                if (res.success) {
                    infoBar.html(res.data.info).fadeIn();
                    chatBox.html(res.data.chat);
                    setTimeout(function () { chatBox.scrollTop(chatBox[0].scrollHeight); }, 100);
                }
            });
        });

        $('#send-reply-btn').click(function () {
            if (!currentTicketId) { alert('لطفاً ابتدا یک تیکت را انتخاب کنید.'); return; }
            var msg = $('#reply-text').val();
            var fileInput = $('#reply-file')[0].files[0];
            var isCloseChecked = $('#close-ticket-check').is(':checked');
            var st = isCloseChecked ? 'closed' : 'answered';

            if (!msg && !fileInput) { alert('متن پاسخ یا فایل الزامی است.'); return; }
            if (isCloseChecked && !confirm('آیا مطمئن هستید که تیکت را می‌بندید؟')) return;

            var btn = $(this);
            btn.prop('disabled', true).text('در حال ارسال...');

            var fd = new FormData();
            fd.append('action', 'reyhan_admin_reply'); // Renamed
            fd.append('security', reyhan_admin_ajax.nonce);
            fd.append('ticket_id', currentTicketId);
            fd.append('message', msg);
            fd.append('status', st);
            if (fileInput) fd.append('reply_file', fileInput);

            $.ajax({
                url: reyhan_admin_ajax.ajax_url,
                type: 'POST', data: fd, contentType: false, processData: false,
                success: function (res) {
                    btn.prop('disabled', false).html('ارسال پاسخ <span class="dashicons dashicons-arrow-left-alt"></span>');
                    if (res.success) {
                        if (st === 'closed') {
                            $('.rp-reply-area').slideUp();
                            $('.ticket-list-item[data-id="' + currentTicketId + '"]').fadeOut();
                            $('#conversation-content').html('<div class="rp-empty-state"><p>تیکت بسته شد.</p></div>');
                            $('#ticket-info-bar').hide();
                        } else {
                            var currentItem = $('.ticket-list-item[data-id="' + currentTicketId + '"]');
                            currentItem.addClass('is-answered');
                            currentItem.click();
                        }
                        $('#reply-text').val('');
                        $('#reply-file').val('');
                        $('#file-name-display').text('');
                        $('#close-ticket-check').prop('checked', false);
                    } else { alert(res.data); }
                }
            });
        });

        $('#reply-file').change(function () { $('#file-name-display').text(this.files[0] ? this.files[0].name : ''); });
        $('#delete-ticket-btn').click(function () {
            if (!currentTicketId) return;
            if (!confirm('حذف تیکت غیرقابل بازگشت است. ادامه می‌دهید؟')) return;
            $.post(reyhan_admin_ajax.ajax_url, {
                action: 'reyhan_tool_action',
                security: reyhan_admin_ajax.nonce,
                tool_action: 'nuke_tickets_single',
                id: currentTicketId
            }, function (res) {
                $('.ticket-list-item[data-id="' + currentTicketId + '"]').fadeOut();
                chatBox.empty(); infoBar.empty();
            });
        });
        loadAdminTickets('open');
        setInterval(function () { loadAdminTickets(); }, 15000);

        $('#canned-search-input').on('keyup focus', function () {
            var term = $(this).val().toLowerCase();
            var resultsBox = $('#canned-results');
            if (resultsBox.length === 0) { $(this).parent().append('<div id="canned-results"></div>'); resultsBox = $('#canned-results'); }
            if (term.length < 1) { resultsBox.hide(); return; }
            if (typeof reyhan_admin_ajax !== 'undefined' && reyhan_admin_ajax.canned_responses) {
                var data = reyhan_admin_ajax.canned_responses;
                if (typeof data === 'object' && !Array.isArray(data)) data = Object.values(data);
                var hits = data.filter(function (item) { return (item.title || '').toLowerCase().indexOf(term) > -1 || (item.content || '').toLowerCase().indexOf(term) > -1; });
                if (hits.length > 0) {
                    var html = '';
                    hits.forEach(function (r) {
                        var safeContent = (r.content || '').replace(/"/g, '&quot;');
                        html += '<div class="rp-canned-item" data-content="' + safeContent + '"><strong>' + (r.title || 'بدون عنوان') + '</strong><br><small>' + (r.content || '').substring(0, 60) + '...</small></div>';
                    });
                    resultsBox.html(html).show();
                } else { resultsBox.html('<div style="padding:10px; color:#999; font-size:11px;">موردی یافت نشد.</div>').show(); }
            }
        });
        $(document).on('click', '.rp-canned-item', function () {
            var content = $(this).data('content');
            var textarea = $('#reply-text');
            textarea.val(textarea.val() + (textarea.val() ? '\n' : '') + content);
            $('#canned-results').hide();
            $('#canned-search-input').val('');
        });
        $(document).on('click', function (e) { if (!$(e.target).closest('.canned-search-wrap').length) $('#canned-results').hide(); });
    }

    /* =======================================================
       سیستم اطلاعیه (نسخه نهایی - همیشه فعال)
    ======================================================= */
    var notifData = [];
    var editIndex = -1;
    var $notifJson = $('#rp_notif_data_json');
    var $saveBar = $('.rp-sticky-save-bar');

    if ($('#rp-notif-grid').length > 0) {
        initModernNotif();
    }

    function initModernNotif() {
        if (typeof rp_server_data !== 'undefined' && rp_server_data) {
            notifData = Array.isArray(rp_server_data) ? rp_server_data : Object.values(rp_server_data);
        }
        renderGrid();
    }

    function renderGrid() {
        var html = '';
        var container = $('#rp-notif-grid');
        var emptyState = $('#rp-empty-state');

        if (notifData.length === 0) {
            container.hide();
            emptyState.fadeIn();
        } else {
            emptyState.hide();
            container.css('display', 'grid');

            $.each(notifData, function (i, item) {
                var title = item.title || '(بدون عنوان)';
                var typeClass = 'rp-card-' + (item.type || 'info');
                var msg = (item.msg || '').substring(0, 80) + '...';

                html += `
                <div class="rp-notif-card ${typeClass}">
                    <div class="rp-card-header">
                        <span class="rp-card-title">${title}</span>
                    </div>
                    <div class="rp-card-msg">${msg}</div>
                    <div class="rp-card-actions">
                        <button type="button" class="rp-btn-sm edit" data-index="${i}">ویرایش</button>
                        <button type="button" class="rp-btn-sm delete" data-index="${i}">حذف</button>
                    </div>
                </div>`;
            });
            container.html(html);
        }

        $notifJson.val(JSON.stringify(notifData));
    }

    $('#rp-btn-add-new').click(function (e) {
        e.preventDefault();
        editIndex = -1;
        resetForm();
        $('#rp-editor-title').text('افزودن اطلاعیه جدید');
        $('#rp-editor-wrapper').slideDown();
        $('html, body').animate({ scrollTop: $("#rp-editor-wrapper").offset().top - 100 }, 300);
    });

    $('#rp-btn-cancel').click(function () {
        $('#rp-editor-wrapper').slideUp();
    });

    $(document).on('click', '.rp-action-btn.edit, .rp-btn-sm.edit', function (e) {
        e.preventDefault();
        editIndex = $(this).data('index');
        var item = notifData[editIndex];

        $('#edit-title').val(item.title);
        $('#edit-type').val(item.type);
        $('#edit-msg').val(item.msg);

        $('#rp-editor-title').text('ویرایش اطلاعیه');
        $('#rp-editor-wrapper').slideDown();
        $('html, body').animate({ scrollTop: $("#rp-editor-wrapper").offset().top - 100 }, 300);
    });

    $(document).on('click', '.rp-action-btn.delete, .rp-btn-sm.delete', function (e) {
        e.preventDefault();
        if (confirm('آیا مطمئن هستید؟')) {
            var idx = $(this).data('index');
            notifData.splice(idx, 1);
            renderGrid();
            showSaveBar();
        }
    });

    $('#rp-btn-save-item').click(function (e) {
        e.preventDefault();

        var newItem = {
            title: $('#edit-title').val(),
            type: $('#edit-type').val(),
            msg: $('#edit-msg').val(),
            active: '1' // همیشه فعال
        };

        if (editIndex === -1) {
            notifData.unshift(newItem);
        } else {
            notifData[editIndex] = newItem;
        }

        renderGrid();
        $('#rp-editor-wrapper').slideUp();
        showSaveBar();
    });

    function resetForm() {
        $('#edit-title').val('');
        $('#edit-msg').val('');
        $('#edit-type').val('info');
    }

    function showSaveBar() {
        $saveBar.addClass('visible');
    }

    /* =======================================================
       6. مدیریت مدرن کارشناسان (اضافه شده)
    ======================================================= */
    var agentsData = [];
    var $agentsJson = $('#rp_agents_data_json');
    var currentEditingAgent = null; // برای ویرایش

    if ($agentsJson.length > 0) {
        try {
            agentsData = JSON.parse($agentsJson.val());
            if (!Array.isArray(agentsData)) agentsData = [];
        } catch (e) { agentsData = []; }
        renderAgentsGrid();
    }

    function renderAgentsGrid() {
        var html = '';
        if (agentsData.length === 0) {
            html = '<div style="grid-column:1/-1; text-align:center; padding:30px; color:#999; background:#fafafa; border-radius:10px; border:2px dashed #eee;">هیچ کارشناسی تعریف نشده است.</div>';
        } else {
            $.each(agentsData, function (i, agent) {
                var deptText = '';
                var cardClass = 'limited';

                if (agent.all_depts) {
                    deptText = '<span style="color:#2E7D32; font-weight:bold;">همه دپارتمان‌ها</span>';
                    cardClass = 'full-access';
                } else if (agent.depts && agent.depts.length > 0) {
                    deptText = agent.depts.join('، ');
                } else {
                    deptText = '<span style="color:#d32f2f;">بدون دسترسی</span>';
                }

                html += `
                <div class="rp-agent-card ${cardClass}">
                    <div class="rp-agent-avatar">
                        <img src="${agent.avatar || '../wp-content/plugins/reyhan-panel/assets/images/user.png'}">
                    </div>
                    <div class="rp-agent-info" style="flex-grow:1;">
                        <h4>${agent.name}</h4>
                        <span class="rp-agent-depts">${deptText}</span>
                    </div>
                    <div class="rp-agent-actions">
                        <button type="button" class="rp-btn-icon edit-agent" data-index="${i}" title="ویرایش دسترسی"><span class="dashicons dashicons-edit"></span></button>
                        <button type="button" class="rp-btn-icon remove-agent" data-index="${i}" title="حذف"><span class="dashicons dashicons-trash"></span></button>
                    </div>
                </div>`;
            });
        }
        $('#rp-agents-grid').html(html);
        $agentsJson.val(JSON.stringify(agentsData));

        // همگام سازی با فیلد قدیمی جهت سازگاری (لیست ID ها)
        // این کار باعث می‌شود اگر کد دیگری از ID ها استفاده می‌کند، خراب نشود
        var ids = agentsData.map(function (a) { return a.id; });
        // (این بخش اختیاری است چون ما منطق فیلترینگ را هم تغییر می‌دهیم)
    }

    // جستجوی کاربر برای کارشناس
    var agentSearchTimer;
    $('#rp-user-search-input').on('keyup', function () {
        var term = $(this).val();
        var resBox = $('#rp-search-results');
        clearTimeout(agentSearchTimer);
        if (term.length < 2) { resBox.hide(); return; }

        agentSearchTimer = setTimeout(function () {
            resBox.show().html('<div style="padding:15px; color:#777;">در حال جستجو...</div>');
            $.post(reyhan_admin_ajax.ajax_url, {
                action: 'reyhan_search_users',
                security: reyhan_admin_ajax.nonce,
                term: term
            }, function (res) {
                if (res.success && res.data.length > 0) {
                    var html = '<ul>';
                    $.each(res.data, function (i, u) {
                        // جلوگیری از افزودن تکراری
                        if (agentsData.find(a => a.id == u.id)) return;

                        html += `<li data-id="${u.id}" data-text="${u.text}" data-avatar="${u.avatar || ''}">
                            <div style="display:flex; align-items:center; gap:10px;">
                                <strong>${u.text}</strong>
                            </div>
                            <span class="dashicons dashicons-plus" style="color:#4CAF50;"></span>
                        </li>`;
                    });
                    html += '</ul>';
                    if (html === '<ul></ul>') resBox.html('<div style="padding:15px; color:#e65100;">این کاربر قبلاً اضافه شده است.</div>');
                    else resBox.html(html);
                } else {
                    resBox.html('<div style="padding:15px; color:#999;">کاربری یافت نشد.</div>');
                }
            });
        }, 500);
    });

    // کلیک روی نتیجه جستجو -> باز شدن مودال
    $(document).on('click', '#rp-search-results li', function () {
        var uid = $(this).data('id');
        var name = $(this).data('text');
        // دریافت آواتار از دیتا
        var rawAvatar = $(this).data('avatar');

        // منطق: اگر آدرس عکس وجود داشت استفاده کن، وگرنه از پیش‌فرض متغیر PHP استفاده کن
        var finalAvatar = (rawAvatar && rawAvatar !== '') ? rawAvatar : rp_default_avatar;

        currentEditingAgent = {
            id: uid,
            name: name,
            avatar: finalAvatar, // ذخیره آواتار صحیح
            all_depts: false,
            depts: [],
            is_new: true
        };

        // ست کردن عکس در تگ img مودال
        $('#modal-agent-avatar').attr('src', finalAvatar);

        openDeptModal();
        $('#rp-search-results').hide();
        $('#rp-user-search-input').val('');
    });

    // همچنین تابع دکمه ویرایش (edit-agent) را هم اصلاح کنید تا عکس در ویرایش هم بیاید:
    $(document).on('click', '.edit-agent', function () {
        var idx = $(this).data('index');
        currentEditingAgent = JSON.parse(JSON.stringify(agentsData[idx]));
        currentEditingAgent.index = idx;
        currentEditingAgent.is_new = false;

        // ست کردن عکس هنگام ویرایش
        var agentImg = currentEditingAgent.avatar || rp_default_avatar;
        $('#modal-agent-avatar').attr('src', agentImg);

        openDeptModal();
    });

    // دکمه ویرایش کارشناس
    $(document).on('click', '.edit-agent', function () {
        var idx = $(this).data('index');
        currentEditingAgent = JSON.parse(JSON.stringify(agentsData[idx])); // Deep copy
        currentEditingAgent.index = idx; // ذخیره ایندکس برای آپدیت
        currentEditingAgent.is_new = false;
        openDeptModal();
    });

    // دکمه حذف کارشناس
    $(document).on('click', '.remove-agent', function () {
        if (confirm('آیا از حذف این کارشناس اطمینان دارید؟')) {
            var idx = $(this).data('index');
            agentsData.splice(idx, 1);
            renderAgentsGrid();
        }
    });

    function openDeptModal() {
        $('#modal-agent-name').text(currentEditingAgent.name);

        // ساخت لیست دپارتمان‌ها
        var html = '';
        if (typeof rp_departments_list !== 'undefined' && rp_departments_list.length > 0) {
            rp_departments_list.forEach(function (dept) {
                var checked = (currentEditingAgent.depts && currentEditingAgent.depts.includes(dept)) ? 'checked' : '';
                html += `<label><input type="checkbox" class="dept-check" value="${dept}" ${checked}> ${dept}</label>`;
            });
        } else {
            html = '<p style="color:#e65100; font-size:12px;">هیچ دپارتمانی تعریف نشده است. (کارشناس بدون دپارتمان ذخیره می‌شود)</p>';
        }
        $('#dept-list-container').html(html);

        // وضعیت چک باکس "همه"
        $('#dept-all').prop('checked', currentEditingAgent.all_depts);
        toggleDeptChecks();

        $('#rp-dept-modal').fadeIn(200).css('display', 'flex');
    }

    // منطق چک باکس همه
    $('#dept-all').change(function () { toggleDeptChecks(); });
    function toggleDeptChecks() {
        var isAll = $('#dept-all').is(':checked');
        $('.dept-check').prop('disabled', isAll);
        if (isAll) $('.dept-check').prop('checked', true);
    }

    $('.close-modal').click(function () { $('#rp-dept-modal').fadeOut(200); });

    // ذخیره نهایی از مودال
    $('#btn-save-agent').click(function () {
        // جمع آوری داده‌ها
        currentEditingAgent.all_depts = $('#dept-all').is(':checked');
        currentEditingAgent.depts = [];

        if (!currentEditingAgent.all_depts) {
            $('.dept-check:checked').each(function () {
                currentEditingAgent.depts.push($(this).val());
            });
        }

        if (currentEditingAgent.is_new) {
            agentsData.push(currentEditingAgent);
        } else {
            agentsData[currentEditingAgent.index] = currentEditingAgent;
        }

        renderAgentsGrid();
        $('#rp-dept-modal').fadeOut(200);
    });

});