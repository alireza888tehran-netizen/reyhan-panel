jQuery(document).ready(function ($) {

    // --- متغیرهای سراسری ---
    var menuData = [];
    var fixedDefinitions = [
        { action: 'dashboard', defaultLabel: 'داشبورد', defaultIcon: 'dashicons-dashboard' },
        { action: 'profile', defaultLabel: 'ویرایش اطلاعات', defaultIcon: 'dashicons-admin-users' },
        { action: 'orders', defaultLabel: 'سفارشات', defaultIcon: 'dashicons-cart', requiresWoo: true },
        { action: 'tickets', defaultLabel: 'پشتیبانی', defaultIcon: 'dashicons-businesswoman' },
        // لاگ اوت را خودکار هندل میکنیم یا میتوانید اینجا اضافه کنید. فعلا 4 مورد خواسته شده.
    ];

    // لیست آیکون‌های دش آیکون (نمونه - لیست کامل طولانی است)
    var dashicons = [
        "dashicons-menu", "dashicons-dashboard", "dashicons-admin-site", "dashicons-admin-media",
        "dashicons-admin-page", "dashicons-admin-comments", "dashicons-admin-appearance", "dashicons-admin-plugins",
        "dashicons-admin-users", "dashicons-admin-tools", "dashicons-admin-settings", "dashicons-admin-network",
        "dashicons-admin-home", "dashicons-admin-generic", "dashicons-welcome-write-blog", "dashicons-welcome-add-page",
        "dashicons-welcome-view-site", "dashicons-welcome-widgets-menus", "dashicons-welcome-comments", "dashicons-welcome-learn-more",
        "dashicons-format-aside", "dashicons-format-image", "dashicons-format-gallery", "dashicons-format-video",
        "dashicons-format-status", "dashicons-format-quote", "dashicons-format-chat", "dashicons-format-audio",
        "dashicons-camera", "dashicons-images-alt", "dashicons-images-alt2", "dashicons-video-alt",
        "dashicons-video-alt2", "dashicons-video-alt3", "dashicons-media-archive", "dashicons-media-audio",
        "dashicons-media-code", "dashicons-media-default", "dashicons-media-document", "dashicons-media-interactive",
        "dashicons-media-spreadsheet", "dashicons-media-text", "dashicons-media-video", "dashicons-playlist-audio",
        "dashicons-playlist-video", "dashicons-controls-play", "dashicons-controls-pause", "dashicons-controls-forward",
        "dashicons-controls-skipforward", "dashicons-controls-back", "dashicons-controls-skipback", "dashicons-controls-repeat",
        "dashicons-controls-volumeon", "dashicons-controls-volumeoff", "dashicons-sme", "dashicons-calendar",
        "dashicons-calendar-alt", "dashicons-visibility", "dashicons-hidden", "dashicons-location",
        "dashicons-location-alt", "dashicons-trash", "dashicons-sticky", "dashicons-share",
        "dashicons-share-alt", "dashicons-share-alt2", "dashicons-twitter", "dashicons-rss",
        "dashicons-email", "dashicons-email-alt", "dashicons-facebook", "dashicons-facebook-alt",
        "dashicons-googleplus", "dashicons-networking", "dashicons-hammer", "dashicons-art",
        "dashicons-migrate", "dashicons-performance", "dashicons-universal-access", "dashicons-universal-access-alt",
        "dashicons-ticket", "dashicons-nametag", "dashicons-clipboard", "dashicons-heart",
        "dashicons-megaphone", "dashicons-schedule", "dashicons-wordpress", "dashicons-wordpress-alt",
        "dashicons-pressthis", "dashicons-update", "dashicons-screenoptions", "dashicons-info",
        "dashicons-cart", "dashicons-feedback", "dashicons-cloud", "dashicons-translation",
        "dashicons-tag", "dashicons-category", "dashicons-archive", "dashicons-tagcloud",
        "dashicons-text", "dashicons-media-default", "dashicons-button", "dashicons-saved",
        "dashicons-yes", "dashicons-no", "dashicons-no-alt", "dashicons-plus", "dashicons-plus-alt",
        "dashicons-minus", "dashicons-dismiss", "dashicons-marker", "dashicons-star-filled",
        "dashicons-star-half", "dashicons-star-empty", "dashicons-flag", "dashicons-warning",
        "dashicons-share", "dashicons-share-alt", "dashicons-share-alt2", "dashicons-twitter",
        "dashicons-rss", "dashicons-email", "dashicons-email-alt", "dashicons-facebook",
        "dashicons-facebook-alt", "dashicons-networking", "dashicons-googleplus", "dashicons-location",
        "dashicons-location-alt", "dashicons-camera", "dashicons-images-alt", "dashicons-images-alt2",
        "dashicons-video-alt", "dashicons-video-alt2", "dashicons-video-alt3", "dashicons-media-archive",
        "dashicons-media-audio", "dashicons-media-code", "dashicons-media-default", "dashicons-media-document",
        "dashicons-media-interactive", "dashicons-media-spreadsheet", "dashicons-media-text", "dashicons-media-video",
        "dashicons-playlist-audio", "dashicons-playlist-video", "dashicons-controls-play", "dashicons-controls-pause",
        "dashicons-controls-forward", "dashicons-controls-skipforward", "dashicons-controls-back", "dashicons-controls-skipback",
        "dashicons-controls-repeat", "dashicons-controls-volumeon", "dashicons-controls-volumeoff", "dashicons-sme",
        "dashicons-id", "dashicons-id-alt", "dashicons-products", "dashicons-awards", "dashicons-forms", "dashicons-testimonial",
        "dashicons-portfolio", "dashicons-book", "dashicons-book-alt", "dashicons-download", "dashicons-upload", "dashicons-backup",
        "dashicons-clock", "dashicons-lightbulb", "dashicons-microphone", "dashicons-desktop", "dashicons-tablet", "dashicons-smartphone",
        "dashicons-phone", "dashicons-index-card", "dashicons-carrot", "dashicons-building", "dashicons-store", "dashicons-album",
        "dashicons-palmtree", "dashicons-tickets-alt", "dashicons-money", "dashicons-smiley", "dashicons-thumbs-up", "dashicons-thumbs-down",
        "dashicons-layout", "dashicons-paperclip", "dashicons-edit", "dashicons-search", "dashicons-slides", "dashicons-analytics", "dashicons-chart-pie",
        "dashicons-chart-bar", "dashicons-chart-line", "dashicons-chart-area", "dashicons-groups", "dashicons-businessman", "dashicons-businesswoman",
        "dashicons-businessperson", "dashicons-shield", "dashicons-shield-alt", "dashicons-sos", "dashicons-search", "dashicons-slides", "dashicons-analytics",
        "dashicons-chart-pie", "dashicons-chart-bar", "dashicons-chart-line", "dashicons-chart-area", "dashicons-groups", "dashicons-businessman",
        "dashicons-businesswoman", "dashicons-businessperson", "dashicons-shield", "dashicons-shield-alt", "dashicons-sos", "dashicons-bell"
    ]; // لیست خلاصه شده برای نمونه. میتوانید لیست کامل را از سایت وردپرس بگیرید

    var $modal = $('#rp-menu-modal');
    var $jsonInput = $('#rp_panel_menu_json');
    var hasWoo = $('#rp-fixed-items-container').data('has-woo') == '1';
    var activeIconInput = null; // برای ذخیره اینکه کدام اینپوت در حال تغییر آیکون است

    // --- 1. باز کردن مودال ---
    $('#rp-open-menu-modal').on('click', function () {
        // خواندن داده‌ها
        try {
            var raw = $jsonInput.val();
            menuData = raw ? JSON.parse(raw) : [];
        } catch (e) {
            menuData = [];
        }

        renderMenu();
        $modal.fadeIn(200);
        $('body').css('overflow', 'hidden'); // جلوگیری از اسکرول صفحه
    });

    // --- 2. بستن مودال ---
    $('.rp-modal-close').on('click', function () {
        $modal.fadeOut(200);
        $('body').css('overflow', '');
    });

    // --- 3. رندر کردن منو ---
    function renderMenu() {
        // الف) رندر آیتم‌های ثابت
        var $fixedContainer = $('#rp-fixed-items-container');
        $fixedContainer.empty();

        fixedDefinitions.forEach(function (def) {
            // اگر نیاز به ووکامرس دارد و ووکامرس نصب نیست، رد کن
            if (def.requiresWoo && !hasWoo) return;

            // پیدا کردن داده فعلی (اگر قبلا ذخیره شده)
            var current = menuData.find(item => item.action === def.action) || {};

            // مقادیر (یا پیش‌فرض)
            var label = current.label || def.defaultLabel;
            var icon = current.icon || def.defaultIcon;

            var html = `
                <div class="rp-fixed-card" data-action="${def.action}">
                    <span class="rp-card-label">${def.defaultLabel}</span>
                    <div class="rp-input-group">
                        <div class="rp-icon-preview" title="تغییر آیکون"><span class="dashicons ${icon}"></span></div>
                        <input type="hidden" class="rp-icon-input" value="${icon}">
                        <input type="text" class="rp-label-input" value="${label}" placeholder="عنوان نمایشی" style="width:100%">
                    </div>
                </div>
            `;
            $fixedContainer.append(html);
        });

        // ب) رندر آیتم‌های دلخواه
        var $customContainer = $('#rp-custom-items-container');
        $customContainer.find('.rp-custom-row').remove(); // فقط سطرها را پاک کن، نه پیام خالی را

        var customItems = menuData.filter(item => item.type === 'custom');

        if (customItems.length > 0) {
            $('#rp-no-custom-items').hide();
            customItems.forEach(function (item) {
                addCustomRow(item);
            });
        } else {
            $('#rp-no-custom-items').show();
        }
    }

    // --- 4. افزودن سطر دلخواه ---
    $('#rp-add-custom-item').on('click', function () {
        $('#rp-no-custom-items').hide();
        addCustomRow({ label: '', icon: 'dashicons-admin-links', content_type: 'link', content_value: '' });
    });

    function addCustomRow(data) {
        var rowId = 'row_' + Date.now() + Math.floor(Math.random() * 1000);
        var html = `
            <div class="rp-custom-row" id="${rowId}">
                <div class="rp-col-small">
                    <label class="rp-card-label">آیکون</label>
                    <div class="rp-icon-preview" title="تغییر آیکون"><span class="dashicons ${data.icon}"></span></div>
                    <input type="hidden" class="rp-custom-icon" value="${data.icon}">
                </div>
                <div class="rp-col">
                    <label class="rp-card-label">عنوان</label>
                    <input type="text" class="rp-custom-label" value="${data.label}" style="width:100%">
                </div>
                <div class="rp-col">
                    <label class="rp-card-label">نوع محتوا</label>
                    <select class="rp-custom-type" style="width:100%">
                        <option value="link" ${data.content_type === 'link' ? 'selected' : ''}>لینک خارجی</option>
                        <option value="shortcode" ${data.content_type === 'shortcode' ? 'selected' : ''}>شورت‌کد</option>
                        <option value="text" ${data.content_type === 'text' ? 'selected' : ''}>متن ساده</option>
                    </select>
                </div>
                <div class="rp-col" style="flex:2;">
                    <label class="rp-card-label">مقدار (لینک / کد / متن)</label>
                    <input type="text" class="rp-custom-value" value="${data.content_value || ''}" style="width:100%; direction:ltr; text-align:left;">
                </div>
                <div class="rp-col-action">
                    <span class="dashicons dashicons-trash rp-remove-row" title="حذف"></span>
                </div>
            </div>
        `;
        $('#rp-custom-items-container').append(html);
    }

    // --- 5. حذف سطر ---
    $(document).on('click', '.rp-remove-row', function () {
        if (confirm('آیا از حذف این آیتم اطمینان دارید؟')) {
            $(this).closest('.rp-custom-row').remove();
            if ($('#rp-custom-items-container .rp-custom-row').length === 0) {
                $('#rp-no-custom-items').show();
            }
        }
    });

    // --- 6. انتخاب آیکون (Icon Picker) ---
    $(document).on('click', '.rp-icon-preview', function () {
        activeIconInput = $(this); // ذخیره المان کلیک شده
        $('#rp-icon-picker').fadeIn(100);
    });

    // پر کردن لیست آیکون‌ها (فقط یکبار)
    if ($('#rp-icons-list').children().length === 0) {
        dashicons.forEach(function (icon) {
            $('#rp-icons-list').append(`<div class="rp-icon-item" data-icon="${icon}"><span class="dashicons ${icon}"></span></div>`);
        });
    }

    // جستجو در آیکون‌ها
    $('#rp-icon-search').on('keyup', function () {
        var val = $(this).val().toLowerCase();
        $('.rp-icon-item').each(function () {
            var iconClass = $(this).data('icon');
            if (iconClass.indexOf(val) > -1) $(this).show(); else $(this).hide();
        });
    });

    // انتخاب آیکون
    $(document).on('click', '.rp-icon-item', function () {
        var selectedIcon = $(this).data('icon');
        if (activeIconInput) {
            // آپدیت ظاهر
            activeIconInput.find('.dashicons').attr('class', 'dashicons ' + selectedIcon);
            // آپدیت اینپوت مخفی کنارش
            activeIconInput.siblings('input[type="hidden"]').val(selectedIcon);
        }
        $('#rp-icon-picker').fadeOut(100);
    });

    $('.rp-picker-close').on('click', function () { $('#rp-icon-picker').fadeOut(100); });

    // --- 7. ذخیره نهایی ---
    $('#rp-save-menu-changes').on('click', function () {
        var finalData = [];
        var $btn = $(this);

        // جمع‌آوری ثابت‌ها
        $('#rp-fixed-items-container .rp-fixed-card').each(function () {
            var action = $(this).data('action');
            var label = $(this).find('.rp-label-input').val();
            var icon = $(this).find('.rp-icon-input').val();
            finalData.push({
                action: action,
                label: label,
                icon: icon,
                type: 'fixed'
            });
        });

        // جمع‌آوری دلخواه‌ها
        $('#rp-custom-items-container .rp-custom-row').each(function () {
            var icon = $(this).find('.rp-custom-icon').val();
            var label = $(this).find('.rp-custom-label').val();
            var cType = $(this).find('.rp-custom-type').val();
            var cVal = $(this).find('.rp-custom-value').val();

            if (label.trim() !== '') { // فقط اگر نام داشت ذخیره کن
                finalData.push({
                    action: 'custom_' + Math.floor(Math.random() * 10000), // شناسه یونیک
                    label: label,
                    icon: icon,
                    type: 'custom',
                    content_type: cType,
                    content_value: cVal
                });
            }
        });

        // بروزرسانی textarea
        $jsonInput.val(JSON.stringify(finalData));

        // افکت ذخیره
        $btn.text('ذخیره شد!').prop('disabled', true);
        setTimeout(function () {
            $modal.fadeOut(200, function () {
                $btn.text('ذخیره تغییرات').prop('disabled', false);
            });
            // نکته: اینجا فقط تکست‌اریا آپدیت شد. کاربر باید دکمه "ذخیره تغییرات" اصلی صفحه تنظیمات را بزند.
            // برای راحتی، می‌توانیم یک نوتیفیکیشن نشان دهیم
            alert('تنظیمات منو در حافظه موقت ذخیره شد. لطفاً برای اعمال نهایی، دکمه "ذخیره تغییرات" پایین صفحه را بزنید.');
        }, 800);
    });

});