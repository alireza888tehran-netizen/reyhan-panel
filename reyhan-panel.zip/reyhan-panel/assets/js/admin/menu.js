jQuery(document).ready(function ($) {
    "use strict";

    if ($('#rp-menu-builder-wrap').length) {
        var $list = $('.rp-menu-list');
        $list.sortable({ handle: '.rp-sort-handle', placeholder: 'rp-sort-placeholder', items: '.rp-menu-item-row:not(.rp-locked-item)', cancel: '.rp-locked-item' });

        $('.rp-add-menu-item').on('click', function (e) {
            e.preventDefault();
            var $clone = $list.find('.rp-menu-item-row:not(.rp-locked-item)').first().clone();
            if (!$clone.length) $clone = $list.find('.rp-menu-item-row').first().clone();

            $clone.addClass('closed').removeClass('rp-locked-item');
            $clone.find('.rp-item-title').text('(آیتم جدید)');
            $clone.find('input, textarea').val('');
            $clone.find('select').val('link').prop('disabled', false).css({ 'pointer-events': 'auto', 'opacity': '1' });
            $clone.find('.rp-icon-input').val('dashicons-marker');
            $clone.find('.preview-icon').attr('class', 'dashicons dashicons-marker preview-icon');

            $clone.find('.rp-sort-handle, .rp-lock-icon, .rp-remove-row').remove();
            $clone.find('.rp-item-header').prepend('<span class="dashicons dashicons-move rp-sort-handle"></span>');
            $clone.find('.rp-header-controls').append('<button type="button" class="rp-remove-row"><span class="dashicons dashicons-trash"></span></button>');

            var newIdx = new Date().getTime();
            $clone.find('input, select, textarea').each(function () {
                var name = $(this).attr('name');
                if (name) $(this).attr('name', name.replace(/\[\d+\]/, '[' + newIdx + ']'));
            });

            $clone.find('.rp-item-body').hide();
            var $logoutItem = $list.find('.rp-menu-item-row[data-action="logout"]');
            if ($logoutItem.length) $clone.insertBefore($logoutItem); else $list.append($clone);
        });

        $(document).on('click', '.rp-toggle-item', function () {
            var row = $(this).closest('.rp-menu-item-row');
            row.find('.rp-item-body').slideToggle();
            row.toggleClass('closed');
        });

        $(document).on('keyup', '.rp-live-title', function () { $(this).closest('.rp-menu-item-row').find('.rp-item-title').text($(this).val()); });

        $(document).on('change', '.rp-menu-action-select', function () {
            var val = $(this).val();
            var row = $(this).closest('.rp-menu-item-row');
            row.find('.rp-item-type-badge').text(val);
            row.find('.rp-menu-link-row').toggle(val === 'link');
            row.find('.rp-menu-shortcode-row').toggle(val === 'content');
        });
    }

    // انتخابگر آیکون
    $(document).on('change', '.rp-icon-type-radio', function () {
        var $row = $(this).closest('.rp-icon-settings-box');
        if ($(this).val() === 'icon') { $row.find('.rp-icon-picker-area').slideDown(200); $row.find('.rp-image-uploader-area').slideUp(200); }
        else { $row.find('.rp-icon-picker-area').slideUp(200); $row.find('.rp-image-uploader-area').slideDown(200); }
    });

    $(document).on('click', '.rp-icon-select-btn', function (e) {
        e.preventDefault(); e.stopPropagation();
        var $dropdown = $(this).siblings('.rp-icon-dropdown');
        $('.rp-icon-dropdown').not($dropdown).removeClass('show');
        if ($dropdown.children().length === 0) {
            var icons = ['dashicons-dashboard', 'dashicons-admin-post', 'dashicons-admin-media', 'dashicons-admin-users', 'dashicons-email', 'dashicons-phone', 'dashicons-cart', 'dashicons-tickets-alt'];
            var html = ''; icons.forEach(icon => { html += `<div class="rp-icon-option" data-icon="${icon}"><span class="dashicons ${icon}"></span></div>`; });
            $dropdown.html(html);
        }
        $dropdown.toggleClass('show');
    });

    $(document).on('click', '.rp-icon-option', function (e) {
        e.stopPropagation();
        var icon = $(this).data('icon');
        var wrap = $(this).closest('.rp-icon-picker-wrap');
        wrap.find('.rp-icon-input').val(icon);
        wrap.find('.preview-icon').attr('class', 'dashicons ' + icon + ' preview-icon');
        wrap.find('.rp-icon-dropdown').removeClass('show');
    });

    $(document).click(function (e) { if (!$(e.target).closest('.rp-icon-picker-wrap').length) $('.rp-icon-dropdown').removeClass('show'); });
});