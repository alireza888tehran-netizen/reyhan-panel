jQuery(document).ready(function ($) {
    "use strict";

    /* =======================================================
       1. تنظیمات عمومی و ابزارها
    ======================================================= */
    // متغیرهای سراسری که توسط ماژول‌های دیگر استفاده می‌شوند
    window.LocalData = (typeof reyhan_admin_ajax !== 'undefined') ? reyhan_admin_ajax : { ajax_url: ajaxurl, nonce: '', canned_responses: [] };
    window.DEFAULT_AVATAR = (typeof rp_default_avatar !== 'undefined') ? rp_default_avatar : '';

    // تابع ذخیره امن در لوکال استوریج
    window.safeStorage = function (key, value = null) {
        try {
            if (value !== null) localStorage.setItem(key, value);
            else return localStorage.getItem(key);
        } catch (e) { return null; }
    };

    // سیستم تب‌ها
    function switchTab(targetId) {
        var $target = $('#' + targetId);
        if ($target.length === 0) return false;
        $('.rp-tab-pane').hide().removeClass('active');
        $target.fadeIn(200).addClass('active');
        $('.rp-tabs-nav li').removeClass('active');
        $('.rp-tabs-nav li[data-tab="' + targetId + '"]').addClass('active');
        safeStorage('reyhan_active_tab', targetId);
        return true;
    }

    if ($('.rp-tabs-nav').length > 0) {
        $(document).on('click', '.rp-tabs-nav li', function (e) {
            e.preventDefault();
            var target = $(this).data('tab');
            if (target) switchTab(target);
        });

        var savedTab = safeStorage('reyhan_active_tab');
        if (!savedTab || !switchTab(savedTab)) {
            var firstTabId = $('.rp-tabs-nav li:first-child').data('tab');
            switchTab(firstTabId);
        }
    }

    // تاگل‌های نمایش/مخفی
    $(document).on('change', '.rp-section-toggle', function () {
        var targetId = $(this).data('target');
        if ($(this).is(':checked')) $('#' + targetId).slideDown();
        else $('#' + targetId).slideUp();
    });
    $('.rp-section-toggle').trigger('change');

    /* =======================================================
       2. مدیا آپلودر (Media Uploader)
    ======================================================= */
    $(document).on('click', '.rp-upload-btn-modern, .rp-preview-circle, .rp-media-upload-btn', function (e) {
        e.preventDefault();
        var $button = $(this);
        var wrap = $button.closest('.rp-media-upload-modern-wrap, .rp-image-uploader-area');
        var isMenuIcon = $button.hasClass('rp-media-upload-btn');
        var isProfile = wrap.find('.rp-preview-img').length > 0;

        var custom_uploader = wp.media({
            title: isMenuIcon ? 'انتخاب آیکون SVG' : 'انتخاب تصویر',
            button: { text: 'استفاده از این فایل' },
            library: { type: isMenuIcon ? 'image/svg+xml' : 'image' },
            multiple: false
        });

        custom_uploader.on('select', function () {
            var attachment = custom_uploader.state().get('selection').first().toJSON();

            if (isProfile && !isMenuIcon) {
                var allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];
                if (allowedTypes.indexOf(attachment.mime) === -1) {
                    alert('خطا: فقط فرمت‌های JPG, JPEG, PNG, WEBP مجاز هستند.');
                    return;
                }
            }

            if (isMenuIcon && attachment.mime !== 'image/svg+xml') {
                alert('لطفاً فقط فایل SVG انتخاب کنید.');
                return;
            }

            wrap.find('input[type="text"], input[type="hidden"]').first().val(attachment.url).trigger('change');
            var preview = wrap.find('img');
            if (preview.length) {
                preview.attr('src', attachment.url);
                wrap.addClass('has-image');
            }

            if (isMenuIcon) {
                $button.text('تغییر فایل (' + attachment.filename + ')').css({ 'background': '#e8f5e9', 'color': '#2e7d32', 'border-color': '#c8e6c9' });
            }
            wrap.find('.rp-remove-btn-modern').fadeIn();
        });
        custom_uploader.open();
    });

    $(document).on('click', '.rp-remove-btn-modern', function (e) {
        e.preventDefault();
        var wrap = $(this).closest('.rp-media-upload-modern-wrap');
        wrap.find('.rp-media-input').val('').trigger('change');
        var img = wrap.find('.rp-preview-img');
        var defaultSrc = img.data('default');
        if (defaultSrc) img.attr('src', defaultSrc);
        $(this).fadeOut();
        wrap.removeClass('has-image');
    });

    /* =======================================================
       3. کامپوننت‌های UI (Repeater, Select2, ColorPicker)
    ======================================================= */
    // ریپیتر ساده
    $(document).on('click', '.rp-add-row', function () {
        var wrap = $(this).closest('.rp-repeater-wrap');
        var list = wrap.find('.rp-repeater-list');
        var id = wrap.data('id');
        var fields = $(this).data('fields');
        var idx = new Date().getTime();

        var html = '<div class="rp-repeater-item" style="display:none;"><div class="rp-repeater-inputs">';
        $.each(fields, function (key, label) {
            var name = 'reyhan_options[' + id + '][' + idx + '][' + key + ']';
            html += `<div class="rp-input-group-row"><label class="rp-input-label">${label}</label>`;
            if (['content', 'a'].includes(key)) html += `<textarea name="${name}" rows="2" class="rp-full-width"></textarea>`;
            else html += `<input type="text" name="${name}" class="rp-full-width">`;
            html += '</div>';
        });
        html += '</div><div class="rp-repeater-actions"><button type="button" class="button rp-remove-row"><span class="dashicons dashicons-no"></span></button></div></div>';
        list.append(html); list.find('.rp-repeater-item:last').fadeIn();
    });

    // ریپیتر مدرن (Canned Responses)
    $(document).on('click', '.rp-add-row-modern', function (e) {
        e.preventDefault();
        var wrap = $(this).closest('.rp-repeater-wrap');
        var list = wrap.find('.rp-repeater-list');
        var id = wrap.data('id');
        var idx = new Date().getTime();
        var html = `
        <div class="rp-canned-item" style="display:none;">
            <div class="rp-drag-handle"><span class="dashicons dashicons-move"></span></div>
            <div class="rp-canned-inputs">
                <div><input type="text" name="reyhan_options[${id}][${idx}][title]" class="rp-mod-input-sm" placeholder="عنوان پاسخ"></div>
                <div><textarea name="reyhan_options[${id}][${idx}][content]" class="rp-mod-input-sm" placeholder="متن کامل پاسخ"></textarea></div>
            </div>
            <button type="button" class="rp-btn-delete rp-remove-row-circle" title="حذف"><span class="dashicons dashicons-trash"></span></button>
        </div>`;
        list.append(html); list.find('.rp-canned-item:last').fadeIn();
    });

    $(document).on('click', '.rp-remove-row, .rp-remove-row-circle', function (e) {
        e.preventDefault();
        if (confirm('آیا مطمئن هستید؟')) {
            $(this).closest('.rp-repeater-item, .rp-canned-item').slideUp(200, function () { $(this).remove(); });
        }
    });

    if ($.fn.sortable) $('.rp-repeater-list').sortable({ handle: '.rp-item-header, .rp-drag-handle', placeholder: "ui-state-highlight", opacity: 0.8 });

    // Select2 & Cities
    const iranCities = { 'Alborz': ['کرج', 'هشتگرد'], 'Tehran': ['تهران', 'شهریار'], 'Isfahan': ['اصفهان', 'کاشان'], 'Fars': ['شیراز', 'مرودشت'], 'Razavi Khorasan': ['مشهد', 'نیشابور'] }; // (لیست کامل در frontend هست، اینجا خلاصه است یا باید از فایل مشترک خوانده شود)

    if ($.fn.select2) {
        $('.rp-select2').select2({ width: '100%', dir: "rtl", language: { noResults: () => "یافت نشد" }, dropdownCssClass: 'rp-select2-drop', containerCssClass: 'rp-select2-container' });
    }

    $('#rp_admin_state').on('change', function () {
        var state = $(this).val();
        var citySelect = $('#rp_admin_city');
        citySelect.empty().append('<option value="">انتخاب شهر...</option>');
        if (state && iranCities[state]) {
            iranCities[state].forEach(city => { citySelect.append(`<option value="${city}">${city}</option>`); });
        }
        citySelect.trigger('change');
    });

    // Color Picker
    if ($.fn.wpColorPicker) $('.rp-color-field').wpColorPicker();

    jQuery(function ($) {
        // Make section headers full-width inside WP settings table
        $('.form-table tr').each(function () {
            var $tr = $(this);
            var $header = $tr.find('.rp-section-header');

            if ($header.length) {
                var $td = $tr.children('td');
                $td.attr('colspan', 2);
                $tr.children('th').remove(); // remove empty TH that creates the blank box
            }
        });
    });

    $(document).on('click', '.rp-mini-tabs-nav li', function () {
        var $this = $(this);
        var method = $this.data('method'); // مقدار pattern یا text
        var $wrapper = $this.closest('.rp-mini-tabs-wrapper');

        // 1. تغییر کلاس اکتیو دکمه‌ها
        $wrapper.find('.rp-mini-tabs-nav li').removeClass('active');
        $this.addClass('active');

        // 2. نمایش/مخفی کردن محتوا
        $wrapper.find('.rp-mini-tab-content').hide();
        $wrapper.find('.content-' + method).fadeIn(200);

        // 3. آپدیت کردن اینپوت مخفی (اصلاح شده برای پیدا کردن همه مدل‌ها)

        // الف) جستجو بر اساس کلاس استاندارد (برای بخش تیکت‌ها)
        var $input = $wrapper.prev('.rp-sms-method-input');

        // ب) اگر پیدا نشد، جستجو بر اساس ID خاص (برای بخش تنظیمات اصلی پیامک)
        if ($input.length === 0) {
            $input = $('#rp_sms_method_input');
        }

        // ج) حالت‌های فرعی (اگر ساختار HTML کمی متفاوت بود)
        if ($input.length === 0) {
            $input = $wrapper.find('.rp-sms-method-input');
        }
        if ($input.length === 0) {
            $input = $wrapper.parent().find('.rp-sms-method-input');
        }

        // اعمال تغییرات
        $input.val(method).trigger('change');
    });
});