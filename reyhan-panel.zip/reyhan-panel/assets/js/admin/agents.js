jQuery(document).ready(function ($) {
    "use strict";

    var agentSearchTimer;
    var agentsData = [];
    var currentEditingAgent = null;

    if ($('#rp_agents_data_json').length > 0) {
        try { agentsData = JSON.parse($('#rp_agents_data_json').val()); } catch (e) { agentsData = []; }
        renderAgentsGrid();
    }

    function renderAgentsGrid() {
        var html = '';
        if (agentsData.length === 0) {
            html = '<div class="rp-empty-agent-state"><span class="dashicons dashicons-admin-users"></span><div>هنوز هیچ کارشناسی تعریف نشده است.</div></div>';
        } else {
            $.each(agentsData, function (i, agent) {
                var deptText = agent.all_depts ? '<span class="rp-badge success">مدیر کل (دسترسی کامل)</span>' :
                    (agent.depts && agent.depts.length > 0) ? 'دسترسی به: ' + agent.depts.join('، ') : '<span class="rp-badge error">بدون دسترسی</span>';
                html += `<div class="rp-agent-card ${agent.all_depts ? 'full-access' : 'limited'}"><div class="rp-agent-avatar"><img src="${agent.avatar || DEFAULT_AVATAR}" alt="${agent.name}"></div><div class="rp-agent-info"><h4>${agent.name}</h4><span class="rp-agent-depts">${deptText}</span></div><div class="rp-agent-actions"><button type="button" class="rp-btn-icon edit-agent" data-index="${i}"><span class="dashicons dashicons-edit"></span></button><button type="button" class="rp-btn-icon remove-agent" data-index="${i}"><span class="dashicons dashicons-trash"></span></button></div></div>`;
            });
        }
        $('#rp-agents-grid').html(html);
        $('#rp_agents_data_json').val(JSON.stringify(agentsData));
    }

    $('#rp-user-search-input').on('keyup', function () {
        var term = $(this).val();
        var resBox = $('#rp-search-results');
        clearTimeout(agentSearchTimer);

        if (term.length < 2) { resBox.hide(); return; }

        agentSearchTimer = setTimeout(function () {
            resBox.show().html('<div class="rp-search-loading"><span class="dashicons dashicons-update spin"></span> در حال جستجو...</div>');
            $.post(LocalData.ajax_url, { action: 'reyhan_search_users', security: LocalData.nonce, term: term }, function (res) {
                if (res.success && res.data.length > 0) {
                    var html = '<ul>';
                    $.each(res.data, function (i, user) {
                        var isAdded = agentsData.find(a => a.id == user.id);
                        html += `<li class="${isAdded ? 'added' : 'rp-result-item'}" data-id="${user.id}" data-text="${user.text}" data-avatar="${user.avatar}"><div class="rp-res-info-text"><span class="rp-res-name">${user.text}</span></div>${isAdded ? '<span class="dashicons dashicons-yes-alt" style="color:#4CAF50;"></span>' : '<span class="dashicons dashicons-plus-alt2" style="color:#FF5722;"></span>'}</li>`;
                    });
                    resBox.html(html + '</ul>');
                } else { resBox.html('<div class="rp-search-empty">کاربری یافت نشد.</div>'); }
            });
        }, 500);
    });

    $(document).on('click', '.rp-result-item', function () {
        var finalAvatar = $(this).data('avatar') || DEFAULT_AVATAR;
        currentEditingAgent = { id: $(this).data('id'), name: $(this).data('text'), avatar: finalAvatar, all_depts: false, depts: [], is_new: true };
        $('#modal-agent-avatar').attr('src', finalAvatar);
        openDeptModal();
        $('#rp-search-results').hide(); $('#rp-user-search-input').val('');
    });

    function openDeptModal() {
        $('#modal-agent-name').text(currentEditingAgent.name);
        var deptContainer = $('#dept-list-container');
        var deptAllCheckbox = $('#dept-all');
        if (typeof rp_departments_list !== 'undefined' && rp_departments_list.length > 0) {
            var html = '';
            rp_departments_list.forEach(function (dept) {
                var checked = (currentEditingAgent.depts && currentEditingAgent.depts.includes(dept)) ? 'checked' : '';
                html += `<label class="rp-access-option"><input type="checkbox" class="dept-check" value="${dept}" ${checked}> <span>${dept}</span></label>`;
            });
            deptContainer.html(html).show();
            deptAllCheckbox.prop('disabled', false).prop('checked', currentEditingAgent.all_depts);
        } else {
            deptContainer.html('<div class="rp-alert-warning">دپارتمانی تعریف نشده، دسترسی کامل اجباری است.</div>').show();
            deptAllCheckbox.prop('checked', true).prop('disabled', true);
            currentEditingAgent.all_depts = true;
        }
        $('#rp-dept-modal').addClass('active').css('display', 'flex');
    }

    $('#btn-save-agent').on('click', function (e) {
        e.preventDefault();
        currentEditingAgent.all_depts = $('#dept-all').is(':checked');
        currentEditingAgent.depts = [];
        if (!currentEditingAgent.all_depts) { $('.dept-check:checked').each(function () { currentEditingAgent.depts.push($(this).val()); }); }
        if (currentEditingAgent.is_new) { delete currentEditingAgent.is_new; agentsData.push(currentEditingAgent); } else { agentsData[currentEditingAgent.index] = currentEditingAgent; }
        renderAgentsGrid();
        $('#rp-dept-modal').removeClass('active').fadeOut();
    });

    $(document).on('click', '.edit-agent', function () {
        var idx = $(this).data('index');
        currentEditingAgent = JSON.parse(JSON.stringify(agentsData[idx]));
        currentEditingAgent.index = idx; currentEditingAgent.is_new = false;
        $('#modal-agent-avatar').attr('src', currentEditingAgent.avatar || DEFAULT_AVATAR);
        openDeptModal();
    });

    $(document).on('click', '.remove-agent', function () { if (confirm('حذف شود؟')) { agentsData.splice($(this).data('index'), 1); renderAgentsGrid(); } });
    $('.close-modal, .rp-modal-close').click(function () { $('#rp-dept-modal').removeClass('active').fadeOut(); });
});