jQuery(document).ready(function ($) {
    var currentStep = 1;
    var maxSteps = 5; // تغییر به 5 مرحله
    var image_frame;

    var isLicenseOk = Boolean(reyhan_wizard_obj.license_status);

    if (isLicenseOk) {
        $('#rw-check-license').data('verified', true).text('تایید شده').prop('disabled', true);
        $('#rw-license-input').val('*******').prop('disabled', true);
    }

    function updateStep(step) {
        $('.rw-step-content').hide().removeClass('active');
        $('#step-' + step).fadeIn().addClass('active');
        $('.rw-steps li').removeClass('active');
        $('.rw-steps li[data-step="' + step + '"]').addClass('active');

        if (step === 1) {
            $('#btn-prev').hide();
            if (isLicenseOk || $('#rw-check-license').data('verified') === true) $('#btn-next').show();
            else $('#btn-next').hide();
        } else {
            $('#btn-prev').show();
            $('#btn-next').show();
        }

        // مرحله آخر (5) ذخیره انجام می‌شود
        if (step === maxSteps) {
            $('#rw-footer-nav').hide();
            saveData();
        } else {
            $('#rw-footer-nav').show();
            $('#btn-next').text('مرحله بعد');
        }
    }

    updateStep(1);

    $('#btn-next').click(function (e) {
        e.preventDefault();
        if (currentStep === 1 && !isLicenseOk && $('#rw-check-license').data('verified') !== true) {
            alert('ابتدا لایسنس را فعال کنید.'); return;
        }
        if (currentStep < maxSteps) { currentStep++; updateStep(currentStep); }
    });

    $('#btn-prev').click(function (e) {
        e.preventDefault();
        if (currentStep > 1) { currentStep--; updateStep(currentStep); }
    });

    $('.rw-steps li').click(function () {
        var step = $(this).data('step');
        if (step > 1 && !isLicenseOk && $('#rw-check-license').data('verified') !== true) return;
        currentStep = step;
        updateStep(currentStep);
    });

    $('#rw-check-license').click(function (e) {
        e.preventDefault();
        var btn = $(this);
        var code = $('#rw-license-input').val();
        if (code.length < 5) return;
        btn.prop('disabled', true).text('...');
        $.post(reyhan_wizard_obj.ajax_url, { action: 'reyhan_check_license_wizard', security: reyhan_wizard_obj.nonce, license: code }, function (res) {
            if (res.success) {
                btn.prop('disabled', false).text('تایید شد').data('verified', true);
                isLicenseOk = true; $('#btn-next').fadeIn();
            } else { btn.prop('disabled', false).text('بررسی'); alert(res.data); }
        });
    });

    $('#rw-upload-trigger').on('click', function (e) {
        e.preventDefault();
        if (image_frame) { image_frame.open(); return; }
        image_frame = wp.media({ title: 'انتخاب لوگو', multiple: false, library: { type: 'image' } });
        image_frame.on('select', function () {
            var selection = image_frame.state().get('selection').first().toJSON();
            $('#rw-logo-input').val(selection.url);
            $('#rw-logo-preview').attr('src', selection.url).show();
        });
        image_frame.open();
    });

    function saveData() {
        var form = document.getElementById('rw-form');
        var fd = new FormData(form);
        fd.append('action', 'reyhan_wizard_save');
        fd.append('security', reyhan_wizard_obj.nonce);

        var chk = $('input[name="create_page"]');
        if (chk.length > 0) {
            fd.delete('create_page');
            fd.append('create_page', chk.is(':checked') ? '1' : '0');
        }

        $.ajax({
            url: reyhan_wizard_obj.ajax_url, type: 'POST', data: fd, contentType: false, processData: false,
            success: function (res) { console.log(res); }
        });
    }
});