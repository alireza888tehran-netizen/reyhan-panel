(function ($) {
    "use strict";

    Object.assign(window.ReyhanApp, {

        loadOrders: function () {
            var $wrapper = $('#rp-orders-table-wrapper');

            // هوشمندی: اگر محتوا از قبل وجود دارد (SSR)، دوباره لود نکن
            // این باعث می‌شود تاخیر کاملاً حذف شود
            if ($wrapper.find('.rp-orders-table').length > 0 || $wrapper.find('.rp-empty-state-modern').length > 0) {
                return;
            }

            $wrapper.html('<div class="rp-loading-spinner" style="margin:20px auto;"></div>');
            $.post(reyhan_front_obj.ajax_url, { action: 'reyhan_user_list_orders', security: reyhan_front_obj.nonce }, function (res) {
                $wrapper.html(res.success ? res.data : 'سفارشی یافت نشد');
            });
        },

        loadSingleOrder: function (oid) {
            $('#rp-orders-list-container').hide();
            $('#rp-single-order-container').show().html('<div class="rp-loading-spinner" style="margin:50px auto;"></div>');

            // اسکرول نرم به بالا
            $('html, body').animate({ scrollTop: 0 }, 'fast');

            $.post(reyhan_front_obj.ajax_url, { action: 'reyhan_user_view_order', security: reyhan_front_obj.nonce, order_id: oid }, function (res) {
                if (res.success) $('#rp-single-order-container').html(res.data);
            });
        },

        backToOrderList: function () {
            $('#rp-single-order-container').hide().empty();
            $('#rp-orders-list-container').show();
        }
    });
})(jQuery);