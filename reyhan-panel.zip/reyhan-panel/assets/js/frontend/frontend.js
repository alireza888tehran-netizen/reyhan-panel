(function ($) {
    "use strict";

    if (typeof reyhan_front_obj === 'undefined') {
        console.error('Reyhan Panel: reyhan_front_obj is missing.');
        return;
    }

    const ReyhanApp = {
        currentEmail: '',
        notifTimer: null,

        labels: {
            wait: '<span class="dashicons dashicons-update" style="animation:spin 2s infinite linear; font-size:16px; width:auto; height:auto; vertical-align:middle;"></span> منتظر بمانید...',
            save: 'ذخیره تغییرات'
        },

        init: function () {
            this.bindEvents();
            this.initDashboardInteractions();
            this.initProfileFeatures();
            this.initIranCitiesAndPostal();
            this.checkMandatoryFields();

            // اکسپوز کردن توابع برای فراخوانی‌های احتمالی خارج از اسکوپ
            window.loadUserTickets = this.loadTickets.bind(this);
            window.loadSingleTicket = this.loadSingleTicket.bind(this);
            window.loadOrders = this.loadOrders.bind(this);
            window.loadSingleOrder = this.loadSingleOrder.bind(this);
            window.backToOrderList = this.backToOrderList.bind(this);
        },

        bindEvents: function () {
            // مدیریت تب‌ها (اصلاح شده برای جلوگیری از تداخل نمایش)
            $(document).on('click', '.rp-menu li', this.handleTabSwitch.bind(this));

            // منو موبایل
            $('#rp-mobile-menu-trigger').on('click', function () {
                $('#rp-main-sidebar').addClass('rp-open');
                $('#rp-mobile-overlay').addClass('active');
            });
            $('#rp-mobile-overlay').on('click', function () {
                $('#rp-main-sidebar').removeClass('rp-open');
                $(this).removeClass('active');
            });

            // فرم‌های تیکت
            $('#rp-ticket-submit-form').on('submit', this.handleTicketSubmit.bind(this));
            $(document).on('submit', '#rp-reply-form', this.handleTicketReply.bind(this));
        },

        handleTabSwitch: function (e) {
            var item = $(e.currentTarget);
            var target = item.data('tab');

            // مدیریت خروج و لینک‌های خارجی
            if (item.hasClass('rp-menu-logout')) {
                window.location.href = item.data('url');
                return;
            }
            if (item.hasClass('rp-menu-link')) {
                window.open(item.data('url'), '_blank');
                return;
            }

            e.preventDefault();

            // تغییر کلاس اکتیو در منو
            $('.rp-menu li').removeClass('active');
            item.addClass('active');

            // مخفی‌سازی کامل تمام بخش‌ها (حل مشکل نمایش همزمان پشتیبانی)
            $('.rp-tab-content').hide().removeClass('active');

            // نمایش بخش هدف
            var targetSection = $('#rp-section-' + target);
            if (targetSection.length) {
                targetSection.fadeIn(200).addClass('active');
            }

            // لود خودکار دیتا برای تب‌های خاص
            if (target === 'tickets') this.loadTickets();
            if (target === 'orders') this.loadOrders();

            // بستن منو موبایل بعد از کلیک
            $('#rp-main-sidebar').removeClass('rp-open');
            $('#rp-mobile-overlay').removeClass('active');
        },

        initDashboardInteractions: function () {
            // کپی کد تخفیف
            $(document).on('click', '.rp-copy-discount-btn', function () {
                var code = $(this).data('code');
                var $btn = $(this);
                navigator.clipboard.writeText(code).then(function () {
                    var originalText = $btn.find('.rp-copy-btn').html();
                    $btn.find('.rp-copy-btn').html('<span class="dashicons dashicons-yes"></span> کپی شد');
                    setTimeout(function () { $btn.find('.rp-copy-btn').html(originalText); }, 2000);
                });
            });

            // باز و بسته کردن باکس تیکت جدید
            $(document).on('click', '.rp-toggle-ticket-box', function (e) {
                e.preventDefault();
                $('#rp-ticket-creation-area').slideToggle();
            });

            // آکاردئون سوالات متداول
            $(document).on('click', '.rp-faq-q', function () {
                $(this).next('.rp-faq-a').slideToggle();
            });
        },

        initProfileFeatures: function () {
            var self = this;

            // هندل کردن آپلود آواتار
            $('.rp-avatar-trigger').on('click', function () { $('#rp_profile_avatar').click(); });
            $('#rp_profile_avatar').on('change', function () {
                if (this.files && this.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function (e) { $('#rp-profile-img-preview').attr('src', e.target.result); }
                    reader.readAsDataURL(this.files[0]);
                }
            });

            // نمایش باکس‌های ویرایش موبایل/ایمیل
            $('#rp_btn_edit_email').on('click', function () { $('#rp-edit-email-box').slideToggle(); });
            $('#rp_btn_edit_mobile').on('click', function () { $('#rp-edit-mobile-box').slideToggle(); });

            // ذخیره نهایی کل پروفایل
            $('#rp_save_profile_info').on('click', function () {
                var btn = $(this);
                var originalHtml = btn.html();
                var formData = new FormData();

                formData.append('action', 'reyhan_update_profile_info');
                formData.append('security', reyhan_front_obj.nonce);

                var dataMain = $('#rp-profile-main-form').serializeArray();
                var dataAddr = $('#rp-profile-address-form').serializeArray();
                $.each(dataMain.concat(dataAddr), function (i, field) { formData.append(field.name, field.value); });

                var file = $('#rp_profile_avatar')[0].files[0];
                if (file) formData.append('profile_image', file);

                btn.prop('disabled', true).html(self.labels.wait);

                $.ajax({
                    url: reyhan_front_obj.ajax_url,
                    type: 'POST',
                    processData: false,
                    contentType: false,
                    data: formData,
                    success: function (res) {
                        self.resetButton(btn, originalHtml);
                        if (res.success) self.showNotification(res.data || 'تغییرات ذخیره شد', 'success');
                        else self.showNotification(res.data, 'error');
                    },
                    error: function () {
                        self.resetButton(btn, originalHtml);
                        self.showNotification('خطای سرور', 'error');
                    }
                });
            });
        },

        initIranCitiesAndPostal: function () {
            const iranCities = {
                'Alborz': ['کرج', 'هشتگرد', 'نظرآباد', 'محمدشهر', 'اشتهارد', 'ماهدشت', 'مشکین دشت', 'کمالشهر', 'گرمدره', 'طالقان'],
                'Ardabil': ['اردبیل', 'پارس آباد', 'مشگین شهر', 'خلخال', 'گیوی', 'گرمی', 'بیله سوار', 'نمین', 'نیر', 'کوراییم'],
                'Bushehr': ['بوشهر', 'برازجان', 'گناوه', 'کنگان', 'خورموج', 'جم', 'دیلم', 'عسلویه', 'دیر', 'آبدان'],
                'Chaharmahal and Bakhtiari': ['شهرکرد', 'بروجن', 'لردگان', 'فرخ شهر', 'فارسان', 'هفشجان', 'جونقان', 'سامان', 'فرادنبه', 'بن'],
                'East Azerbaijan': ['تبریز', 'مراغه', 'مرند', 'میانه', 'اهر', 'بناب', 'سراب', 'آذرشهر', 'هادی شهر', 'عجب شیر'],
                'Fars': ['شیراز', 'مرودشت', 'جهرم', 'فسا', 'کازرون', 'داراب', 'فیروزآباد', 'لار', 'آباده', 'نورآباد'],
                'Gilan': ['رشت', 'بندر انزلی', 'لاهیجان', 'لنگرود', 'هشتپر', 'آستارا', 'صومعه سرا', 'آستانه اشرفیه', 'رودسر', 'فومن'],
                'Golestan': ['گرگان', 'گنبد کاووس', 'علی آباد کتول', 'بندر ترکمن', 'کردکوی', 'کلاله', 'آزادشهر', 'رامیان', 'مینودشت', 'گالیکش'],
                'Hamadan': ['همدان', 'ملایر', 'نهاوند', 'اسدآباد', 'توسرکان', 'بهار', 'کبودرآهنگ', 'لالجین', 'رزن', 'فامنین'],
                'Hormozgan': ['بندرعباس', 'میناب', 'قشم', 'کیش', 'بندر لنگه', 'رودان', 'حاجی آباد', 'بستک', 'خمیر', 'پارسیان'],
                'Ilam': ['ایلام', 'دهلران', 'ایوان', 'آبدانان', 'دره شهر', 'مهران', 'سرابله', 'ارکواز', 'آسمان آباد', 'توحید'],
                'Isfahan': ['اصفهان', 'کاشان', 'خمینی شهر', 'نجف آباد', 'شاهین شهر', 'شهرضا', 'فولادشهر', 'تیران', 'مبارکه', 'زرین شهر'],
                'Kerman': ['کرمان', 'سیرجان', 'رفسنجان', 'جیرفت', 'بم', 'زرند', 'کهنوج', 'شهربابک', 'بافت', 'بردسیر'],
                'Kermanshah': ['کرمانشاه', 'اسلام آباد غرب', 'جوانرود', 'کنگاور', 'سنقر', 'هرسین', 'صحنه', 'پاوه', 'روانسر', 'گیلانغرب'],
                'Khuzestan': ['اهواز', 'دزفول', 'آبادان', 'ماهشهر', 'اندیمشک', 'خرمشهر', 'بهبهان', 'ایذه', 'شوشتر', 'مسجدسلیمان'],
                'Kohgiluyeh and Boyer-Ahmad': ['یاسوج', 'دوگنبدان', 'دهدشت', 'لیکک', 'چرام', 'لنده', 'باشت', 'سیسخت', 'سوق', 'قلعه رییسی'],
                'Kurdistan': ['سنندج', 'سقز', 'مریوان', 'بانه', 'قروه', 'کامیاران', 'بیجار', 'دیواندره', 'دهگلان', 'کانی دینار'],
                'Lorestan': ['خرم آباد', 'بروجرد', 'دورود', 'کوهدشت', 'الیگودرز', 'نورآباد', 'ازنا', 'الشتر', 'پلدختر', 'کونانی'],
                'Markazi': ['اراک', 'ساوه', 'خمین', 'محلات', 'دلیجان', 'شازند', 'مامونیه', 'تفرش', 'میلاجرد', 'خنداب'],
                'Mazandaran': ['ساری', 'بابل', 'آمل', 'قائم شهر', 'بهشهر', 'چالوس', 'نکا', 'بابلسر', 'تنکابن', 'نوشهر'],
                'North Khorasan': ['بجنورد', 'شیروان', 'اسفراین', 'آشخانه', 'جاجرم', 'گرمه', 'درق', 'فاروج'],
                'Qazvin': ['قزوین', 'الوند', 'محمدیه', 'تاکستان', 'آبیک', 'بویین زهرا', 'اقبالیه', 'محمودآباد نمونه', 'شریفیه', 'بیدستان'],
                'Qom': ['قم', 'جعفریه', 'پردیسان', 'سلفچگان', 'دستجرد', 'قنوات', 'کهک'],
                'Razavi Khorasan': ['مشهد', 'نیشابور', 'سبزوار', 'تربت حیدریه', 'کاشمر', 'قوچان', 'تربت جام', 'تایباد', 'چناران', 'سرخس'],
                'Semnan': ['سمنان', 'شاهرود', 'دامغان', 'گرمسار', 'مهدی شهر', 'ایوانکی', 'شهمیرزاد', 'سرخه', 'بسطام', 'آرادان'],
                'Sistan and Baluchestan': ['زاهدان', 'زابل', 'ایرانشهر', 'چابهار', 'سراوان', 'خاش', 'کنارک', 'جالق', 'نیکشهر', 'پیشین'],
                'South Khorasan': ['بیرجند', 'قاین', 'طبس', 'فردوس', 'نهبندان', 'بشرویه', 'سرایان', 'سربیشه', 'اسلامیه', 'آرین شهر'],
                'Tehran': ['تهران', 'اسلامشهر', 'گلستان', 'قدس', 'ملارد', 'ورامین', 'شهریار', 'قرچک', 'نسیم شهر', 'پاکدشت'],
                'West Azerbaijan': ['ارومیه', 'خوی', 'بوکان', 'مهاباد', 'میاندوآب', 'سلماس', 'پیرانشهر', 'نقده', 'تکاب', 'ماکو'],
                'Yazd': ['یزد', 'میبد', 'اردکان', 'بافق', 'مهریز', 'ابرکوه', 'اشکذر', 'تفت', 'شاهدیه', 'زارچ'],
                'Zanjan': ['زنجان', 'ابهر', 'خرمدره', 'قیدار', 'هیدج', 'صایین قلعه', 'آب بر', 'سلطانیه', 'سجاس', 'ماهنشان']
            };

            const iranStates = {
                'Alborz': 'البرز', 'Ardabil': 'اردبیل', 'Bushehr': 'بوشهر', 'Chaharmahal and Bakhtiari': 'چهارمحال و بختیاری',
                'East Azerbaijan': 'آذربایجان شرقی', 'Fars': 'فارس', 'Gilan': 'گیلان', 'Golestan': 'گلستان',
                'Hamadan': 'همدان', 'Hormozgan': 'هرمزگان', 'Ilam': 'ایلام', 'Isfahan': 'اصفهان', 'Kerman': 'کرمان',
                'Kermanshah': 'کرمانشاه', 'Khuzestan': 'خوزستان', 'Kohgiluyeh and Boyer-Ahmad': 'کهگیلویه و بویراحمد',
                'Kurdistan': 'کردستان', 'Lorestan': 'لرستان', 'Markazi': 'مرکزی', 'Mazandaran': 'مازندران',
                'North Khorasan': 'خراسان شمالی', 'Qazvin': 'قزوین', 'Qom': 'قم', 'Razavi Khorasan': 'خراسان رضوی',
                'Semnan': 'سمنان', 'Sistan and Baluchestan': 'سیستان و بلوچستان', 'South Khorasan': 'خراسان جنوبی',
                'Tehran': 'تهران', 'West Azerbaijan': 'آذربایجان غربی', 'Yazd': 'یزد', 'Zanjan': 'زنجان'
            };

            var stateSelect = $('#rp_state_select');
            var citySelect = $('#rp_city_select');

            if (stateSelect.length) {
                // پر کردن استان‌ها
                var defaultState = stateSelect.data('default');
                stateSelect.empty().append('<option value="">انتخاب استان...</option>');
                $.each(iranStates, function (key, val) {
                    var sel = (key === defaultState) ? 'selected' : '';
                    stateSelect.append(`<option value="${key}" ${sel}>${val}</option>`);
                });

                // هندلر تغییر استان
                stateSelect.on('change', function () {
                    var stateKey = $(this).val();
                    citySelect.empty().append('<option value="">انتخاب شهر...</option>');
                    if (stateKey && iranCities[stateKey]) {
                        iranCities[stateKey].forEach(city => citySelect.append(`<option value="${city}">${city}</option>`));
                    }
                });

                // بارگذاری اولیه شهر اگر مقدار ذخیره شده وجود دارد
                if (defaultState) {
                    stateSelect.trigger('change');
                    citySelect.val(citySelect.data('default'));
                }
            }
        },

        // --- بخش تیکت‌ها ---
        loadTickets: function () {
            $('#rp-user-tickets-list').html('<div class="rp-loading-spinner" style="margin:20px auto;"></div>');
            $.post(reyhan_front_obj.ajax_url, { action: 'reyhan_user_list', security: reyhan_front_obj.nonce }, function (res) {
                $('#rp-user-tickets-list').html(res.success ? res.data : 'خطا در بارگذاری');
            });
        },

        loadSingleTicket: function (tid) {
            $('.rp-ticket-header').hide();
            $('#rp-user-tickets-list').html('<div class="rp-loading-spinner" style="margin:20px auto;"></div>');
            $.post(reyhan_front_obj.ajax_url, { action: 'reyhan_user_view', security: reyhan_front_obj.nonce, ticket_id: tid }, function (res) {
                if (res.success) $('#rp-user-tickets-list').html(res.data);
                else ReyhanApp.loadTickets();
            });
        },

        handleTicketSubmit: function (e) {
            e.preventDefault();
            var btn = $(e.target).find('button');
            var fd = new FormData(e.target);
            fd.append('action', 'reyhan_user_submit');
            fd.append('security', reyhan_front_obj.nonce);

            btn.prop('disabled', true).text('ارسال...');
            $.ajax({
                url: reyhan_front_obj.ajax_url, type: 'POST', data: fd, contentType: false, processData: false,
                success: function (res) {
                    if (res.success) {
                        $('#rp-ticket-creation-area').slideUp();
                        e.target.reset();
                        ReyhanApp.loadTickets();
                    }
                    btn.prop('disabled', false).text('ارسال تیکت');
                }
            });
        },

        handleTicketReply: function (e) {
            e.preventDefault();
            var fd = new FormData(e.target);
            fd.append('action', 'reyhan_user_reply');
            fd.append('security', reyhan_front_obj.nonce);
            $.ajax({
                url: reyhan_front_obj.ajax_url, type: 'POST', data: fd, contentType: false, processData: false,
                success: function (res) { if (res.success) ReyhanApp.loadSingleTicket(fd.get('ticket_id')); }
            });
        },

        // --- بخش سفارشات ---
        loadOrders: function () {
            $('#rp-orders-table-wrapper').html('<div class="rp-loading-spinner" style="margin:20px auto;"></div>');
            $.post(reyhan_front_obj.ajax_url, { action: 'reyhan_user_list_orders', security: reyhan_front_obj.nonce }, function (res) {
                $('#rp-orders-table-wrapper').html(res.success ? res.data : 'سفارشی یافت نشد');
            });
        },

        loadSingleOrder: function (oid) {
            $('#rp-orders-list-container').hide();
            $('#rp-single-order-container').show().html('<div class="rp-loading-spinner" style="margin:50px auto;"></div>');
            $.post(reyhan_front_obj.ajax_url, { action: 'reyhan_user_view_order', security: reyhan_front_obj.nonce, order_id: oid }, function (res) {
                if (res.success) $('#rp-single-order-container').html(res.data);
            });
        },

        backToOrderList: function () {
            $('#rp-single-order-container').hide().empty();
            $('#rp-orders-list-container').show();
        },

        // --- ابزارهای کمکی ---
        showNotification: function (msg, type = 'error') {
            if ($('.rp-notification').length === 0) $('body').append('<div class="rp-notification"></div>');
            var notif = $('.rp-notification');
            notif.html(msg).removeClass('error success').addClass(type).fadeIn();
            setTimeout(function () { notif.fadeOut(); }, 4000);
        },

        resetButton: function (btn, text) { btn.prop('disabled', false).html(text); },

        checkMandatoryFields: function () {
            // لاجیک پاپ‌آپ تکمیل اطلاعات در صورت نیاز
        }
    };

    $(document).ready(function () { ReyhanApp.init(); });

})(jQuery);