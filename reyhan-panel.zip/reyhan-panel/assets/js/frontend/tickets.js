(function ($) {
    "use strict";

    Object.assign(window.ReyhanApp, {

        // سیستم نمایش نوتیفیکیشن
        showNotification: function (msg, type = 'info') {
            $('.rp-notification-toast').remove();
            var icon = (type === 'success') ? 'dashicons-yes' : 'dashicons-warning';
            var $toast = $('<div class="rp-notification-toast rp-toast-' + type + '">' +
                '<span class="dashicons ' + icon + '"></span> ' + msg +
                '</div>');
            $('body').append($toast);
            setTimeout(function () { $toast.addClass('show'); }, 10);
            setTimeout(function () {
                $toast.removeClass('show');
                setTimeout(function () { $toast.remove(); }, 300);
            }, 4000);
        },

        initTickets: function () {
            console.log('ReyhanPanel: Tickets System Active');

            // لود اولیه لیست
            if ($('#rp-user-tickets-list').length > 0) {
                this.loadTickets(1);
            }

            // دکمه رفرش
            $(document).off('click', '#btn-refresh-tickets').on('click', '#btn-refresh-tickets', (e) => {
                e.preventDefault();
                this.loadTickets(1);
            });

            // دکمه نمایش فرم
            $(document).off('click', '.rp-btn-new-ticket-full').on('click', '.rp-btn-new-ticket-full', function (e) {
                e.preventDefault();
                $('#rp-ticket-creation-area').slideToggle();
            });

            // دکمه بازگشت
            $(document).off('click', '.rp-btn-back-list').on('click', '.rp-btn-back-list', function (e) {
                e.preventDefault();
                $('#rp-new-ticket-form, #rp-single-ticket-container').slideUp();
                $('#rp-user-tickets-list, .rp-ticket-header-wrapper').slideDown();
                $('#rp-ticket-creation-area').slideUp();
            });

            // ثبت تیکت جدید
            $(document).off('submit', '#rp-ticket-submit-form').on('submit', '#rp-ticket-submit-form', (e) => {
                e.preventDefault();
                this.submitNewTicket();
            });

            // ثبت پاسخ
            $(document).off('submit', '#rp-form-reply-ticket').on('submit', '#rp-form-reply-ticket', (e) => {
                e.preventDefault();
                this.replyTicket();
            });
        },

        loadTickets: function (page) {
            var container = $('#rp-user-tickets-list');
            container.html('<div class="rp-loading-spinner" style="margin:20px auto;"></div>');

            $.post(reyhan_front_obj.ajax_url, {
                action: 'reyhan_user_list_tickets',
                security: reyhan_front_obj.nonce,
                paged: page
            }, (res) => {
                if (res.success) {
                    container.html(res.data.html);
                } else {
                    container.html('<div class="rp-error-msg">' + (res.data || 'خطا') + '</div>');
                }
            }).fail((xhr) => {
                container.html('<div class="rp-error-msg">خطای ارتباط با سرور</div>');
            });
        },

        loadSingleTicket: function (tid) {
            $('#rp-user-tickets-list, .rp-ticket-header-wrapper, #rp-ticket-creation-area').slideUp();

            if ($('#rp-single-ticket-container').length === 0) {
                var mainContainer = $('.rp-dashboard-container').length ? $('.rp-dashboard-container') : $('body');
                // سعی میکنیم داخل والد لیست تیکت قرار دهیم
                if ($('#rp-user-tickets-list').length) mainContainer = $('#rp-user-tickets-list').parent();

                if ($('#rp-single-ticket-container').length === 0) {
                    mainContainer.append('<div id="rp-single-ticket-container"></div>');
                }
            }

            $('#rp-single-ticket-container').html('<div class="rp-loading-spinner" style="margin:50px auto;"></div>').slideDown();

            $.post(reyhan_front_obj.ajax_url, {
                action: 'reyhan_user_view_ticket',
                security: reyhan_front_obj.nonce,
                ticket_id: tid
            }, (res) => {
                if (res.success) {
                    $('#rp-single-ticket-container').html(res.data);
                    var chatBox = $('.rp-chat-box');
                    if (chatBox.length) chatBox.scrollTop(chatBox[0].scrollHeight);
                } else {
                    this.showNotification(res.data || 'خطا', 'error');
                    $('.rp-btn-back-list').click();
                }
            }).fail(() => {
                this.showNotification('خطای سرور', 'error');
                $('.rp-btn-back-list').click();
            });
        },

        closeTicket: function (tid) {
            if (!confirm('آیا مطمئن هستید؟')) return;
            $.post(reyhan_front_obj.ajax_url, {
                action: 'reyhan_user_close', security: reyhan_front_obj.nonce, ticket_id: tid
            }, (res) => {
                if (res.success) {
                    this.showNotification('تیکت بسته شد', 'success');
                    this.loadSingleTicket(tid);
                } else {
                    this.showNotification(res.data, 'error');
                }
            });
        },

        // --- تابع کمکی اعتبارسنجی فایل ---
        validateFile: function (fileInput) {
            if (fileInput && fileInput.files.length > 0) {
                var file = fileInput.files[0];
                var ext = file.name.split('.').pop().toLowerCase();
                // لیست فایل‌های ممنوعه (هماهنگ با PHP)
                var blockedExts = ['php', 'exe', 'js', 'bat', 'sh', 'phtml', 'phar', 'vbs', 'cmd'];

                if (blockedExts.includes(ext)) {
                    this.showNotification('آپلود این نوع فایل به دلایل امنیتی مجاز نیست.', 'error');
                    return false;
                }

                // بررسی حجم (مثلاً ۲ مگابایت)
                if (file.size > 2 * 1024 * 1024) {
                    this.showNotification('حجم فایل انتخابی بیش از حد مجاز (۲ مگابایت) است.', 'error');
                    return false;
                }
            }
            return true;
        },

        submitNewTicket: function () {
            var $form = $('#rp-ticket-submit-form');
            var formData = new FormData($form[0]);

            var title = formData.get('title') || formData.get('subject') || '';
            title = title.trim();
            var msg = formData.get('message') ? formData.get('message').trim() : '';
            var unsafeChars = /[<>{}\[\]\/\\;]/;

            if (!title) { this.showNotification('لطفاً موضوع را وارد کنید.', 'error'); return; }
            if (!isNaN(title)) { this.showNotification('موضوع نمی‌تواند فقط عدد باشد.', 'error'); return; }
            if (unsafeChars.test(title)) { this.showNotification('کاراکتر غیرمجاز در عنوان.', 'error'); return; }
            if (msg.length < 20) { this.showNotification('متن تیکت باید حداقل ۲۰ کاراکتر باشد.', 'error'); return; }

            // 1. بررسی فایل سمت کلاینت
            var fileInput = $form.find('input[type="file"]')[0];
            if (!this.validateFile(fileInput)) return;

            formData.append('action', 'reyhan_user_create_ticket');
            formData.append('security', reyhan_front_obj.nonce);

            var $btn = $form.find('button[type="submit"]');
            var txt = $btn.text();
            $btn.text('در حال ارسال...').prop('disabled', true);

            $.ajax({
                url: reyhan_front_obj.ajax_url, type: 'POST', data: formData,
                processData: false, contentType: false,
                success: (res) => {
                    $btn.text(txt).prop('disabled', false);
                    if (res.success) {
                        this.showNotification(res.data, 'success');
                        $form[0].reset();
                        $('#rp-ticket-creation-area').slideUp();
                        this.loadTickets(1);
                    } else { this.showNotification(res.data, 'error'); }
                },
                error: (xhr) => {
                    $btn.text(txt).prop('disabled', false);
                    this.showNotification('خطای سرور: ' + xhr.status, 'error');
                }
            });
        },

        replyTicket: function () {
            var $form = $('#rp-form-reply-ticket');
            var formData = new FormData($form[0]);
            var msg = formData.get('message') ? formData.get('message').trim() : '';

            if (!msg) { this.showNotification('متن پاسخ نمی‌تواند خالی باشد.', 'error'); return; }
            if (msg.length < 20) { this.showNotification('متن پاسخ باید حداقل ۲۰ کاراکتر باشد.', 'error'); return; }

            // 2. بررسی فایل سمت کلاینت
            var fileInput = $form.find('input[type="file"]')[0];
            if (!this.validateFile(fileInput)) return;

            formData.append('action', 'reyhan_user_reply_ticket');
            formData.append('security', reyhan_front_obj.nonce);

            var $btn = $form.find('button[type="submit"]');
            var txt = $btn.text();
            $btn.text('...').prop('disabled', true);

            $.ajax({
                url: reyhan_front_obj.ajax_url, type: 'POST', data: formData,
                processData: false, contentType: false,
                success: (res) => {
                    $btn.text(txt).prop('disabled', false);
                    if (res.success) {
                        this.showNotification(res.data, 'success');
                        var tid = formData.get('ticket_id');
                        this.loadSingleTicket(tid);
                    } else { this.showNotification(res.data, 'error'); }
                },
                error: (xhr) => {
                    $btn.text(txt).prop('disabled', false);
                    this.showNotification('خطای سرور', 'error');
                }
            });
        }
    });

    $(document).ready(function () {
        if (typeof ReyhanApp !== 'undefined') {
            ReyhanApp.initTickets();
        }
    });

})(jQuery);