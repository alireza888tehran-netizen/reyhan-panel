(function ($) {
    "use strict";

    Object.assign(window.ReyhanApp, {

        loadTickets: function () {
            $('.rp-ticket-header').fadeIn();
            $('#rp-user-tickets-list').html('<div class="rp-loading-spinner" style="margin:20px auto;"></div>');
            $.post(reyhan_front_obj.ajax_url, { action: 'reyhan_user_list', security: reyhan_front_obj.nonce }, function (res) {
                $('#rp-user-tickets-list').html(res.success ? res.data : 'خطا در بارگذاری');
            });
        },

        loadSingleTicket: function (tid) {
            $('.rp-ticket-header').hide();
            $('#rp-user-tickets-list').html('<div class="rp-loading-spinner" style="margin:20px auto;"></div>');
            $.post(reyhan_front_obj.ajax_url, { action: 'reyhan_user_view', security: reyhan_front_obj.nonce, ticket_id: tid }, function (res) {
                if (res.success) $('#rp-user-tickets-list').html(res.data);
                else ReyhanApp.loadTickets();
            });
        },

        handleTicketSubmit: function (e) {
            e.preventDefault();
            var btn = $(e.target).find('button[type="submit"]');
            var fd = new FormData(e.target);
            fd.append('action', 'reyhan_user_submit'); fd.append('security', reyhan_front_obj.nonce);
            btn.prop('disabled', true).text('ارسال...');
            $.ajax({
                url: reyhan_front_obj.ajax_url, type: 'POST', data: fd, contentType: false, processData: false,
                success: function (res) {
                    if (res.success) {
                        $('#rp-ticket-creation-area').slideUp();
                        e.target.reset();
                        $('#file-chosen-text').text('فایلی انتخاب نشده'); // ریست متن فایل
                        ReyhanApp.loadTickets();
                    }
                    btn.prop('disabled', false).text('ارسال تیکت');
                }
            });
        },

        handleTicketReply: function (e) {
            e.preventDefault();
            var fd = new FormData(e.target);
            fd.append('action', 'reyhan_user_reply'); fd.append('security', reyhan_front_obj.nonce);
            var btn = $(e.target).find('button[type="submit"]');
            btn.prop('disabled', true).text('در حال ارسال...');

            $.ajax({
                url: reyhan_front_obj.ajax_url, type: 'POST', data: fd, contentType: false, processData: false,
                success: function (res) {
                    btn.prop('disabled', false).text('ارسال پاسخ');
                    if (res.success) ReyhanApp.loadSingleTicket(fd.get('ticket_id'));
                }
            });
            // خط تکراری $(document).off... حذف شد چون در ready تعریف شده است
        },

        // --- لاجیک جستجو در سوالات متداول ---
        initFaqSearch: function () {
            var $input = $('#rp-faq-search');
            var $list = $('#rp-faq-results-list');
            var $noResult = $('#rp-faq-no-result'); // اگر در HTML اضافه کردید

            $input.on('keyup focus', function () {
                var term = $(this).val().toLowerCase().trim();

                if (term.length < 2) {
                    $list.slideUp(200);
                    return;
                }

                var hasResult = false;
                $list.find('.rp-faq-item').each(function () {
                    var text = $(this).text().toLowerCase();
                    if (text.indexOf(term) > -1) {
                        $(this).show();
                        hasResult = true;
                    } else {
                        $(this).hide();
                    }
                });

                if (hasResult) {
                    $list.slideDown(200);
                } else {
                    $list.slideDown(200); // یا مخفی کردن اگر می‌خواهید پیام نباشد
                }
            });

            // بستن لیست با کلیک در خارج
            $(document).on('click', function (e) {
                if (!$(e.target).closest('.rp-faq-search-box').length) {
                    $list.slideUp(200);
                }
            });

            // باز کردن مودال
            $(document).on('click', '.rp-faq-item', function () {
                var q = $(this).data('question');
                var a = $(this).data('answer');
                $('#rp-faq-modal-q').text(q);
                $('#rp-faq-modal-a').html(a.replace(/\n/g, '<br>'));
                $('#rp-faq-modal-overlay').fadeIn().css('display', 'flex');
                $list.slideUp();
            });

            // بستن مودال
            $(document).on('click', '.rp-close-faq, #rp-faq-modal-overlay', function (e) {
                if (e.target !== this && !$(e.target).hasClass('rp-close-faq')) return;
                $('#rp-faq-modal-overlay').fadeOut();
            });
        },

        // --- مدیریت آپلود فایل (اصلاح شده و تجمیع شده) ---
        initFileUpload: function () {
            // برای فرم تیکت جدید
            $(document).on('change', '#ticket-attachment', function () {
                var fileName = this.files[0] ? this.files[0].name : 'فایلی انتخاب نشده';
                $('#file-chosen-text').text(fileName);
            });

            // برای فرم پاسخ (اضافه شده از فایل PHP)
            $(document).on('change', '#rp-reply-file', function () {
                var fileName = this.files[0] ? this.files[0].name : 'انتخاب فایل پیوست (اختیاری)';
                // دقت کنید که متن پیش‌فرض را می‌توان از متغیرهای لوکالایز شده گرفت، اینجا هاردکد شده برای سادگی
                $('#rp-reply-file-label').html('<span class="dashicons dashicons-paperclip"></span> ' + fileName).css('color', '#FF5722');
            });
        }
    });

    $(document).ready(function () {
        // استفاده از Delegate برای هندل کردن فرم‌هایی که با ایجکس لود می‌شوند
        $(document).on('submit', '#rp-ticket-submit-form', function (e) { ReyhanApp.handleTicketSubmit(e); });
        $(document).on('submit', '#rp-reply-form', function (e) { ReyhanApp.handleTicketReply(e); });

        if (window.ReyhanApp.initFaqSearch) window.ReyhanApp.initFaqSearch();
        if (window.ReyhanApp.initFileUpload) window.ReyhanApp.initFileUpload();
    });

})(jQuery);