jQuery(document).ready(function($){
    var currentStep = 1;
    
    // مدیریت مراحل
    function updateStep(step) {
        $('.rw-step-content').hide().removeClass('active');
        $('#step-' + step).fadeIn().addClass('active');
        
        $('.rw-steps li').removeClass('active');
        $('.rw-steps li[data-step="'+step+'"]').addClass('active');
        
        if(step === 1) $('#btn-prev').hide(); else $('#btn-prev').show();
        
        if(step === 4) {
            $('#rw-footer-nav').hide(); 
            saveData(); 
        } else {
            $('#rw-footer-nav').show();
            $('#btn-next').text('مرحله بعد');
        }
    }

    $('#btn-next').click(function(e){
        e.preventDefault();
        if(currentStep < 4) {
            currentStep++;
            updateStep(currentStep);
        }
    });

    $('#btn-prev').click(function(e){
        e.preventDefault();
        if(currentStep > 1) {
            currentStep--;
            updateStep(currentStep);
        }
    });

    // مدیا آپلودر
    $('#rw-upload-trigger').click(function(e){
        e.preventDefault();
        if (typeof wp === 'undefined' || !wp.media) {
            console.error('WP Media not loaded');
            return;
        }
        
        var frame = wp.media({
            title: 'انتخاب لوگو',
            button: { text: 'استفاده از این تصویر' },
            multiple: false
        });
        
        frame.on('select', function(){
            var att = frame.state().get('selection').first().toJSON();
            $('#rw-logo-input').val(att.url);
            $('#rw-logo-preview').attr('src', att.url).show();
            $('.rw-upload-icon, .rw-upload-text').hide();
        });
        
        frame.open();
    });

    // ذخیره داده‌ها (ایجکس)
    function saveData() {
        var data = $('#rw-form').serialize();
        $.post(ajaxurl, data + '&action=reyhan_wizard_save');
    }

    // لاجیک بررسی لایسنس
    $('#rw-check-license').click(function(e){
        e.preventDefault();
        var btn = $(this);
        var code = $('#rw-license-input').val();
        var msg = $('#rw-license-msg');

        if(code.length < 5) {
            msg.html('<span style="color:#d32f2f;">لطفاً کد لایسنس معتبر وارد کنید.</span>');
            return;
        }

        btn.prop('disabled', true).text('در حال بررسی...');
        msg.html('');

        setTimeout(function(){
            btn.prop('disabled', false).text('تایید شد').css('background', '#4CAF50');
            msg.html('<span style="color:#4CAF50; font-weight:bold;">لایسنس با موفقیت تایید شد. (حالت تست)</span>');
            $('#rw-license-input').prop('disabled', true);
        }, 1500);
    });
});