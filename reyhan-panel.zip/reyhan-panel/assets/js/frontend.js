jQuery(document).ready(function ($) {

    var rpTimerInterval;
    function rp_start_timer(duration, display) {
        var timer = duration, minutes, seconds;
        $('#rp-resend-btn').hide();
        $('#rp-timer-wrap').show();

        clearInterval(rpTimerInterval); // جلوگیری از تداخل تایمرها

        rpTimerInterval = setInterval(function () {
            // تبدیل ثانیه به فرمت دقیقه:ثانیه (اختیاری، فعلا فقط ثانیه طبق درخواست)
            // minutes = parseInt(timer / 60, 10);
            // seconds = parseInt(timer % 60, 10);

            display.text(timer);

            if (--timer < 0) {
                clearInterval(rpTimerInterval);
                $('#rp-timer-wrap').hide();
                $('#rp-resend-btn').fadeIn();
            }
        }, 1000);
    }

    // ===============================================================
    // 1. Dashboard Tab Management (Conflict-Free & Corrected)
    // ===============================================================
    $(document).on('click', '.rp-menu li', function (e) {

        // Ignore if it's a logout link or an external link
        if ($(this).attr('onclick') || $(this).find('a').length > 0) return;

        // Prevent theme conflicts
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();

        // Update active class
        $('.rp-menu li').removeClass('active');
        $(this).addClass('active');

        // Get target tab name
        var targetName = $(this).data('tab');

        // Find the main plugin container
        var $container = $('#reyhan-app-root');

        // Smart selector: supports new ID with prefix
        var $targetSection = $container.find('#rp-section-' + targetName);

        // Fallback for old ID support
        if ($targetSection.length === 0) {
            $targetSection = $container.find('#' + targetName);
        }

        // Show content
        if ($targetSection.length > 0) {
            $container.find('.rp-tab-content').hide(); // Hide all tabs
            $targetSection.fadeIn(300); // Show target tab

            // Save state
            localStorage.setItem('rp_user_last_tab', targetName);

            // Refresh ticket list if needed
            if (targetName === 'tickets' && typeof window.loadUserTickets === 'function') {
                window.loadUserTickets();
            }
        }
    });

    // Auto-load saved tab
    var savedTab = localStorage.getItem('rp_user_last_tab') || 'dashboard';
    var $activeTabBtn = $('.rp-menu li[data-tab="' + savedTab + '"]');
    if ($activeTabBtn.length > 0) {
        setTimeout(function () { $activeTabBtn.trigger('click'); }, 100);
    } else {
        $('.rp-menu li').first().trigger('click');
    }

    // ===============================================================
    // 2. Login & Registration Section
    // ===============================================================

    // Email Login
    $('#rp-login-form-email').on('submit', function (e) {
        e.preventDefault();
        var btn = $(this).find('button');
        var msg = $('#rp-email-msg');

        btn.prop('disabled', true).text('در حال بررسی...');

        $.post(reyhan_front_obj.ajax_url, {
            action: 'reyhan_email_login',
            security: reyhan_front_obj.nonce,
            log: $(this).find('input[name="log"]').val(),
            pwd: $(this).find('input[name="pwd"]').val()
        })
            .done(function (res) {
                if (res.success) {
                    msg.html('<span style="color:green; font-weight:bold;">' + res.data + '</span>');
                    setTimeout(function () { location.reload(); }, 1000);
                } else {
                    btn.prop('disabled', false).text('ورود به سایت');
                    msg.html('<span style="color:red;">' + res.data + '</span>');
                }
            })
            .fail(function () {
                btn.prop('disabled', false).text('ورود به سایت');
                msg.html('<span style="color:red;">خطا در ارتباط با سرور.</span>');
            });
    });

    // Email Registration
    $('#rp-register-form-email').on('submit', function (e) {
        e.preventDefault();
        var btn = $(this).find('button');
        var msg = $('#rp-register-msg');

        btn.prop('disabled', true).text('در حال ساخت حساب...');

        $.post(reyhan_front_obj.ajax_url, {
            action: 'reyhan_email_register',
            security: reyhan_front_obj.nonce,
            name: $(this).find('input[name="name"]').val(),
            email: $(this).find('input[name="email"]').val(),
            pwd: $(this).find('input[name="pwd"]').val()
        })
            .done(function (res) {
                if (res.success) {
                    msg.html('<span style="color:green; font-weight:bold;">' + res.data + '</span>');
                    setTimeout(function () { location.reload(); }, 1000);
                } else {
                    btn.prop('disabled', false).text('ثبت‌نام در سایت');
                    msg.html('<span style="color:red;">' + res.data + '</span>');
                }
            });
    });

    // SMS Login Logic (Updated with Timer)
    $('#rp-login-form-sms').on('submit', function (e) {
        e.preventDefault();
        var loginStep = $('#step-2-box').is(':visible') ? 2 : 1;
        var btn = $(this).find('button[type="submit"]'); // انتخاب دقیق دکمه سابمیت
        var msg = $('#rp-login-msg');

        if (loginStep === 1) {
            var userMobile = $('#rp_mobile').val();
            // اعتبارسنجی ساده برای ایران (شروع با 09 و 11 رقم)
            if (!/^09[0-9]{9}$/.test(userMobile)) { alert('شماره موبایل صحیح نیست (مثال: 09123456789)'); return; }

            btn.prop('disabled', true).text('در حال ارسال کد...');

            $.post(reyhan_front_obj.ajax_url, {
                action: 'reyhan_send_otp',
                security: reyhan_front_obj.nonce,
                mobile: userMobile
            }, function (res) {
                if (res.success) {
                    $('#step-1-box').hide();
                    $('#step-2-box').fadeIn();
                    btn.text('ورود به سایت'); // تغییر متن دکمه برای مرحله بعد
                    btn.prop('disabled', false);
                    msg.html('<span style="color:green">' + res.data + '</span>');

                    // شروع تایمر 120 ثانیه
                    rp_start_timer(120, $('#rp-timer-sec'));
                } else {
                    btn.prop('disabled', false).text('دریافت کد ورود');
                    msg.html('<span style="color:red">' + res.data + '</span>');
                }
            }).fail(function () {
                btn.prop('disabled', false).text('دریافت کد ورود');
                msg.text('خطا در ارتباط با سرور.');
            });

        } else {
            var code = $('#rp_code').val();
            var mob = $('#rp_mobile').val();

            if (code.length < 4) { alert('کد تایید را وارد کنید'); return; }

            btn.prop('disabled', true).text('بررسی...');

            $.post(reyhan_front_obj.ajax_url, {
                action: 'reyhan_verify_otp',
                security: reyhan_front_obj.nonce,
                mobile: mob,
                code: code
            }, function (res) {
                if (res.success) {
                    msg.html('<span style="color:green">' + res.data + '</span>');
                    // رفرش صفحه
                    location.reload();
                } else {
                    btn.prop('disabled', false).text('ورود به سایت');
                    msg.html('<span style="color:red">' + res.data + '</span>');
                }
            });
        }
    });

    // دکمه ارسال مجدد
    $('#rp-resend-btn').click(function () {
        var userMobile = $('#rp_mobile').val();
        var myself = $(this);

        myself.text('در حال ارسال...').css('opacity', '0.5');

        $.post(reyhan_front_obj.ajax_url, {
            action: 'reyhan_send_otp',
            security: reyhan_front_obj.nonce,
            mobile: userMobile
        }, function (res) {
            myself.text('ارسال مجدد کد').css('opacity', '1');
            if (res.success) {
                // شروع مجدد تایمر
                rp_start_timer(120, $('#rp-timer-sec'));
                $('#rp-login-msg').html('<span style="color:green">کد مجدداً ارسال شد.</span>');
            } else {
                alert(res.data);
            }
        });
    });

    $('#rp-edit-number').click(function () {
        $('#step-2-box').hide();
        $('#step-1-box').fadeIn();
        // ریست کردن متن دکمه اصلی به حالت اول
        $('#rp-login-form-sms button[type="submit"]').text('دریافت کد ورود');
        clearInterval(rpTimerInterval); // توقف تایمر
    });

    $('#rp-edit-number').click(function () {
        $('#step-2-box').hide();
        $('#step-1-box').fadeIn();
        $('#rp-login-btn').text('دریافت کد ورود');
    });

    // ===============================================================
    // 3. Ticket Functions (Send, List, View)
    // ===============================================================

    window.loadUserTickets = function () {
        var listContainer = $('#rp-user-tickets-list');
        listContainer.html('<div style="text-align:center; padding:50px; color:#999;"><span class="dashicons dashicons-update" style="animation:spin 1s infinite linear; font-size:30px; display:inline-block; margin-bottom:15px;"></span><br>در حال بروزرسانی لیست...</div>');

        $('.rp-ticket-header').slideDown();
        $('#rp-user-new-ticket-form').slideUp();

        $.ajax({
            url: reyhan_front_obj.ajax_url,
            type: 'POST',
            dataType: 'json',
            data: { action: 'reyhan_user_list', security: reyhan_front_obj.nonce },
            success: function (res) {
                listContainer.html(res.success ? res.data : '<div class="rp-alert rp-alert-danger">' + (res.data || 'خطا') + '</div>');
            },
            error: function () {
                listContainer.html('<div class="rp-alert rp-alert-danger">خطا در ارتباط با سرور.</div>');
            }
        });
    };

    window.loadTicketConversation = function (ticketId) {
        $('#rp-user-tickets-list').html('<div style="text-align:center; padding:40px;">در حال بارگذاری...</div>');
        $('.rp-ticket-header').slideUp();
        $('.rp-faq-section-modern').slideUp();

        $.post(reyhan_front_obj.ajax_url, {
            action: 'reyhan_user_view',
            security: reyhan_front_obj.nonce,
            ticket_id: ticketId
        }, function (res) {
            $('#rp-user-tickets-list').html(res.success ? res.data : res.data);
        });
    };

    // --- تابع جدید: بستن تیکت توسط کاربر ---
    window.closeTicketByUser = function (ticketId) {
        if (!confirm('آیا از بستن این تیکت اطمینان دارید؟')) return;

        // تغییر متن دکمه برای فیدبک بصری (اختیاری)
        // چون دکمه داخل المنت جنریت شده است، دسترسی مستقیم نداریم، اما مشکلی نیست.

        $.post(reyhan_front_obj.ajax_url, {
            action: 'reyhan_user_close',
            security: reyhan_front_obj.nonce,
            ticket_id: ticketId
        }, function (res) {
            if (res.success) {
                alert(res.data);
                // رفرش کردن صفحه مکالمه برای اینکه وضعیت "بسته شده" نمایش داده شود
                window.loadTicketConversation(ticketId);
            } else {
                alert(res.data || 'خطا در بستن تیکت.');
            }
        });
    };

    $('#rp-ticket-submit-form').on('submit', function (e) {
        e.preventDefault();
        var form = $(this);
        var btn = form.find('button[type="submit"]');

        if (form.data('sending')) return;
        form.data('sending', true);
        btn.prop('disabled', true).text('در حال ارسال...');

        var fd = new FormData(this);
        fd.append('action', 'reyhan_user_submit');
        fd.append('security', reyhan_front_obj.nonce);

        $.ajax({
            url: reyhan_front_obj.ajax_url, type: 'POST', data: fd, contentType: false, processData: false,
            success: function (res) {
                alert(res.success ? 'تیکت ثبت شد' : res.data);
                if (res.success) {
                    $('#rp-ticket-creation-area').slideUp();
                    form[0].reset();
                    window.loadUserTickets();
                }
            },
            complete: function () {
                form.data('sending', false);
                btn.prop('disabled', false).text('ارسال تیکت');
            }
        });
    });

    // FAQ Search
    $('#rp-modern-faq-input').on('keyup', function () {
        var term = $(this).val().toLowerCase();
        var resBox = $('#rp-modern-faq-results');
        if (term.length < 2) { resBox.slideUp(); return; }

        if (typeof rp_faq_db !== 'undefined') {
            var hits = rp_faq_db.filter(function (item) { return (item.q + item.a).toLowerCase().indexOf(term) > -1; });
            var html = hits.map(function (f) { return '<div class="rp-faq-result-item" onclick="$(this).find(\'.rp-faq-a\').slideToggle()"><div class="rp-faq-q">' + f.q + '</div><div class="rp-faq-a">' + f.a + '</div></div>'; }).join('');
            resBox.html(html || '<div style="padding:10px;">موردی یافت نشد.</div>').slideDown();
        }
    });

    // ===============================================================
    // 4. Profile Management & Settings
    // ===============================================================

    // Change Profile Picture
    $('#rp_avatar_input').change(function () {
        if (this.files && this.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) { $('#rp-profile-preview').attr('src', e.target.result); }
            reader.readAsDataURL(this.files[0]);

            var fd = new FormData();
            fd.append('action', 'reyhan_update_avatar');
            fd.append('security', reyhan_front_obj.nonce);
            fd.append('avatar', this.files[0]);

            $.ajax({
                url: reyhan_front_obj.ajax_url, type: 'POST', data: fd, contentType: false, processData: false,
                success: function (res) { alert(res.data); }
            });
        }
    });

    // Save General Info
    $('#rp-general-info-form').on('submit', function (e) {
        e.preventDefault();
        var btn = $(this).find('button');
        btn.prop('disabled', true).text('در حال ذخیره...');

        $.post(reyhan_front_obj.ajax_url, {
            action: 'reyhan_update_general_info',
            security: reyhan_front_obj.nonce,
            first_name: $(this).find('input[name="first_name"]').val(),
            last_name: $(this).find('input[name="last_name"]').val(),
            email: $(this).find('input[name="email"]').val()
        }, function (res) {
            alert(res.data);
            btn.prop('disabled', false).text('ذخیره اطلاعات عمومی');
            if (res.success) location.reload();
        });
    });

    // Change Password
    $('#rp-password-form').on('submit', function (e) {
        e.preventDefault();
        var p1 = $(this).find('input[name="new_pass"]').val();
        var p2 = $(this).find('input[name="conf_pass"]').val();

        if (p1 !== p2) { alert('رمز عبور و تکرار آن یکسان نیستند.'); return; }
        if (p1.length < 6) { alert('رمز عبور باید حداقل 6 کاراکتر باشد.'); return; }

        var btn = $(this).find('button');
        btn.prop('disabled', true).text('...');

        $.post(reyhan_front_obj.ajax_url, {
            action: 'reyhan_update_password',
            security: reyhan_front_obj.nonce,
            pass: p1
        }, function (res) {
            alert(res.data);
            btn.prop('disabled', false).text('تغییر رمز عبور');
            if (res.success) $('#rp-password-form')[0].reset();
        });
    });

    // Send Mobile OTP (Change Number)
    $('#rp-send-mobile-otp').click(function () {
        var newMobile = $('#rp-new-mobile').val();
        if (newMobile.length < 10) { alert('شماره موبایل معتبر نیست.'); return; }

        var btn = $(this);
        btn.prop('disabled', true).text('ارسال...');

        $.post(reyhan_front_obj.ajax_url, {
            action: 'reyhan_send_otp_update',
            security: reyhan_front_obj.nonce,
            mobile: newMobile
        }, function (res) {
            if (res.success) {
                $('#rp-mobile-verify-box').slideDown();
                btn.hide();
                alert('کد تایید ارسال شد.');
            } else {
                alert(res.data);
                btn.prop('disabled', false).text('دریافت کد تایید');
            }
        });
    });

    // Verify Mobile OTP
    $('#rp-verify-mobile-otp').click(function () {
        var code = $('#rp-mobile-otp-input').val();
        var mobile = $('#rp-new-mobile').val();

        $.post(reyhan_front_obj.ajax_url, {
            action: 'reyhan_verify_otp_update',
            security: reyhan_front_obj.nonce,
            mobile: mobile,
            code: code
        }, function (res) {
            if (res.success) {
                alert('شماره موبایل با موفقیت تغییر کرد.');
                location.reload();
            } else {
                alert(res.data);
            }
        });
    });

    // ===============================================================
    // 5. WooCommerce Orders Management
    // ===============================================================
    $(document).on('click', '.rp-view-order-btn', function (e) {
        e.preventDefault();
        var btn = $(this);
        var orderId = btn.data('id');
        var container = $('#rp-single-order-content');
        var listSection = $('#rp-order-list-container');
        var detailSection = $('#rp-single-order-container');

        listSection.slideUp(300);
        detailSection.slideDown(300);
        $('#rp-single-order-id').text('#' + orderId);
        container.html('<div style="text-align:center; padding:50px; color:#999;"><span class="dashicons dashicons-update" style="animation:spin 1s infinite linear; font-size:40px;"></span><br>در حال دریافت جزئیات سفارش...</div>');

        $.post(reyhan_front_obj.ajax_url, {
            action: 'reyhan_view_order',
            security: reyhan_front_obj.nonce,
            order_id: orderId
        }, function (res) {
            if (res.success) {
                container.html(res.data).hide().fadeIn();
            } else {
                container.html('<div class="rp-alert rp-alert-danger">' + res.data + '</div>');
            }
        });
    });

    $(document).on('click', '#rp-back-to-orders', function (e) {
        e.preventDefault();
        $('#rp-single-order-container').slideUp(300);
        $('#rp-order-list-container').slideDown(300);
    });

});