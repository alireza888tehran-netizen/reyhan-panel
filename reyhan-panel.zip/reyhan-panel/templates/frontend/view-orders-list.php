<?php 
if ( ! defined( 'ABSPATH' ) ) { exit; } 

if ( ! class_exists( 'WooCommerce' ) ) {
    echo '<div class="rp-error">' . esc_html__('فروشگاه فعال نیست.', 'reyhan-panel') . '</div>';
    return;
}
?>

<div class="rp-orders-wrapper">
    <?php if ( ! empty( $orders ) ) : ?>
        <table class="rp-orders-table">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'شماره سفارش', 'reyhan-panel' ); ?></th>
                    <th><?php esc_html_e( 'تاریخ', 'reyhan-panel' ); ?></th>
                    <th><?php esc_html_e( 'وضعیت', 'reyhan-panel' ); ?></th>
                    <th><?php esc_html_e( 'مبلغ کل', 'reyhan-panel' ); ?></th>
                    <th><?php esc_html_e( 'عملیات', 'reyhan-panel' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $orders as $order_id ) : 
                    $order = wc_get_order( $order_id );
                    if ( ! $order ) continue;
                    
                    $status_label = wc_get_order_status_name( $order->get_status() );
                    $status_class = 'rp-order-status-' . esc_attr( $order->get_status() );
                    ?>
                    <tr>
                        <td>
                            <span class="rp-order-id">#<?php echo esc_html( $order->get_order_number() ); ?></span>
                        </td>
                        <td>
                            <span class="rp-order-date"><?php echo esc_html( wc_format_datetime( $order->get_date_created() ) ); ?></span>
                        </td>
                        <td>
                            <span class="rp-badge <?php echo esc_attr( $status_class ); ?>">
                                <?php echo esc_html( $status_label ); ?>
                            </span>
                        </td>
                        <td>
                            <?php 
                            echo wp_kses_post( $order->get_formatted_order_total() ); 
                            ?>
                        </td>
                        <td>
                            <button class="rp-btn-view-order" onclick="loadSingleOrder(<?php echo intval( $order_id ); ?>)">
                                <?php esc_html_e( 'جزئیات', 'reyhan-panel' ); ?>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else : ?>
        <div class="rp-empty-state">
            <img src="<?php echo esc_url( REYHAN_URL . 'assets/images/icon-panel.svg' ); ?>" alt="Empty">
            <p><?php esc_html_e( 'هنوز سفارشی ثبت نکرده‌اید.', 'reyhan-panel' ); ?></p>
            <a href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>" class="rp-btn-primary">
                <?php esc_html_e( 'مشاهده فروشگاه', 'reyhan-panel' ); ?>
            </a>
        </div>
    <?php endif; ?>
</div>