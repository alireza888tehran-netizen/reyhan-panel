<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<div class="rp-orders-wrapper">
    <?php if ( empty($orders) ): ?>
        <div style="text-align:center; padding: 50px 20px;">
            <span class="dashicons dashicons-cart" style="font-size: 60px; color: #eee; width: 60px; height: 60px;"></span>
            <h4 style="color:#777; margin-top:15px;"><?php esc_html_e('هنوز هیچ سفارشی ثبت نکرده‌اید!', 'reyhan-panel'); ?></h4>
            <?php if(function_exists('wc_get_page_permalink')): ?>
                <a href="<?php echo esc_url(wc_get_page_permalink('shop')); ?>" class="rp-btn-primary" style="margin-top:15px; display:inline-block;">
                    <?php esc_html_e('مشاهده محصولات', 'reyhan-panel'); ?>
                </a>
            <?php endif; ?>
        </div>
    <?php else: ?>
        
        <div class="rp-table-responsive">
            <table class="rp-modern-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e('شماره سفارش', 'reyhan-panel'); ?></th>
                        <th><?php esc_html_e('تاریخ', 'reyhan-panel'); ?></th>
                        <th><?php esc_html_e('وضعیت', 'reyhan-panel'); ?></th>
                        <th><?php esc_html_e('مبلغ کل', 'reyhan-panel'); ?></th>
                        <th><?php esc_html_e('عملیات', 'reyhan-panel'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order_id): 
                        $order = wc_get_order($order_id);
                        if (!$order) continue;
                        
                        $status = $order->get_status();
                        $status_name = wc_get_order_status_name($status);
                        
                        // تعیین کلاس رنگی برای وضعیت
                        $status_class = 'rp-status-pending';
                        if(in_array($status, ['completed'])) $status_class = 'rp-status-completed';
                        if(in_array($status, ['processing'])) $status_class = 'rp-status-processing';
                        if(in_array($status, ['on-hold'])) $status_class = 'rp-status-on-hold';
                        if(in_array($status, ['cancelled', 'failed'])) $status_class = 'rp-status-cancelled';
                    ?>
                    <tr>
                        <td>
                            <strong>#<?php echo $order->get_order_number(); ?></strong>
                            <div style="font-size:11px; color:#999; margin-top:3px;"><?php echo count($order->get_items()); ?> <?php esc_html_e('محصول', 'reyhan-panel'); ?></div>
                        </td>
                        <td><?php echo date_i18n(get_option('date_format'), $order->get_date_created()->getTimestamp()); ?></td>
                        <td><span class="rp-status-badge <?php echo esc_attr($status_class); ?>"><?php echo esc_html($status_name); ?></span></td>
                        <td><?php echo $order->get_formatted_order_total(); ?></td>
                        <td>
                            <button type="button" class="rp-btn-view" onclick="loadSingleOrder(<?php echo $order_id; ?>)">
                                <span class="dashicons dashicons-visibility"></span>
                                <?php esc_html_e('مشاهده', 'reyhan-panel'); ?>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    <?php endif; ?>
</div>