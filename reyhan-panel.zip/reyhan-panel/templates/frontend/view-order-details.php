<?php 
if ( ! defined( 'ABSPATH' ) ) { exit; } 
$order = wc_get_order($order_id);
if (!$order) { echo '<div class="rp-alert rp-alert-danger">'.__('سفارش یافت نشد.', 'reyhan-panel').'</div>'; return; }

$status = $order->get_status();
$status_name = wc_get_order_status_name($status);
$status_class = 'rp-status-pending';
if(in_array($status, ['completed'])) $status_class = 'rp-status-completed';
if(in_array($status, ['processing'])) $status_class = 'rp-status-processing';
if(in_array($status, ['on-hold'])) $status_class = 'rp-status-on-hold';
if(in_array($status, ['cancelled', 'failed'])) $status_class = 'rp-status-cancelled';
?>

<div class="rp-order-header">
    <button type="button" class="rp-back-btn" onclick="backToOrderList()">
        <span class="dashicons dashicons-arrow-right-alt2"></span> <?php esc_html_e('بازگشت به لیست', 'reyhan-panel'); ?>
    </button>
    <div style="display:flex; align-items:center; gap:10px;">
        <span style="font-size:18px; font-weight:bold;"><?php printf( __('سفارش #%s', 'reyhan-panel'), $order->get_order_number() ); ?></span>
        <span class="rp-status-badge <?php echo esc_attr($status_class); ?>"><?php echo esc_html($status_name); ?></span>
    </div>
</div>

<div class="rp-order-details-grid">
    
    <div class="rp-col-products">
        <div class="rp-order-card">
            <div class="rp-card-title">
                <span class="dashicons dashicons-cart"></span> <?php esc_html_e('اقلام سفارش', 'reyhan-panel'); ?>
            </div>
            
            <div class="rp-items-list">
                <?php foreach ( $order->get_items() as $item_id => $item ) : 
                    $product = $item->get_product();
                    $thumb = $product ? $product->get_image(array(60, 60)) : '';
                ?>
                <div class="rp-order-item">
                    <div class="rp-item-thumb"><?php echo $thumb; ?></div>
                    <div class="rp-item-meta">
                        <span class="rp-item-title"><?php echo esc_html( $item->get_name() ); ?></span>
                        <span class="rp-item-qty">x <?php echo esc_html( $item->get_quantity() ); ?></span>
                        
                        <?php if($product && $product->is_downloadable() && $order->is_download_permitted()): ?>
                            <div style="margin-top:5px;">
                                <?php foreach( $order->get_item_downloads( $item ) as $download ): ?>
                                    <a href="<?php echo esc_url( $download['download_url'] ); ?>" class="rp-btn-small" target="_blank" style="font-size:11px; padding:3px 8px;">
                                        <span class="dashicons dashicons-download"></span> <?php echo esc_html( $download['name'] ); ?>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="rp-item-price">
                        <?php echo $order->get_formatted_line_subtotal( $item ); ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <div class="rp-col-info">
        <div class="rp-order-card" style="margin-bottom:20px;">
            <div class="rp-card-title">
                <span class="dashicons dashicons-chart-bar"></span> <?php esc_html_e('صورتحساب', 'reyhan-panel'); ?>
            </div>
            <div class="rp-order-totals">
                <?php foreach ( $order->get_order_item_totals() as $key => $total ) : ?>
                    <div class="rp-order-totals-row <?php echo ($key=='order_total') ? 'final' : ''; ?>">
                        <span><?php echo esc_html( $total['label'] ); ?></span>
                        <span><?php echo wp_kses_post( $total['value'] ); ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="rp-order-card">
            <div class="rp-card-title">
                <span class="dashicons dashicons-location"></span> <?php esc_html_e('اطلاعات ارسال', 'reyhan-panel'); ?>
            </div>
            <div style="font-size:13px; line-height:1.8; color:#555;">
                <strong><?php esc_html_e('تحویل گیرنده:', 'reyhan-panel'); ?></strong> <?php echo esc_html($order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name()); ?><br>
                <strong><?php esc_html_e('آدرس:', 'reyhan-panel'); ?></strong> <?php echo esc_html($order->get_shipping_address_1() . ' ' . $order->get_shipping_city() . ' ' . $order->get_shipping_state()); ?><br>
                <strong><?php esc_html_e('کد پستی:', 'reyhan-panel'); ?></strong> <?php echo esc_html($order->get_shipping_postcode()); ?><br>
                <strong><?php esc_html_e('تلفن:', 'reyhan-panel'); ?></strong> <?php echo esc_html($order->get_billing_phone()); ?>
            </div>
        </div>
    </div>

</div>