<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<div class="rp-order-details-modern">
    <div class="rp-order-header-card">
        <div class="rp-oh-info">
            <h3><?php printf(__('سفارش #%s', 'reyhan-panel'), $order->get_order_number()); ?></h3>
            <span class="rp-order-date"><?php echo date_i18n(get_option('date_format'), $order->get_date_created()->getTimestamp()); ?></span>
        </div>
        <div class="rp-oh-status">
            <span class="rp-badge status-<?php echo esc_attr($order->get_status()); ?>"><?php echo esc_html(wc_get_order_status_name($order->get_status())); ?></span>
        </div>
    </div>

    <div class="rp-order-items-card">
        <h4><?php esc_html_e('اقلام سفارش', 'reyhan-panel'); ?></h4>
        <div class="rp-items-table-wrap">
            <table class="rp-items-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e('محصول', 'reyhan-panel'); ?></th>
                        <th><?php esc_html_e('قیمت', 'reyhan-panel'); ?></th>
                        <th><?php esc_html_e('تعداد', 'reyhan-panel'); ?></th>
                        <th><?php esc_html_e('جمع کل', 'reyhan-panel'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($order->get_items() as $item_id => $item): 
                        $product = $item->get_product();
                        $img = $product ? $product->get_image(['50', '50']) : '';
                    ?>
                    <tr>
                        <td class="rp-item-name-col">
                            <div class="rp-item-thumb"><?php echo $img; ?></div>
                            <div class="rp-item-meta">
                                <strong><?php echo esc_html($item->get_name()); ?></strong>
                                <?php if($product && $product->is_downloadable() && $order->is_paid()): 
                                    $downloads = $order->get_downloadable_items();
                                    foreach($downloads as $download) {
                                        if($download['product_id'] == $product->get_id()) {
                                            echo '<br><a href="'.esc_url($download['download_url']).'" class="rp-dl-link">⬇ '.esc_html__('دانلود فایل', 'reyhan-panel').'</a>';
                                        }
                                    }
                                endif; ?>
                            </div>
                        </td>
                        <td><?php echo wc_price($order->get_item_total($item, false, true)); ?></td>
                        <td><?php echo esc_html($item->get_quantity()); ?></td>
                        <td><?php echo wc_price($item->get_total()); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <div class="rp-order-totals">
            <div class="rp-total-row"><span><?php esc_html_e('جمع جزء:', 'reyhan-panel'); ?></span> <span><?php echo $order->get_subtotal_to_display(); ?></span></div>
            <div class="rp-total-row"><span><?php esc_html_e('هزینه ارسال:', 'reyhan-panel'); ?></span> <span><?php echo $order->get_shipping_to_display(); ?></span></div>
            <?php if($order->get_total_discount() > 0): ?>
                <div class="rp-total-row discount"><span><?php esc_html_e('تخفیف:', 'reyhan-panel'); ?></span> <span>-<?php echo wc_price($order->get_total_discount()); ?></span></div>
            <?php endif; ?>
            <div class="rp-total-row final"><span><?php esc_html_e('مبلغ نهایی:', 'reyhan-panel'); ?></span> <span><?php echo $order->get_formatted_order_total(); ?></span></div>
        </div>
    </div>

    <div class="rp-order-addresses-grid">
        <div class="rp-addr-card">
            <h4><?php esc_html_e('آدرس صورتحساب', 'reyhan-panel'); ?></h4>
            <address><?php echo wp_kses_post($order->get_formatted_billing_address() ?: __('ثبت نشده', 'reyhan-panel')); ?></address>
            <div class="rp-addr-contact">
                <?php if($order->get_billing_phone()): ?><div>📞 <?php echo esc_html($order->get_billing_phone()); ?></div><?php endif; ?>
                <?php if($order->get_billing_email()): ?><div>✉️ <?php echo esc_html($order->get_billing_email()); ?></div><?php endif; ?>
            </div>
        </div>
        <?php if($order->needs_shipping_address()): ?>
        <div class="rp-addr-card">
            <h4><?php esc_html_e('آدرس حمل و نقل', 'reyhan-panel'); ?></h4>
            <address><?php echo wp_kses_post($order->get_formatted_shipping_address() ?: __('همانند صورتحساب', 'reyhan-panel')); ?></address>
        </div>
        <?php endif; ?>
    </div>
    
    <div style="text-align:left; margin-top:20px;">
        <button onclick="backToOrderList()" class="rp-btn-secondary"><span class="dashicons dashicons-arrow-left-alt"></span> <?php esc_html_e('بازگشت به لیست', 'reyhan-panel'); ?></button>
    </div>
</div>