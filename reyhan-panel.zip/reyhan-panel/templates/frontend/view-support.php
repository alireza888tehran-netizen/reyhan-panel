<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div id="reyhan-app-root" class="rp-standalone">
    <div class="rp-content" style="width:100%; padding:20px;">
        <div class="rp-ticket-header">
            <h2><?php esc_html_e('پشتیبانی', 'reyhan-panel'); ?></h2>
            <button class="rp-btn-new-ticket" onclick="jQuery('#rp-user-new-ticket-form').slideToggle()">
                + <?php esc_html_e('تیکت جدید', 'reyhan-panel'); ?>
            </button>
        </div>
        
        <div id="rp-user-new-ticket-form" class="rp-new-ticket-box" style="display:none;">
            <form id="rp-ticket-submit-form">
                <input type="text" name="title" class="rp-input-modern" placeholder="<?php esc_attr_e('موضوع', 'reyhan-panel'); ?>" required>
                <textarea name="message" class="rp-input-modern" rows="5" placeholder="<?php esc_attr_e('پیام...', 'reyhan-panel'); ?>" required></textarea>
                <button type="submit" class="rp-btn-new-ticket"><?php esc_html_e('ارسال', 'reyhan-panel'); ?></button>
            </form>
        </div>

        <div id="rp-user-tickets-list">
            <?php esc_html_e('در حال بارگذاری...', 'reyhan-panel'); ?>
        </div>
        
        <script>
            jQuery(document).ready(function($){ 
                if(typeof window.loadUserTickets === "function") window.loadUserTickets(); 
            });
        </script>
    </div>
</div>