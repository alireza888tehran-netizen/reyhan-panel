<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<div id="reyhan-app-root" class="rp-standalone">
    <div class="rp-content" style="width:100%; margin:0; padding:20px;">
        <div class="rp-ticket-header" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
            <h2 style="margin:0; font-size:20px; color:#333;">پشتیبانی</h2>
            <div style="display:flex; gap:10px;">
                <button class="rp-btn-secondary" onclick="loadUserTickets()" style="background:#f5f5f5; color:#555; border:none; padding:10px 15px; border-radius:8px; cursor:pointer;">🔄 بروزرسانی</button>
                <button class="rp-btn-new-ticket" onclick="jQuery('#rp-user-new-ticket-form').slideToggle()">+ ثبت تیکت جدید</button>
            </div>
        </div>
        
        <div id="rp-user-new-ticket-form" class="rp-new-ticket-box" style="display:none;">
            <h3 style="margin-top:0; border-bottom:1px solid #eee; padding-bottom:15px; margin-bottom:20px;">ارسال درخواست جدید</h3>
            <form id="rp-ticket-submit-form" enctype="multipart/form-data">
                <div class="rp-form-grid"><div><label class="rp-form-label">موضوع</label><input type="text" name="title" class="rp-input-modern" required></div>
                <div><label class="rp-form-label">دپارتمان</label><select name="department" class="rp-input-modern"><?php
                    if($depts && is_array($depts)) foreach($depts as $d) echo '<option value="'.$d['name'].'">'.$d['name'].'</option>'; else echo '<option value="پشتیبانی">پشتیبانی</option>';
                ?></select></div></div>
                <div class="rp-form-grid" style="margin-bottom:20px;"><div><label class="rp-form-label">اولویت</label><select name="priority" class="rp-input-modern"><option value="high">مهم</option><option value="medium" selected>متوسط</option><option value="low">کم</option></select></div>
                <div><label class="rp-form-label">ضمیمه</label><input type="file" name="attachment" class="rp-input-modern" style="padding:9px;"></div></div>
                <label class="rp-form-label">پیام</label><textarea name="message" class="rp-input-modern" rows="5" required></textarea>
                <div style="margin-top:20px; text-align:left;"><button type="submit" class="rp-btn-new-ticket" style="width:150px;">ارسال تیکت</button></div>
            </form>
        </div>
        
        <div id="rp-user-tickets-list"><div style="text-align:center; padding:40px; color:#999;">در حال بارگذاری...</div></div>
        <script>jQuery(document).ready(function($){ if(typeof window.loadUserTickets === "function") { window.loadUserTickets(); } });</script>
    </div>
</div>