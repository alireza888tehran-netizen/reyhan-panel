<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<div class="rp-chat-header" style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #eee; padding-bottom:15px; margin-bottom:20px;">
    <div>
        <h3 style="margin:0; font-size:16px;">#<?php echo $ticket->ID; ?> <?php echo esc_html( $ticket->post_title ); ?></h3>
        <span style="font-size:12px; color:#888;">دپارتمان: <?php echo esc_html( $dept ); ?></span>
    </div>
    <div style="display:flex; gap:10px;">
        <?php if($status !== 'closed'): ?>
            <button onclick="closeTicketByUser(<?php echo $ticket->ID; ?>)" style="background:#fff; border:1px solid #4CAF50; color:#4CAF50; padding:5px 15px; border-radius:5px; cursor:pointer; font-size:12px; font-weight:bold;">بستن تیکت</button>
        <?php endif; ?>
        <button onclick="loadUserTickets()" style="background:#f5f5f5; border:1px solid #ddd; padding:5px 15px; border-radius:5px; cursor:pointer; color:#555;">بازگشت</button>
    </div>
</div>

<div class="rp-chat-box" style="background:#fafafa; border:1px solid #eee; border-radius:10px; padding:20px; height:400px; overflow-y:auto; margin-bottom:20px;">
    
    <?php 
    // ۱. نمایش پیام اول (متن تیکت)
    // برای این بخش از پارشیال استفاده نمی‌کنیم یا می‌توانیم دستی فراخوانی کنیم
    // برای سادگی اینجا include می‌کنیم
    $comment = $ticket; 
    $is_user = true; 
    $is_first = true;
    $display_name = 'شما';
    include REYHAN_DIR . 'templates/frontend/partials/chat-message.php';
    unset($is_first); // پاک کردن پرچم

    // ۲. نمایش پاسخ‌ها
    foreach( $comments as $c ):
        $is_user = ( $c->user_id == $ticket->post_author );
        
        // تعیین نام و آواتار
        $avatar_html = '';
        if ( $is_user ) {
            $display_name = 'شما';
        } else {
            $u_info = get_userdata( $c->user_id );
            $display_name = $u_info ? $u_info->display_name : 'پشتیبانی';
            
            // آواتار پشتیبان
            $custom_avatar = get_user_meta( $c->user_id, 'reyhan_user_avatar', true );
            $def_avatar = REYHAN_URL . 'assets/images/user.png';
            $img_src = !empty($custom_avatar) ? $custom_avatar : $def_avatar;
            $avatar_html = '<img src="'.esc_url($img_src).'" class="rp-chat-avatar">';
        }

        $comment = $c; // متغیر برای پارشیال
        include REYHAN_DIR . 'templates/frontend/partials/chat-message.php';
    endforeach; 
    ?>

</div>

<?php if ( $status === 'closed' ): ?>
    <div class="rp-alert rp-alert-warning" style="margin-top:20px; text-align:center;"><span class="dashicons dashicons-lock"></span> این تیکت بسته شده است.</div>
<?php else: ?>
    <div class="rp-reply-box">
        <form id="rp-reply-form" enctype="multipart/form-data">
            <input type="hidden" name="ticket_id" value="<?php echo $ticket->ID; ?>">
            <textarea name="reply_message" class="rp-input-modern" rows="3" placeholder="پاسخ خود را بنویسید..." required style="width:100%; margin-bottom:10px;"></textarea>
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <input type="file" name="reply_attachment" style="font-size:12px;">
                <button type="submit" class="rp-btn-new-ticket">ارسال پاسخ</button>
            </div>
        </form>
    </div>
    
    <script>
        var chatBox = document.querySelector('.rp-chat-box'); 
        if(chatBox) chatBox.scrollTop = chatBox.scrollHeight;
        
        jQuery('#rp-reply-form').on('submit', function(e){
            e.preventDefault();
            var btn = jQuery(this).find('button[type="submit"]');
            var fd = new FormData(this);
            fd.append('action', 'reyhan_user_reply'); 
            fd.append('security', reyhan_front_obj.nonce);
            btn.prop('disabled', true).text('در حال ارسال...');
            jQuery.ajax({
                url: reyhan_front_obj.ajax_url, type: 'POST', data: fd, contentType: false, processData: false,
                success: function(res) { 
                    if(res.success) window.loadTicketConversation(<?php echo $ticket->ID; ?>); 
                    else { alert(res.data || 'خطا'); btn.prop('disabled', false).text('ارسال پاسخ'); } 
                },
                error: function() { btn.prop('disabled', false).text('ارسال پاسخ'); alert('خطا در ارتباط'); }
            });
        });
    </script>
<?php endif; ?>