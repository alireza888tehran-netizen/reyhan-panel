<?php if ( ! defined( 'ABSPATH' ) ) { exit; } 
/**
 * متغیرها: $t (آبجکت تیکت)
 */
$status = get_post_meta( $t->ID, '_ticket_status', true );
$st_label = ( $status == 'open' ) ? 'باز' : ( ( $status == 'answered' ) ? 'پاسخ داده شده' : 'بسته' );
$st_class = 'rp-order-status-' . $status; // استفاده از کلاس‌های CSS موجود


// تعیین استایل وضعیت (برای هماهنگی با CSS فعلی)
$badge_style = '';
if($status == 'open') $badge_style = 'background:#fff3e0; color:#ef6c00; border:1px solid #ffe0b2;';
elseif($status == 'answered') $badge_style = 'background:#e8f5e9; color:#2e7d32; border:1px solid #c8e6c9;';
elseif($status == 'closed') $badge_style = 'background:#f5f5f5; color:#757575; border:1px solid #e0e0e0;';
?>
<tr>
    <td style="color:#888;">#<?php echo $t->ID; ?></td>
    <td style="font-weight:bold;"><?php echo esc_html( $t->post_title ); ?></td>
    <td style="text-align:center;">
        <span class="rp-status-badge" style="<?php echo $badge_style; ?>"><?php echo $st_label; ?></span>
    </td>
    <td style="text-align:center;">
        <div style="display:flex; flex-direction:column; align-items:center; gap:3px;">
            <span class="rp-badge-common" style="background:#f3e5f5; color:#7b1fa2; font-size:10px; padding:2px 8px; border-radius:10px;">
                <?php echo get_the_date( 'Y/m/d', $t ); ?>
            </span>
            <span class="rp-badge-common" style="background:#e3f2fd; color:#1976d2; font-size:10px; padding:2px 8px; border-radius:10px;">
                <?php echo get_the_date( 'H:i', $t ); ?>
            </span>
        </div>
    </td>
    <td style="text-align:center;">
        <button class="t-view-link" onclick="window.loadTicketConversation(<?php echo $t->ID; ?>)">مشاهده</button>
    </td>
</tr>