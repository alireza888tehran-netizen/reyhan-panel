<?php if ( ! defined( 'ABSPATH' ) ) { exit; } 

$is_first_msg = isset($is_first_msg) ? $is_first_msg : false;
$is_user      = isset($is_user) ? $is_user : false;

$content = $is_first_msg ? $comment->post_content : $comment->comment_content;

$att = $is_first_msg 
    ? get_post_meta( $comment->ID, '_ticket_attachment', true ) 
    : get_comment_meta( $comment->comment_ID, 'attachment', true );

$time = $is_first_msg 
    ? get_the_date('H:i', $comment) 
    : get_comment_date('H:i', $comment);

$align_items = $is_user ? 'flex-end' : 'flex-start';
$bubble_bg   = $is_user ? '#e3f2fd' : '#ffffff'; 
$bubble_border = $is_user ? '1px solid #bbdefb' : '1px solid #e2e8f0';
$radius_style = $is_user ? 'border-bottom-left-radius: 4px;' : 'border-bottom-right-radius: 4px;';
$text_color   = $is_user ? '#1565c0' : '#2d3748';
?>

<div style="display:flex; flex-direction:column; align-items:<?php echo esc_attr($align_items); ?>; width:100%; margin-bottom: 5px;">
    <div style="display:flex; align-items:flex-end; gap:12px; max-width:85%; <?php echo esc_attr( $is_user ? 'flex-direction:row;' : 'flex-direction:row-reverse;' ); ?>">
        
        <div class="rp-msg-bubble" style="background:<?php echo esc_attr($bubble_bg); ?> !important; border:<?php echo esc_attr($bubble_border); ?> !important; padding:15px; border-radius:18px; <?php echo esc_attr( $radius_style ); ?> box-shadow:0 2px 6px rgba(0,0,0,0.04); position:relative; min-width: 140px;">
            
            <div style="font-size:12px; font-weight:800; color:<?php echo esc_attr($text_color); ?> !important; margin-bottom:8px; display:flex; justify-content:space-between; align-items:center; gap:25px;">
                <span style="color:inherit !important;"><?php echo esc_html($display_name); ?></span>
                <span style="font-size:10px; font-weight:normal; color:#a0aec0 !important;"><?php echo esc_html($time); ?></span>
            </div>

            <div style="font-size:14px !important; line-height:1.7 !important; color:#2d3748 !important; white-space: pre-wrap; text-align: right;">
                <?php echo wp_kses_post( wpautop($content) ); ?>
            </div>

            <?php if ( !empty($att) ): ?>
                <div style="margin-top:12px; padding-top:10px; border-top:1px dashed rgba(0,0,0,0.1);">
                    <a href="<?php echo esc_url( $att ); ?>" target="_blank" style="text-decoration:none !important; display:inline-flex; align-items:center; gap:6px; font-size:12px; color:#e53e3e !important; background:#fff5f5; padding:6px 12px; border-radius:8px; border:1px solid #fed7d7;">
                        <span class="dashicons dashicons-paperclip"></span> <?php esc_html_e('دانلود فایل پیوست', 'reyhan-panel'); ?>
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <div style="flex-shrink:0;">
            <?php 
            $def_img = REYHAN_URL . 'assets/images/user.png';
            $img_src = !empty($avatar) ? $avatar : $def_img;
            ?>
            <img src="<?php echo esc_url($img_src); ?>" style="width:38px !important; height:38px !important; border-radius:50% !important; object-fit:cover !important; border:2px solid #ffffff !important; box-shadow:0 2px 8px rgba(0,0,0,0.12) !important;" alt="Avatar">
        </div>

    </div>
</div>