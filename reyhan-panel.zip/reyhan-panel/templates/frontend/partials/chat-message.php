<?php if ( ! defined( 'ABSPATH' ) ) { exit; } 
/**
 * متغیرها: $comment (آبجکت پیام), $is_user (آیا کاربر است؟), $display_name, $avatar_html (اختیاری)
 */
$cls = $is_user ? 'user' : 'admin';
$content = isset($is_first) ? $comment->post_content : $comment->comment_content;
$date = isset($is_first) ? $comment->post_date : $comment->comment_date;
$att_url = '';

if ( isset($is_first) ) {
    $att_url = get_post_meta( $comment->ID, '_ticket_attachment', true );
} else {
    $att_url = get_comment_meta( $comment->comment_ID, 'attachment', true );
}
?>
<div class="rp-msg-row <?php echo $cls; ?>">
    <div class="rp-msg-bubble">
        <div class="rp-msg-meta">
            <?php echo esc_html( $display_name ); ?> 
            <span style="font-size:10px; color:<?php echo $is_user?'#999':'#5c6bc0'; ?>;">(<?php echo date_i18n('Y/m/d H:i', strtotime($date)); ?>)</span>
        </div>
        <div class="rp-msg-content"><?php echo wpautop( $content ); ?></div>
        <?php if ( $att_url ): ?>
            <div class="rp-msg-att"><a href="<?php echo esc_url( $att_url ); ?>" target="_blank">📎 دانلود ضمیمه</a></div>
        <?php endif; ?>
    </div>
    <?php if ( ! $is_user && ! empty( $avatar_html ) ) echo '<div class="rp-msg-avatar">' . $avatar_html . '</div>'; ?>
</div>