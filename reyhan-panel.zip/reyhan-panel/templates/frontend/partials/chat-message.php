<?php if ( ! defined( 'ABSPATH' ) ) { exit; } 
// تشخیص نوع پیام
$cls = $is_user ? 'rp-msg-user' : 'rp-msg-admin';
$content = isset($is_first_msg) && $is_first_msg ? $comment->post_content : $comment->comment_content;
$att = isset($is_first_msg) && $is_first_msg ? get_post_meta( $comment->ID, '_ticket_attachment', true ) : get_comment_meta( $comment->comment_ID, 'attachment', true );
$time = isset($is_first_msg) && $is_first_msg ? get_the_date('H:i', $comment) : get_comment_date('H:i', $comment);

// استایل‌های درون‌خطی برای اطمینان از نمایش صحیح
$bubble_bg = $is_user ? '#e3f2fd' : '#ffffff'; // آبی کمرنگ برای کاربر، سفید برای ادمین
$bubble_border = $is_user ? '1px solid #bbdefb' : '1px solid #e0e0e0';
$align = $is_user ? 'flex-end' : 'flex-start'; // کاربر چپ (چون rtl هست میشه چپ)، ادمین راست
// نکته: در RTL، flex-end می‌شود سمت چپ و flex-start می‌شود سمت راست.
// معمولا در چت فارسی: کاربر (خودم) سمت چپ، پشتیبان سمت راست.
// پس $is_user باید flex-end باشد.
?>

<div style="display:flex; flex-direction:column; align-items:<?php echo $align; ?>; width:100%;">
    
    <div style="display:flex; align-items:flex-end; gap:10px; max-width:80%; <?php echo $is_user ? 'flex-direction:row;' : 'flex-direction:row-reverse;'; ?>">
        
        <div style="background:<?php echo $bubble_bg; ?>; border:<?php echo $bubble_border; ?>; padding:12px 15px; border-radius:15px; border-bottom-<?php echo $is_user?'left':'right'; ?>-radius: 2px; position:relative; box-shadow:0 1px 2px rgba(0,0,0,0.05);">
            
            <div style="font-size:11px; font-weight:bold; color:<?php echo $is_user?'#1565c0':'#424242'; ?>; margin-bottom:5px;">
                <?php echo esc_html($display_name); ?>
            </div>

            <div style="font-size:13px; line-height:1.6; color:#333; white-space: pre-wrap;">
                <?php echo wpautop($content); ?>
            </div>

            <?php if ( $att ): ?>
                <div style="margin-top:10px; padding-top:10px; border-top:1px dashed rgba(0,0,0,0.1);">
                    <a href="<?php echo esc_url( $att ); ?>" target="_blank" style="text-decoration:none; display:flex; align-items:center; gap:5px; font-size:12px; color:<?php echo $is_user?'#1565c0':'#FF5722'; ?>;">
                        <span class="dashicons dashicons-paperclip"></span> <?php esc_html_e('دانلود فایل پیوست', 'reyhan-panel'); ?>
                    </a>
                </div>
            <?php endif; ?>

            <div style="text-align:left; font-size:10px; color:#999; margin-top:5px;">
                <?php echo esc_html($time); ?>
            </div>
        </div>

        <div style="flex-shrink:0;">
            <?php 
            $def_img = REYHAN_URL . 'assets/images/user.png';
            $img = !empty($avatar) ? $avatar : $def_img;
            ?>
            <img src="<?php echo esc_url($img); ?>" style="width:35px; height:35px; border-radius:50%; object-fit:cover; border:1px solid #eee;">
        </div>

    </div>
</div>