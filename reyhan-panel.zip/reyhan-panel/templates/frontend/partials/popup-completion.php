<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

$uid = get_current_user_id();
if ( ! $uid ) { return; }

$u = get_userdata($uid);
if ( ! $u ) { return; }

// وضعیت داده‌ها
$has_real_email = ( strpos($u->user_email, '@user.reyhan') === false ); 
$mobile         = get_user_meta($uid, 'mobile', true);
$has_mobile     = !empty($mobile);

// متغیرهای تصمیم‌گیری
$ask_mobile = false; $ask_email  = false; $ask_names  = false;
$title = ''; $desc = '';

if ( $has_real_email && ! $has_mobile ) {
    $ask_mobile = true;
    $title = 'تایید شماره موبایل';
    $desc  = 'برای امنیت بیشتر حساب کاربری، لطفاً شماره موبایل خود را ثبت کنید.';
}
elseif ( ! $has_real_email ) {
    $ask_email = true; $ask_names = true;
    $title = 'تکمیل اطلاعات کاربری';
    $desc  = 'لطفاً نام و ایمیل خود را جهت تکمیل پروفایل وارد نمایید.';
}
elseif ( empty($u->first_name) || empty($u->last_name) ) {
    $ask_names = true;
    $title = 'تکمیل نام و نام خانوادگی';
    $desc  = 'لطفاً نام خود را وارد کنید.';
}
else {
    return;
}
?>

<div id="rp-completion-overlay">
    <div class="rp-completion-box">
        <div class="rp-comp-icon">
            <span class="dashicons dashicons-admin-users"></span>
        </div>

        <h3 class="rp-font-target"><?php echo esc_html($title); ?></h3>
        <p class="rp-font-target"><?php echo esc_html($desc); ?></p>

        <form id="rp-forced-completion-form" onsubmit="return false;">
            <?php if ( $ask_names ): ?>
                <div class="rp-form-row-2">
                    <input type="text" name="first_name" class="rp-inp-modern rp-font-target" placeholder="نام" required>
                    <input type="text" name="last_name" class="rp-inp-modern rp-font-target" placeholder="نام خانوادگی" required>
                </div>
            <?php endif; ?>

            <?php if ( $ask_email ): ?>
                <div class="rp-inp-group">
                    <input type="email" name="email" class="rp-inp-modern ltr-inp rp-font-target" placeholder="ایمیل (مثال: name@gmail.com)" required>
                </div>
            <?php endif; ?>

            <?php if ( $ask_mobile ): ?>
                <div class="rp-inp-group">
                    <input type="text" name="mobile" class="rp-inp-modern ltr-inp rp-font-target"
                           placeholder="شماره موبایل (مثال: 0912xxxxxxx)" maxlength="11" required inputmode="numeric" autocomplete="tel">
                </div>
            <?php endif; ?>

            <div id="rp-comp-msg" class="rp-font-target"></div>

            <button type="button" class="rp-btn-submit-comp rp-font-target">
                <span class="dashicons dashicons-saved"></span> ذخیره اطلاعات
            </button>
        </form>
    </div>
</div>

<style>
    #rp-completion-overlay {
        position: fixed; top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(0, 0, 0, 0.5);
        z-index: 9999999;
        display: flex; align-items: center; justify-content: center;
        backdrop-filter: blur(5px); -webkit-backdrop-filter: blur(5px);
    }

    .rp-completion-box {
        background: #fff; width: 90%; max-width: 400px;
        padding: 30px; border-radius: 20px; text-align: center;
        box-shadow: 0 25px 60px rgba(0,0,0,0.3);
        position: relative;
        z-index: 10000000;
    }

    .rp-comp-icon {
        width: 70px; height: 70px; background: #e3f2fd; color: #1565c0;
        border-radius: 50%; margin: 0 auto 20px; display: flex;
        align-items: center; justify-content: center;
    }
    .rp-comp-icon .dashicons { font-size: 32px; width: 32px; height: 32px; font-family: dashicons !important; }

    .rp-completion-box h3 { margin: 0 0 10px; color: #333; font-weight: 800; font-size: 18px; }
    .rp-completion-box p { margin: 0 0 25px; color: #666; font-size: 13px; line-height: 1.6; }

    .rp-btn-submit-comp {
        width: 100%;
        background: var(--rp-gradient, linear-gradient(135deg, #2196F3, #1976D2));
        color: #fff; border: none; padding: 12px; border-radius: 10px;
        font-weight: bold; cursor: pointer; margin-top: 5px;
        display: flex; align-items: center; justify-content: center; gap: 8px;
        transition: all 0.3s ease;
        position: relative !important;
        z-index: 10000002 !important;
        pointer-events: auto !important;
    }
    .rp-btn-submit-comp:hover { opacity: 0.95; transform: translateY(-2px); box-shadow: 0 5px 15px rgba(33, 150, 243, 0.3); }
    .rp-btn-submit-comp:disabled { opacity: 0.7; cursor: not-allowed; transform: none; }

    .rp-inp-modern { margin-bottom: 12px; width: 100%; padding: 12px; border: 1px solid #e0e0e0; border-radius: 8px; box-sizing: border-box; transition: border 0.3s; }
    .rp-inp-modern:focus { border-color: #2196F3; outline: none; }
    .rp-form-row-2 { display: flex; gap: 10px; }

    /* پیام‌ها */
    #rp-comp-msg {
        margin-bottom: 15px;
        width: 100%;
        display: block !important;
        visibility: visible !important;
        opacity: 1 !important;
        min-height: 44px; /* تا پیام جا داشته باشه */
        position: relative;
        z-index: 10000001;
    }

    .rp-pop-msg {
        padding: 12px;
        border-radius: 8px;
        font-size: 13px;
        display: flex;
        align-items: center;
        justify-content: flex-start;
        gap: 10px;
        text-align: right;
        width: 100%;
        box-sizing: border-box;
        line-height: 1.5;
        position: relative !important;
        transform: none !important;
        visibility: visible !important;
        opacity: 1 !important;
    }

    .rp-pop-error {
        background-color: #ffebee !important;
        color: #c62828 !important;
        border: 1px solid #ffcdd2 !important;
    }

    .rp-pop-success {
        background-color: #e8f5e9 !important;
        color: #2e7d32 !important;
        border: 1px solid #c8e6c9 !important;
    }

    .rp-pop-info {
        background-color: #e3f2fd !important;
        color: #1565c0 !important;
        border: 1px solid #bbdefb !important;
    }

    .rp-completion-box { pointer-events: auto !important; }
</style>

<script>
(function () {
  "use strict";

  // 1) تبدیل اعداد فارسی/عربی به انگلیسی
  function rp_to_en_digits(s) {
    if (s == null) return "";
    return String(s)
      .replace(/[۰-۹]/g, d => "0123456789"["۰۱۲۳۴۵۶۷۸۹".indexOf(d)])
      .replace(/[٠-٩]/g, d => "0123456789"["٠١٢٣٤٥٦٧٨٩".indexOf(d)]);
  }

  // 2) نمایش پیام به شکل قطعی (حتی اگر CSS قالب بخواهد قایمش کند)
  function rp_show_msg(type, text) {
    var msg = document.getElementById("rp-comp-msg");
    if (!msg) return;

    msg.style.display = "block";
    msg.style.visibility = "visible";
    msg.style.opacity = "1";
    msg.style.minHeight = "44px";

    var icon = (type === "success") ? "dashicons-yes"
             : (type === "info")    ? "dashicons-update"
             : "dashicons-warning";

    msg.innerHTML =
      '<div class="rp-pop-msg rp-pop-' + type + '">' +
        '<span class="dashicons ' + icon + '"></span> ' +
        String(text || "") +
      "</div>";

    if (typeof window.rp_fix_popup_font_global === "function") {
      window.rp_fix_popup_font_global();
    }
  }

  // 3) فونت (همان کد خودت)
  window.rp_fix_popup_font_global = function () {
    var ref = document.querySelector(".rp-dashboard-box");
    if (!ref) ref = document.body;
    var style = window.getComputedStyle(ref);
    var font = style.fontFamily;
    if (font) {
      var targets = document.querySelectorAll(
        ".rp-completion-box, .rp-completion-box h3, .rp-completion-box p, .rp-completion-box input, .rp-completion-box button, .rp-font-target, .rp-pop-msg"
      );
      targets.forEach(function (el) { el.style.fontFamily = font; });
    }
  };
  setTimeout(window.rp_fix_popup_font_global, 200);

  // 4) تابع اصلی ارسال (تمیز + آزاد کردن Busy در همه مسیرها)
  window.rp_submit_profile_data = function (btn) {
    var form = document.getElementById("rp-forced-completion-form");
    var msg  = document.getElementById("rp-comp-msg");

    if (!form || !msg) {
      alert("فرم یا محل پیام پیدا نشد.");
      return;
    }

    // جلوگیری از دوبار اجرا
    if (btn && btn.dataset.rpBusy === "1") return;
    if (btn) btn.dataset.rpBusy = "1";

    var originalBtnText = btn ? btn.innerHTML : "";

    try {
      // پاکسازی پیام قبلی
      msg.innerHTML = "";

      // ---- ولیدیشن ----
      var errorText = "";

      // موبایل
      var mobileInp = form.querySelector('input[name="mobile"]');
      if (mobileInp) {
        var mVal = rp_to_en_digits(mobileInp.value).trim();
        mobileInp.value = mVal; // نرمال‌سازی در خود فیلد

        if (!/^\d+$/.test(mVal)) {
          errorText = "شماره موبایل باید فقط شامل اعداد باشد.";
        } else if (mVal.length !== 11) {
          errorText = "شماره موبایل باید دقیقاً ۱۱ رقم باشد.";
        } else if (!/^09\d{9}$/.test(mVal)) {
          // اختیاری ولی دقیق‌تر برای ایران
          errorText = "شماره موبایل باید با 09 شروع شود و ۱۱ رقم باشد.";
        }
      }

      // ایمیل
      if (!errorText) {
        var emailInp = form.querySelector('input[name="email"]');
        if (emailInp) {
          var eVal = emailInp.value.trim();
          // چک سبک فرانت (چک اصلی باید سرور باشد)
          if (eVal.indexOf("@") === -1 || eVal.indexOf(".") === -1) {
            errorText = "فرمت ایمیل نامعتبر است.";
          }
        }
      }

      // نام‌ها
      if (!errorText) {
        var fName = form.querySelector('input[name="first_name"]');
        var lName = form.querySelector('input[name="last_name"]');
        if (fName && lName) {
          var fnVal = fName.value.trim();
          var lnVal = lName.value.trim();
          var full = (fnVal + " " + lnVal).trim();

          if (full.replace(/\s+/g, "").length < 3) {
            errorText = "مجموع نام و نام خانوادگی باید حداقل ۳ حرف باشد.";
          } else {
            var nameRegex = /^[a-zA-Z\u0600-\u06FF\s]+$/;
            if (!nameRegex.test(fnVal) || !nameRegex.test(lnVal)) {
              errorText = "نام و نام خانوادگی فقط باید شامل حروف فارسی یا انگلیسی باشد.";
            }
          }
        }
      }

      if (errorText) {
        rp_show_msg("error", errorText);
        return;
      }

      // ---- ارسال ----
      if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<span class="dashicons dashicons-update"></span> در حال پردازش...';
      }
      rp_show_msg("info", "در حال ارسال...");

      var formData = new FormData(form);
      formData.append("action", "reyhan_save_forced_completion");

      var ajaxUrl = "<?php echo esc_js(admin_url('admin-ajax.php')); ?>";

      if (typeof window.reyhan_front_obj !== "undefined" && window.reyhan_front_obj) {
        if (window.reyhan_front_obj.nonce) formData.append("security", window.reyhan_front_obj.nonce);
        if (window.reyhan_front_obj.ajax_url) ajaxUrl = window.reyhan_front_obj.ajax_url;
      }

      fetch(ajaxUrl, { method: "POST", body: formData })
        .then(function (r) { return r.text(); })
        .then(function (text) {
          var res;
          try { res = JSON.parse(text); }
          catch (e) { res = { success: false, data: "پاسخ سرور JSON نیست: " + text }; }

          if (res && res.success) {
            rp_show_msg("success", res.data || "با موفقیت ذخیره شد.");
            setTimeout(function () { location.reload(); }, 1200);
          } else {
            rp_show_msg("error", (res && res.data) ? res.data : "خطایی رخ داده است.");
            if (btn) {
              btn.disabled = false;
              btn.innerHTML = originalBtnText;
            }
          }
        })
        .catch(function () {
          rp_show_msg("error", "خطای ارتباط با سرور.");
          if (btn) {
            btn.disabled = false;
            btn.innerHTML = originalBtnText;
          }
        });

    } finally {
      // Busy را آزاد می‌کنیم (حتی اگر قبل از fetch return شود)
      if (btn) btn.dataset.rpBusy = "0";
    }
  };

  // 5) اتصال قطعی کلیک به دکمه (Overwrite -> بدون تداخل و بدون چندبار bind)
  function rp_bind_button() {
    var btn = document.querySelector("#rp-forced-completion-form .rp-btn-submit-comp");
    if (!btn) return;

    // مهم: onclick را مستقیم set می‌کنیم تا تداخل addEventListenerها از بین برود
    btn.onclick = function (e) {
      e.preventDefault();
      e.stopPropagation();
      window.rp_submit_profile_data(btn);
    };
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", rp_bind_button);
  } else {
    rp_bind_button();
  }

})();
</script>

