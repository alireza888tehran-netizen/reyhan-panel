<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div id="rp-completion-overlay">
    <div class="rp-comp-box">
        <h3><?php esc_html_e('تکمیل اطلاعات حساب', 'reyhan-panel'); ?></h3>
        <p><?php esc_html_e('برای دسترسی کامل به پنل، لطفاً اطلاعات زیر را تکمیل کنید.', 'reyhan-panel'); ?></p>
        
        <div class="rp-comp-form">
            
            <?php if ( !empty($needs_name) ): ?>
                <div class="rp-comp-row">
                    <input type="text" id="rp_comp_fname" class="rp-comp-input" placeholder="<?php esc_attr_e('نام', 'reyhan-panel'); ?>">
                    <input type="text" id="rp_comp_lname" class="rp-comp-input" placeholder="<?php esc_attr_e('نام خانوادگی', 'reyhan-panel'); ?>">
                </div>
            <?php endif; ?>

            <?php if ( !empty($needs_mobile) ): ?>
                <div class="rp-comp-row">
                    <input type="text" id="rp_comp_mobile" class="rp-comp-input ltr-inp" placeholder="<?php esc_attr_e('شماره موبایل (09xxxxxxxxx)', 'reyhan-panel'); ?>">
                </div>
            <?php endif; ?>

            <div id="rp-comp-msg"></div>
            
            <button type="button" id="rp-btn-complete-profile" class="rp-comp-btn">
                <?php esc_html_e('ذخیره و ورود به پنل', 'reyhan-panel'); ?>
            </button>
        </div>
    </div>
</div>

<style>
    .rp-comp-row { display: flex; gap: 10px; margin-bottom: 10px; }
    .rp-comp-input { width: 100%; }
    @media(max-width:480px){ .rp-comp-row { flex-direction: column; gap: 0; } }
</style>

<script>
jQuery(document).ready(function($){
    $('#rp-btn-complete-profile').click(function(){
        var btn = $(this);
        var fname = $('#rp_comp_fname').length ? $('#rp_comp_fname').val() : '';
        var lname = $('#rp_comp_lname').length ? $('#rp_comp_lname').val() : '';
        var mobile = $('#rp_comp_mobile').length ? $('#rp_comp_mobile').val() : '';
        
        <?php if(!empty($needs_name)): ?>
        if(fname.length < 2 || lname.length < 2) {
            $('#rp-comp-msg').css('color','red').text('لطفا نام و نام خانوادگی را کامل وارد کنید.');
            return;
        }
        <?php endif; ?>

        <?php if(!empty($needs_mobile)): ?>
        if(mobile.length < 10) {
            $('#rp-comp-msg').css('color','red').text('شماره موبایل معتبر نیست.');
            return;
        }
        <?php endif; ?>

        btn.prop('disabled', true).text('در حال ذخیره...');

        var ajaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';

        $.post(ajaxUrl, { 
            action: 'save_details_final_action',
            security: '<?php echo wp_create_nonce("reyhan_admin_nonce"); ?>', 
            first_name: fname,
            last_name: lname,
            mobile: mobile
        }, function(res) {
            if(res.success) {
                $('#rp-comp-msg').css('color','green').text('با موفقیت ذخیره شد. در حال انتقال...');
                setTimeout(function(){ location.reload(); }, 1000);
            } else {
                $('#rp-comp-msg').css('color','red').text(res.data);
                btn.prop('disabled', false).text('ذخیره و ورود به پنل');
            }
        });
    });
});
</script>