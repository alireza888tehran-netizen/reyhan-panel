<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<div class="rp-tickets-table-wrapper">
    <?php if ( ! empty( $tickets ) ) : ?>
        <table class="rp-ticket-table">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'شناسه', 'reyhan-panel' ); ?></th>
                    <th><?php esc_html_e( 'موضوع', 'reyhan-panel' ); ?></th>
                    <th><?php esc_html_e( 'دپارتمان', 'reyhan-panel' ); ?></th>
                    <th><?php esc_html_e( 'وضعیت', 'reyhan-panel' ); ?></th>
                    <th><?php esc_html_e( 'آخرین بروزرسانی', 'reyhan-panel' ); ?></th>
                    <th><?php esc_html_e( 'عملیات', 'reyhan-panel' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $tickets as $ticket ) : 
                    $tid = $ticket->ID;
                    $dept   = get_post_meta( $tid, '_ticket_department', true ) ?: 'general';
                    $status = get_post_meta( $tid, '_ticket_status', true ) ?: 'open';
                    $date   = get_the_modified_date( 'Y/m/d H:i', $tid );
                    
                    $status_labels = [
                        'open'       => __( 'باز', 'reyhan-panel' ),
                        'answered'   => __( 'پاسخ داده شده', 'reyhan-panel' ),
                        'user_reply' => __( 'پاسخ کاربر', 'reyhan-panel' ),
                        'closed'     => __( 'بسته شده', 'reyhan-panel' ),
                        'pending'    => __( 'در انتظار', 'reyhan-panel' )
                    ];
                    $status_text = isset($status_labels[$status]) ? $status_labels[$status] : $status;
                    ?>
                    <tr>
                        <td>#<?php echo esc_html( $tid ); ?></td>
                        <td>
                            <strong><?php echo esc_html( $ticket->post_title ); ?></strong>
                        </td>
                        <td>
                            <span class="rp-dept-badge"><?php echo esc_html( $dept ); ?></span>
                        </td>
                        <td>
                            <span class="rp-badge rp-status-<?php echo esc_attr( $status ); ?>">
                                <?php echo esc_html( $status_text ); ?>
                            </span>
                        </td>
                        <td class="ltr-text"><?php echo esc_html( $date ); ?></td>
                        <td>
                            <button class="rp-btn-view-ticket" onclick="loadSingleTicket(<?php echo intval( $tid ); ?>)">
                                <?php esc_html_e( 'مشاهده', 'reyhan-panel' ); ?>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else : ?>
        <div class="rp-empty-state">
            <img src="<?php echo esc_url( REYHAN_URL . 'assets/images/icon-ticket.svg' ); ?>" alt="Empty">
            <p><?php esc_html_e( 'هنوز تیکتی ثبت نکرده‌اید.', 'reyhan-panel' ); ?></p>
        </div>
    <?php endif; ?>
</div>