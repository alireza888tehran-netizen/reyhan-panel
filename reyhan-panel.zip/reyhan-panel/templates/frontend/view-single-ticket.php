<?php 
if ( ! defined( 'ABSPATH' ) ) { exit; } 

if ( ! isset($post) || ! $post instanceof WP_Post ) {
    echo '<div class="rp-error">' . esc_html__('تیکت نامعتبر است.', 'reyhan-panel') . '</div>';
    return;
}

$tid = $post->ID;
$status = get_post_meta( $tid, '_ticket_status', true );

$status_labels = [
    'open' => __('باز', 'reyhan-panel'), 'answered' => __('پاسخ داده شده', 'reyhan-panel'),
    'user_reply' => __('پاسخ کاربر', 'reyhan-panel'), 'closed' => __('بسته شده', 'reyhan-panel'),
    'pending' => __('در انتظار', 'reyhan-panel')
];
$status_text = isset($status_labels[$status]) ? $status_labels[$status] : $status;
?>

<div class="rp-single-ticket-header">
    <button class="rp-btn-back" onclick="loadUserTickets()">
        <span class="dashicons dashicons-arrow-right-alt2"></span> <?php esc_html_e('بازگشت', 'reyhan-panel'); ?>
    </button>
    
    <div class="rp-st-info">
        <h3><?php echo esc_html( $post->post_title ); ?> <span class="rp-id-badge">#<?php echo esc_html( $tid ); ?></span></h3>
        <span class="rp-badge rp-status-<?php echo esc_attr( $status ); ?>">
            <?php echo esc_html( $status_text ); ?>
        </span>
    </div>

    <?php if ( $status !== 'closed' ) : ?>
    <button class="rp-btn-close-ticket" onclick="closeTicket(<?php echo intval( $tid ); ?>)">
        <?php esc_html_e('بستن تیکت', 'reyhan-panel'); ?>
    </button>
    <?php endif; ?>
</div>

<div class="rp-ticket-conversation">
    <div class="rp-chat-msg user-msg">
        <div class="rp-msg-avatar">
            <?php echo get_avatar( $post->post_author, 40 ); ?>
        </div>
        <div class="rp-msg-content">
            <div class="rp-msg-meta">
                <span class="rp-msg-author"><?php echo esc_html( get_the_author_meta( 'display_name', $post->post_author ) ); ?></span>
                <span class="rp-msg-time"><?php echo esc_html( get_the_date( 'Y/m/d H:i', $tid ) ); ?></span>
            </div>
            <div class="rp-msg-text"><?php echo nl2br( esc_html( $post->post_content ) ); ?></div>
            <?php 
            $attachments = get_children([ 'post_parent' => $tid, 'post_type' => 'attachment' ]);
            if ( ! empty( $attachments ) ) {
                foreach ( $attachments as $att ) {
                    echo '<div class="rp-attachment-box"><a href="' . esc_url( wp_get_attachment_url( $att->ID ) ) . '" target="_blank"><span class="dashicons dashicons-paperclip"></span> ' . esc_html__('دانلود ضمیمه', 'reyhan-panel') . '</a></div>';
                }
            }
            ?>
        </div>
    </div>

    <?php 
    $comments = get_comments([ 'post_id' => $tid, 'order' => 'ASC', 'type' => 'ticket_reply' ]);
    foreach ( $comments as $comment ) : 
        $is_admin = user_can( $comment->user_id, 'manage_options' ) || user_can( $comment->user_id, 'edit_posts' );
        $msg_class = $is_admin ? 'admin-msg' : 'user-msg';
        $display_name = $comment->comment_author;
        
        if ($is_admin) {
            $fname = get_user_meta($comment->user_id, 'first_name', true);
            $lname = get_user_meta($comment->user_id, 'last_name', true);
            if (!empty($fname) || !empty($lname)) {
                $display_name = trim("$fname $lname");
            } elseif (empty($display_name) || strtolower($display_name) === 'admin') {
                $display_name = __('پشتیبان آنلاین', 'reyhan-panel');
            }
        }

        $avatar_html = '';
        if ($is_admin) {
            $custom_img = get_user_meta($comment->user_id, 'profile_image', true);
            if (!empty($custom_img)) {
                $avatar_html = '<img src="' . esc_url($custom_img) . '" class="avatar" alt="Agent">';
            }
        }
        
        if (empty($avatar_html)) {
            $avatar_html = get_avatar( $comment->user_id, 40 );
        }
    ?>
        <div class="rp-chat-msg <?php echo esc_attr( $msg_class ); ?>">
            <div class="rp-msg-avatar">
                <?php
                $allowed_avatar_tags = [
                    'img' => [
                        'src' => true,
                        'class' => true,
                        'alt' => true,
                        'width' => true,
                        'height' => true,
                        'srcset' => true,
                        'sizes' => true,
                        'loading' => true,
                        'decoding' => true,
                    ],
                    'span' => [ 'class' => true ],
                ];
                echo wp_kses( $avatar_html, $allowed_avatar_tags );
            ?>
            </div>
            <div class="rp-msg-content">
                <div class="rp-msg-meta">
                    <span class="rp-msg-author">
                        <?php echo esc_html( $display_name );?>
                        
                        <?php if($is_admin): ?>
                            <span class="rp-admin-label"><?php esc_html_e('پشتیبان', 'reyhan-panel'); ?></span>
                        <?php endif; ?>
                    </span>
                    <span class="rp-msg-time"><?php echo esc_html( get_comment_date( 'Y/m/d H:i', $comment->comment_ID ) ); ?></span>
                </div>
                <div class="rp-msg-text">
                    <?php echo wp_kses_post( wpautop( $comment->comment_content ) ); ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<?php if ( $status !== 'closed' ) : ?>
<div class="rp-reply-area">
    <form id="rp-reply-form">
        <input type="hidden" name="ticket_id" value="<?php echo intval( $tid ); ?>">
        <textarea name="message" class="rp-reply-textarea" rows="4" placeholder="<?php esc_attr_e('پاسخ خود را بنویسید...', 'reyhan-panel'); ?>" required></textarea>
        
        <div class="rp-reply-actions">
            <label for="rp-reply-file" id="rp-reply-file-label">
                <span class="dashicons dashicons-paperclip"></span> <?php esc_html_e('انتخاب فایل پیوست (اختیاری)', 'reyhan-panel'); ?>
            </label>
            <input type="file" name="attachment" id="rp-reply-file">
            
            <button type="submit" class="rp-btn-send-reply">
                <?php esc_html_e('ارسال پاسخ', 'reyhan-panel'); ?> <span class="dashicons dashicons-arrow-left-alt"></span>
            </button>
        </div>
    </form>
</div>
<?php else : ?>
<div class="rp-ticket-closed-alert">
    <span class="dashicons dashicons-lock"></span> <?php esc_html_e('این تیکت بسته شده است و امکان ارسال پاسخ وجود ندارد.', 'reyhan-panel'); ?>
</div>
<?php endif; ?>