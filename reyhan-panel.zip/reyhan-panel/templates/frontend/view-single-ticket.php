<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<style>
    /* ریست کردن تداخلات احتمالی قالب برای این بخش */
    .rp-single-ticket-wrap, .rp-single-ticket-wrap * {
        box-sizing: border-box;
    }
    
    .rp-single-ticket-wrap { display: flex; flex-direction: column; gap: 20px; width: 100%; }
    
    /* هدر تیکت */
    .rp-chat-header {
        display: flex; justify-content: space-between; align-items: center;
        padding: 20px; background: #ffffff !important; border-radius: 16px;
        border: 1px solid #e2e8f0 !important; box-shadow: var(--rp-shadow);
        flex-wrap: wrap; gap: 15px;
    }
    
    .rp-chat-title h3 { 
        margin: 0 !important; font-size: 18px !important; 
        color: #1a202c !important; font-weight: 800 !important; 
        line-height: 1.5 !important;
    }
    
    .rp-chat-meta { 
        font-size: 13px !important; color: #718096 !important; 
        margin-top: 8px !important; display: flex; flex-wrap: wrap; gap: 15px; 
    }
    
    .rp-chat-actions { display: flex; gap: 10px; }
    
    /* دکمه‌های هدر */
    .rp-btn-chat-action {
        padding: 8px 16px !important; border-radius: 10px !important; font-size: 12px !important;
        cursor: pointer; display: flex; align-items: center; gap: 6px;
        border: 1px solid #e2e8f0 !important; background: #fff !important; 
        color: #4a5568 !important; font-family: inherit !important; font-weight: 600 !important;
    }
    .rp-btn-chat-action:hover { background: #f7fafc !important; }
    
    /* باکس پیام‌ها */
    .rp-chat-box {
        background: #f8fafc !important; border: 1px solid #e2e8f0 !important; 
        border-radius: 20px; padding: 25px; max-height: 550px; overflow-y: auto;
        display: flex; flex-direction: column; gap: 25px;
        box-shadow: inset 0 2px 10px rgba(0,0,0,0.02);
    }
    
    /* ناحیه پاسخگویی */
    .rp-reply-area {
        background: #ffffff !important; border: 1px solid #e2e8f0 !important; 
        border-radius: 18px; padding: 10px; box-shadow: var(--rp-shadow);
    }
    
    .rp-reply-textarea {
        width: 100%; border: none !important; resize: none; min-height: 100px;
        padding: 15px; font-family: inherit; outline: none !important; 
        font-size: 14px !important; color: #2d3748 !important; background: transparent !important;
    }
    
    .rp-reply-footer {
        display: flex; justify-content: space-between; align-items: center;
        padding: 10px 15px; border-top: 1px solid #edf2f7;
    }
    
    /* دکمه ارسال با گرادینت انتخابی مدیر */
    .rp-btn-send-reply {
        background: var(--rp-gradient) !important; color: #ffffff !important; 
        border: none !important; padding: 10px 25px !important; border-radius: 12px !important; 
        font-weight: bold !important; cursor: pointer; font-family: inherit !important;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    .rp-btn-send-reply:hover { transform: translateY(-2px); opacity: 0.9; }

    .rp-ticket-closed-notice {
        text-align: center; padding: 25px; background: #fffaf0 !important;
        color: #dd6b20 !important; border-radius: 15px; font-weight: bold !important;
        border: 1px dashed #fbd38d !important;
    }
</style>

<div class="rp-single-ticket-wrap">
    
    <div class="rp-chat-header">
        <div class="rp-chat-title">
            <h3><?php echo esc_html($ticket->post_title); ?> <span style="opacity:0.4; font-weight:normal; color: #718096 !important;">#<?php echo $ticket->ID; ?></span></h3>
            <div class="rp-chat-meta">
                <span style="color: inherit !important;"><span class="dashicons dashicons-category" style="font-size:16px;"></span> <?php echo esc_html(get_post_meta($ticket->ID, '_ticket_department', true) ?: __('عمومی', 'reyhan-panel')); ?></span>
                <span style="color: inherit !important;"><span class="dashicons dashicons-calendar-alt" style="font-size:16px;"></span> <?php echo get_the_date('j F Y ساعت H:i', $ticket); ?></span>
            </div>
        </div>
        <div class="rp-chat-actions">
            <?php if($status !== 'closed'): ?>
                <button onclick="closeTicketByUser(<?php echo $ticket->ID; ?>)" class="rp-btn-chat-action" style="color:#e53e3e !important; border-color:#feb2b2 !important; background:#fff5f5 !important;">
                    <span class="dashicons dashicons-no"></span> <?php esc_html_e('بستن تیکت', 'reyhan-panel'); ?>
                </button>
            <?php endif; ?>
            <button onclick="loadUserTickets()" class="rp-btn-chat-action">
                <span class="dashicons dashicons-arrow-left-alt"></span> <?php esc_html_e('بازگشت', 'reyhan-panel'); ?>
            </button>
        </div>
    </div>

    <div class="rp-chat-box">
        <?php 
        $comment = $ticket; 
        $is_user = true; 
        $is_first_msg = true; 
        $display_name = get_user_meta($ticket->post_author, 'first_name', true) ?: __('شما', 'reyhan-panel');
        $avatar = get_user_meta($ticket->post_author, 'reyhan_user_avatar', true);
        
        include REYHAN_DIR . 'templates/frontend/partials/chat-message.php';
        
        unset($is_first_msg);
        foreach($comments as $c) {
            $is_user = ($c->user_id == $ticket->post_author);
            $display_name = $is_user ? (get_user_meta($c->user_id, 'first_name', true) ?: __('شما', 'reyhan-panel')) : __('پشتیبان سایت', 'reyhan-panel');
            $avatar = $is_user ? get_user_meta($c->user_id, 'reyhan_user_avatar', true) : REYHAN_URL . 'assets/images/support.png';
            $comment = $c;
            include REYHAN_DIR . 'templates/frontend/partials/chat-message.php';
        } 
        ?>
    </div>

    <?php if($status !== 'closed'): ?>
        <form id="rp-reply-form" class="rp-reply-area">
            <input type="hidden" name="ticket_id" value="<?php echo $ticket->ID; ?>">
            <textarea name="reply_message" class="rp-reply-textarea" placeholder="<?php esc_attr_e('پاسخ خود را اینجا بنویسید...', 'reyhan-panel'); ?>" required></textarea>
            
            <div class="rp-reply-footer">
                <div>
                    <input type="file" name="reply_attachment" id="rp-reply-file" style="display:none;">
                    <label for="rp-reply-file" class="rp-attach-btn" style="color:#718096 !important; cursor:pointer; font-size:12px; display:flex; align-items:center; gap:5px;">
                        <span class="dashicons dashicons-paperclip"></span> <?php esc_html_e('پیوست فایل', 'reyhan-panel'); ?>
                    </label>
                    <span id="rp-file-name" style="font-size:11px; color:#38a169 !important; margin-right:10px;"></span>
                </div>

                <button type="submit" class="rp-btn-send-reply">
                    <?php esc_html_e('ارسال پاسخ', 'reyhan-panel'); ?>
                </button>
            </div>
        </form>
    <?php else: ?>
        <div class="rp-ticket-closed-notice">
            <span class="dashicons dashicons-lock"></span> <?php esc_html_e('این تیکت بسته شده است و امکان ارسال پاسخ وجود ندارد.', 'reyhan-panel'); ?>
        </div>
    <?php endif; ?>

</div>