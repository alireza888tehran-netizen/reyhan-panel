<?php 
if ( ! defined( 'ABSPATH' ) ) exit; 

// دریافت متغیر تیکت
$ticket = isset($post) ? $post : null;
if(!$ticket) { echo 'خطا در بارگذاری تیکت'; return; }

$tid = $ticket->ID;
$code = get_post_meta($tid, '_ticket_code', true) ?: $tid;
$status = get_post_meta($tid, '_ticket_status', true);
$dept = get_post_meta($tid, '_ticket_department', true);

// ترجمه وضعیت‌ها به فارسی
$status_labels = [
    'open'        => 'باز',
    'closed'      => 'بسته شده',
    'answered'    => 'پاسخ داده شده',
    'user_reply'  => 'پاسخ کاربر',
    'admin_reply' => 'پاسخ پشتیبان',
    'pending'     => 'در حال بررسی'
];
$status_text = isset($status_labels[$status]) ? $status_labels[$status] : $status;
$status_class = 'rp-status-' . $status;

// دریافت پیام‌های گفتگو
$replies = get_comments([
    'post_id' => $tid,
    'order'   => 'ASC',
    'orderby' => 'comment_date'
]);

// تابع کمکی برای آواتار سفارشی (اصلاح شده)
function rp_get_user_avatar_url($user_id) {
    // 1. اولویت اول: آواتار آپلود شده توسط کاربر
    $custom_avatar = get_user_meta($user_id, 'reyhan_user_avatar', true);
    if (!empty($custom_avatar)) {
        return $custom_avatar;
    }
    
    // 2. اولویت دوم (پیش‌فرض): فایل user.png موجود در پوشه تصاویر افزونه
    return REYHAN_URL . 'assets/images/user.png';
}
?>

<div class="rp-ticket-single-wrap">
    
    <div class="rp-ticket-header-card">
        <div class="rp-th-top">
            <button class="rp-btn-back-list" title="بازگشت به لیست">
                <span class="dashicons dashicons-arrow-right-alt2"></span>
            </button>
            <h1 class="rp-ticket-main-title"><?php echo esc_html($ticket->post_title); ?></h1>
        </div>
        
        <div class="rp-th-meta-grid">
            <div class="rp-meta-box">
                <span class="rp-meta-label">کد پیگیری</span>
                <span class="rp-meta-value code">#<?php echo esc_html($code); ?></span>
            </div>
            <div class="rp-meta-box">
                <span class="rp-meta-label">دپارتمان</span>
                <span class="rp-meta-value dept"><?php echo esc_html($dept); ?></span>
            </div>
            <div class="rp-meta-box">
                <span class="rp-meta-label">وضعیت</span>
                <span class="rp-meta-value status <?php echo esc_attr($status_class); ?>"><?php echo esc_html($status_text); ?></span>
            </div>
            <div class="rp-meta-box">
                <span class="rp-meta-label">آخرین بروزرسانی</span>
                <span class="rp-meta-value date"><?php echo get_the_modified_date('Y/m/d H:i', $tid); ?></span>
            </div>
        </div>

        <?php if($status !== 'closed'): ?>
            <button class="rp-btn-close-ticket" onclick="ReyhanApp.closeTicket(<?php echo $tid; ?>)">
                <span class="dashicons dashicons-no"></span> بستن تیکت
            </button>
        <?php endif; ?>
    </div>

    <div class="rp-chat-box">
        
        <?php 
            $starter_id = $ticket->post_author;
            $starter_name = get_the_author_meta('display_name', $starter_id);
            $starter_avatar = rp_get_user_avatar_url($starter_id);
        ?>
        <div class="rp-msg-row user-msg">
            <div class="rp-msg-avatar">
                <img src="<?php echo esc_url($starter_avatar); ?>" alt="User">
            </div>
            <div class="rp-msg-container">
                <span class="rp-msg-author-name"><?php echo esc_html($starter_name); ?></span>
                <div class="rp-msg-bubble">
                    <div class="rp-msg-content"><?php echo nl2br(esc_html($ticket->post_content)); ?></div>
                    
                    <?php 
                    $att_id = get_post_meta($tid, '_ticket_attachment_id', true);
                    if($att_id): 
                        $att_url = wp_get_attachment_url($att_id);
                    ?>
                        <a href="<?php echo esc_url($att_url); ?>" target="_blank" class="rp-att-link">
                            <span class="dashicons dashicons-paperclip"></span> دانلود ضمیمه
                        </a>
                    <?php endif; ?>
                    
                    <div class="rp-msg-date"><?php echo get_the_date('Y/m/d H:i', $tid); ?></div>
                </div>
            </div>
        </div>

        <?php foreach($replies as $reply): 
            $uid = $reply->user_id;
            $is_admin = user_can($uid, 'manage_options') || user_can($uid, 'edit_posts'); // تشخیص ایجنت
            $row_class = $is_admin ? 'admin-msg' : 'user-msg';
            
            // اطلاعات نویسنده
            $author_name = get_the_author_meta('display_name', $uid);
            $author_avatar = rp_get_user_avatar_url($uid);
        ?>
            <div class="rp-msg-row <?php echo $row_class; ?>">
                <div class="rp-msg-avatar">
                    <img src="<?php echo esc_url($author_avatar); ?>" alt="Avatar">
                </div>
                <div class="rp-msg-container">
                    <span class="rp-msg-author-name">
                        <?php echo esc_html($author_name); ?>
                        <?php if($is_admin): ?><span class="rp-role-tag">پشتیبان</span><?php endif; ?>
                    </span>

                    <div class="rp-msg-bubble">
                        <div class="rp-msg-content"><?php echo wp_kses_post($reply->comment_content); ?></div>
                        
                        <?php 
                        $r_att = get_comment_meta($reply->comment_ID, '_attachment_id', true);
                        if($r_att): 
                            $r_url = wp_get_attachment_url($r_att);
                        ?>
                            <a href="<?php echo esc_url($r_url); ?>" target="_blank" class="rp-att-link">
                                <span class="dashicons dashicons-paperclip"></span> دانلود ضمیمه
                            </a>
                        <?php endif; ?>

                        <div class="rp-msg-date"><?php echo get_comment_date('Y/m/d H:i', $reply->comment_ID); ?></div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <?php if($status !== 'closed'): ?>
    <div class="rp-reply-area">
        <form id="rp-form-reply-ticket" enctype="multipart/form-data">
            <input type="hidden" name="ticket_id" value="<?php echo $tid; ?>">
            <textarea name="message" class="rp-input-modern" placeholder="پاسخ خود را بنویسید..." rows="3"></textarea>
            <div class="rp-reply-footer">
                <div class="rp-upload-wrap-mini">
                    <label for="reply-att" class="rp-upload-label-mini">
                        <span class="dashicons dashicons-paperclip"></span> پیوست فایل
                    </label>
                    <input type="file" name="attachment" id="reply-att" style="display:none;">
                    <span id="reply-file-name"></span>
                </div>
                <button type="submit" class="rp-btn-primary">
                    <span class="dashicons dashicons-location-alt"></span> ارسال پاسخ
                </button>
            </div>
        </form>
    </div>
    <?php else: ?>
        <div class="rp-ticket-closed-alert">
            <span class="dashicons dashicons-lock"></span>
            این تیکت بسته شده است و امکان ارسال پاسخ وجود ندارد.
        </div>
    <?php endif; ?>
</div>

<script>
    jQuery('#reply-att').change(function(){
        var file = this.files[0];
        if(file) jQuery('#reply-file-name').text(file.name);
    });
</script>