<?php 
if ( ! defined( 'ABSPATH' ) ) exit; 

// دریافت متغیر تیکت
$ticket = isset($post) ? $post : null;
if(!$ticket) { echo 'خطا در بارگذاری تیکت'; return; }

$tid = $ticket->ID;
$code = get_post_meta($tid, '_ticket_code', true) ?: $tid;
$status = get_post_meta($tid, '_ticket_status', true);
$dept = get_post_meta($tid, '_ticket_department', true);
$opts = get_option('reyhan_options'); // دریافت تنظیمات کل افزونه

// ترجمه وضعیت‌ها
$status_labels = [
    'open'        => 'باز',
    'closed'      => 'بسته شده',
    'answered'    => 'پاسخ داده شده',
    'user_reply'  => 'پاسخ کاربر',
    'admin_reply' => 'پاسخ پشتیبان',
    'pending'     => 'در حال بررسی'
];
$status_text = isset($status_labels[$status]) ? $status_labels[$status] : $status;
$status_class = 'rp-status-' . $status;

// دریافت پیام‌ها
$replies = get_comments([ 'post_id' => $tid, 'order' => 'ASC', 'orderby' => 'comment_date' ]);

// --- تابع کمکی هوشمند برای دریافت آواتار و نام (طبق منطق درخواستی) ---
function rp_get_author_data($user_id, $opts) {
    $user = get_userdata($user_id);
    
    // آدرس تصویر پیش‌فرض (user.png)
    $default_avatar = REYHAN_URL . 'assets/images/user.png';

    // اگر کاربر وجود نداشت
    if(!$user) return ['name' => 'پشتیبان سایت', 'avatar' => $default_avatar, 'role' => 'agent'];

    // بررسی نقش‌ها
    $is_admin_role = in_array('administrator', $user->roles);
    $is_agent_role = in_array('rp_support_agent', $user->roles) || user_can($user_id, 'edit_posts'); 

    // 1. منطق مخصوص مدیر سایت (Administrator)
    if ( $is_admin_role ) {
        // نام: خواندن از تنظیمات اصلی افزونه
        $name_opt = isset($opts['ticket_support_name']) ? $opts['ticket_support_name'] : '';
        $name = !empty($name_opt) ? $name_opt : 'پشتیبان سایت';
        
        // تصویر: خواندن از تنظیمات اصلی افزونه
        $avatar_opt = isset($opts['ticket_support_avatar']) ? $opts['ticket_support_avatar'] : '';
        $avatar = !empty($avatar_opt) ? $avatar_opt : $default_avatar;

        return ['name' => $name, 'avatar' => $avatar, 'role' => 'admin'];
    }

    // 2. منطق مخصوص ایجنت/کارمند (غیر مدیر)
    if ( $is_agent_role ) {
        // نام: خواندن از پروفایل شخصی (First Name + Last Name)
        $fname = get_user_meta($user_id, 'first_name', true);
        $lname = get_user_meta($user_id, 'last_name', true);
        $full_name = trim($fname . ' ' . $lname);
        
        $name = !empty($full_name) ? $full_name : 'پشتیبان سایت';

        // تصویر: خواندن از پروفایل شخصی (reyhan_user_avatar)
        $custom_avatar = get_user_meta($user_id, 'reyhan_user_avatar', true);
        $avatar = !empty($custom_avatar) ? $custom_avatar : $default_avatar;

        return ['name' => $name, 'avatar' => $avatar, 'role' => 'agent'];
    }

    // 3. منطق کاربر عادی (مشتری)
    $u_avatar = get_user_meta($user_id, 'reyhan_user_avatar', true);
    if(empty($u_avatar)) $u_avatar = $default_avatar;
    
    $dname = $user->display_name;
    if(empty($dname)) $dname = $user->first_name . ' ' . $user->last_name;
    if(empty(trim($dname))) $dname = 'کاربر';

    return ['name' => $dname, 'avatar' => $u_avatar, 'role' => 'user'];
}
?>

<div class="rp-ticket-single-wrap">
    <div class="rp-ticket-header-card">
        <div class="rp-th-top">
            <button class="rp-btn-back-list" title="بازگشت"><span class="dashicons dashicons-arrow-right-alt2"></span></button>
            <h1 class="rp-ticket-main-title"><?php echo esc_html($ticket->post_title); ?></h1>
        </div>
        <div class="rp-th-meta-grid">
            <div class="rp-meta-box"><span class="rp-meta-label">کد</span><span class="rp-meta-value code">#<?php echo esc_html($code); ?></span></div>
            <div class="rp-meta-box"><span class="rp-meta-label">دپارتمان</span><span class="rp-meta-value dept"><?php echo esc_html($dept); ?></span></div>
            <div class="rp-meta-box"><span class="rp-meta-label">وضعیت</span><span class="rp-meta-value status <?php echo esc_attr($status_class); ?>"><?php echo esc_html($status_text); ?></span></div>
            <div class="rp-meta-box"><span class="rp-meta-label">بروزرسانی</span><span class="rp-meta-value date"><?php echo get_the_modified_date('Y/m/d H:i', $tid); ?></span></div>
        </div>
        <?php if($status !== 'closed'): ?>
            <button class="rp-btn-close-ticket" onclick="ReyhanApp.closeTicket(<?php echo $tid; ?>)"><span class="dashicons dashicons-no"></span> بستن تیکت</button>
        <?php endif; ?>
    </div>

    <div class="rp-chat-box">
        <?php 
            // پیام شروع کننده (کاربر)
            $starter_id = $ticket->post_author;
            $starter_data = rp_get_author_data($starter_id, $opts);
        ?>
        <div class="rp-msg-row user-msg">
            <div class="rp-msg-avatar"><img src="<?php echo esc_url($starter_data['avatar']); ?>" alt="User"></div>
            <div class="rp-msg-container">
                <span class="rp-msg-author-name"><?php echo esc_html($starter_data['name']); ?></span>
                <div class="rp-msg-bubble">
                    <div class="rp-msg-content"><?php echo nl2br(esc_html($ticket->post_content)); ?></div>
                    
                    <?php 
                    $att_ids = get_post_meta($tid, '_ticket_attachment_id', false); 
                    if(!empty($att_ids)): 
                        echo '<div class="rp-att-list-grid">';
                        foreach($att_ids as $att_id):
                            $url = wp_get_attachment_url($att_id);
                            if(!$url) continue;
                            $filename = basename(get_attached_file($att_id));
                    ?>
                        <a href="<?php echo esc_url($url); ?>" target="_blank" class="rp-att-chip">
                            <span class="dashicons dashicons-paperclip"></span> <?php echo esc_html($filename); ?>
                        </a>
                    <?php endforeach; echo '</div>'; endif; ?>
                    
                    <div class="rp-msg-date"><?php echo get_the_date('Y/m/d H:i', $tid); ?></div>
                </div>
            </div>
        </div>

        <?php foreach($replies as $reply): 
            $uid = $reply->user_id;
            $auth_data = rp_get_author_data($uid, $opts);
            
            // تشخیص استایل: ادمین یا ایجنت هر دو سمت چپ (admin-msg) نمایش داده می‌شوند
            $is_staff = ($auth_data['role'] === 'admin' || $auth_data['role'] === 'agent');
            $row_class = $is_staff ? 'admin-msg' : 'user-msg';
        ?>
            <div class="rp-msg-row <?php echo $row_class; ?>">
                <div class="rp-msg-avatar"><img src="<?php echo esc_url($auth_data['avatar']); ?>"></div>
                <div class="rp-msg-container">
                    <span class="rp-msg-author-name">
                        <?php echo esc_html($auth_data['name']); ?>
                        <?php if($is_staff): ?><span class="rp-role-tag">پشتیبان</span><?php endif; ?>
                    </span>
                    <div class="rp-msg-bubble">
                        <div class="rp-msg-content"><?php echo wp_kses_post($reply->comment_content); ?></div>
                        
                        <?php 
                        $r_atts = get_comment_meta($reply->comment_ID, '_attachment_id', false);
                        if(!empty($r_atts)): 
                             echo '<div class="rp-att-list-grid">';
                             foreach($r_atts as $rat):
                                 $r_url = wp_get_attachment_url($rat);
                                 if(!$r_url) continue;
                                 $r_name = basename(get_attached_file($rat));
                        ?>
                            <a href="<?php echo esc_url($r_url); ?>" target="_blank" class="rp-att-chip">
                                <span class="dashicons dashicons-paperclip"></span> <?php echo esc_html($r_name); ?>
                            </a>
                        <?php endforeach; echo '</div>'; endif; ?>

                        <div class="rp-msg-date"><?php echo get_comment_date('Y/m/d H:i', $reply->comment_ID); ?></div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <?php if($status !== 'closed'): ?>
    <div class="rp-reply-area">
        <form id="rp-form-reply-ticket">
            <input type="hidden" name="ticket_id" value="<?php echo $tid; ?>">
            <textarea name="message" class="rp-input-modern" placeholder="پاسخ خود را بنویسید..." rows="3"></textarea>
            
            <div class="rp-upload-modern-wrap" style="flex-grow: 1;">
                <input type="file" id="reply-att" class="rp-hidden-file-input" multiple style="display:none;">
                <label for="reply-att" class="rp-upload-modern-box" style="padding: 12px; min-height: auto;">
                    <span class="dashicons dashicons-paperclip"></span>
                    <span>افزودن ضمیمه</span>
                </label>
                <div class="rp-file-list-queue"></div>
            </div>

            <button type="submit" class="rp-btn-primary" style="margin-top: 10px; height: 48px;">
                <span class="dashicons dashicons-location-alt"></span> ارسال پاسخ
            </button>
        </form>
    </div>
    <?php else: ?>
        <div class="rp-ticket-closed-alert">
            <span class="dashicons dashicons-lock"></span> تیکت بسته شده است.
        </div>
    <?php endif; ?>
</div>