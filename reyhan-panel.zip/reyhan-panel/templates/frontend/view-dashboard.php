<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<style>
    :root{--rp-orange:<?php echo esc_attr($p['btn_bg']);?>;--rp-gradient:<?php echo $p['gradient'];?>;--rp-shadow:<?php echo $p['shadow'];?>;<?php if($sb_img) echo "--rp-sb-img: url('$sb_img');";?><?php if($sb_img && $sb_overlay) echo "--rp-sb-overlay: $sb_overlay;";?>}
    <?php if($sb_img):?>.rp-sidebar{background-image:var(--rp-sb-img)!important;background-size:cover!important;}<?php endif;?><?php if($sb_img && $sb_overlay):?>.rp-sidebar::before{content:'';position:absolute;inset:0;background:var(--rp-sb-overlay);z-index:-1;border-radius:20px;}<?php endif;?>
    
    /* فاصله بیشتر برای فیلدها */
    .rp-input-modern, .rp-new-ticket-box select { margin-bottom: 15px !important; }
</style>

<button id="rp-mobile-menu-trigger" class="rp-mobile-toggle-btn"><span class="dashicons dashicons-menu-alt"></span></button><div id="rp-mobile-overlay" class="rp-mobile-overlay"></div>

<?php if ( !empty($opts['force_profile_completion']) ): // بررسی فعال بودن گزینه تکمیل اجباری ?>
    <div id="rp-popup-overlay" class="rp-mobile-overlay" style="z-index: 99999;"></div>
    <div id="rp-popup-mandatory" class="rp-comp-box" style="display:none; position:fixed; top:50%; left:50%; transform:translate(-50%, -50%); z-index:100000;">
        <h3 style="color:#d32f2f; margin-bottom:10px;"><?php esc_html_e('تکمیل اطلاعات', 'reyhan-panel'); ?></h3>
        <p style="font-weight:bold; margin-bottom:20px;"><?php esc_html_e('برای بازشدن دسترسی پنل کاربری فیلد زیر را پر کنید!', 'reyhan-panel'); ?></p>
        <div id="rp-popup-mobile-form" style="display:none;">
            <input type="text" id="rp_popup_mobile" class="rp-comp-input" placeholder="<?php esc_attr_e('شماره موبایل (09xxxxxxxxx)', 'reyhan-panel'); ?>" style="margin-bottom:10px;">
            <button type="button" id="rp-popup-save-mobile" class="rp-comp-btn"><?php esc_html_e('ثبت شماره', 'reyhan-panel'); ?></button>
        </div>
        <div id="rp-popup-name-form" style="display:none;">
            <input type="text" id="rp_popup_fname" class="rp-comp-input" placeholder="<?php esc_attr_e('نام', 'reyhan-panel'); ?>" style="margin-bottom:10px;">
            <input type="text" id="rp_popup_lname" class="rp-comp-input" placeholder="<?php esc_attr_e('نام خانوادگی', 'reyhan-panel'); ?>" style="margin-bottom:10px;">
            <button type="button" id="rp-popup-save-name" class="rp-comp-btn"><?php esc_html_e('ثبت نام و نام خانوادگی', 'reyhan-panel'); ?></button>
        </div>
    </div>
<?php endif; ?>

<div class="rp-dashboard-box">
    <div class="rp-sidebar" id="rp-main-sidebar">
        <a href="<?php echo home_url(); ?>" class="rp-back-home-btn"><span class="dashicons dashicons-admin-home"></span> <?php esc_html_e('بازگشت به خانه', 'reyhan-panel'); ?></a>
        <div class="rp-user-info">
            <div class="rp-user-avatar"><img src="<?php echo esc_url($avatar_url); ?>"></div>
            <div class="rp-user-name"><?php echo esc_html($display_name); ?></div>
            <div class="rp-user-role-badge"><?php echo esc_html($role_label); ?></div>
            <?php if ( $is_agent_user ) : ?>
                <div class="rp-agent-badge-box">
                    <span class="rp-agent-badge" style="background:#e3f2fd; color:#1565c0; border:1px solid #bbdefb; padding:2px 8px; border-radius:12px; font-size:11px; margin-top:5px; display:inline-block;">
                        <span class="dashicons dashicons-headset" style="font-size:14px; vertical-align:middle;"></span> 
                        <?php esc_html_e('کارشناس پشتیبانی', 'reyhan-panel'); ?>
                    </span>
                </div>
            <?php endif; ?>
        </div>
        <ul class="rp-menu">
            <?php foreach($menu_items as $idx => $item) {
                $act = $item['action'];
                $js_attr = ($act=='logout') ? 'onclick="location.href=\''.wp_logout_url(get_permalink()).'\'"' : (($act=='link') ? 'onclick="window.open(\''.esc_url($item['link']??'#').'\', \'_blank\')"' : '');
                $tab_id = ($act == 'content') ? 'custom_tab_'.$idx : $act;
                
                $icon_type = $item['icon_type'] ?? 'icon';
                
                echo '<li class="'.($act=='dashboard'?'active':'').'" data-tab="'.esc_attr($tab_id).'" '.$js_attr.'>';
                
                if ( $icon_type === 'image' && !empty($item['custom_image']) ) {
                    echo '<img src="'.esc_url($item['custom_image']).'" class="rp-menu-icon-img" alt="'.esc_attr($item['label']).'">';
                } else {
                    $icon_cls = !empty($item['icon']) ? $item['icon'] : 'dashicons-marker';
                    echo '<span class="dashicons '.esc_attr($icon_cls).'"></span>';
                }
                
                echo esc_html($item['label']).'</li>';
            } ?>
        </ul>
    </div>
    <div class="rp-content">
        <?php if(!empty($notifications) && is_array($notifications)) { foreach($notifications as $n) { if(isset($n['active']) && $n['active']) {
            $cls = 'rp-notif-'.($n['type']??'info');
            echo '<div class="rp-global-notification '.esc_attr($cls).'"><div class="rp-gn-content"><strong class="rp-gn-title">'.esc_html($n['title']).'</strong><div class="rp-gn-text">'.nl2br(esc_html($n['msg'])).'</div></div></div>';
        }}} ?>
        
        <div id="rp-section-dashboard" class="rp-tab-content" style="display:block;">
            <h3><?php printf( esc_html__('%s عزیز! خوش آمدید 👋', 'reyhan-panel'), esc_html($display_name) ); ?></h3>
            <div class="rp-dashboard-grid">
                <?php if(empty($opts['panel_widget_ticket_hide'])): ?><div class="rp-card-stat"><span><?php esc_html_e('تیکت‌های باز', 'reyhan-panel'); ?></span><strong><?php echo $count_tickets_open; ?></strong></div><?php endif; ?>
                <?php if(empty($opts['panel_widget_order_hide']) && class_exists('WooCommerce')): ?><div class="rp-card-stat"><span><?php esc_html_e('سفارشات', 'reyhan-panel'); ?></span><strong><?php echo $count_orders; ?></strong></div><?php endif; ?>
                <?php if(empty($opts['panel_widget_days_hide'])): ?><div class="rp-card-stat"><span><?php esc_html_e('روز عضویت', 'reyhan-panel'); ?></span><strong><?php echo $days_diff; ?></strong></div><?php endif; ?>
                <?php if(empty($opts['panel_widget_comments_hide'])): ?><div class="rp-card-stat"><span><?php esc_html_e('دیدگاه‌ها', 'reyhan-panel'); ?></span><strong><?php echo $count_comments; ?></strong></div><?php endif; ?>
                <?php if(empty($opts['panel_widget_discount_hide']) && !empty($opts['panel_widget_discount_text'])): 
                    $d_title = !empty($opts['panel_widget_discount_title']) ? $opts['panel_widget_discount_title'] : __('کد تخفیف ویژه شما', 'reyhan-panel');
                    $d_code  = $opts['panel_widget_discount_text'];
                ?>
                    <div class="rp-card-stat rp-card-discount rp-full-width">
                        <div class="rp-discount-bg-decor"></div>
                        <div class="rp-discount-content-flex">
                            <div class="rp-discount-info">
                                <div class="rp-discount-icon-box">
                                    <span class="dashicons dashicons-tickets-alt"></span>
                                </div>
                                <div class="rp-discount-text">
                                    <span class="rp-dt-label"><?php echo esc_html($d_title); ?></span>
                                    <span class="rp-dt-desc"><?php esc_html_e('با استفاده از این کد در خرید بعدی تخفیف بگیرید.', 'reyhan-panel'); ?></span>
                                </div>
                            </div>
                            
                            <div class="rp-discount-code-area" onclick="navigator.clipboard.writeText('<?php echo esc_js($d_code); ?>'); alert('<?php echo esc_js(__('کد تخفیف کپی شد!', 'reyhan-panel')); ?>');">
                                <span class="rp-code-val"><?php echo esc_html($d_code); ?></span>
                                <span class="rp-copy-btn" title="<?php esc_attr_e('کپی کد', 'reyhan-panel'); ?>">
                                    <span class="dashicons dashicons-admin-page"></span>
                                    <?php esc_html_e('کپی', 'reyhan-panel'); ?>
                                </span>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div id="rp-section-orders" class="rp-tab-content" style="display:none;">
            <div id="rp-orders-list-container">
                <h2><?php esc_html_e('سفارشات من', 'reyhan-panel'); ?></h2>
                <div id="rp-orders-table-wrapper"><?php esc_html_e('در حال دریافت اطلاعات...', 'reyhan-panel'); ?></div>
            </div>
            <div id="rp-single-order-container" style="display:none;"></div>
        </div>

        <div id="rp-section-tickets" class="rp-tab-content" style="display:none;">
            <div class="rp-ticket-header"><h2><?php esc_html_e('پشتیبانی', 'reyhan-panel'); ?></h2><div><button class="rp-btn-new-ticket" onclick="jQuery('#rp-ticket-creation-area').slideToggle()">+ <?php esc_html_e('تیکت جدید', 'reyhan-panel'); ?></button></div></div>
            
            <div id="rp-ticket-creation-area" style="display:none;">
                <?php if(!empty($faqs)): ?>
                <div style="margin: 20px 0; background:#f9f9f9; padding:15px; border-radius:10px; border:1px dashed #ccc;">
                    <p style="text-align:center; font-weight:bold; color:#555; margin-bottom:10px;">
                        <span class="dashicons dashicons-search" style="vertical-align:middle;"></span> <?php esc_html_e('قبل از ارسال تیکت، اگر سوالی دارید اینجا جستجو کنید!', 'reyhan-panel'); ?>
                    </p>
                    <input type="text" id="rp-faq-search" class="rp-input-modern" placeholder="<?php esc_attr_e('جستجو در سوالات متداول...', 'reyhan-panel'); ?>" style="margin-bottom:0 !important;">
                    <div id="rp-faq-list" style="margin-top:10px;">
                        <?php foreach($faqs as $f): ?>
                            <div class="rp-faq-item" style="background:#fff; padding:10px; border-radius:8px; margin-bottom:5px; border:1px solid #eee; display:none;">
                                <div class="rp-faq-q" style="font-weight:bold; cursor:pointer;" onclick="jQuery(this).next().slideToggle()"><?php echo esc_html($f['q']); ?></div>
                                <div class="rp-faq-a" style="display:none; padding-top:5px; color:#666;"><?php echo nl2br(esc_html($f['a'])); ?></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <div class="rp-new-ticket-box">
                    <form id="rp-ticket-submit-form">
                        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:15px; margin-bottom:15px;">
                            <select name="department" class="rp-input-modern">
                                <?php 
                                if(!empty($depts)) {
                                    foreach($depts as $d) { echo '<option value="'.esc_attr($d['name']).'">'.esc_html($d['name']).'</option>'; }
                                } else {
                                    echo '<option value="general">'.__('عمومی', 'reyhan-panel').'</option>';
                                }
                                ?>
                            </select>
                            <select name="priority" class="rp-input-modern">
                                <option value="medium"><?php esc_html_e('اولویت: متوسط', 'reyhan-panel'); ?></option>
                                <option value="low"><?php esc_html_e('اولویت: کم', 'reyhan-panel'); ?></option>
                                <option value="high"><?php esc_html_e('اولویت: زیاد', 'reyhan-panel'); ?></option>
                            </select>
                        </div>
                        <input type="text" name="title" class="rp-input-modern" placeholder="<?php esc_attr_e('موضوع', 'reyhan-panel'); ?>" required>
                        <textarea name="message" class="rp-input-modern" rows="5" placeholder="<?php esc_attr_e('پیام...', 'reyhan-panel'); ?>" required></textarea>
                        <div style="margin-top:10px;"><input type="file" name="attachment"></div>
                        <button type="submit" class="rp-btn-new-ticket" style="margin-top:15px;"><?php esc_html_e('ارسال تیکت', 'reyhan-panel'); ?></button>
                    </form>
                </div>
            </div>

            <div id="rp-user-tickets-list" style="margin-top:20px;">
                <div class="rp-loading-spinner" style="margin:20px auto;"></div>
                <p style="text-align:center; color:#999;"><?php esc_html_e('در حال دریافت لیست تیکت‌ها...', 'reyhan-panel'); ?></p>
            </div>
        </div>

        <div id="rp-section-profile" class="rp-tab-content" style="display:none;">
            <div class="rp-profile-card">
                <div class="rp-pc-header">
                    <span class="dashicons dashicons-id-alt"></span>
                    <h3><?php esc_html_e('اطلاعات حساب کاربری', 'reyhan-panel'); ?></h3>
                </div>
                <div class="rp-pc-body">
                    <div class="rp-avatar-upload-box">
                        <div class="rp-avatar-circle">
                            <img src="<?php echo esc_url($avatar_url); ?>" id="rp-profile-img-preview" class="rp-dashboard-avatar-img">
                            <div class="rp-avatar-overlay" onclick="document.getElementById('rp_profile_avatar').click()">
                                <span class="dashicons dashicons-camera"></span>
                            </div>
                        </div>
                        <input type="file" id="rp_profile_avatar" style="display:none;" accept="image/jpeg, image/png">
                        <p><?php esc_html_e('برای تغییر تصویر روی آن کلیک کنید', 'reyhan-panel'); ?></p>
                    </div>

                    <form id="rp-profile-main-form">
                        <div class="rp-form-row-2">
                            <div class="rp-inp-group">
                                <label><?php esc_html_e('نام', 'reyhan-panel'); ?></label>
                                <input type="text" name="first_name" value="<?php echo esc_attr($u->first_name); ?>" class="rp-inp-modern">
                            </div>
                            <div class="rp-inp-group">
                                <label><?php esc_html_e('نام خانوادگی', 'reyhan-panel'); ?></label>
                                <input type="text" name="last_name" value="<?php echo esc_attr($u->last_name); ?>" class="rp-inp-modern">
                            </div>
                        </div>

                        <div class="rp-inp-group rp-verify-group">
                            <label><?php esc_html_e('ایمیل', 'reyhan-panel'); ?></label>
                            <div class="rp-verify-wrapper">
                                <input type="email" value="<?php echo esc_attr($u->user_email); ?>" class="rp-inp-modern ltr-inp" disabled>
                                <button type="button" class="rp-btn-verify" id="rp_btn_edit_email"><?php esc_html_e('تغییر ایمیل', 'reyhan-panel'); ?></button>
                            </div>
                            <div id="rp-edit-email-box" class="rp-edit-box">
                                <p class="rp-box-desc"><?php esc_html_e('ایمیل جدید را وارد کنید تا کد تایید ارسال شود:', 'reyhan-panel'); ?></p>
                                <input type="email" id="rp_new_email" placeholder="example@mail.com" class="rp-inp-modern ltr-inp">
                                <button type="button" class="rp-send-otp-btn rp-btn-small" data-type="email"><?php esc_html_e('ارسال کد تایید', 'reyhan-panel'); ?></button>
                                <span id="rp-email-timer" class="rp-timer-badge"></span>
                                <div class="rp-verify-email-section" style="display:none; margin-top:10px;">
                                    <input type="text" id="rp_email_code" placeholder="<?php esc_attr_e('کد تایید ۵ رقمی', 'reyhan-panel'); ?>" class="rp-inp-small ltr-inp">
                                    <button type="button" id="rp_confirm_email_final" class="rp-btn-small success"><?php esc_html_e('تایید نهایی', 'reyhan-panel'); ?></button>
                                </div>
                            </div>
                        </div>

                        <div class="rp-inp-group rp-verify-group">
                            <label><?php esc_html_e('شماره موبایل', 'reyhan-panel'); ?></label>
                            <?php $mob = get_user_meta($u->ID, 'mobile', true); ?>
                            <div class="rp-verify-wrapper">
                                <input type="text" value="<?php echo esc_attr($mob); ?>" class="rp-inp-modern ltr-inp" disabled>
                                <button type="button" class="rp-btn-verify" id="rp_btn_edit_mobile"><?php esc_html_e('تغییر شماره', 'reyhan-panel'); ?></button>
                            </div>
                            <div id="rp-edit-mobile-box" class="rp-edit-box">
                                <p class="rp-box-desc"><?php esc_html_e('شماره موبایل جدید را وارد کنید:', 'reyhan-panel'); ?></p>
                                <input type="text" id="rp_new_mobile" placeholder="09xxxxxxxxx" class="rp-inp-modern ltr-inp">
                                <button type="button" class="rp-send-otp-btn rp-btn-small" data-type="mobile"><?php esc_html_e('ارسال کد پیامک', 'reyhan-panel'); ?></button>
                                <span id="rp-mobile-timer" class="rp-timer-badge"></span>
                                <div class="rp-verify-mobile-section" style="display:none; margin-top:10px;">
                                    <input type="text" id="rp_mobile_code" placeholder="<?php esc_attr_e('کد پیامک شده', 'reyhan-panel'); ?>" class="rp-inp-small ltr-inp">
                                    <button type="button" id="rp_confirm_mobile_final" class="rp-btn-small success"><?php esc_html_e('تایید نهایی', 'reyhan-panel'); ?></button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <div class="rp-profile-card" style="margin-top:25px;">
                <div class="rp-pc-header">
                    <span class="dashicons dashicons-location"></span>
                    <h3><?php esc_html_e('اطلاعات آدرس', 'reyhan-panel'); ?></h3>
                </div>
                <div class="rp-pc-body">
                    <form id="rp-profile-address-form">
                        <div class="rp-form-row-2">
                            <div class="rp-inp-group">
                                <label><?php esc_html_e('استان', 'reyhan-panel'); ?></label>
                                <select name="billing_state" id="rp_state_select" class="rp-inp-modern" data-default="<?php echo esc_attr(get_user_meta($u->ID, 'billing_state', true)); ?>">
                                    <option value=""><?php esc_html_e('انتخاب استان...', 'reyhan-panel'); ?></option>
                                </select>
                            </div>
                            <div class="rp-inp-group">
                                <label><?php esc_html_e('شهر', 'reyhan-panel'); ?></label>
                                <select name="billing_city" id="rp_city_select" class="rp-inp-modern" data-default="<?php echo esc_attr(get_user_meta($u->ID, 'billing_city', true)); ?>">
                                    <option value=""><?php esc_html_e('انتخاب شهر...', 'reyhan-panel'); ?></option>
                                </select>
                            </div>
                        </div>
                        <div class="rp-form-row-2">
                            <div class="rp-inp-group" style="flex:2;">
                                <label><?php esc_html_e('آدرس کامل پستی', 'reyhan-panel'); ?></label>
                                <input type="text" name="billing_address_1" value="<?php echo esc_attr(get_user_meta($u->ID, 'billing_address_1', true)); ?>" class="rp-inp-modern">
                            </div>
                            <div class="rp-inp-group" style="flex:1;">
                                <label><?php esc_html_e('کد پستی', 'reyhan-panel'); ?></label>
                                <input type="text" name="billing_postcode" id="rp_postal_code" value="<?php echo esc_attr(get_user_meta($u->ID, 'billing_postcode', true)); ?>" class="rp-inp-modern ltr-inp postal-inp" maxlength="10">
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <div class="rp-save-area">
                <button type="button" id="rp_save_profile_info" class="rp-btn-save-all">
                    <span class="dashicons dashicons-saved"></span> <?php esc_html_e('ذخیره تمام تغییرات', 'reyhan-panel'); ?>
                </button>
            </div>
        </div>

        <?php foreach($menu_items as $idx => $item) { if(isset($item['action']) && $item['action']=='content') echo '<div id="rp-section-custom_tab_'.$idx.'" class="rp-tab-content" style="display:none;">'.do_shortcode($item['shortcode']??'').'</div>'; } ?>
    </div>
</div>