<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<style>
    :root {
        --rp-orange: <?php echo $p['btn_bg']; ?>;
        --rp-gradient: <?php echo $p['gradient']; ?>;
        --rp-shadow: <?php echo $p['shadow']; ?>;
        <?php if($sb_img) echo "--rp-sb-img: url('$sb_img');"; ?>
        <?php if($sb_img && $sb_overlay) echo "--rp-sb-overlay: $sb_overlay;"; ?>
    }
    <?php if($sb_img): ?>
        .rp-sidebar { background-image: var(--rp-sb-img) !important; background-size: cover !important; }
    <?php endif; ?>
    <?php if($sb_img && $sb_overlay): ?>
        .rp-sidebar::before { content:''; position:absolute; inset:0; background: var(--rp-sb-overlay); z-index: -1; border-radius: 20px; }
    <?php endif; ?>
</style>

<button id="rp-mobile-menu-trigger" class="rp-mobile-toggle-btn">
    <span class="dashicons dashicons-menu-alt"></span>
</button>

<div id="rp-mobile-overlay" class="rp-mobile-overlay"></div>

<div class="rp-dashboard-box">
    <div class="rp-sidebar" id="rp-main-sidebar">
        <a href="<?php echo home_url(); ?>" class="rp-back-home-btn" title="بازگشت به صفحه اصلی">
            <span class="dashicons dashicons-admin-home"></span> بازگشت به خانه
        </a>

        <div class="rp-user-info">
            <div class="rp-user-avatar"><img src="<?php echo esc_url($avatar_url); ?>" style="width:100%; height:100%; object-fit:cover;"></div>
            <div class="rp-user-name"><?php echo esc_html($display_name); ?></div>
            <div class="rp-user-role-badge"><?php echo esc_html($role_label); ?></div>
            <?php if ( $is_agent_user ) : ?>
                <div class="rp-agent-badge-box">
                    <span class="rp-agent-badge">
                        <span class="dashicons dashicons-headset"></span> پاسخگوی تیکت
                    </span>
                </div>
            <?php endif; ?>
        </div>

        <ul class="rp-menu">
            <?php
            foreach($menu_items as $idx => $item) {
                $lbl = esc_html($item['label']); $act = $item['action']; $lnk = $item['link'] ?? '#';
                $tab_id = ($act == 'content') ? 'custom_tab_'.$idx : $act;
                
                $icon_type = $item['icon_type'] ?? 'icon'; $uploaded_url = $item['custom_image'] ?? ''; $icon_html = '';
                if ( $icon_type === 'image' && !empty($uploaded_url) ) { $icon_html = '<img src="'.esc_url($uploaded_url).'" class="rp-menu-img-icon" alt="icon">'; } 
                else { $ico = esc_attr($item['icon'] ?? 'dashicons-marker'); $icon_html = '<span class="dashicons '.$ico.'"></span>'; }

                if(in_array($act, ['dashboard', 'tickets', 'orders', 'profile', 'content'])) {
                    if($act == 'orders' && !class_exists('WooCommerce')) continue;
                    $cls = ($act == 'dashboard') ? 'active' : '';
                    echo "<li class='$cls' data-tab='$tab_id'>$icon_html $lbl</li>";
                } elseif($act == 'logout') {
                    echo "<li onclick=\"location.href='".wp_logout_url(get_permalink())."'\">$icon_html $lbl</li>";
                } elseif($act == 'link') {
                    echo "<li onclick=\"window.open('$lnk', '_blank')\">$icon_html $lbl <span class='dashicons dashicons-external' style='font-size:12px; float:left; margin-top:4px;'></span></li>";
                }
            }
            ?>
        </ul>
    </div>

    <div class="rp-content">
        
        <?php 
        if ( ! empty( $notifications ) && is_array( $notifications ) ) {
            foreach ( $notifications as $n ) {
                $is_active = ( isset($n['active']) && ( $n['active'] === '1' || $n['active'] === true ) );
                if ( $is_active ) {
                    $type = $n['type'] ?? 'info';
                    $icon_class = 'dashicons-info';
                    switch($type) {
                        case 'success': $icon_class = 'dashicons-yes-alt'; break;
                        case 'warning': $icon_class = 'dashicons-warning'; break;
                        case 'danger':  $icon_class = 'dashicons-dismiss'; break;
                    }
                    echo '<div class="rp-global-notification rp-notif-' . $type . '">
                            <div class="rp-gn-icon"><span class="dashicons ' . $icon_class . '"></span></div>
                            <div class="rp-gn-content">
                                ' . ($n['title'] ? '<strong class="rp-gn-title">'.esc_html($n['title']).'</strong>' : '') . '
                                <div class="rp-gn-text">'.nl2br(esc_html($n['msg'])).'</div>
                            </div>
                          </div>';
                }
            }
        }
        ?>

        <div id="rp-section-dashboard" class="rp-tab-content" style="display:block;">
            <h3 style="border-bottom:2px solid #eee; padding-bottom:10px; margin-bottom:20px;"><?php echo esc_html($display_name); ?> عزیز! خوش آمدید 👋</h3>
            <div class="rp-dashboard-grid">
                <?php if(empty($opts['panel_widget_ticket_hide'])): ?><div class="rp-card-stat"><span>تیکت‌های باز</span><strong id="rp-dash-count-open"><?php echo $count_tickets_open; ?></strong></div><?php endif; ?>
                <?php if(empty($opts['panel_widget_order_hide']) && class_exists('WooCommerce')): ?><div class="rp-card-stat"><span>کل سفارشات</span><strong><?php echo $count_orders; ?></strong></div><?php endif; ?>
                <?php if(empty($opts['panel_widget_comments_hide'])): ?><div class="rp-card-stat"><span>دیدگاه‌های شما</span><strong><?php echo $count_comments; ?></strong></div><?php endif; ?>
                <?php if(empty($opts['panel_widget_days_hide'])): ?><div class="rp-card-stat"><span>روزهای عضویت</span><strong><?php echo $days_diff; ?> روز</strong></div><?php endif; ?>
                <?php if(!empty($opts['panel_widget_discount_text']) && empty($opts['panel_widget_discount_hide'])): ?><div class="rp-card-stat rp-full-width" style="border-right-color:#4CAF50 !important; background:#e8f5e9;"><span style="color:#2E7D32;">🎁 کد تخفیف ویژه برای شما</span><strong style="font-family:monospace; font-size:18px; color:#1B5E20;"><?php echo esc_html($opts['panel_widget_discount_text']); ?></strong></div><?php endif; ?>
            </div>
        </div>

        <div id="rp-section-tickets" class="rp-tab-content" style="display:none;">
            <div class="rp-ticket-header">
                <h2 style="margin:20px; font-size:20px; color:#333;">تیکت‌های پشتیبانی</h2>
                <div style="display:flex; gap:10px;">
                    <button class="rp-btn-secondary" onclick="loadUserTickets()" style="background:#f5f5f5; color:#555; border:none; padding:10px 15px; border-radius:8px; cursor:pointer;">🔄 بروزرسانی</button>
                    <button class="rp-btn-new-ticket" onclick="jQuery('#rp-ticket-creation-area').slideToggle()">+ ثبت تیکت جدید</button>
                </div>
            </div>

            <?php
            // انتقال داده‌ها به JS برای جستجو
            echo '<script>var rp_faq_db = ' . json_encode(array_values($faqs)) . ';</script>';
            ?>
            
            <div class="rp-faq-section-modern">
                <div class="rp-faq-search-wrap">
                    <input type="text" id="rp-modern-faq-input" placeholder="جستجو در سوالات متداول (قبل از ارسال تیکت)...">
                    <span class="dashicons dashicons-search"></span>
                </div>
                <div id="rp-modern-faq-results" style="display:none;"></div>
            </div>

            <div id="rp-ticket-creation-area" style="display:none;">
                <div class="rp-new-ticket-box">
                    <h3 style="margin-top:0; border-bottom:1px solid #eee; padding-bottom:15px; margin-bottom:20px;">ارسال درخواست جدید</h3>
                    <form id="rp-ticket-submit-form" enctype="multipart/form-data">
                        <div class="rp-form-grid"><div><label class="rp-form-label">موضوع</label><input type="text" name="title" class="rp-input-modern" required></div><div><label class="rp-form-label">دپارتمان</label><select name="department" class="rp-input-modern"><?php if($depts) foreach($depts as $d) echo '<option value="'.$d['name'].'">'.$d['name'].'</option>'; else echo '<option value="پشتیبانی">پشتیبانی</option>'; ?></select></div></div>
                        <div class="rp-form-grid" style="margin-bottom:20px;"><div><label class="rp-form-label">اولویت</label><select name="priority" class="rp-input-modern"><option value="high">مهم</option><option value="medium" selected>متوسط</option><option value="low">کم</option></select></div><div><label class="rp-form-label">ضمیمه</label><input type="file" name="attachment" class="rp-input-modern" style="padding:9px;"></div></div>
                        <label class="rp-form-label">پیام</label><textarea name="message" class="rp-input-modern" rows="5" required></textarea>
                        <div style="margin-top:20px; text-align:left;"><button type="submit" class="rp-btn-new-ticket">ارسال تیکت</button></div>
                    </form>
                </div>
            </div>
            
            <div id="rp-user-tickets-list"><div style="text-align:center; padding:40px; color:#999;">در حال بارگذاری لیست...</div></div>
        </div>

        <?php if(class_exists('WooCommerce')): ?>
            <div id="rp-section-orders" class="rp-tab-content" style="display:none;">
                <div id="rp-order-list-container">
                    <h3 style="margin-bottom:20px; border-bottom: 2px dashed #eee; padding-bottom: 15px;">لیست سفارشات</h3>
                    <?php 
                    $customer_orders = wc_get_orders( array( 'customer' => get_current_user_id(), 'limit' => -1, 'status' => 'any' ) );
                    if ( $customer_orders ) : ?>
                        <div class="rp-orders-grid">
                            <?php foreach ( $customer_orders as $order ) : 
                                $status_class = 'rp-order-status-' . $order->get_status();
                                ?>
                                <div class="rp-order-card">
                                    <div class="rp-order-card-header">
                                        <span class="rp-order-id">#<?php echo $order->get_order_number(); ?></span>
                                        <span class="rp-order-date"><?php echo wc_format_datetime( $order->get_date_created() ); ?></span>
                                    </div>
                                    <div class="rp-order-card-body">
                                        <div class="rp-order-row"><span class="rp-label">وضعیت:</span><span class="rp-value rp-badge <?php echo $status_class; ?>"><?php echo wc_get_order_status_name( $order->get_status() ); ?></span></div>
                                        <div class="rp-order-row"><span class="rp-label">مبلغ:</span><span class="rp-value price"><?php echo $order->get_formatted_order_total(); ?></span></div>
                                        <div class="rp-order-row"><span class="rp-label">تعداد اقلام:</span><span class="rp-value"><?php echo $order->get_item_count(); ?> عدد</span></div>
                                    </div>
                                    <div class="rp-order-card-footer">
                                        <button type="button" class="rp-view-order-btn" data-id="<?php echo $order->get_id(); ?>">مشاهده جزئیات <span class="dashicons dashicons-arrow-left-alt2"></span></button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else : ?>
                        <div class="rp-alert rp-alert-info">شما هنوز هیچ سفارشی ثبت نکرده‌اید.</div>
                    <?php endif; ?>
                </div>
                <div id="rp-single-order-container" style="display:none;">
                    <div class="rp-order-header-actions">
                        <button type="button" id="rp-back-to-orders" class="rp-btn-secondary"><span class="dashicons dashicons-arrow-right-alt2"></span> بازگشت به لیست</button>
                        <h3>جزئیات سفارش <span id="rp-single-order-id"></span></h3>
                    </div>
                    <div id="rp-single-order-content"></div>
                </div>
            </div>
        <?php endif; ?>

        <div id="rp-section-profile" class="rp-tab-content" style="display:none;">
            <div class="rp-profile-section" style="text-align:center;"><img id="rp-profile-preview" src="<?php echo esc_url($avatar_url); ?>" class="rp-profile-avatar-edit" style="width:100px; height:100px; border-radius:50%; margin:0 auto 15px; display:block; border:3px solid #eee;"><form id="rp-avatar-form"><label for="rp_avatar_input" style="cursor:pointer; color:var(--rp-orange); font-weight:bold; display:inline-flex; align-items:center; gap:5px; padding:5px 15px; border:1px solid var(--rp-orange); border-radius:20px; transition:0.3s;"><span class="dashicons dashicons-camera"></span> تغییر تصویر پروفایل</label><input type="file" name="avatar" id="rp_avatar_input" style="display:none;" accept="image/*"></form></div>
            <div class="rp-profile-section"><div class="rp-section-title"><span class="dashicons dashicons-id-alt"></span> اطلاعات عمومی</div><form id="rp-general-info-form"><div class="rp-profile-grid"><div><label class="rp-form-label">نام کوچک</label><input type="text" name="first_name" class="rp-input-modern" value="<?php echo esc_attr($u->first_name); ?>"></div><div><label class="rp-form-label">نام خانوادگی</label><input type="text" name="last_name" class="rp-input-modern" value="<?php echo esc_attr($u->last_name); ?>"></div></div><div style="margin-top:15px;"><label class="rp-form-label">آدرس ایمیل</label><input type="email" name="email" class="rp-input-modern" value="<?php echo esc_attr($u->user_email); ?>" style="direction:ltr; text-align:left;"></div><div style="margin-top:20px; text-align:left;"><button type="submit" class="rp-btn-new-ticket">ذخیره اطلاعات عمومی</button></div></form></div>
            
            <div class="rp-profile-section">
                <div class="rp-section-title"><span class="dashicons dashicons-smartphone"></span> شماره همراه (نیاز به تایید)</div>
                <div class="rp-mobile-wrap" style="display:flex; gap:10px; align-items:flex-end;">
                    <div style="flex-grow:1; width:100%;"><label class="rp-form-label">شماره فعلی: <span style="font-weight:normal; color:#666;"><?php echo esc_html(get_user_meta($u->ID, 'mobile', true)); ?></span></label><input type="text" id="rp-new-mobile" class="rp-input-modern" placeholder="شماره جدید را وارد کنید..." maxlength="11" style="text-align:center; letter-spacing:2px;"></div><button type="button" id="rp-send-mobile-otp" class="rp-btn-new-ticket" style="margin-bottom:2px; white-space:nowrap;">دریافت کد تایید</button>
                </div>
                <div id="rp-mobile-verify-box" class="rp-verify-box">
                    <p style="font-size:12px; margin-bottom:10px;">کد ارسال شده به شماره جدید را وارد کنید:</p>
                    <div class="rp-mobile-wrap" style="display:flex; gap:10px;"><input type="text" id="rp-mobile-otp-input" class="rp-input-modern" placeholder="کد 5 رقمی" maxlength="5" style="text-align:center; letter-spacing:5px; font-weight:bold;"><button type="button" id="rp-verify-mobile-otp" class="rp-btn-new-ticket" style="background:#4CAF50 !important; white-space:nowrap;">تایید و ثبت</button></div>
                </div>
            </div>

            <?php if ($auth_method === 'email'): ?><div class="rp-profile-section"><div class="rp-section-title"><span class="dashicons dashicons-lock"></span> امنیت و رمز عبور</div><form id="rp-password-form"><div class="rp-profile-grid"><div><label class="rp-form-label">رمز عبور جدید</label><input type="password" name="new_pass" class="rp-input-modern" placeholder="••••••••"></div><div><label class="rp-form-label">تکرار رمز عبور</label><input type="password" name="conf_pass" class="rp-input-modern" placeholder="••••••••"></div></div><div style="margin-top:20px; text-align:left;"><button type="submit" class="rp-btn-new-ticket" style="background:#333 !important;">تغییر رمز عبور</button></div></form></div><?php endif; ?>
        </div>

        <?php foreach($menu_items as $idx => $item) {
            if(isset($item['action']) && $item['action'] == 'content') {
                echo '<div id="rp-section-custom_tab_'.$idx.'" class="rp-tab-content" style="display:none;"><h3>'.esc_html($item['label']).'</h3><div class="rp-custom-content">'.do_shortcode($item['shortcode'] ?? '').'</div></div>';
            }
        } ?>
    </div>
</div>