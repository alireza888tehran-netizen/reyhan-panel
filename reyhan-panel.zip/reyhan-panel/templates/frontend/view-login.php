<?php 
if ( ! defined( 'ABSPATH' ) ) { exit; } 

$opts = isset($opts) ? $opts : get_option('reyhan_options');
$p = isset($p) ? $p : [
    'gradient' => 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    'btn_bg' => '#764ba2', 
    'shadow' => 'rgba(118, 75, 162, 0.4)', 
    'text_col' => '#764ba2'
];

$auth_method = isset($method) ? $method : ($opts['auth_method'] ?? 'email');
$is_sms = ($auth_method === 'sms');

$login_placeholder = $is_sms ? __('شماره موبایل', 'reyhan-panel') : __('ایمیل یا نام کاربری', 'reyhan-panel');
$reg_placeholder   = $is_sms ? __('شماره موبایل', 'reyhan-panel') : __('آدرس ایمیل معتبر', 'reyhan-panel');
$reg_input_name    = $is_sms ? 'reg_mobile' : 'reg_email';

$block_disposable = !empty($opts['block_disposable_emails']);
$recaptcha_active = !empty($opts['recaptcha_active']) && !empty($opts['recaptcha_site_key']);
$recaptcha_site_key = $recaptcha_active ? $opts['recaptcha_site_key'] : '';

$show_home_link = !empty($opts['login_show_home']);
$copyright_text = !empty($opts['login_copyright']) ? $opts['login_copyright'] : '';
?>

<style>
    :root {
        --rp-login-bg: <?php echo $p['gradient']; ?>;
        --rp-login-btn: <?php echo $p['btn_bg']; ?>;
        --rp-login-shadow: <?php echo $p['shadow']; ?>;
        --rp-login-text: <?php echo $p['text_col']; ?>;
    }
    .rp-auth-tabs { display: flex; gap: 15px; justify-content: center; margin-bottom: 20px; border-bottom: 1px solid rgba(0,0,0,0.05); padding-bottom: 10px; }
    .rp-switch-auth-link { background: none; border: none; font-size: 14px; color: #999; cursor: pointer; padding: 5px 10px; transition: 0.3s; font-family: inherit; }
    .rp-switch-auth-link.active { color: var(--rp-login-text); font-weight: bold; border-bottom: 2px solid var(--rp-login-text); }
    .rp-footer-links { margin-top: 20px; border-top: 1px dashed #eee; padding-top: 15px; width: 100%; text-align: center; display: flex; flex-direction: column; gap: 10px; align-items: center; }
    .rp-footer-copyright { font-size: 11px; opacity: 0.6; color: #555; }

    /* باکس راهنما */
    .rp-pwd-guide-box { background: rgba(0,0,0,0.02); border: 1px dashed #ddd; border-radius: 12px; padding: 15px; margin-top: 10px; font-size: 11px; text-align: right; display: none; transition: 0.3s; }
    .rp-pwd-title { font-weight: bold; color: var(--rp-login-text); margin-bottom: 8px; display: block; border-bottom: 1px solid rgba(0,0,0,0.05); padding-bottom: 5px; }
    .rp-pwd-rules { list-style: none; padding: 0; margin: 0; display: grid; grid-template-columns: 1fr 1fr; gap: 5px; }
    .rp-rule-item { color: #999; transition: all 0.3s ease; display: flex; align-items: center; }
    .rp-rule-item::before { content: '\2022'; margin-left: 5px; font-size: 14px; color: #ccc; }
    .rp-rule-item.valid { color: #4caf50; font-weight: bold; }
    .rp-rule-item.valid::before { content: '\2713'; color: #4caf50; }
    
    .shake-box { animation: shake 0.5s; border-color: #e53935; }
    @keyframes shake { 0% { transform: translateX(0); } 25% { transform: translateX(-5px); } 50% { transform: translateX(5px); } 75% { transform: translateX(-5px); } 100% { transform: translateX(0); } }
    
    .rp-input.error { border-color: #e53935 !important; background: #fff5f5 !important; }
    
    /* باکس‌های پیام (نوتیفیکیشن) */
    .rp-alert-box {
        padding: 10px; border-radius: 8px; font-size: 12px; margin-bottom: 15px; display: none; text-align: center; width: 100%;
    }
    .rp-alert-error { background: #ffebee; color: #c62828; border: 1px solid #ef9a9a; }
    .rp-alert-success { background: #e8f5e9; color: #2e7d32; border: 1px solid #a5d6a7; }
    
    /* لودینگ دکمه */
    .rp-btn-loading { opacity: 0.7; pointer-events: none; cursor: wait; }
</style>

<?php if($recaptcha_active): ?>
<script src="https://www.google.com/recaptcha/api.js?render=<?php echo esc_attr($recaptcha_site_key); ?>"></script>
<?php endif; ?>

<div class="rp-fullscreen-canvas">
    <div class="rp-login-wrap">
        
        <div class="rp-logo-area">
            <?php if ( ! empty( $logo ) ) : ?>
                <img src="<?php echo esc_url( $logo ); ?>" class="rp-custom-logo" style="width: <?php echo esc_attr($logo_w); ?>px;">
            <?php endif; ?>
            <h2><?php echo esc_html($title); ?></h2>
            <p><?php echo esc_html($sub); ?></p>
        </div>

        <div class="rp-auth-tabs">
            <button type="button" class="rp-switch-auth-link active" data-target="login-form">
                <?php esc_html_e('ورود به حساب', 'reyhan-panel'); ?>
            </button>
            <button type="button" class="rp-switch-auth-link" data-target="register-form">
                <?php esc_html_e('ساخت حساب جدید', 'reyhan-panel'); ?>
            </button>
        </div>

        <div id="rp-global-msg" class="rp-alert-box"></div>

        <form id="rp-login-form" class="rp-auth-form active">
            <div class="rp-input-group">
                <input type="text" name="log" class="rp-input" placeholder="<?php echo esc_attr($login_placeholder); ?>" required style="text-align:center;">
            </div>
            
            <div class="rp-pass-field" style="display:none; width:100%; margin-top:10px;">
                <input type="password" name="pwd" class="rp-input" placeholder="<?php esc_attr_e('رمز عبور', 'reyhan-panel'); ?>" style="text-align:center;">
            </div>

            <div class="rp-login-actions" style="width:100%; margin-top:15px;">
                <?php if ( $is_sms ) : ?>
                    <button type="button" id="rp-btn-otp-login" class="rp-btn-primary">
                        <?php esc_html_e('ورود با کد تایید', 'reyhan-panel'); ?>
                    </button>
                    <button type="button" id="rp-btn-pass-login" class="rp-switch-mode-btn" style="margin-top:10px; background:none; border:none; color:#777; font-size:12px; cursor:pointer; width:100%;">
                        <?php esc_html_e('ورود با رمز عبور', 'reyhan-panel'); ?>
                    </button>
                <?php else : ?>
                    <button type="button" id="rp-btn-pass-login" class="rp-btn-primary" style="display:block;">
                        <?php esc_html_e('ورود به سیستم', 'reyhan-panel'); ?>
                    </button>
                <?php endif; ?>
            </div>
            
            <div class="rp-otp-verify-section" style="display:none; width:100%; margin-top:15px;">
                <p style="font-size:12px; margin-bottom:5px; text-align:center;"><?php esc_html_e('کد پیامک شده را وارد کنید:', 'reyhan-panel'); ?></p>
                <input type="text" id="rp-otp-code" class="rp-input" maxlength="5" placeholder="_ _ _ _ _" style="letter-spacing: 5px; font-weight:bold; text-align:center;">
                <button type="button" id="rp-verify-otp" class="rp-btn-primary" style="margin-top:10px;">
                    <?php esc_html_e('تایید و ورود', 'reyhan-panel'); ?>
                </button>
            </div>
        </form>

        <form id="rp-register-form" class="rp-auth-form" style="display:none;">
            <input type="hidden" name="recaptcha_token" id="rp_recaptcha_token">
            <input type="hidden" name="action" value="reyhan_register_request">

            <div style="width:100%; margin-bottom:10px;">
                <input type="text" id="reg_main_input" name="<?php echo esc_attr($reg_input_name); ?>" class="rp-input" placeholder="<?php echo esc_attr($reg_placeholder); ?>" required style="text-align:center;">
            </div>

            <input type="text" name="reg_name" id="reg_name_input" class="rp-input" placeholder="<?php esc_attr_e('نام و نام خانوادگی', 'reyhan-panel'); ?>" style="text-align:center; margin-bottom:10px;">
            
            <?php if ( $is_sms ) : ?>
                <button type="button" id="rp-btn-register-start" class="rp-btn-primary">
                    <?php esc_html_e('دریافت کد تایید', 'reyhan-panel'); ?>
                </button>
            <?php else : ?>
                 <div class="rp-pass-field" style="width:100%; margin-bottom:10px;">
                    <input type="password" id="reg_pwd_input" name="reg_pwd" class="rp-input" placeholder="<?php esc_attr_e('رمز عبور امن...', 'reyhan-panel'); ?>" style="text-align:center; direction:ltr;">
                    
                    <div id="rp-pwd-smart-guide" class="rp-pwd-guide-box">
                        <span class="rp-pwd-title"><?php esc_html_e('شرایط رمز عبور امن:', 'reyhan-panel'); ?></span>
                        <ul class="rp-pwd-rules">
                            <li id="rule-len" class="rp-rule-item"><?php esc_html_e('حداقل ۸ کاراکتر', 'reyhan-panel'); ?></li>
                            <li id="rule-eng" class="rp-rule-item"><?php esc_html_e('فقط انگلیسی و اعداد', 'reyhan-panel'); ?></li>
                            <li id="rule-upper" class="rp-rule-item"><?php esc_html_e('حداقل یک حرف بزرگ', 'reyhan-panel'); ?></li>
                            <li id="rule-spec" class="rp-rule-item"><?php esc_html_e('یک کاراکتر خاص (@!#)', 'reyhan-panel'); ?></li>
                        </ul>
                    </div>
                </div>
                <button type="button" id="rp-btn-register-email" class="rp-btn-primary">
                    <?php esc_html_e('تکمیل ثبت نام', 'reyhan-panel'); ?>
                </button>
            <?php endif; ?>
        </form>

        <div class="rp-footer-links">
            <?php if ( $show_home_link ) : ?>
                <a href="<?php echo home_url(); ?>" style="text-decoration:none; color:var(--rp-login-text); font-size:12px; font-weight:bold;">
                    <?php esc_html_e('بازگشت به صفحه اصلی', 'reyhan-panel'); ?>
                </a>
            <?php endif; ?>

            <?php if ( ! empty($copyright_text) ) : ?>
                <div class="rp-footer-copyright">
                    <?php echo wp_kses_post( $copyright_text ); ?>
                </div>
            <?php endif; ?>
        </div>

    </div>
</div>

<script>
jQuery(document).ready(function($){
    var blockDisposable = <?php echo $block_disposable ? 'true' : 'false'; ?>;
    
    // توابع نمایش پیام
    function showError(msg) {
        $('#rp-global-msg').removeClass('rp-alert-success').addClass('rp-alert-error').html(msg).slideDown();
        setTimeout(function(){ $('#rp-global-msg').slideUp(); }, 5000);
    }
    function showSuccess(msg) {
        $('#rp-global-msg').removeClass('rp-alert-error').addClass('rp-alert-success').html(msg).slideDown();
    }

    // سوییچ تب‌ها
    $('.rp-switch-auth-link').click(function(){
        $('.rp-switch-auth-link').removeClass('active');
        $(this).addClass('active');
        var target = $(this).data('target');
        $('.rp-auth-form').hide();
        $('#' + 'rp-' + target).fadeIn(200);
        $('#rp-global-msg').hide();
    });

    $('#rp-btn-pass-login').click(function(e){
        if($(this).attr('type') === 'button') {
            e.preventDefault();
            $('.rp-pass-field').slideToggle();
            $(this).hide(); 
        }
    });

    // راهنمای رمز عبور
    var $pwdInput = $('#reg_pwd_input');
    var $guideBox = $('#rp-pwd-smart-guide');
    $pwdInput.focus(function(){ $guideBox.slideDown(200); });
    $pwdInput.on('keyup input', function(){
        var val = $(this).val();
        if(val.length >= 8) $('#rule-len').addClass('valid'); else $('#rule-len').removeClass('valid');
        var isEnglishOnly = /^[A-Za-z0-9!@#$%^&*()_+=.-]+$/.test(val);
        if(val.length > 0 && isEnglishOnly) $('#rule-eng').addClass('valid'); else $('#rule-eng').removeClass('valid');
        if(/[A-Z]/.test(val)) $('#rule-upper').addClass('valid'); else $('#rule-upper').removeClass('valid');
        if(/[!@#$%^&*()_+=.-]/.test(val)) $('#rule-spec').addClass('valid'); else $('#rule-spec').removeClass('valid');
    });

    function validateEmail(email) {
        var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    var disposableDomains = ['tempmail.com', '10minutemail.com', 'throwawaymail.com', 'guerrillamail.com', 'yopmail.com'];

    // --- مدیریت کلیک دکمه ثبت نام ---
    $('#rp-btn-register-email').click(function(e){
        e.preventDefault();
        
        // 1. اعتبارسنجی رمز
        var allPwdValid = $('#rp-pwd-smart-guide .rp-rule-item').length === $('#rp-pwd-smart-guide .rp-rule-item.valid').length;
        if (!allPwdValid) {
            $guideBox.addClass('shake-box'); setTimeout(function(){ $guideBox.removeClass('shake-box'); }, 500);
            if(!$guideBox.is(':visible')) $guideBox.slideDown();
            return;
        }

        // 2. اعتبارسنجی ایمیل
        var $emailInput = $('#reg_main_input');
        var emailVal = $emailInput.val().trim().toLowerCase();
        $emailInput.removeClass('error');
        
        if (!validateEmail(emailVal)) {
            $emailInput.addClass('error');
            showError('<?php esc_html_e("لطفاً یک ایمیل معتبر وارد کنید.", "reyhan-panel"); ?>');
            return;
        }
        if (blockDisposable) {
            var domain = emailVal.split('@')[1];
            if (disposableDomains.includes(domain)) {
                $emailInput.addClass('error');
                showError('<?php esc_html_e("ثبت نام با ایمیل‌های موقت مجاز نیست.", "reyhan-panel"); ?>');
                return;
            }
        }

        // 3. تابع ارسال AJAX
        var performRegister = function(token) {
            var $btn = $('#rp-btn-register-email');
            var originalText = $btn.text();
            $btn.addClass('rp-btn-loading').text('<?php esc_html_e("در حال پردازش...", "reyhan-panel"); ?>');

            var formData = {
                action: 'reyhan_register_request', // اکشن پیش‌فرض
                nonce: reyhan_front_obj.nonce,
                reg_email: emailVal,
                reg_name: $('#reg_name_input').val(),
                reg_pwd: $('#reg_pwd_input').val(),
                recaptcha_token: token || ''
            };

            $.post(reyhan_front_obj.ajax_url, formData, function(response) {
                $btn.removeClass('rp-btn-loading').text(originalText);
                
                if (response.success) {
                    showSuccess(response.data.message || '<?php esc_html_e("ثبت نام با موفقیت انجام شد. در حال انتقال...", "reyhan-panel"); ?>');
                    setTimeout(function(){
                        if(response.data.redirect) window.location.href = response.data.redirect;
                        else location.reload();
                    }, 1500);
                } else {
                    showError(response.data.message || '<?php esc_html_e("خطایی رخ داد.", "reyhan-panel"); ?>');
                }
            }).fail(function(){
                $btn.removeClass('rp-btn-loading').text(originalText);
                showError('<?php esc_html_e("خطای ارتباط با سرور.", "reyhan-panel"); ?>');
            });
        };

        // 4. اجرای نهایی (با یا بدون ریکپچا)
        <?php if($recaptcha_active): ?>
            grecaptcha.ready(function() {
                grecaptcha.execute('<?php echo esc_attr($recaptcha_site_key); ?>', {action: 'register'}).then(function(token) {
                    performRegister(token);
                });
            });
        <?php else: ?>
            performRegister('');
        <?php endif; ?>
    });
});
</script>