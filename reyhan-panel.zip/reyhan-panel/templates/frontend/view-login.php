<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<style>:root{--rp-login-bg:<?php echo $p['gradient'];?>;--rp-login-btn:<?php echo $p['btn_bg'];?>;--rp-login-text:<?php echo $p['text_col'];?>;}</style>
<div class="rp-fullscreen-canvas">
    <div class="rp-login-wrap">
        <div class="rp-logo-area">
            <?php if($logo): ?><img src="<?php echo esc_url($logo); ?>" class="rp-custom-logo"><?php endif; ?>
            <h2><?php echo esc_html($title); ?></h2>
        </div>

        <?php if ($method == 'sms'): ?>
            <form id="rp-login-form-sms">
                <div id="step-1-box"><input type="text" id="rp_mobile" class="rp-input" placeholder="<?php esc_attr_e('شماره موبایل', 'reyhan-panel'); ?>"></div>
                <div id="step-2-box" style="display:none;"><input type="text" id="rp_code" class="rp-input" placeholder="<?php esc_attr_e('کد تایید', 'reyhan-panel'); ?>"></div>
                <button type="submit" id="rp-login-btn" class="rp-btn-primary"><?php esc_html_e('دریافت کد', 'reyhan-panel'); ?></button>
            </form>
        <?php else: ?>
            <div id="rp-email-flow-container">
                
                <form id="rp-step-email-check">
                    <input type="email" id="rp_flow_email" class="rp-input" placeholder="<?php esc_attr_e('ایمیل خود را وارد کنید', 'reyhan-panel'); ?>" required>
                    <button type="submit" class="rp-btn-primary"><?php esc_html_e('ادامه', 'reyhan-panel'); ?></button>
                </form>

                <form id="rp-step-login-pass" style="display:none;">
                    <div class="rp-user-badge"><span id="rp-badge-email"></span> <a href="#" class="rp-change-email">(<?php esc_html_e('تغییر', 'reyhan-panel'); ?>)</a></div>
                    <input type="password" id="rp_flow_pass" class="rp-input" placeholder="<?php esc_attr_e('رمز عبور', 'reyhan-panel'); ?>" required>
                    <button type="submit" class="rp-btn-primary"><?php esc_html_e('ورود', 'reyhan-panel'); ?></button>
                    <div style="margin-top:10px; text-align:center;">
                        <a href="#" id="rp-trigger-fp" style="font-size:12px; color:#666;"><?php esc_html_e('رمز عبور را فراموش کردید؟', 'reyhan-panel'); ?></a>
                    </div>
                </form>

                <form id="rp-step-register-full" style="display:none;">
                    <div class="rp-user-badge"><?php esc_html_e('ثبت‌نام با:', 'reyhan-panel'); ?> <span id="rp-reg-email-display"></span></div>
                    <input type="text" id="rp_reg_fname" class="rp-input" placeholder="<?php esc_attr_e('نام', 'reyhan-panel'); ?>" required>
                    <input type="text" id="rp_reg_lname" class="rp-input" placeholder="<?php esc_attr_e('نام خانوادگی', 'reyhan-panel'); ?>" required>
                    
                    <div class="rp-pass-wrapper">
                        <input type="password" id="rp_reg_pass" class="rp-input" placeholder="<?php esc_attr_e('رمز عبور (مثال: A@a12345)', 'reyhan-panel'); ?>" required>
                        <input type="password" id="rp_reg_pass_confirm" class="rp-input" placeholder="<?php esc_attr_e('تکرار رمز عبور', 'reyhan-panel'); ?>" required>
                    </div>
                    <div id="rp-pass-rules" style="font-size:11px; color:#d63638; display:none; margin-bottom:10px; text-align:right;">
                        <?php esc_html_e('رمز عبور باید حداقل ۸ کاراکتر، شامل حروف بزرگ و کوچک انگلیسی و یک علامت (مانند @) باشد.', 'reyhan-panel'); ?>
                    </div>

                    <button type="submit" class="rp-btn-primary"><?php esc_html_e('ثبت نام و ورود', 'reyhan-panel'); ?></button>
                </form>

                <form id="rp-step-fp-otp" style="display:none;">
                    <p style="font-size:12px; margin-bottom:15px; color:#666;"><?php esc_html_e('کد تایید ارسال شده به ایمیل را وارد کنید:', 'reyhan-panel'); ?></p>
                    
                    <input type="text" id="rp_fp_code" class="rp-input" placeholder="<?php esc_attr_e('کد تایید', 'reyhan-panel'); ?>" required>
                    
                    <div style="margin: 10px 0; display:flex; justify-content:space-between; align-items:center;">
                        <span id="rp-fp-timer" style="font-size:13px; color:#FF5722; font-weight:bold;">05:00</span>
                        <button type="button" id="rp-fp-resend-btn" class="rp-btn-secondary" style="display:none; font-size:11px; padding:5px 10px; height:auto;"><?php esc_html_e('ارسال مجدد کد', 'reyhan-panel'); ?></button>
                    </div>

                    <button type="submit" class="rp-btn-primary"><?php esc_html_e('بررسی کد', 'reyhan-panel'); ?></button>
                    <button type="button" class="rp-btn-secondary rp-back-login" style="margin-top:5px;"><?php esc_html_e('بازگشت', 'reyhan-panel'); ?></button>
                </form>

                <form id="rp-step-fp-newpass" style="display:none;">
                    <p style="font-size:12px; margin-bottom:15px;"><?php esc_html_e('رمز عبور جدید خود را وارد کنید:', 'reyhan-panel'); ?></p>
                    <input type="password" id="rp_fp_new_pass" class="rp-input" placeholder="<?php esc_attr_e('رمز جدید', 'reyhan-panel'); ?>" required>
                    <input type="password" id="rp_fp_new_pass_conf" class="rp-input" placeholder="<?php esc_attr_e('تکرار رمز جدید', 'reyhan-panel'); ?>" required>
                    <button type="submit" class="rp-btn-primary"><?php esc_html_e('تغییر رمز و ورود', 'reyhan-panel'); ?></button>
                </form>

            </div>
        <?php endif; ?>
    </div>
</div>