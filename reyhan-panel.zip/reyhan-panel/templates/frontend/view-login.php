<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<style>
    :root {
        --rp-login-bg: <?php echo $p['gradient']; ?>;
        --rp-login-btn: <?php echo $p['btn_bg']; ?>;
        --rp-login-text: <?php echo $p['text_col']; ?>;
        --rp-login-shadow: <?php echo $p['shadow']; ?>;
        --rp-logo-width: <?php echo $logo_w; ?>px;
        <?php if($bg_mode === 'image' && $bg_image) echo "--rp-bg-image: url('$bg_image');"; ?>
        <?php if($bg_mode === 'color' && $bg_color) echo "--rp-bg-color: $bg_color;"; ?>
    }
    
    .rp-fullscreen-canvas {
        <?php if($bg_mode === 'image' && $bg_image): ?>
            background-image: var(--rp-bg-image) !important;
            background-size: cover !important;
            background-position: center !important;
        <?php elseif($bg_mode === 'color' && $bg_color): ?>
            background: var(--rp-bg-color) !important;
        <?php else: ?>
            background: var(--rp-login-bg) !important;
        <?php endif; ?>
    }
</style>

<div class="rp-fullscreen-canvas">
    <div class="rp-login-wrap">
        <div class="rp-logo-area">
            <?php if($logo): ?><img src="<?php echo esc_url($logo); ?>" class="rp-custom-logo" alt="logo"><?php endif; ?>
            <h2><?php echo esc_html($title); ?></h2> 
            <p><?php echo esc_html($sub); ?></p>
        </div>
        
        <?php if ($method == 'sms'): ?>
            <form id="rp-login-form-sms">
                <div id="step-1-box" style="width:100%;">
                    <input type="text" id="rp_mobile" class="rp-input" placeholder="شماره موبایل (مثال: 0912...)" maxlength="11">
                </div>
                <div id="step-2-box" style="display:none; width:100%;">
                    <p style="font-size:13px; color:#555; margin-bottom:10px;">کد ارسال شده را وارد کنید:</p>
                    <input type="text" id="rp_code" class="rp-input" placeholder="- - - - -" maxlength="5" style="letter-spacing: 8px; font-weight:800; font-size:18px;">
                    
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-top:10px; font-size:12px;">
                        <span id="rp-edit-number">ویرایش شماره</span>
                        <span id="rp-timer-wrap" style="color:#777;">
                            ارسال مجدد: <span id="rp-timer-sec">120</span> ثانیه
                        </span>
                        <a id="rp-resend-btn" style="display:none; cursor:pointer; color:var(--rp-login-text); font-weight:bold;">ارسال مجدد کد</a>
                    </div>
                </div>
                <button type="submit" id="rp-login-btn" class="rp-btn-primary">دریافت کد ورود</button>
                <div id="rp-login-msg" style="font-size:13px; margin-top:5px;"></div>
            </form>

        <?php else: ?>
            <div id="rp-email-login-container" style="width:100%;">
                <form id="rp-login-form-email">
                    <input type="email" name="log" class="rp-input" placeholder="ایمیل خود را وارد کنید" required>
                    <input type="password" name="pwd" class="rp-input" placeholder="رمز عبور خود را وارد کنید" required>
                    <button type="submit" class="rp-btn-primary">ورود به سایت</button>
                    <div id="rp-email-msg" style="font-size:13px; margin-top:5px;"></div>
                </form>
                <div class="rp-switch-auth-link" onclick="jQuery('#rp-email-login-container').hide(); jQuery('#rp-email-register-container').fadeIn();">حساب کاربری ندارید؟ <strong>ثبت‌نام کنید</strong></div>
            </div>

            <div id="rp-email-register-container" style="display:none; width:100%;">
                <form id="rp-register-form-email">
                    <input type="text" name="name" class="rp-input" placeholder="نام و نام خانوادگی" required>
                    <input type="email" name="email" class="rp-input" placeholder="آدرس ایمیل" required>
                    <input type="password" name="pwd" class="rp-input" placeholder="رمز عبور (حداقل ۶ رقم)" required>
                    <?php 
                    if ( $terms_id && get_post($terms_id) ) {
                        $terms_link = get_permalink($terms_id);
                        echo '<div style="text-align:right; font-size:12px; padding-right:10px;"><label style="cursor:pointer; color:#666;"><input type="checkbox" name="terms_accepted" required> با <a href="'.esc_url($terms_link).'" target="_blank" style="color:var(--rp-login-text); text-decoration:none; font-weight:bold;">قوانین و مقررات</a> موافقم.</label></div>';
                    }
                    ?>
                    <button type="submit" class="rp-btn-primary">ثبت‌نام در سایت</button>
                    <div id="rp-register-msg" style="font-size:13px; margin-top:5px;"></div>
                </form>
                <div class="rp-switch-auth-link" onclick="jQuery('#rp-email-register-container').hide(); jQuery('#rp-email-login-container').fadeIn();">قبلاً ثبت‌نام کرده‌اید؟ <strong>وارد شوید</strong></div>
            </div>
        <?php endif; ?>

        <?php if( !empty($opts['login_show_home']) || !empty($opts['login_copyright']) ): ?>
            <div class="rp-footer-links">
                <?php if(!empty($opts['login_show_home'])): ?>
                    <a href="<?php echo home_url(); ?>">
                        <span class="dashicons dashicons-arrow-right-alt2" style="font-size:14px; width:auto; height:auto;"></span> بازگشت به صفحه اصلی
                    </a><br>
                <?php endif; ?>
                <?php echo nl2br(esc_html($opts['login_copyright'] ?? '')); ?>
            </div>
        <?php endif; ?>
    </div>
</div>