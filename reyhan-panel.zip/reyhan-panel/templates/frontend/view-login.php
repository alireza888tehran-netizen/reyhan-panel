<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<div class="rp-login-container">
    <div class="rp-login-box">
        
        <div class="rp-login-header">
            <?php if ( ! empty( $opts['login_logo'] ) ) : ?>
                <img src="<?php echo esc_url( $opts['login_logo'] ); ?>" class="rp-login-logo" alt="Logo">
            <?php endif; ?>
            <h2><?php echo !empty($opts['login_title']) ? esc_html($opts['login_title']) : esc_html__('ورود به حساب کاربری', 'reyhan-panel'); ?></h2>
        </div>

        <div class="rp-auth-tabs">
            <button class="rp-auth-tab active" data-target="login-form"><?php esc_html_e('ورود', 'reyhan-panel'); ?></button>
            <button class="rp-auth-tab" data-target="register-form"><?php esc_html_e('ثبت نام', 'reyhan-panel'); ?></button>
        </div>

        <form id="rp-login-form" class="rp-auth-form active">
            <div class="rp-field-group">
                <label><?php esc_html_e('شماره موبایل یا ایمیل', 'reyhan-panel'); ?></label>
                <input type="text" name="log" class="rp-input-auth" required>
            </div>
            
            <div class="rp-field-group rp-pass-field" style="display:none;">
                <label><?php esc_html_e('رمز عبور', 'reyhan-panel'); ?></label>
                <input type="password" name="pwd" class="rp-input-auth">
            </div>

            <div class="rp-login-actions">
                <button type="button" id="rp-btn-otp-login" class="rp-btn-block">
                    <?php esc_html_e('ورود با کد تایید (پیامک)', 'reyhan-panel'); ?>
                </button>
                <button type="button" id="rp-btn-pass-login" class="rp-btn-block-sec" style="display:none;">
                    <?php esc_html_e('ورود با رمز عبور', 'reyhan-panel'); ?>
                </button>
            </div>
            
            <div class="rp-otp-verify-section" style="display:none;">
                <p><?php esc_html_e('کد ارسال شده را وارد کنید:', 'reyhan-panel'); ?></p>
                <input type="text" id="rp-otp-code" class="rp-input-otp" maxlength="5" placeholder="_ _ _ _ _">
                <button type="button" id="rp-verify-otp" class="rp-btn-block success"><?php esc_html_e('تایید و ورود', 'reyhan-panel'); ?></button>
            </div>
        </form>

        <form id="rp-register-form" class="rp-auth-form" style="display:none;">
            <div class="rp-field-group">
                <label><?php esc_html_e('شماره موبایل', 'reyhan-panel'); ?></label>
                <input type="text" name="reg_mobile" class="rp-input-auth" required>
            </div>
            <div class="rp-field-group">
                <label><?php esc_html_e('نام و نام خانوادگی', 'reyhan-panel'); ?></label>
                <input type="text" name="reg_name" class="rp-input-auth">
            </div>
            <button type="button" id="rp-btn-register-start" class="rp-btn-block">
                <?php esc_html_e('دریافت کد تایید', 'reyhan-panel'); ?>
            </button>
        </form>

    </div>
</div>