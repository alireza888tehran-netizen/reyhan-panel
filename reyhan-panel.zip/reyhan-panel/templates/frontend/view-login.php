<?php if ( ! defined( 'ABSPATH' ) ) exit; 
$opts = isset($opts) ? $opts : get_option('reyhan_options');
$show_home = !empty($opts['login_show_home']);
$copyright = !empty($opts['login_copyright']) ? $opts['login_copyright'] : '';
$recaptcha_active = !empty($opts['recaptcha_active']) && !empty($opts['recaptcha_site_key']);
$auth_method = $method ?? 'email';
$is_sms = ($auth_method === 'sms');
?>

<style>
    :root {
        --rp-login-bg: <?php echo $p['gradient']; ?>;
        --rp-login-btn: <?php echo $p['btn_bg']; ?>;
        --rp-login-shadow: <?php echo $p['shadow']; ?>;
        --rp-login-text: <?php echo $p['text_col']; ?>;
    }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
</style>

<?php if($recaptcha_active): ?>
<script src="https://www.google.com/recaptcha/api.js?render=<?php echo esc_attr($opts['recaptcha_site_key']); ?>"></script>
<?php endif; ?>

<div class="rp-fullscreen-canvas">
    <div class="rp-login-wrap">
        <div class="rp-logo-area">
            <?php if (!empty($logo)): ?><img src="<?php echo esc_url($logo); ?>" style="max-width:<?php echo $logo_w; ?>px; margin-bottom:12px;"><?php endif; ?>
            <h2><?php echo esc_html($title); ?></h2>
            <p id="rp-desc"><?php echo esc_html($sub); ?></p>
        </div>

        <div id="rp-ajax-msg" style="display:none; width:100%; padding:12px; border-radius:25px; font-size:12px; margin-bottom:15px; text-align:center;"></div>
        
        <div id="rp-limit-box" class="rp-ban-timer">
            <span class="dashicons dashicons-warning" style="font-size:20px;width:20px;height:20px;vertical-align:middle;"></span> دسترسی شما محدود شده است
            <span id="rp-limit-clock" class="rp-ban-clock">15:00</span>
            <span class="rp-ban-msg">لطفاً تا پایان تایمر صبر کنید...</span>
        </div>

        <div class="rp-step-outer">
            <div style="width: 100%;"> 
                <div class="rp-step active" id="step-check">
                    <input type="text" id="rp-main-input" class="rp-input" placeholder="<?php echo $is_sms ? 'شماره موبایل' : 'ایمیل'; ?>">
                    <button class="rp-btn-primary" id="btn-check">بررسی کن</button>
                </div>

                <div class="rp-step" id="step-login">
                    <input type="password" id="rp-login-pass" class="rp-input" placeholder="رمز عبور">
                    <span class="rp-forgot-link" id="btn-forgot-start">رمز عبور را فراموش کردم</span>
                    <button class="rp-btn-primary" id="btn-login">ورود</button>
                    <span class="rp-back-step" onclick="goToStep('step-check')">ایمیل / شماره رو اشتباه وارد کردم</span>
                </div>

                <div class="rp-step" id="step-register">
                    <input type="text" id="reg-fname" class="rp-input" placeholder="نام">
                    <input type="text" id="reg-lname" class="rp-input" placeholder="نام خانوادگی">
                    <input type="password" id="reg-pass" class="rp-input rp-pwd-check" placeholder="رمز عبور">
                    <input type="password" id="reg-pass-conf" class="rp-input rp-pwd-check" placeholder="تکرار رمز عبور">
                    
                    <div class="rp-pwd-rules-container">
                        <div class="rp-rule-item" id="rule-num"><span class="dashicons dashicons-no"></span> اعداد انگلیسی</div>
                        <div class="rp-rule-item" id="rule-up"><span class="dashicons dashicons-no"></span> حداقل یک حرف بزرگ</div>
                        <div class="rp-rule-item" id="rule-low"><span class="dashicons dashicons-no"></span> حداقل یک حرف کوچک</div>
                        <div class="rp-rule-item" id="rule-spec"><span class="dashicons dashicons-no"></span> کاراکتر خاص (!@#$%^&*)</div>
                        <div class="rp-rule-item" id="rule-match"><span class="dashicons dashicons-no"></span> تایید رمز عبور</div>
                    </div>

                    <button class="rp-btn-primary" id="btn-register">ثبت نام</button>
                    <span class="rp-back-step" onclick="goToStep('step-check')">← بازگشت</span>
                </div>

                <div class="rp-step" id="step-otp">
                    <p style="font-size:12px; color:#666; text-align:center; margin:0;">کد ۵ رقمی ارسال شده را وارد کنید</p>
                    <div id="rp-otp-timer" class="rp-timer-box">زمان باقی‌مانده: <span id="rp-timer-sec"></span></div>
                    <input type="text" id="otp-code" class="rp-input" placeholder="_ _ _ _ _" maxlength="5" style="letter-spacing:5px; font-weight:bold;">
                    <button class="rp-btn-primary" id="btn-verify">تایید کد</button>
                    <span class="rp-back-step" onclick="window.location.reload()">← اصلاح شماره / ایمیل</span>
                </div>

                <div class="rp-step" id="step-reset-pass">
                    <p style="font-size:12px; color:#666; text-align:center; margin:0;">رمز عبور جدید خود را وارد کنید</p>
                    <input type="password" id="new-pass" class="rp-input rp-pwd-check" placeholder="رمز عبور جدید">
                    <input type="password" id="new-pass-conf" class="rp-input rp-pwd-check" placeholder="تکرار رمز عبور">
                    
                    <div class="rp-pwd-rules-container">
                        <div class="rp-rule-item" id="rule-num-2"><span class="dashicons dashicons-no"></span> اعداد انگلیسی</div>
                        <div class="rp-rule-item" id="rule-up-2"><span class="dashicons dashicons-no"></span> حداقل یک حرف بزرگ</div>
                        <div class="rp-rule-item" id="rule-low-2"><span class="dashicons dashicons-no"></span> حداقل یک حرف کوچک</div>
                        <div class="rp-rule-item" id="rule-spec-2"><span class="dashicons dashicons-no"></span> کاراکتر خاص (!@#$%^&*)</div>
                        <div class="rp-rule-item" id="rule-match-2"><span class="dashicons dashicons-no"></span> تایید رمز عبور</div>
                    </div>

                    <button class="rp-btn-primary" id="btn-save-new-pass">تغییر رمز و ورود</button>
                </div>
            </div>
        </div>

        <div class="rp-footer-links">
            <?php if ($show_home): ?>
                <a href="<?php echo home_url(); ?>"><span class="dashicons dashicons-admin-home"></span> بازگشت به سایت</a>
            <?php endif; ?>
            <?php if (!empty($copyright)): ?>
                <div class="rp-copyright-text"><?php echo wp_kses_post($copyright); ?></div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
// تابع مدیریت نمایش مراحل
function goToStep(stepId) {
    jQuery('.rp-step').removeClass('active');
    jQuery('#' + stepId).addClass('active');
}

jQuery(document).ready(function($){
    var userIdentity = ''; 
    var authMethod = '<?php echo $auth_method; ?>';
    var isForgotMode = false;
    var timerInterval; // تایمر کد تایید
    var limitInterval; // تایمر محدودیت (Ban)

    // ============================================================
    // ۱. بررسی وضعیت در لحظه لود صفحه (فیکس مشکل رفرش)
    // ============================================================
    function checkInitStatus() {
        // غیرفعال کردن موقت فرم تا مشخص شدن وضعیت
        $('.rp-btn-primary').prop('disabled', true).css('opacity', '0.6');
        
        $.post(reyhan_front_obj.ajax_url, { 
            action: 'reyhan_check_init', 
            nonce: reyhan_front_obj.nonce 
        }, function(res){
            // بازگرداندن دکمه‌ها به حالت عادی
            $('.rp-btn-primary').prop('disabled', false).css('opacity', '1');

            if(res.success) {
                // اگر کاربر لاگین است، رایرکت شود
                if(res.data.logged_in) {
                    window.location.href = res.data.redirect;
                }
            } else {
                // اگر ارور محدودیت دریافت شد -> نمایش تایمر
                if(res.data && res.data.code === 'rate_limit') {
                    startBanTimer(res.data.wait);
                }
            }
        });
    }
    // اجرای خودکار هنگام لود
    checkInitStatus();


    // ============================================================
    // توابع کمکی و تایمرها
    // ============================================================
    
    // --- تایمر معکوس محدودیت (قرمز) ---
    function startBanTimer(seconds) {
        clearInterval(limitInterval);
        var timer = seconds, m, s;
        
        // نمایش باکس محدودیت
        $('#rp-limit-box').slideDown().addClass('rp-ban-timer');
        $('#rp-ajax-msg').hide();
        
        // قفل کردن کل فرم
        $('.rp-btn-primary').prop('disabled', true).css('opacity', '0.5');
        $('.rp-input').prop('disabled', true);

        limitInterval = setInterval(function () {
            m = parseInt(timer / 60, 10);
            s = parseInt(timer % 60, 10);
            m = m < 10 ? "0" + m : m;
            s = s < 10 ? "0" + s : s;
            
            $('#rp-limit-clock').text(m + ":" + s);

            if (--timer < 0) {
                clearInterval(limitInterval);
                // رفع محدودیت
                $('#rp-limit-box').removeClass('rp-ban-timer').css({
                    'background':'#d4edda', 'color':'#155724', 'border-color':'#c3e6cb', 'animation':'none'
                }).html('<span class="dashicons dashicons-yes" style="font-size:20px;vertical-align:middle;"></span> محدودیت رفع شد. می‌توانید تلاش کنید.');
                
                // باز کردن قفل فرم
                $('.rp-btn-primary').prop('disabled', false).css('opacity', '1');
                $('.rp-input').prop('disabled', false);
                
                setTimeout(function(){ $('#rp-limit-box').slideUp(); }, 4000);
            }
        }, 1000);
    }

    // --- مدیریت پاسخ‌های AJAX ---
    function handleResponse(res, $btn, defaultText) {
        $btn.text(defaultText).prop('disabled', false);
        
        if(res.success) return true;
        
        // اگر ارور از نوع محدودیت بود
        if(res.data && res.data.code === 'rate_limit') {
            startBanTimer(res.data.wait);
        } else {
            var msg = (typeof res.data === 'string') ? res.data : 'خطایی رخ داد';
            showMsg(msg);
        }
        return false;
    }

    // --- تایمر کد تایید (SMS/Email) ---
    function startOtpTimer(durationSeconds) {
        clearInterval(timerInterval);
        var timer = durationSeconds, m, s;
        var display = $('#rp-timer-sec');
        $('#rp-otp-timer').show().removeClass('expired');
        $('#btn-verify').prop('disabled', false).text('تایید کد');
        
        updateDisplay(); 
        timerInterval = setInterval(function () {
            if (--timer < 0) {
                clearInterval(timerInterval);
                $('#rp-otp-timer').addClass('expired').html('کد منقضی شد. <a href="#" onclick="window.location.reload()" style="color:#666;">ارسال مجدد</a>');
                $('#btn-verify').prop('disabled', true).text('منقضی شده');
            } else { updateDisplay(); }
        }, 1000);
        function updateDisplay() {
            m = parseInt(timer / 60, 10); s = parseInt(timer % 60, 10);
            m = m < 10 ? "0" + m : m; s = s < 10 ? "0" + s : s;
            display.text(m + ":" + s);
        }
    }

    function showMsg(msg, type='error') {
        var color = (type === 'success') ? '#155724' : '#721c24';
        var bg    = (type === 'success') ? '#d4edda' : '#f8d7da';
        $('#rp-ajax-msg').css({'background': bg, 'color': color}).html(msg).fadeIn();
        setTimeout(function(){ $('#rp-ajax-msg').fadeOut(); }, 5000);
    }

    // --- لاجیک اعتبارسنجی پسورد ---
    $('.rp-pwd-check').on('keyup input', function(){
        var p1, p2, suffix = '';
        if($(this).attr('id').indexOf('new-pass') !== -1) { p1 = $('#new-pass').val(); p2 = $('#new-pass-conf').val(); suffix = '-2'; } 
        else { p1 = $('#reg-pass').val(); p2 = $('#reg-pass-conf').val(); }

        updateRule('#rule-num'+suffix, /\d/.test(p1));
        updateRule('#rule-up'+suffix, /[A-Z]/.test(p1));
        updateRule('#rule-low'+suffix, /[a-z]/.test(p1));
        updateRule('#rule-spec'+suffix, /[!@#$%^&*)(]/.test(p1));
        updateRule('#rule-match'+suffix, (p1 === p2 && p1.length > 0));
    });

    function updateRule(id, isValid) {
        var $el = $(id);
        if(isValid) $el.addClass('valid').find('.dashicons').removeClass('dashicons-no').addClass('dashicons-yes');
        else $el.removeClass('valid').find('.dashicons').removeClass('dashicons-yes').addClass('dashicons-no');
    }

    // ----------------------------------------------------
    // دکمه‌های فرم
    // ----------------------------------------------------

    // 1. بررسی وضعیت
    $('#btn-check').click(function(){
        var val = $('#rp-main-input').val().trim();
        if(!val) { showMsg('لطفاً ورودی را پر کنید'); return; }
        userIdentity = val;
        var $btn = $(this), txt = $btn.text();
        $btn.text('صبر کنید ...').prop('disabled', true);
        
        var action = (authMethod === 'sms') ? 'reyhan_send_otp' : 'reyhan_check_email_status';
        var data = { action: action, security: reyhan_front_obj.nonce };
        if(authMethod==='sms') data.mobile = val; else data.email = val;

        $.post(reyhan_front_obj.ajax_url, data, function(res){
            if(handleResponse(res, $btn, txt)) {
                if(authMethod === 'sms') { goToStep('step-otp'); startOtpTimer(120); }
                else {
                    if(res.data.exists) goToStep('step-login'); else goToStep('step-register');
                }
            }
        }).fail(function(){ $btn.text(txt).prop('disabled', false); showMsg('خطا در ارتباط'); });
    });

    // 2. ورود
    $('#btn-login').click(function(){
        var pwd = $('#rp-login-pass').val();
        if(!pwd) { showMsg('رمز عبور را وارد کنید'); return; }
        var $btn = $(this), txt = $btn.text();
        $btn.text('صبر کنید ...').prop('disabled', true);
        
        $.post(reyhan_front_obj.ajax_url, { 
            action: 'reyhan_email_login', log: userIdentity, pwd: pwd, security: reyhan_front_obj.nonce 
        }, function(res){
            if(handleResponse(res, $btn, txt)) window.location.reload();
        });
    });

    // 3. ثبت نام
    $('#btn-register').click(function(){
        var f=$('#reg-fname').val(), l=$('#reg-lname').val(), p1=$('#reg-pass').val(), p2=$('#reg-pass-conf').val();
        if(!f || !l || !p1) { showMsg('فیلدها را پر کنید'); return; }
        if(p1!==p2) { showMsg('رمزها یکسان نیستند'); return; }
        
        var $btn = $(this), txt = $btn.text();
        $btn.text('صبر کنید ...').prop('disabled', true);
        $.post(reyhan_front_obj.ajax_url, {
            action: 'reyhan_email_register_full', email: userIdentity, fname: f, lname: l, pwd: p1, security: reyhan_front_obj.nonce
        }, function(res){
            if(handleResponse(res, $btn, txt)) { showMsg('ثبت نام انجام شد. در حال ورود ...', 'success'); setTimeout(()=>location.reload(), 1500); }
        });
    });

    // 4. فراموشی رمز
    $('#btn-forgot-start').click(function(){
        isForgotMode = true;
        var $btn = $(this); $btn.css('opacity', '0.5'); showMsg('در حال ارسال کد...', 'success');
        $.post(reyhan_front_obj.ajax_url, { 
            action: 'reyhan_send_email_otp_fp', email: userIdentity, nonce: reyhan_front_obj.nonce 
        }, function(res){
            $btn.css('opacity', '1');
            if(handleResponse(res, $btn, 'رمز عبور را فراموش کردم')) { 
                goToStep('step-otp'); startOtpTimer(300);
            }
        });
    });

    // 5. تایید کد
    $('#btn-verify').click(function(){
        var code = $('#otp-code').val();
        if(!code) return;
        var $btn = $(this), txt = $btn.text();
        $btn.text('صبر کنید ...').prop('disabled', true);

        var action = isForgotMode ? 'reyhan_check_otp_only' : 'reyhan_verify_otp';
        var data = { action: action, code: code, nonce: reyhan_front_obj.nonce };
        if(isForgotMode) data.email = userIdentity; else { data.mobile = userIdentity; data.security = reyhan_front_obj.nonce; }

        $.post(reyhan_front_obj.ajax_url, data, function(res){
            if(handleResponse(res, $btn, txt)) {
                if(isForgotMode) { clearInterval(timerInterval); goToStep('step-reset-pass'); }
                else window.location.reload();
            }
        });
    });

    // 6. تغییر رمز
    $('#btn-save-new-pass').click(function(){
        var p1=$('#new-pass').val(), p2=$('#new-pass-conf').val(), code=$('#otp-code').val();
        if(p1!==p2) { showMsg('رمزها یکسان نیستند'); return; }
        var $btn=$(this), txt=$btn.text();
        $btn.text('صبر کنید ...').prop('disabled', true);
        
        $.post(reyhan_front_obj.ajax_url, { 
            action: 'reyhan_reset_password_fp', email: userIdentity, code: code, pass: p1, nonce: reyhan_front_obj.nonce 
        }, function(res){
            if(handleResponse(res, $btn, txt)) { showMsg('رمز عبور شما با موفقیت تغییر کرد. در حال ورود ...', 'success'); setTimeout(()=>location.reload(), 2000); }
        });
    });
});
</script>