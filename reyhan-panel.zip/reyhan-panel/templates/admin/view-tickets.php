<?php 
if ( ! defined( 'ABSPATH' ) ) { exit; } 
?>

<div class="wrap reyhanpanel-wrap rp-admin-wrap" id="reyhan-manager-app">
    
    <div class="rp-manager-header">
        <div class="rp-title-area">
            <h1><span class="dashicons dashicons-email-alt"></span> مدیریت تیکت‌های پشتیبانی</h1>
            <p style="color:#777; margin-top:5px; font-size:12px;">در این بخش می‌توانید به درخواست‌های کاربران پاسخ دهید.</p>
        </div>
        
        <div class="rp-filters">
            <button class="filter-pill active" data-status="active">
                <span class="dashicons dashicons-email"></span> تیکت‌های باز
            </button>
            <button class="filter-pill" data-status="closed">
                <span class="dashicons dashicons-yes"></span> تیکت‌های بسته
            </button>
        </div>
    </div>

    <div class="rp-app-container">
        
        <div class="rp-sidebar-panel">
            <div class="rp-panel-head">
                <span class="dashicons dashicons-list-view"></span> لیست درخواست‌ها
            </div>
            <div id="ticket-list-container" class="rp-scrollable-list">
                <div class="rp-loading-state">
                    <span class="spinner is-active" style="float:none; margin:0 0 10px 0;"></span><br>در حال بارگذاری لیست...
                </div>
            </div>
        </div>

        <div class="rp-chat-panel">
            <div id="conversation-header" class="rp-panel-head chat-head-flex" style="justify-content:space-between; display:flex;">
                <span><span class="dashicons dashicons-format-chat"></span> جزئیات گفتگو</span>
                    <?php if ( current_user_can('manage_options') ) : ?>
                        <button id="delete-ticket-btn" class="rp-btn-sm delete" style="display:none;">
                            <span class="dashicons dashicons-trash"></span> حذف تیکت
                        </button>
                    <?php endif; ?>
            </div>
            
            <div id="ticket-info-bar" style="display:none;"></div>
            
            <div id="conversation-content" class="rp-scrollable-chat">
                <div class="rp-empty-chat-state">
                    <img src="<?php echo REYHAN_URL; ?>assets/images/logo.png" style="opacity:0.1; max-width:150px; margin-bottom:20px; filter: grayscale(100%);">
                    <h3>تیکتی انتخاب نشده است</h3>
                    <p>برای مشاهده جزئیات و ارسال پاسخ، یک تیکت را از لیست سمت راست انتخاب کنید.</p>
                </div>
            </div>
            
            <div class="rp-reply-area" style="display:none;">
                <div class="canned-search-wrap">
                    <span class="dashicons dashicons-search" style="position:absolute; right:10px; top:10px; color:#aaa;"></span>
                    <input type="text" id="canned-search-input" placeholder="جستجو در پاسخ‌های آماده (تایپ کنید)...">
                    <div id="canned-results"></div>
                </div>
                
                <textarea id="reply-text" placeholder="پاسخ خود را اینجا بنویسید..."></textarea>
                
                <div class="rp-reply-tools">
                    <div class="rp-action-buttons">
                        <button id="send-reply-btn" class="rp-btn-send">
                            ارسال پاسخ <span class="dashicons dashicons-arrow-left-alt"></span>
                        </button>
                        
                        <input type="file" id="reply-file" style="display:none;">
                        <button type="button" class="rp-btn-icon" onclick="document.getElementById('reply-file').click()" title="افزودن فایل">
                            <span class="dashicons dashicons-paperclip"></span>
                        </button>
                        <span id="file-name-display" style="font-size:11px; color:#666;"></span>
                    </div>
                    
                    <div class="rp-status-options">
                        <label>
                            <input type="checkbox" id="close-ticket-check" value="closed"> 
                            بستن تیکت پس از ارسال
                        </label>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>