<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<div class="wrap reyhanpanel-wrap">
    <div class="rp-title-area">
        <h1><span class="dashicons dashicons-email-alt"></span> تنظیمات عمومی</h1>
        <p style="color:#777; margin-top:5px; font-size:12px;">در این بخش تنظیمات عمومی ریحان پنل را تنظیم کنید.</p>
    </div>
    
    <?php 
    if ( isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true' ) {
        echo '<div id="reyhan-toast-msg" class="rp-modern-toast"><span class="dashicons dashicons-saved"></span> <span>تغییرات با موفقیت ذخیره شد.</span></div>';
    }
    ?>

    <form method="post" action="options.php">
        <?php settings_fields('reyhan_master_group'); ?>
        
        <div class="rp-settings-container"> 
            <div class="rp-settings-sidebar">
                <div class="rp-sidebar-logo"><img src="<?php echo REYHAN_URL . 'assets/images/logo.png'; ?>" alt="Logo"></div>
                <ul class="rp-tabs-nav" id="rp-main-nav">
                    <li class="active" data-tab="tab-login"><span class="dashicons dashicons-admin-users"></span> ورود و عضویت</li>
                    <li data-tab="tab-sms"><span class="dashicons dashicons-smartphone"></span> پیامک پنل کاربری</li>
                    <li data-tab="tab-email"><span class="dashicons dashicons-email"></span> ایمیل پنل کاربری</li>
                    <li data-tab="tab-ticket"><span class="dashicons dashicons-tickets-alt"></span> تنظیمات تیکت</li>
                    <li data-tab="tab-security"><span class="dashicons dashicons-shield"></span> امنیت</li>
                    <li data-tab="tab-tools"><span class="dashicons dashicons-admin-tools"></span> ابزارها</li>
                </ul>
                <div class="rp-save-box">
                    <?php submit_button('ذخیره تغییرات', 'primary', 'submit', false); ?>
                    <div class="rp-version-info">نسخه <?php echo REYHAN_VERSION; ?></div>
                </div>
            </div> 
            
            <div class="rp-settings-content">
                <?php 
                $guide_style = 'color:#666; font-size:13px; margin-bottom:20px; background:#fffbe5; padding:10px; border:1px solid #ffe58f; border-radius:5px; line-height:1.6;'; 
                ?>

                <div id="tab-login" class="rp-tab-pane active">
                    <h2>تنظیمات ورود و عضویت</h2>
                    <p style="<?php echo $guide_style; ?>">💡 <strong>راهنما:</strong> تنظیمات ورود و عضویت رو اینجا انجام بده</p>
                    <table class="form-table"><?php do_settings_fields('reyhan-general', 'sec_login'); ?></table>
                </div>

                <div id="tab-sms" class="rp-tab-pane">
                    <h2>تنظیمات پیامک اطلاع رسانی</h2>
                    <p style="<?php echo $guide_style; ?>">💡 <strong>راهنما:</strong> تنظیمات پیامکی برای پنل ورود رو اینجا انجام بده</p>
                    <table class="form-table"><?php do_settings_fields('reyhan-general', 'sec_sms'); ?></table>
                </div>

                <div id="tab-email" class="rp-tab-pane">
                    <h2>تنظیمات ایمیل اطلاع رسانی</h2>
                    <p style="<?php echo $guide_style; ?>">💡 <strong>راهنما:</strong> تنظیمات ایمیل های اطلاع رسانی رو اینجا انجام بده</p>
                    <table class="form-table"><?php do_settings_fields('reyhan-general', 'sec_email'); ?></table>
                </div>

                <div id="tab-ticket" class="rp-tab-pane">
                    <h2>تنظیمات تیکت سایت</h2>
                    <p style="<?php echo $guide_style; ?>">💡 <strong>راهنما:</strong> تنظیمات سیستم تیکت سایت رو اینجا انجام بده</p>
                    <table class="form-table"><?php do_settings_fields('reyhan-general', 'sec_ticket'); ?></table>
                </div>

                <div id="tab-security" class="rp-tab-pane">
                    <h2>تنظیمات امنیتی</h2>
                    <p style="<?php echo $guide_style; ?>">💡 <strong>راهنما:</strong> تنظیمات امنیتی افزونه رو اینجا انجام بده</p>
                    <table class="form-table"><?php do_settings_fields('reyhan-general', 'sec_security'); ?></table>
                </div>

                <div id="tab-tools" class="rp-tab-pane">
                    <h2>ابزار های مفید افزونه</h2>
                    <p style="<?php echo $guide_style; ?>">💡 <strong>راهنما:</strong> ابزار های مختلف افزونه رو اینجا میتونی ببینی</p>
                    <table class="form-table"><?php do_settings_fields('reyhan-general', 'sec_tools'); ?></table>
                </div>
            </div> 
        </div> 
    </form>
</div>