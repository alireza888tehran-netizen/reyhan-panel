<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<div class="wrap reyhanpanel-wrap">
    <div class="rp-title-area">
        <h1><span class="dashicons dashicons-email-alt"></span> تنظیمات ظاهر</h1>
        <p style="color:#777; margin-top:5px; font-size:12px;">در این بخش تنظیمات استایل پنل کاربری و درگاه ورود و عضویت را انجام دهید.</p>
    </div>
    
    <?php 
    if ( isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true' ) {
        echo '<div id="reyhan-toast-msg" class="rp-modern-toast"><span class="dashicons dashicons-saved"></span> <span>تغییرات با موفقیت ذخیره شد.</span></div>';
    }
    ?>

    <form method="post" action="options.php">
        <?php settings_fields('reyhan_master_group'); ?>
        <div class="rp-settings-container">
            <div class="rp-settings-sidebar">
                <div class="rp-sidebar-logo"><img src="<?php echo REYHAN_URL . 'assets/images/logo.png'; ?>" alt="Logo"></div>
                <ul class="rp-tabs-nav">
                    <li class="active" data-tab="tab-style-login"><span class="dashicons dashicons-lock"></span>استایل ورود / عضویت</li>
                    <li data-tab="tab-style-panel"><span class="dashicons dashicons-layout"></span>استایل پنل کاربری</li>
                </ul>
                <div class="rp-save-box">
                    <?php submit_button('ذخیره تغییرات', 'primary', 'submit', false); ?>
                    <div class="rp-version-info">نسخه <?php echo REYHAN_VERSION; ?></div>
                </div>
            </div>
            <div class="rp-settings-content">
                <div id="tab-style-login" class="rp-tab-pane active">
                    <h2>ظاهر صفحه ورود</h2>
                    <p style="color:#666;font-size:13px;margin-bottom:20px;background:#fffbe5;padding:10px;border:1px solid #ffe58f;border-radius:5px;">💡 <strong>راهنما:</strong> تنظیمات استایل درگاه ورود و عضویت رو اینجا انجام بده</p>
                    <table class="form-table"><?php do_settings_fields('reyhan-user-panel', 'sec_style_login'); ?></table>
                </div>
                <div id="tab-style-panel" class="rp-tab-pane">
                    <h2>ظاهر داشبورد</h2>
                    <p style="color:#666;font-size:13px;margin-bottom:20px;background:#fffbe5;padding:10px;border:1px solid #ffe58f;border-radius:5px;">💡 <strong>راهنما:</strong> تنظیمات استایل پنل کاربری رو اینجا انجام بده</p>
                    <table class="form-table"><?php do_settings_fields('reyhan-user-panel', 'sec_style_panel'); ?></table>
                </div>
            </div>
        </div>
    </form>
</div>