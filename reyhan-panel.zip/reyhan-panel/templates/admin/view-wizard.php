<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<div class="rw-wrapper">
    <div class="rw-sidebar">
        <div class="rw-logo">
            <img src="<?php echo REYHAN_URL . 'assets/images/logo.png'; ?>" alt="Logo">
            ریحان پنل
        </div>
        
        <ul class="rw-steps">
            <li class="active" data-step="1"><span class="circle">1</span> خوش‌آمدگویی</li>
            <li data-step="2"><span class="circle">2</span> صفحات</li>
            <li data-step="3"><span class="circle">3</span> تنظیمات</li>
            <li data-step="4"><span class="circle">4</span> پایان</li>
        </ul>

        <div>
            <a href="<?php echo admin_url('index.php'); ?>" class="rw-exit">
                <span class="dashicons dashicons-no-alt"></span> خروج از ویزارد
            </a>
            <div style="font-size:11px; opacity:0.6; text-align:center; margin-top:15px;">نسخه <?php echo REYHAN_VERSION; ?></div>
        </div>
    </div>
    
    <form id="rw-form" class="rw-content">
        
        <div class="rw-step-content active" id="step-1">
            <h2>به ریحان پنل خوش آمدید! 👋</h2>
            <p>از اینکه افزونه ما را انتخاب کردید متشکریم. برای شروع، لطفاً لایسنس محصول را تایید کنید.</p>
            
            <div class="rw-license-area">
                <div class="rw-license-head">
                    <span class="dashicons dashicons-lock"></span> فعال‌سازی لایسنس
                </div>
                <div class="rw-license-form">
                    <input type="text" id="rw-license-input" class="rw-input" placeholder="XXXX-XXXX-XXXX-XXXX">
                    <button type="button" id="rw-check-license" class="rw-btn">بررسی لایسنس</button>
                </div>
                <div id="rw-license-msg" style="margin-top:10px; font-size:12px;"></div>
            </div>
        </div>

        <div class="rw-step-content" id="step-2">
            <h2>ساخت صفحات ضروری</h2>
            <p>برای شروع کار، نیاز به یک برگه جهت "ورود و پنل کاربری" دارید.</p>
            
            <label class="rw-switch-box">
                <div class="rw-switch">
                    <input type="checkbox" name="create_page" value="1" checked>
                    <span class="rw-slider"></span>
                </div>
                <div class="rw-switch-label">
                    <strong>ساخت خودکار برگه "پنل کاربری"</strong>
                    <span>یک برگه جدید با شورت‌کد [reyhan_panel] ایجاد می‌شود.</span>
                </div>
            </label>
        </div>

        <div class="rw-step-content" id="step-3">
            <h2>شخصی‌سازی ظاهر</h2>
            <p>مشخصات ظاهری فرم ورود را تنظیم کنید.</p>
            
            <div class="rw-field">
                <label class="rw-label">آپلود لوگو (نمایش در فرم ورود)</label>
                <div class="rw-upload-area" id="rw-upload-trigger">
                    <span class="dashicons dashicons-cloud-upload rw-upload-icon"></span>
                    <span class="rw-upload-text">برای انتخاب تصویر کلیک کنید</span>
                    <img src="" class="rw-preview-img" id="rw-logo-preview">
                    <input type="hidden" name="login_logo" id="rw-logo-input">
                </div>
            </div>
            
            <div class="rw-field">
                <label class="rw-label">عنوان صفحه ورود</label>
                <input type="text" name="login_title" class="rw-input" placeholder="مثال: ورود به حساب کاربری" value="ورود به حساب کاربری">
            </div>
        </div>

        <div class="rw-step-content" id="step-4">
            <div style="text-align:center; padding-top:40px;">
                <span style="font-size:70px;">🎉</span>
                <h2 style="margin-top:40px;">همه‌چیز آماده است!</h2>
                <p>تنظیمات اولیه با موفقیت انجام شد. اکنون می‌توانید وارد پنل تنظیمات شده و جزئیات بیشتری را مدیریت کنید.</p>
                <br>
                <a href="<?php echo admin_url('admin.php?page=reyhan-settings'); ?>" class="rw-btn">ورود به تنظیمات افزونه</a>
            </div>
        </div>

        <div class="rw-footer" id="rw-footer-nav">
            <button type="button" class="rw-btn rw-btn-outline" id="btn-prev" style="display:none;">مرحله قبل</button>
            <button type="button" class="rw-btn" id="btn-next">مرحله بعد</button>
        </div>

    </form>
</div>