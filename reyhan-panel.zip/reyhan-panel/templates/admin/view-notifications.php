<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<script>var rp_server_data = <?php echo wp_json_encode( array_values( $notifications ?? [] ) ); ?>;</script>

<div class="wrap reyhanpanel-wrap">
    <div class="rp-title-area">
        <h1><span class="dashicons dashicons-email-alt"></span> اطلاعیه های سراسری</h1>
        <p style="color:#777; margin-top:5px; font-size:12px;">در این بخش میتوانید اطلاعیه های خود را ثبت، ویرایش یا حذف کنید.</p>
    </div>
    
    <?php 
    if ( isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true' ) {
        echo '<div id="reyhan-toast-msg" class="rp-modern-toast"><span class="dashicons dashicons-saved"></span> <span>تغییرات با موفقیت ذخیره شد.</span></div>';
    }
    ?>
    
    <form method="post" action="options.php" id="rp-notif-main-form">
        <?php settings_fields('reyhan_master_group'); ?>
        
        <textarea name="reyhan_options[global_notifications_json]" id="rp_notif_data_json" style="display:none;"></textarea>
        
        <div class="rp-notif-container">
            <div class="rp-notif-top-bar">
                <div class="rp-top-info">
                    <h2>لیست پیام‌ها</h2>
                    <p>این پیام‌ها در داشبورد کاربران نمایش داده می‌شوند.</p>
                </div>
                <button type="button" id="rp-btn-add-new" class="rp-btn-primary-large">
                    <span class="dashicons dashicons-plus"></span> ایجاد اطلاعیه جدید
                </button>
            </div>

            <div id="rp-editor-wrapper" class="rp-editor-wrapper" style="display:none;">
                <div class="rp-editor-card">
                    <div class="rp-editor-header">
                        <div class="rp-ed-head-title">
                            <span class="dashicons dashicons-edit"></span> <span id="rp-editor-title">افزودن اطلاعیه</span>
                        </div>
                        <button type="button" id="rp-btn-cancel" class="rp-btn-close" title="بستن"><span class="dashicons dashicons-no-alt"></span></button>
                    </div>
                    <div class="rp-editor-body">
                        <div class="rp-row-grid-modern">
                            <div class="rp-field-group title-group">
                                <label>عنوان پیام</label>
                                <div class="rp-input-icon-wrap">
                                    <span class="dashicons dashicons-heading"></span>
                                    <input type="text" id="edit-title" class="rp-input-modern" placeholder="مثال: جشنواره نوروزی...">
                                </div>
                            </div>
                            <div class="rp-field-group type-group">
                                <label>رنگ و نوع</label>
                                <div class="rp-select-wrap">
                                    <select id="edit-type" class="rp-input-modern">
                                        <option value="info">🔵 آبی (اطلاع‌رسانی)</option>
                                        <option value="success">🟢 سبز (موفقیت)</option>
                                        <option value="warning">🟡 زرد (هشدار)</option>
                                        <option value="danger">🔴 قرمز (خطر)</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="rp-field-group">
                            <label>متن کامل پیام</label>
                            <textarea id="edit-msg" rows="5" class="rp-input-modern" placeholder="متن پیام خود را اینجا بنویسید..."></textarea>
                        </div>
                    </div>
                    <div class="rp-editor-footer">
                        <button type="button" id="rp-btn-save-item" class="rp-btn-save">
                            <span class="dashicons dashicons-saved"></span> ثبت در لیست
                        </button>
                        <span class="rp-hint"><span class="dashicons dashicons-info"></span> پس از ثبت در لیست، حتماً دکمه <strong>"ذخیره تغییرات نهایی"</strong> پایین صفحه را بزنید.</span>
                    </div>
                </div>
            </div>

            <div id="rp-notif-grid" class="rp-notif-grid"></div>
            
            <div id="rp-empty-state" style="display:none;">
                <div class="rp-empty-icon"><span class="dashicons dashicons-megaphone"></span></div>
                <h3>هیچ اطلاعیه‌ای وجود ندارد</h3>
                <p>با زدن دکمه بالا، اولین پیام خود را بسازید.</p>
            </div>
        </div>

        <div class="rp-sticky-save-bar">
            <div class="rp-save-info">تغییرات شما آماده ذخیره سازی است.</div>
            <?php submit_button('ذخیره تغییرات نهایی', 'primary', 'submit', false); ?>
        </div>
    </form>
</div>