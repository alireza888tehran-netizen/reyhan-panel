<?php if ( ! defined( 'ABSPATH' ) ) { exit; } 
/**
 * متغیرهای دریافتی:
 * $t (آبجکت پست تیکت)
 */

$u = get_userdata( $t->post_author );
$display_name = __('کاربر حذف شده', 'reyhan-panel');
if ( $u ) {
    $fname = get_user_meta( $u->ID, 'first_name', true );
    $lname = get_user_meta( $u->ID, 'last_name', true );
    $full = trim( $fname . ' ' . $lname );
    $display_name = ! empty( $full ) ? $full : __('کاربر جدید', 'reyhan-panel');
}

$st_val = get_post_meta( $t->ID, '_ticket_status', true );
$prio = get_post_meta( $t->ID, '_ticket_priority', true );
$dept = get_post_meta( $t->ID, '_ticket_department', true );

$prio_label = ( $prio == 'high' ) ? __('فوری', 'reyhan-panel') : ( ( $prio == 'medium' ) ? __('متوسط', 'reyhan-panel') : __('معمولی', 'reyhan-panel') );
$st_class = ( $st_val == 'answered' ) ? 'is-answered' : '';
$dept_badge = $dept ? '<span class="rp-badge-dept">' . esc_html( $dept ) . '</span>' : '';
?>

<div class="ticket-list-item <?php echo esc_attr( $st_class ); ?>" data-id="<?php echo absint( $t->ID ); ?>" data-status="<?php echo esc_attr( $st_val ); ?>">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:5px;">
        <span class="ticket-id">#<?php echo absint( $t->ID ); ?></span>
        <div style="display:flex; gap:5px;">
            <?php echo wp_kses_post($dept_badge); ?>
            <span class="rp-badge-prio prio-<?php echo esc_attr($prio); ?>"><?php echo esc_html($prio_label); ?></span>
        </div>
    </div>
    <span class="ticket-title">
        <?php echo esc_html( $t->post_title ); ?>
        <div class="ticket-meta"> <?php esc_html_e('نام کاربر:', 'reyhan-panel'); ?> 👤 <?php echo esc_html( $display_name ); ?></div>
        <span style="direction:ltr;"><?php echo esc_html( get_the_date( 'Y/m/d', $t ) ); ?></span>
    </span>
</div>