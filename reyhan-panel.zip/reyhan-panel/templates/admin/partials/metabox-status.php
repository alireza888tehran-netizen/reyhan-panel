<?php if ( ! defined( 'ABSPATH' ) ) { exit; } 
/**
 * متغیرها: $status (وضعیت فعلی تیکت)
 */
?>
<select name="ticket_status" style="width:100%">
    <option value="open" <?php selected($status, 'open'); ?>>باز (در انتظار بررسی)</option>
    <option value="processing" <?php selected($status, 'processing'); ?>>در حال رسیدگی</option> 
    <option value="answered" <?php selected($status, 'answered'); ?>>پاسخ داده شده</option>
    <option value="closed" <?php selected($status, 'closed'); ?>>بسته شده</option>
</select>