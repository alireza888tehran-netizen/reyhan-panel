<?php if ( ! defined( 'ABSPATH' ) ) { exit; } 
$cls = $is_author ? 'user-msg' : 'admin-msg';
$content = isset($is_first_msg) && $is_first_msg ? $comment->post_content : $comment->comment_content;
$att = isset($is_first_msg) && $is_first_msg ? get_post_meta( $comment->ID, '_ticket_attachment', true ) : get_comment_meta( $comment->comment_ID, 'attachment', true );
?>
<div class="msg-row <?php echo $cls; ?>">
    <div class="msg-bubble">
        <?php echo wpautop( $content ); ?>
        <?php if ( $att ): ?>
            <div class="msg-attachment"><a href="<?php echo esc_url( $att ); ?>" target="_blank">📎 <?php esc_html_e('دانلود فایل', 'reyhan-panel'); ?></a></div>
        <?php endif; ?>
    </div>
</div>