<?php if ( ! defined( 'ABSPATH' ) ) { exit; } 
/**
 * متغیرهای دریافتی:
 * $comment (آبجکت کامنت یا پیام اول)
 * $is_author (آیا نویسنده پیام، نویسنده تیکت است؟)
 * $is_first_msg (آیا پیام اول تیکت است؟ - اختیاری)
 */

$cls = $is_author ? 'user-msg' : 'admin-msg';
$content = isset($is_first_msg) && $is_first_msg ? $comment->post_content : $comment->comment_content;
$att = '';

if ( isset($is_first_msg) && $is_first_msg ) {
    $att = get_post_meta( $comment->ID, '_ticket_attachment', true );
} else {
    $att = get_comment_meta( $comment->comment_ID, 'attachment', true );
}
?>

<div class="msg-row <?php echo $cls; ?>">
    <div class="msg-bubble">
        <?php echo wpautop( $content ); ?>
        <?php if ( $att ): ?>
            <div class="msg-attachment">
                <a href="<?php echo esc_url( $att ); ?>" target="_blank">📎 دانلود فایل</a>
            </div>
        <?php endif; ?>
    </div>
</div>