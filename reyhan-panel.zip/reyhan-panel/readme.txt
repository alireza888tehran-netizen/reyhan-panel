=== Reyhan Panel ===
Contributors: AliREYHANI
Tags: user panel, ticketing, support system, sms login
Requires at least: 7.4
Tested up to: 6.4
Stable tag: 3.0.0
License: GPLv2 or later

سیستم جامع پنل کاربری پیشرفته و تیکتینگ حرفه‌ای.

== Description ==
ریحان پنل یک راهکار جامع برای مدیریت کاربران و پشتیبانی است.

== Changelog ==
= 3.0.0 =
* انتشار اولیه نسخه حرفه‌ای