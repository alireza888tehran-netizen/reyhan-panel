<?php
namespace ReyhanPanel\Frontend;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Controller {

    public function __construct() {
        add_shortcode( 'reyhan_panel',   [ $this, 'render_master_panel' ] );
        add_action( 'wp_footer', [ $this, 'render_profile_completion_popup' ] );
    }

    /**
     * رندر پاپ‌آپ تکمیل پروفایل (اجباری)
     */
    public function render_profile_completion_popup() {
        if (!is_user_logged_in()) return;

        $opts = get_option('reyhan_options');
        
        // اگر تیک اجباری بودن پروفایل زده نشده، کاری نکن
        if ( empty($opts['force_profile_completion']) ) {
            return;
        }

        $uid = get_current_user_id();
        $u = wp_get_current_user();
        
        $fname = get_user_meta($uid, 'first_name', true);
        $lname = get_user_meta($uid, 'last_name', true);
        $mobile = get_user_meta($uid, 'mobile', true);
        
        // اگر کاربر با موبایل ثبت نام کرده ولی در متا ذخیره نشده، آن را فیکس کن
        if ( preg_match('/^09[0-9]{9}$/', $u->user_login) ) {
            if ( empty($mobile) ) {
                update_user_meta($uid, 'mobile', $u->user_login);
                $mobile = $u->user_login;
            }
        }

        $needs_mobile = empty($mobile); 
        $needs_name   = (empty($fname) || empty($lname));

        if ( $needs_mobile || $needs_name ) {
            $file = REYHAN_DIR . 'templates/frontend/partials/popup-completion.php';
            if ( file_exists( $file ) ) { include $file; }
        }
    }

    /**
     * رندر شورت‌کد اصلی [reyhan_panel]
     */
    public function render_master_panel() {
        ob_start();
        $opts = get_option('reyhan_options');
        $selected_font = $opts['plugin_selected_font'] ?? 'yekan';
        $font_class = 'rp-font-' . esc_attr($selected_font);
        
        echo '<div id="reyhan-app-root" class="' . $font_class . '">';
        if ( ! is_user_logged_in() ) { 
            $this->load_view( 'view-login', $this->get_login_data() );
        } else { 
            $this->load_view( 'view-dashboard', $this->get_dashboard_data() );
        }
        echo '</div>';
        return ob_get_clean();
    }

    private function load_view( $view_name, $args = [] ) {
        if ( ! empty( $args ) && is_array( $args ) ) { extract( $args ); }
        $file = REYHAN_DIR . 'templates/frontend/' . $view_name . '.php';
        if ( file_exists( $file ) ) { include $file; }
    }

    private function get_login_data() {
        $opts = get_option('reyhan_options');
        if ( ! is_array( $opts ) ) $opts = []; 

        $method = $opts['auth_method'] ?? 'email'; 

        // اگر متد پیامک انتخاب شده اما تنظیمات ناقص است، به ایمیل سوییچ کن
        if ( $method === 'sms' ) {
            $api_key  = $opts['sms_apikey'] ?? '';
            $username = $opts['sms_username'] ?? '';
            $password = $opts['sms_password'] ?? '';
            
            if ( empty($api_key) && (empty($username) || empty($password)) ) {
                $method = 'email';
            }
        }

        $active_theme = $opts['login_active_theme'] ?? 'default';
        $palettes = $this->get_palettes();
        
        // دریافت تیترها با پشتیبانی از مقادیر پیش‌فرض
        $title = !empty($opts['login_custom_title']) ? $opts['login_custom_title'] : ($opts['login_title'] ?? __('ورود به پنل کاربری', 'reyhan-panel'));
        $sub = !empty($opts['login_custom_subtitle']) ? $opts['login_custom_subtitle'] : __('اطلاعات خود را وارد کنید', 'reyhan-panel');

        return [
            'opts' => $opts,
            'logo' => $opts['login_logo'] ?? '',
            'logo_w' => !empty($opts['login_logo_width']) ? intval($opts['login_logo_width']) : 120,
            'method' => $method, 
            'title' => $title,
            'sub' => $sub,
            'p' => $palettes[$active_theme] ?? $palettes['default'],
            'bg_mode' => $opts['login_bg_mode'] ?? 'image',
            'bg_image' => $opts['login_bg_image'] ?? '',
            'bg_color' => $opts['login_bg_color'] ?? '',
            'terms_id' => $opts['terms_page_id'] ?? 0
        ];
    }

    private function get_dashboard_data() {
        $u = wp_get_current_user();
        $opts = get_option('reyhan_options');
        $active_theme = $opts['panel_active_theme'] ?? 'default';
        $palettes = $this->get_palettes();
        
        $fname = get_user_meta($u->ID, 'first_name', true) ?: __('کاربر', 'reyhan-panel');
        $lname = get_user_meta($u->ID, 'last_name', true) ?: __('جدید', 'reyhan-panel');
        
        // --- مدیریت نقش‌ها ---
        $roles_list = [];
        if ( user_can($u, 'manage_options') ) {
            $roles_list[] = __('مدیر کل', 'reyhan-panel');
        }
        elseif ( !empty($u->roles) ) {
            $role_map = [
                'editor' => 'ویرایشگر',
                'author' => 'نویسنده',
                'contributor' => 'مشارکت‌کننده',
                'subscriber' => 'کاربر عادی',
                'shop_manager' => 'مدیر فروشگاه',
                'customer' => 'مشتری'
            ];
            foreach ($u->roles as $role) {
                if ( isset($role_map[$role]) ) {
                    $roles_list[] = $role_map[$role];
                } else {
                    $roles_list[] = ucfirst($role); 
                }
            }
        }

        $is_agent = $this->check_if_agent($u);
        if ( $is_agent && ! user_can($u, 'manage_options') ) {
            $roles_list[] = __('پاسخگوی تیکت', 'reyhan-panel');
        }

        if ( empty($roles_list) ) {
            $roles_list[] = __('کاربر مهمان', 'reyhan-panel');
        }
        $role_label = implode(' | ', array_unique($roles_list));

        $custom_avatar = get_user_meta($u->ID, 'reyhan_user_avatar', true);
        
        // --- منو ---
        $menu_items = get_option('reyhan_heavy_panel_menu_structure');
        if(!$menu_items) $menu_items = $opts['panel_menu_structure'] ?? [];
        
        if(empty($menu_items)) {
            $menu_items = [
                ['label'=>__('داشبورد', 'reyhan-panel'), 'icon'=>'dashicons-dashboard', 'action'=>'dashboard'],
                ['label'=>__('ویرایش اطلاعات', 'reyhan-panel'), 'icon'=>'dashicons-id', 'action'=>'profile'], 
                ['label'=>__('سفارشات', 'reyhan-panel'), 'icon'=>'dashicons-cart', 'action'=>'orders'],
                ['label'=>__('پشتیبانی', 'reyhan-panel'), 'icon'=>'dashicons-email-alt', 'action'=>'tickets'],
                ['label'=>__('خروج', 'reyhan-panel'), 'icon'=>'dashicons-no-alt', 'action'=>'logout']
            ];
        }
        
        // --- داده‌های سنگین ---
        $faqs = get_option('reyhan_heavy_ticket_faqs');
        if(!$faqs) $faqs = $opts['ticket_faqs'] ?? [];

        $notifications = get_option('reyhan_heavy_global_notifications_json');
        if(is_string($notifications)) $notifications = json_decode($notifications, true);
        if(!$notifications) {
             if(!empty($opts['global_notifications_json'])) $notifications = json_decode($opts['global_notifications_json'], true);
             else $notifications = [];
        }

        // --- آمارها ---
        // ۱. تیکت‌های باز (تیکت‌هایی که وضعیتشان بسته نیست)
        $tickets_open = $this->get_post_count('ticket', $u->ID, [['key'=>'_ticket_status', 'value'=>'closed', 'compare'=>'!=']]);
        
        // ۲. تعداد سفارشات
        $orders_count = class_exists('WooCommerce') ? count(wc_get_orders(['customer_id'=>$u->ID, 'return'=>'ids'])) : 0;
        
        // ۳. تعداد دیدگاه‌ها (فقط روی پست‌ها و محصولات)
        $comments_count = get_comments([
            'user_id'   => $u->ID,
            'count'     => true,
            'status'    => 'approve',
            'post_type' => ['post', 'product', 'page']
        ]);

        $days_diff = floor((time() - strtotime($u->user_registered)) / (60 * 60 * 24));

        // --- دریافت لیست سفارشات (برای رفع تاخیر لود) ---
        // این بخش جدید است: سفارشات را همینجا می‌گیریم و به ویو می‌فرستیم
        $orders_list = [];
        if ( class_exists('WooCommerce') ) {
            $orders_list = wc_get_orders([
                'customer_id' => $u->ID,
                'limit'       => 15, // دریافت ۱۵ سفارش آخر
                'return'      => 'ids',
                'orderby'     => 'date',
                'order'       => 'DESC'
            ]);
        }

        return [
            'u' => $u, 'opts' => $opts,
            'p' => $palettes[$active_theme] ?? $palettes['default'],
            'sb_img' => $opts['panel_sidebar_bg_image'] ?? '',
            'sb_overlay' => $opts['panel_sidebar_overlay_color'] ?? '',
            'display_name' => $fname . ' ' . $lname,
            'role_label' => $role_label,
            'is_agent_user' => $this->check_if_agent($u),
            'avatar_url' => $custom_avatar ?: REYHAN_URL . 'assets/images/user.png',
            'menu_items' => $menu_items,
            'notifications' => $notifications,
            'count_tickets_open' => $tickets_open,
            'count_orders' => $orders_count,
            'count_comments' => $comments_count,
            'days_diff' => $days_diff,
            'faqs' => $faqs,
            'depts' => $opts['ticket_departments'] ?? [],
            'auth_method' => $opts['auth_method'] ?? 'sms',
            'orders_list' => $orders_list // <--- ارسال لیست به ویو
        ];
    }

    private function check_if_agent($user) {
        if(user_can($user, 'manage_options')) return true;
        $agents_raw = get_option('reyhan_heavy_ticket_support_agents_data');
        if(!$agents_raw) {
             $opts = get_option('reyhan_options');
             $agents_raw = $opts['ticket_support_agents_data'] ?? '[]';
        }
        $agents_data = is_string($agents_raw) ? json_decode($agents_raw, true) : $agents_raw;
        if(is_array($agents_data)) {
            foreach($agents_data as $a) {
                if(isset($a['id']) && intval($a['id']) === $user->ID) return true;
            }
        }
        return false;
    }

    private function get_palettes() {
        return [
            'default' => [ 'gradient' => 'radial-gradient( circle farthest-corner at 10% 20%,  rgba(253, 187, 5, 1) 0%, rgba(245,139,139,1) 100.3% )', 'btn_bg' => '#FF5722', 'text_col' => '#FF5722', 'shadow' => 'rgba(255, 87, 34, 0.3)' ],
            'theme_1' => [ 'gradient' => 'radial-gradient( circle farthest-corner at -0.1% 0.5%,  rgba(15, 170, 64, 1) 0.1%, rgba(16, 170, 144, 1) 100.2% )', 'btn_bg' => '#0f8a40', 'text_col' => '#0f8a40', 'shadow' => 'rgba(15, 170, 64, 0.3)' ],
            'theme_2' => [ 'gradient' => 'linear-gradient( 103deg,  rgba(54,209,220,1) 15.7%, rgba(91,134,229,1) 88.8% )', 'btn_bg' => '#3f5efb', 'text_col' => '#3f5efb', 'shadow' => 'rgba(63, 94, 251, 0.3)' ],
            'theme_3' => [ 'gradient' => 'radial-gradient( circle farthest-corner at 10% 20%,  rgba(254,113,210,1) 0%, rgba(184,96,255,1) 90% )', 'btn_bg' => '#833ab4', 'text_col' => '#833ab4', 'shadow' => 'rgba(131, 58, 180, 0.3)' ],
            'theme_4' => [ 'gradient' => 'radial-gradient( circle 1106px at 91% 53.8%,  rgba(221,147,179,1) 9%, rgba(240,246,215,1) 68.1% )', 'btn_bg' => '#ae94e9', 'text_col' => '#9c7ddb', 'shadow' => 'rgba(148, 187, 233, 0.4)' ]
        ];
    }

    private function get_post_count($type, $author, $meta_query = []) {
        $args = [ 'post_type' => $type, 'posts_per_page' => -1, 'author' => $author, 'fields' => 'ids' ];
        if(!empty($meta_query)) $args['meta_query'] = $meta_query;
        $q = new \WP_Query($args);
        return $q->found_posts;
    }
}