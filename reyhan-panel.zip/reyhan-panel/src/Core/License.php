<?php
namespace ReyhanPanel\Core;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class License {

    // کلید آپشن برای ذخیره لایسنس
    const LICENSE_OPTION = 'reyhan_license_key';
    const STATUS_OPTION  = 'reyhan_license_status';

    /**
     * بررسی وضعیت فعال بودن لایسنس
     */
    public static function is_active() {
        // در نسخه نهایی، اینجا باید تاریخ انقضا و ... چک شود
        // فعلاً اگر استاتوس 'valid' بود، تایید است
        return get_option( self::STATUS_OPTION ) === 'valid';
    }

    /**
     * متد فعال‌سازی (اتصال به API مارکت)
     * فعلاً شبیه‌سازی شده است
     */
    public static function activate_license( $license_key ) {
        // 1. تمیزسازی ورودی
        $license_key = sanitize_text_field( $license_key );

        // 2. شبیه‌سازی تماس با API (در نسخه واقعی اینجا curl زده می‌شود)
        // شرط تستی: اگر طول لایسنس بیشتر از 8 کاراکتر بود، تایید کن
        if ( strlen( $license_key ) > 8 ) {
            update_option( self::LICENSE_OPTION, $license_key );
            update_option( self::STATUS_OPTION, 'valid' );
            return true;
        }

        return false;
    }

    /**
     * دریافت لایسنس ذخیره شده
     */
    public static function get_license() {
        return get_option( self::LICENSE_OPTION );
    }
}