<?php
namespace ReyhanPanel\Core;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class PostTypes {

    public function __construct() {
        add_action( 'init', [ $this, 'register_post_type' ] );
        add_action( 'add_meta_boxes', [ $this, 'add_meta_boxes' ] );
        add_action( 'save_post_ticket', [ $this, 'save_meta_boxes' ] );
        
        // حذف دکمه "افزودن جدید" چون تیکت فقط از فرانت باید بیاید
        add_filter( 'views_edit-ticket', [ $this, 'remove_add_new_link' ] );
        
        // نمایش تعداد تیکت‌های باز در منو
        add_action( 'admin_menu', [ $this, 'add_menu_notification' ], 999 );

        // *** لایه امنیتی جدید: کنترل دسترسی اختصاصی ***
        add_filter( 'map_meta_cap', [ $this, 'restrict_ticket_capabilities' ], 10, 4 );
    }

    public function register_post_type() {
        register_post_type( 'ticket', [
            'labels' => [
                'name' => __('تیکت‌ها', 'reyhan-panel'),
                'singular_name' => __('تیکت', 'reyhan-panel'),
                'all_items' => __('همه تیکت‌ها', 'reyhan-panel'),
                'edit_item' => __('بررسی تیکت', 'reyhan-panel'),
                'view_item' => __('مشاهده', 'reyhan-panel'),
                'search_items' => __('جستجو', 'reyhan-panel'),
                'not_found' => __('تیکتی نیست', 'reyhan-panel'),
                'not_found_in_trash' => __('زباله‌دان خالی است', 'reyhan-panel')
            ],
            'public' => false, // عدم نمایش در سایت اصلی
            'show_ui' => true, // نمایش در ادمین
            'show_in_menu' => false, // مخفی کردن منوی پیش‌فرض
            
            // *** استفاده از دسترسی اختصاصی ***
            'capability_type' => 'rp_ticket',
            'map_meta_cap' => true,
            
            'supports' => ['title', 'editor', 'author', 'comments', 'custom-fields'],
            'menu_icon' => 'dashicons-email-alt'
        ]);
    }

    /**
     * هسته امنیتی: اجازه دسترسی به مدیر، ایجنت و نویسنده تیکت
     */
    public function restrict_ticket_capabilities( $caps, $cap, $user_id, $args ) {
        if ( strpos( $cap, 'rp_ticket' ) === false ) {
            return $caps;
        }

        // 1. مدیر کل دسترسی دارد
        if ( user_can( $user_id, 'manage_options' ) ) {
            return [ 'manage_options' ];
        }

        // 2. کارشناسان (Agents) دسترسی دارند
        if ( $this->is_agent( $user_id ) ) {
            return [ 'read' ];
        }

        // 3. اصلاح اصلی: اجازه به نویسنده تیکت برای دیدن تیکت خودش
        if ( !empty( $args[0] ) ) {
            $post = get_post( $args[0] );
            if ( $post && (int) $post->post_author === (int) $user_id ) {
                return [ 'read' ];
            }
        }

        return [ 'do_not_allow' ];
    }

    private function is_agent( $user_id ) {
        $agents_raw = get_option('reyhan_heavy_ticket_support_agents_data');
        if ( ! $agents_raw ) {
            $opts = get_option('reyhan_options');
            $agents_raw = $opts['ticket_support_agents_data'] ?? '[]';
        }
        $agents_data = is_string($agents_raw) ? json_decode($agents_raw, true) : $agents_raw;

        if ( is_array($agents_data) ) {
            foreach ( $agents_data as $agent ) {
                if ( isset($agent['id']) && intval($agent['id']) === intval($user_id) ) {
                    return true;
                }
            }
        }
        return false;
    }

    public function add_meta_boxes() {
        add_meta_box( 'ticket_status', __('وضعیت تیکت', 'reyhan-panel'), [ $this, 'render_status_box' ], 'ticket', 'side' );
    }

    public function render_status_box($post) {
        $status = get_post_meta($post->ID, '_ticket_status', true);
        $file = REYHAN_DIR . 'templates/admin/partials/metabox-status.php';
        if ( file_exists( $file ) ) { include $file; }
    }

    public function save_meta_boxes($post_id) {
        if(isset($_POST['ticket_status'])) {
            update_post_meta($post_id, '_ticket_status', sanitize_text_field($_POST['ticket_status']));
        }
    }

    public function remove_add_new_link($views) { return $views; }

    public function add_menu_notification() {
        if ( ! current_user_can( 'manage_options' ) && ! $this->is_agent( get_current_user_id() ) ) {
            return;
        }

        $count = $this->get_unreviewed_count();
        if ($count > 0) {
            global $menu;
            foreach ( $menu as $key => $item ) {
                if ( isset($item[2]) && ( $item[2] == 'reyhan-tickets' || $item[2] == 'reyhan-agent-panel' ) ) {
                    if ( strpos( $menu[$key][0], 'awaiting-mod' ) === false ) {
                        $menu[$key][0] .= ' <span class="awaiting-mod count-1"><span class="pending-count">' . $count . '</span></span>';
                    }
                    break;
                }
            }
        }
    }

    private function get_unreviewed_count() {
        $uid = get_current_user_id();
        $transient_key = 'rp_pending_count_' . $uid;
        if ( false !== ( $cached = get_transient( $transient_key ) ) ) {
            return (int) $cached;
        }

        $allowed_depts = [];
        $has_full_access = user_can($uid, 'manage_options');

        if ( ! $has_full_access ) {
            $agents_raw = get_option('reyhan_heavy_ticket_support_agents_data');
            if(!$agents_raw) {
                 $opts = get_option('reyhan_options');
                 $agents_raw = $opts['ticket_support_agents_data'] ?? '[]';
            }
            $agents_data = is_string($agents_raw) ? json_decode($agents_raw, true) : $agents_raw;
            
            foreach ($agents_data as $agent) {
                if (isset($agent['id']) && intval($agent['id']) === intval($uid)) {
                    if (!empty($agent['all_depts'])) $has_full_access = true;
                    else $allowed_depts = $agent['depts'] ?? [];
                    break;
                }
            }
        }

        if ( ! $has_full_access && empty($allowed_depts) ) {
            return 0;
        }

        $args = [
            'post_type' => 'ticket', 
            'post_status' => 'publish', 
            'fields' => 'ids',
            'meta_query' => [ ['key' => '_ticket_status', 'value' => 'open'] ]
        ];

        if (!$has_full_access) {
            $args['meta_query'][] = [
                'key' => '_ticket_department', 'value' => $allowed_depts, 'compare' => 'IN'
            ];
        }

        $query = new \WP_Query($args);
        $count = $query->found_posts;
        
        set_transient($transient_key, $count, 5 * MINUTE_IN_SECONDS);
        return $count;
    }
}