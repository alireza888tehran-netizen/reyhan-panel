<?php
namespace ReyhanPanel\Core;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class AuthRedirects {

    public function __construct() {
        add_action( 'init', array( $this, 'redirect_wp_login_page' ) );
        add_filter( 'login_redirect', array( $this, 'custom_login_redirect' ), 10, 3 );
        add_action( 'wp_logout', array( $this, 'custom_logout_redirect' ) );
        
        // فیلترهای تغییر لینک‌های ورود
        add_filter( 'login_url', array( $this, 'change_wp_login_url' ), 10, 3 );
        add_filter( 'register_url', array( $this, 'change_wp_register_url' ) );
        add_filter( 'lostpassword_url', array( $this, 'change_wp_lostpassword_url' ) );

        // **مهم: جلوگیری از مسدودسازی توسط ووکامرس**
        add_filter( 'woocommerce_prevent_admin_access', array( $this, 'bypass_woocommerce_restriction' ) );
    }

    /**
     * جلوگیری از ریدایرکت اجباری ووکامرس برای نویسندگان و ایجنت‌ها
     */
    public function bypass_woocommerce_restriction( $prevent ) {
        if ( ! is_user_logged_in() ) {
            return $prevent;
        }

        // اگر کاربر توانایی ویرایش پست دارد (نویسنده، ویرایشگر، مدیر) -> اجازه بده
        if ( current_user_can( 'edit_posts' ) ) {
            return false;
        }

        // اگر کاربر ایجنت پشتیبانی است -> اجازه بده
        $uid = get_current_user_id();
        if ( function_exists('rp_is_support_agent') && rp_is_support_agent($uid) ) {
            return false; 
        }
        
        // اینجا هم چک می‌کنیم چون شاید تابع گلوبال هنوز لود نشده باشد
        if ( $this->is_agent_user( $uid ) ) {
            return false;
        }

        return $prevent;
    }

    public function change_wp_login_url( $login_url, $redirect, $force_reauth ) {
        $opts = get_option('reyhan_options');
        if ( empty($opts['exclusive_login_active']) || empty($opts['login_page_id']) ) return $login_url;

        $login_page = get_permalink( $opts['login_page_id'] );
        return $login_page ? $login_page : $login_url;
    }

    public function change_wp_register_url( $url ) {
        $opts = get_option('reyhan_options');
        if ( empty($opts['exclusive_login_active']) || empty($opts['login_page_id']) ) return $url;
        return get_permalink( $opts['login_page_id'] );
    }

    public function change_wp_lostpassword_url( $url ) {
        return $this->change_wp_register_url( $url );
    }

    // تابع کمکی داخلی برای تشخیص ایجنت (برای استفاده در همین کلاس)
    private function is_agent_user( $user_id ) {
        $opts = get_option('reyhan_options');
        $agents_raw = get_option('reyhan_heavy_ticket_support_agents_data');
        if(!$agents_raw) $agents_raw = $opts['ticket_support_agents_data'] ?? '[]';
        $agents_data = is_string($agents_raw) ? json_decode($agents_raw, true) : $agents_raw;
        
        if (is_array($agents_data)) {
            foreach($agents_data as $a) {
                if(isset($a['id']) && intval($a['id']) === intval($user_id)) { 
                    return true;
                }
            }
        }
        return false;
    }

    public function redirect_wp_login_page() {
        $opts = get_option('reyhan_options');
        
        // فقط اگر "ورود اختصاصی" فعال باشد
        if ( !empty($opts['exclusive_login_active']) ) {
            global $pagenow;
            
            // تشخیص کاربران مجاز (ادمین، نویسنده و پشتیبان)
            $is_privileged = false;
            
            if ( is_user_logged_in() ) {
                $uid = get_current_user_id();

                // 1. آیا مدیر است؟
                if ( current_user_can('manage_options') ) { 
                    $is_privileged = true; 
                }
                // 2. **اصلاح مهم:** آیا نویسنده/ویرایشگر است؟ (دسترسی wp-admin دارد)
                elseif ( current_user_can('edit_posts') ) {
                    $is_privileged = true;
                }
                // 3. آیا ایجنت است؟
                elseif ( $this->is_agent_user( $uid ) ) {
                    $is_privileged = true;
                }
            }

            $page_id = $opts['login_page_id'] ?? 0;
            $login_url = $page_id ? get_permalink($page_id) : home_url();

            // ریدایرکت صفحه wp-login.php (برای همه بجز درخواست خروج)
            if ( $pagenow == 'wp-login.php' && $_SERVER['REQUEST_METHOD'] == 'GET' ) {
                if ( isset($_GET['action']) && $_GET['action'] == 'logout' ) return;
                wp_safe_redirect( $login_url );
                exit;
            }

            // ریدایرکت wp-admin برای کاربران غیرمجاز
            // حالا چون نویسنده $is_privileged=true دارد، وارد شرط زیر نمی‌شود
            if ( is_admin() && ! defined('DOING_AJAX') && !$is_privileged ) {
                wp_safe_redirect( $login_url );
                exit;
            }
        }
    }

    public function custom_login_redirect( $redirect_to, $request, $user ) {
        $opts = get_option('reyhan_options');

        if ( ! empty( $opts['login_redirect_url'] ) ) {
            return wp_validate_redirect( $opts['login_redirect_url'], $redirect_to );
        }

        // اگر ورود اختصاصی فعال است، پیش‌فرض به پنل برگرد
        if ( ! empty( $opts['exclusive_login_active'] ) && ! empty( $opts['login_page_id'] ) ) {
            return wp_validate_redirect( get_permalink( $opts['login_page_id'] ), $redirect_to );
        }

        return $redirect_to;
    }


public function custom_logout_redirect() {
        $opts = get_option('reyhan_options');

        $target = home_url();

        if ( ! empty( $opts['logout_redirect_url'] ) ) {
            $target = $opts['logout_redirect_url'];
        } elseif ( ! empty( $opts['exclusive_login_active'] ) && ! empty( $opts['login_page_id'] ) ) {
            $target = get_permalink( $opts['login_page_id'] );
        }

        $target = wp_validate_redirect( $target, home_url() );
        wp_safe_redirect( $target );
        exit;
    }

}