<?php
namespace ReyhanPanel\Core;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class AuthRedirects {

    public function __construct() {
        add_action( 'init', array( $this, 'redirect_wp_login_page' ) );
        add_filter( 'login_redirect', array( $this, 'custom_login_redirect' ), 10, 3 );
        add_action( 'wp_logout', array( $this, 'custom_logout_redirect' ) );
        
        // فیلترهای جدید برای تغییر تمام لینک‌های ورود در وردپرس
        add_filter( 'login_url', array( $this, 'change_wp_login_url' ), 10, 3 );
        add_filter( 'register_url', array( $this, 'change_wp_register_url' ) );
        add_filter( 'lostpassword_url', array( $this, 'change_wp_lostpassword_url' ) );
    }

    public function change_wp_login_url( $login_url, $redirect, $force_reauth ) {
        $opts = get_option('reyhan_options');
        if ( empty($opts['exclusive_login_active']) || empty($opts['login_page_id']) ) return $login_url;

        $login_page = get_permalink( $opts['login_page_id'] );
        return $login_page ? $login_page : $login_url;
    }

    public function change_wp_register_url( $url ) {
        $opts = get_option('reyhan_options');
        if ( empty($opts['exclusive_login_active']) || empty($opts['login_page_id']) ) return $url;
        return get_permalink( $opts['login_page_id'] );
    }

    public function change_wp_lostpassword_url( $url ) {
        return $this->change_wp_register_url( $url );
    }

    public function redirect_wp_login_page() {
        $opts = get_option('reyhan_options');
        
        // فقط اگر "ورود اختصاصی" فعال باشد
        if ( !empty($opts['exclusive_login_active']) ) {
            global $pagenow;
            
            // تشخیص کاربران مجاز (ادمین و پشتیبان)
            $is_privileged = false;
            if ( is_user_logged_in() ) {
                $uid = get_current_user_id();
                $agents_raw = get_option('reyhan_heavy_ticket_support_agents_data');
                if(!$agents_raw) $agents_raw = $opts['ticket_support_agents_data'] ?? '[]';
                $agents_data = is_string($agents_raw) ? json_decode($agents_raw, true) : $agents_raw;
                if (is_array($agents_data)) {
                    foreach($agents_data as $a) {
                        if(isset($a['id']) && intval($a['id']) === intval($uid)) { $is_privileged = true; break; }
                    }
                }
                if ( current_user_can('manage_options') ) { $is_privileged = true; }
            }

            $page_id = $opts['login_page_id'] ?? 0;
            $login_url = $page_id ? get_permalink($page_id) : home_url();

            // ریدایرکت صفحه wp-login.php
            if ( $pagenow == 'wp-login.php' && $_SERVER['REQUEST_METHOD'] == 'GET' ) {
                if ( isset($_GET['action']) && $_GET['action'] == 'logout' ) return;
                wp_redirect( $login_url );
                exit;
            }

            // ریدایرکت wp-admin برای کاربران غیرمجاز
            if ( is_admin() && ! defined('DOING_AJAX') && !$is_privileged ) {
                wp_redirect( $login_url );
                exit;
            }
        }
    }

    public function custom_login_redirect( $redirect_to, $request, $user ) {
        $opts = get_option('reyhan_options');
        if ( !empty($opts['login_redirect_url']) ) { return $opts['login_redirect_url']; }
        
        // اگر ورود اختصاصی فعال است، پیش‌فرض به پنل برگرد
        if ( !empty($opts['exclusive_login_active']) && !empty($opts['login_page_id']) ) {
             return get_permalink($opts['login_page_id']);
        }
        
        return $redirect_to;
    }

    public function custom_logout_redirect() {
        $opts = get_option('reyhan_options');
        if ( !empty($opts['logout_redirect_url']) ) { 
            wp_redirect( $opts['logout_redirect_url'] ); 
            exit; 
        }
        
        if ( !empty($opts['exclusive_login_active']) && !empty($opts['login_page_id']) ) {
            wp_redirect( get_permalink($opts['login_page_id']) );
            exit;
        }
        
        wp_redirect( home_url() );
        exit;
    }
}