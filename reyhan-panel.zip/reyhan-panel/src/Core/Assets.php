<?php
namespace ReyhanPanel\Core;
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Assets {
    private $version;
    private $url;

    public function __construct() {
        $this->version = defined('REYHAN_VERSION') ? REYHAN_VERSION : '3.0.0';
        $this->url     = defined('REYHAN_URL') ? REYHAN_URL : plugin_dir_url( dirname( dirname( __FILE__ ) ) );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin' ] );
        add_action( 'wp_enqueue_scripts',    [ $this, 'enqueue_frontend' ] );
    }

    public function enqueue_admin( $hook ) {
        $allowed_pages = [ 'profile.php', 'user-edit.php' ];

        // شرط اجرای فقط در صفحات ریحان پنل یا پروفایل‌ها
        if ( strpos( $hook, 'reyhan' ) === false && ! in_array( $hook, $allowed_pages ) ) {
            return;
        }

        wp_enqueue_media(); 
        wp_enqueue_style( 'wp-color-picker' ); 
        wp_enqueue_script( 'wp-color-picker' ); 
        wp_enqueue_script( 'jquery-ui-sortable' );
        
        // >> اضافه کردن Select2 (نسخه CDN پایدار) <<
        wp_enqueue_style( 'select2-css', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css' );
        wp_enqueue_script( 'select2-js', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', ['jquery'], '4.1.0', true );

        // --- شروع تغییرات: فراخوانی ساختار جدید CSS از پوشه admin ---
        $css_base = $this->url . 'assets/css/admin/';

        // 1. هسته اصلی (فونت‌ها، متغیرها و لی‌اوت)
        wp_enqueue_style( 'reyhan-admin-core', $css_base . 'admin-core.css', [], $this->version );

        // 2. رابط کاربری (دکمه‌ها، فرم‌ها، کارت‌ها) - وابسته به Core
        wp_enqueue_style( 'reyhan-admin-ui', $css_base . 'admin-ui.css', ['reyhan-admin-core'], $this->version );

        // 3. ویژگی‌های پنل (تیکت، منوساز، تنظیمات) - وابسته به UI
        wp_enqueue_style( 'reyhan-admin-features', $css_base . 'admin-features.css', ['reyhan-admin-ui'], $this->version );

        // 4. استایل اختصاصی صفحه پروفایل پاسخگو (لود شرطی)
        // بررسی می‌کنیم اگر در صفحه پروفایل هستیم، این فایل لود شود
        if ( isset($_GET['page']) && ( strpos($_GET['page'], 'agent-profile') !== false ) ) {
            wp_enqueue_style( 'reyhan-admin-agent', $css_base . 'admin-agent.css', ['reyhan-admin-features'], $this->version );
        }
        // --- پایان تغییرات ---

        // فایل JS اصلی (بدون تغییر)
        wp_enqueue_script( 'reyhan-admin-js', $this->url . 'assets/js/admin.js', [ 'jquery', 'select2-js' ], $this->version, true );
        
        $uid = get_current_user_id();
        $canned = get_user_meta( $uid, 'rp_user_canned_responses', true );
        
        wp_localize_script( 'reyhan-admin-js', 'reyhan_admin_ajax', [ 
            'ajax_url' => admin_url( 'admin-ajax.php' ), 
            'nonce' => wp_create_nonce( 'reyhan_admin_nonce' ), 
            'rp_profile_nonce' => wp_create_nonce( 'rp_profile_update' ), 
            'canned_responses' => ! empty( $canned ) ? array_values( $canned ) : [] 
        ]);
    }

    public function enqueue_frontend() {
        if ( ! $this->should_load_frontend() ) return;
        $opts = get_option( 'reyhan_options' );
        
        // 1. استایل آیکون‌ها
        wp_enqueue_style( 'dashicons' );

        // 2. لود Select2 (نسخه CDN)
        wp_enqueue_style( 'select2-front-css', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css' );
        wp_enqueue_script( 'select2-front-js', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', ['jquery'], '4.1.0', true );
        
        // 3. استایل اختصاصی خودمان (وابسته به select2)
        wp_enqueue_style( 'reyhan-front-css', $this->url . 'assets/css/frontend.css', ['select2-front-css'], $this->version );
        
        // 4. اینجکت فونت
        $this->inject_custom_font( 'reyhan-front-css', '#reyhan-app-root' );
        
        // 5. اسکریپت اصلی (وابسته به jquery و select2)
        wp_enqueue_script( 'reyhan-front-js', $this->url . 'assets/js/frontend.js', [ 'jquery', 'select2-front-js' ], $this->version, true );
        
        // 6. لوکالایز و ارسال متغیرها
        $raw_faqs = get_option('reyhan_heavy_ticket_faqs'); 
        if(!$raw_faqs) $raw_faqs = ! empty( $opts['ticket_faqs'] ) ? $opts['ticket_faqs'] : [];
        
        wp_localize_script( 'reyhan-front-js', 'reyhan_front_obj', [ 
            'ajax_url' => admin_url( 'admin-ajax.php' ), 
            'nonce' => wp_create_nonce( 'reyhan_auth_nonce' ), 
            'faqs' => is_array( $raw_faqs ) ? array_values( $raw_faqs ) : [], 
            'labels' => [ 'wait' => __('لطفاً صبر کنید...', 'reyhan-panel'), 'success' => __('عملیات موفقیت‌آمیز بود.', 'reyhan-panel') ] 
        ]);

        if ( ! empty( $opts['recaptcha_active'] ) && ! empty( $opts['recaptcha_site_key'] ) ) {
            wp_enqueue_script( 'google-recaptcha', 'https://www.google.com/recaptcha/api.js?render=' . esc_attr( $opts['recaptcha_site_key'] ), [], null, true );
            wp_localize_script( 'reyhan-front-js', 'reyhan_captcha', [ 'site_key' => $opts['recaptcha_site_key'] ] );
        }
    }

    private function should_load_frontend() {
        global $post; $opts = get_option( 'reyhan_options' ); $login_page_id = $opts['login_page_id'] ?? 0;
        if ( is_page() && ! empty( $login_page_id ) && get_the_ID() == $login_page_id ) return true;
        if ( is_a( $post, 'WP_Post' ) && ( has_shortcode( $post->post_content, 'reyhan_panel' ) || has_shortcode( $post->post_content, 'reyhan_support' ) ) ) return true;
        return false;
    }

    private function inject_custom_font( $handle, $selector_prefix ) {
        $opts = get_option( 'reyhan_options' );
        
        $font_reg  = $this->url . 'assets/fonts/Regular.woff2';
        $font_bold = $this->url . 'assets/fonts/SemiBold.woff2';
        
        $css = "
            @font-face { font-family: 'ReyhanFont'; src: url('$font_reg') format('woff2'); font-weight: normal; font-display: swap; } 
            @font-face { font-family: 'ReyhanFontBold'; src: url('$font_bold') format('woff2'); font-weight: bold; font-display: swap; } 
            
            {$selector_prefix}, 
            {$selector_prefix} *:not(.dashicons):not(.fa),
            .rp-notification { 
                font-family: 'ReyhanFont', Tahoma, sans-serif !important; 
            }
            
            {$selector_prefix} h1, {$selector_prefix} h2, {$selector_prefix} h3, 
            {$selector_prefix} h4, {$selector_prefix} h5, {$selector_prefix} h6,
            {$selector_prefix} strong, {$selector_prefix} b,
            {$selector_prefix} .rp-user-name, {$selector_prefix} .rp-card-stat strong,
            {$selector_prefix} .rp-btn-primary { 
                font-family: 'ReyhanFontBold', Tahoma, sans-serif !important; 
            }
            
            {$selector_prefix} .dashicons, {$selector_prefix} .dashicons-before:before,
            .rp-notification .dashicons { 
                font-family: dashicons !important; 
            }
        ";
        wp_add_inline_style( $handle, $css );
    }
}