<?php
namespace ReyhanPanel\Core;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Assets {

    private $version;
    private $url;

    public function __construct() {
        $this->version = defined('REYHAN_VERSION') ? REYHAN_VERSION : '2.1.0';
        $this->url = defined('REYHAN_URL') ? REYHAN_URL : plugin_dir_url( dirname( dirname( dirname( __FILE__ ) ) ) );

        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin' ] );
        add_action( 'wp_enqueue_scripts',    [ $this, 'enqueue_frontend' ] );
    }

    public function enqueue_admin( $hook ) {
        // صفحات مجاز برای بارگذاری
        $allowed_pages = [ 'profile.php', 'user-edit.php' ];
        $is_reyhan = ( strpos( $hook, 'reyhan' ) !== false );

        if ( ! $is_reyhan && ! in_array( $hook, $allowed_pages ) ) {
            return;
        }

        // 1. استایل‌های پایه و لی‌اوت
        wp_enqueue_style( 'rp-admin-core',   $this->url . 'assets/css/admin/core.css', [], $this->version );
        wp_enqueue_style( 'rp-admin-layout', $this->url . 'assets/css/admin/layout.css', ['rp-admin-core'], $this->version );
        wp_enqueue_style( 'rp-admin-ui',     $this->url . 'assets/css/admin/ui.css', ['rp-admin-layout'], $this->version );

        // 2. استایل‌های ماژولار (تیکت، کاربران، منو)
        wp_enqueue_style( 'rp-admin-tickets', $this->url . 'assets/css/admin/tickets.css', ['rp-admin-ui'], $this->version );
        wp_enqueue_style( 'rp-admin-users',   $this->url . 'assets/css/admin/users.css', ['rp-admin-ui'], $this->version );
        wp_enqueue_style( 'rp-admin-menu',    $this->url . 'assets/css/admin/menu.css', ['rp-admin-ui'], $this->version );

        // 3. ویزارد نصب (فقط در صفحه خودش)
        if ( isset($_GET['page']) && $_GET['page'] === 'reyhan-setup-wizard' ) {
            wp_enqueue_style( 'rp-wizard-css', $this->url . 'assets/css/wizard.css', [], $this->version );
            wp_enqueue_script( 'rp-admin-wizard', $this->url . 'assets/js/admin/wizard.js', ['jquery'], $this->version, true );
            wp_localize_script( 'rp-admin-wizard', 'reyhan_wizard_obj', [
                'nonce' => wp_create_nonce('reyhan_wizard_nonce'),
                'license_status' => get_option('reyhan_license_status')
            ]);
        }

        // 4. اسکریپت‌های ضروری
        wp_enqueue_media();
        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_script( 'wp-color-picker' );
        wp_enqueue_script( 'jquery-ui-sortable' );

        // 5. فایل‌های جاوا اسکریپت ادمین
        wp_enqueue_script( 'rp-admin-core-js', $this->url . 'assets/js/admin/core.js', ['jquery', 'wp-color-picker', 'jquery-ui-sortable'], $this->version, true );
        wp_enqueue_script( 'rp-admin-tools',   $this->url . 'assets/js/admin/tools.js', ['rp-admin-core-js'], $this->version, true );
        wp_enqueue_script( 'rp-admin-notif',   $this->url . 'assets/js/admin/notifications.js', ['rp-admin-core-js'], $this->version, true );
        wp_enqueue_script( 'rp-admin-agents',  $this->url . 'assets/js/admin/agents.js', ['rp-admin-core-js'], $this->version, true );
        wp_enqueue_script( 'rp-admin-tickets', $this->url . 'assets/js/admin/tickets.js', ['rp-admin-core-js'], $this->version, true );
        wp_enqueue_script( 'rp-admin-menu',    $this->url . 'assets/js/admin/menu.js', ['rp-admin-core-js'], $this->version, true );

        wp_localize_script( 'rp-admin-core-js', 'reyhan_admin_ajax', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'reyhan_admin_nonce' ),
            'canned_responses' => []
        ]);
    }

    public function enqueue_frontend() {
        // جلوگیری از بارگذاری منابع در تمام صفحات سایت
        // منابع فقط زمانی لود شوند که پنل/پشتیبانی در همان صفحه استفاده شده باشد
        if ( ! $this->should_enqueue_frontend_assets() ) {
            return;
        }

        wp_enqueue_style( 'dashicons' );
        // لود Select2 از CDN برای پایداری
        wp_enqueue_style( 'rp-select2-css', $this->url . 'assets/vendor/select2/select2.min.css', [], '0.1.0' );
        wp_enqueue_script( 'rp-select2-js', $this->url . 'assets/vendor/select2/select2.min.js', ['jquery'], '0.1.0', true );

        wp_enqueue_style( 'rp-front-core',   $this->url . 'assets/css/frontend/core.css', [], $this->version );
        wp_enqueue_style( 'rp-front-ui',     $this->url . 'assets/css/frontend/ui.css', ['rp-front-core', 'rp-select2-css'], $this->version );
        wp_enqueue_style( 'rp-front-layout', $this->url . 'assets/css/frontend/layout.css', ['rp-front-ui'], $this->version );
        wp_enqueue_style( 'rp-front-login',     $this->url . 'assets/css/frontend/login.css', ['rp-front-layout'], $this->version );
        wp_enqueue_style( 'rp-front-dashboard', $this->url . 'assets/css/frontend/dashboard.css', ['rp-front-layout'], $this->version );
        wp_enqueue_style( 'rp-front-tickets',   $this->url . 'assets/css/frontend/tickets.css', ['rp-front-layout'], $this->version );
        wp_enqueue_style( 'rp-front-orders',    $this->url . 'assets/css/frontend/orders.css', ['rp-front-layout'], $this->version );
        wp_enqueue_style( 'rp-front-profile',   $this->url . 'assets/css/frontend/profile.css', ['rp-front-layout'], $this->version );

        wp_enqueue_script( 'rp-iran-data',     $this->url . 'assets/js/frontend/iran-data.js', [], $this->version, true );
        wp_enqueue_script( 'rp-front-core',    $this->url . 'assets/js/frontend/core.js',      ['jquery', 'rp-iran-data', 'rp-select2-js'], $this->version, true );
        wp_enqueue_script( 'rp-front-profile', $this->url . 'assets/js/frontend/profile.js',   ['rp-front-core'], $this->version, true );
        wp_enqueue_script( 'rp-front-tickets', $this->url . 'assets/js/frontend/tickets.js',   ['rp-front-core'], $this->version, true );
        wp_enqueue_script( 'rp-front-orders',  $this->url . 'assets/js/frontend/orders.js',    ['rp-front-core'], $this->version, true );

        wp_localize_script( 'rp-front-core', 'reyhan_front_obj', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'reyhan_auth_nonce' ),
            'home_url' => home_url(),
            'is_logged_in' => is_user_logged_in()
        ]);
    }

    /**
     * تعیین اینکه منابع فرانت‌اند در این صفحه لود شوند یا نه
     * - صفحه پنل/ورود انتخاب‌شده
     * - صفحه My Account ووکامرس (اگر استفاده شده باشد)
     * - صفحاتی که شورتکدهای افزونه داخل محتوای آنهاست
     */
    private function should_enqueue_frontend_assets() {
        // امکان اجبار برای توسعه‌دهنده‌ها (بدون تغییر UI)
        if ( apply_filters( 'reyhan_panel_force_enqueue_assets', false ) ) {
            return true;
        }

        // صفحه‌های تنظیم‌شده در افزونه
        $opts = get_option( 'reyhan_options' );
        if ( is_array( $opts ) ) {
            $panel_page_id = ! empty( $opts['login_page_id'] ) ? absint( $opts['login_page_id'] ) : 0;
            if ( $panel_page_id && is_page( $panel_page_id ) ) {
                return true;
            }
        }

        // صفحه My Account ووکامرس (در صورت استفاده)
        $wc_myaccount_id = absint( get_option( 'woocommerce_myaccount_page_id' ) );
        if ( $wc_myaccount_id && is_page( $wc_myaccount_id ) ) {
            return true;
        }

        // بررسی وجود شورتکد در محتوا
        if ( is_singular() ) {
            $post = get_post();
            if ( $post && ! empty( $post->post_content ) ) {
                if ( has_shortcode( $post->post_content, 'reyhan_panel' ) || has_shortcode( $post->post_content, 'reyhan_support' ) ) {
                    return true;
                }
            }
        }

        return false;
    }
}