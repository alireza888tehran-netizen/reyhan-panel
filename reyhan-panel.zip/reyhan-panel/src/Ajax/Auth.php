<?php
namespace ReyhanPanel\Ajax;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Auth {

    public function __construct() {
        // ثبت اکشن‌های AJAX
        $actions = [
            'reyhan_check_email_status'     => 'handle_check_email_status',
            'reyhan_email_login'            => 'handle_email_login',
            'reyhan_email_register_full'    => 'handle_email_register_full',
            'reyhan_send_otp'               => 'handle_send_otp',
            'reyhan_verify_otp'             => 'handle_verify_otp',
            'reyhan_send_email_otp_fp'      => 'handle_send_email_otp_fp',
            'reyhan_check_otp_only'         => 'handle_check_otp_only',
            'reyhan_reset_password_fp'      => 'handle_reset_password_fp',
            'reyhan_send_otp_request'       => 'handle_send_otp_request',
            'reyhan_verify_contact_final'   => 'handle_verify_contact_final',
            'reyhan_update_profile_info'    => 'handle_update_profile_info',
            'reyhan_check_init' => 'handle_check_init'
        ];

        foreach ( $actions as $action => $method ) {
            add_action( "wp_ajax_{$action}", [ $this, $method ] );
            add_action( "wp_ajax_nopriv_{$action}", [ $this, $method ] );
        }
    }

    // --- متدهای کمکی داخلی (برای جلوگیری از خطای 500) ---
    private function check_nonce() {
        // بررسی نانس امنیتی (نام نانس در JS باید reyhan_auth_nonce باشد)
        if ( ! check_ajax_referer( 'reyhan_auth_nonce', 'security', false ) && ! check_ajax_referer( 'reyhan_auth_nonce', 'nonce', false ) ) {
            wp_send_json_error( 'نشست امنیتی منقضی شده است. لطفاً صفحه را رفرش کنید.' );
        }
    }

    private function check_limit() {
        // دریافت تنظیمات از دیتابیس
        $opts = get_option('reyhan_options');
        
        // دریافت سقف تلاش (پیش‌فرض: ۵ بار)
        $max_attempts = !empty($opts['login_max_attempts']) ? (int)$opts['login_max_attempts'] : 5;
        
        // دریافت زمان مسدودی به دقیقه و تبدیل به ثانیه (پیش‌فرض: ۱۵ دقیقه)
        $ban_minutes  = !empty($opts['login_lockout_time']) ? (int)$opts['login_lockout_time'] : 15;
        $ban_seconds  = $ban_minutes * 60;

        $ip = $_SERVER['REMOTE_ADDR'];
        $key_count = 'rp_limit_count_' . md5( $ip ); // شمارنده تلاش‌ها
        $key_time  = 'rp_limit_ban_' . md5( $ip );    // زمان پایان محرومیت

        // ۱. آیا کاربر الان محروم است؟
        $ban_timestamp = get_transient( $key_time );
        if ( $ban_timestamp ) {
            $remaining = $ban_timestamp - time();
            if ( $remaining > 0 ) {
                wp_send_json_error([
                    'code' => 'rate_limit',
                    'wait' => $remaining
                ]);
                exit;
            }
        }

        // ۲. دریافت تعداد تلاش‌های فعلی
        $attempts = get_transient( $key_count ) ?: 0;
        
        // ۳. اگر به سقف مجاز (تنظیم شده در پنل) رسید
        if ( $attempts >= $max_attempts ) {
            // اعمال محرومیت طبق زمان تنظیم شده
            set_transient( $key_time, time() + $ban_seconds, $ban_seconds );
            
            // ریست کردن شمارنده
            delete_transient( $key_count ); 

            wp_send_json_error([
                'code' => 'rate_limit',
                'wait' => $ban_seconds
            ]);
            exit;
        }

        // ۴. افزایش شمارنده (اعتبار این شمارنده هم به اندازه زمان مسدودی است)
        set_transient( $key_count, $attempts + 1, $ban_seconds );
    }

    public function handle_check_init() {
        // ۱. بررسی محدودیت (اگر محدود باشد، اینجا متوقف می‌شود و تایمر برمی‌گرداند)
        $this->check_limit();

        // ۲. اگر محدود نبود، وضعیت لاگین را چک می‌کنیم
        $is_logged_in = is_user_logged_in();
        $redirect = '';
        
        if ( $is_logged_in ) {
            $opts = get_option('reyhan_options');
            $redirect = !empty($opts['login_redirect_url']) ? $opts['login_redirect_url'] : home_url();
        }

        wp_send_json_success([
            'logged_in' => $is_logged_in,
            'redirect'  => $redirect
        ]);
    }

    // ---------------------------------------------------
    // ۱. لاگین و ثبت نام
    // ---------------------------------------------------

    // در فایل src/Ajax/Auth.php
public function handle_check_email_status() {
    $this->check_limit(); 
    $this->check_nonce();
    
    $email = sanitize_email( $_POST['email'] ?? '' );
    $opts = get_option('reyhan_options');

    // اعمال محدودیت ایمیل‌های یکبار مصرف
    if ( !empty($opts['block_disposable_emails']) ) {
        $disposable_domains = ['tempmail.com', '10minutemail.com', 'yopmail.com']; // این لیست می‌تواند از دیتابیس بیاید
        $domain = substr(strrchr($email, "@"), 1);
        if ( in_array($domain, $disposable_domains) ) {
            wp_send_json_error( 'استفاده از ایمیل‌های موقت مجاز نیست.' );
        }
    }

    $exists = email_exists( $email ) || username_exists( $email );
    wp_send_json_success( [ 'exists' => $exists ] );
}

    public function handle_email_login() {
        $this->check_limit(); $this->check_nonce();
        $email = sanitize_email( $_POST['log'] ?? '' );
        $pass  = $_POST['pwd'] ?? '';

        // پارامتر دوم false برای کوکی غیر امن (اگر SSL ندارید)
        $user = wp_signon( [ 'user_login' => $email, 'user_password' => $pass, 'remember' => true ], false );

        if ( is_wp_error( $user ) ) {
            // ترجمه خطاهای رایج
            $err = $user->get_error_code();
            if ( $err == 'incorrect_password' ) wp_send_json_error( 'رمز عبور اشتباه است.' );
            if ( $err == 'invalid_username' ) wp_send_json_error( 'نام کاربری یا ایمیل یافت نشد.' );
            wp_send_json_error( 'اطلاعات ورود صحیح نیست.' );
        }

        wp_set_current_user( $user->ID );
        wp_set_auth_cookie( $user->ID, true );
        wp_send_json_success( 'ورود موفقیت‌آمیز بود.' );
    }

    public function handle_email_register_full() {
        $this->check_limit(); $this->check_nonce();
        $email = sanitize_email( $_POST['email'] ?? '' );
        $pass  = $_POST['pwd'] ?? '';
        $fname = sanitize_text_field( $_POST['fname'] ?? '' );
        $lname = sanitize_text_field( $_POST['lname'] ?? '' );

        if ( ! is_email( $email ) ) wp_send_json_error( 'ایمیل نامعتبر است.' );
        if ( email_exists( $email ) ) wp_send_json_error( 'این ایمیل قبلاً ثبت شده است.' );
        
        $uid = wp_create_user( $email, $pass, $email );
        if ( is_wp_error( $uid ) ) wp_send_json_error( $uid->get_error_message() );

        wp_update_user([ 'ID' => $uid, 'first_name' => $fname, 'last_name' => $lname, 'display_name' => "$fname $lname" ]);
        
        wp_set_current_user( $uid ); 
        wp_set_auth_cookie( $uid, true );
        wp_send_json_success( 'ثبت نام انجام شد.' );
    }

    public function handle_send_otp() {
        // لاگین پیامکی
        $this->check_limit(); $this->check_nonce();
        $mobile = sanitize_text_field( $_POST['mobile'] ?? '' );
        
        if ( ! preg_match( '/^09[0-9]{9}$/', $mobile ) ) wp_send_json_error( 'شماره موبایل نامعتبر است.' );
        
        $code = (string) wp_rand( 12345, 98765 );
        set_transient( 'rp_otp_' . $mobile, $code, 120 ); // 2 دقیقه
        
        // ارسال پیامک
        if ( class_exists( '\ReyhanPanel\Services\SMS' ) ) {
            \ReyhanPanel\Services\SMS::send_otp( $mobile, $code );
            wp_send_json_success( 'کد تایید ارسال شد.' );
        } else {
            // حالت تست (اگر سرویس پیامک فعال نیست)
            wp_send_json_success( "کد تایید (تست): $code" );
        }
    }

    // در متد handle_verify_otp (اصلاح شده برای سرعت)
public function handle_verify_otp() {
    $this->check_nonce();
    $mobile = sanitize_text_field( $_POST['mobile'] ?? '' );
    $code   = sanitize_text_field( $_POST['code'] ?? '' );

    $saved = get_transient( 'rp_otp_' . $mobile );
    if ( empty( $saved ) || ! hash_equals( (string) $saved, (string) $code ) ) {
        wp_send_json_error( 'کد تایید اشتباه یا منقضی شده است.' );
    }

    delete_transient( 'rp_otp_' . $mobile );

    $user = get_user_by( 'login', $mobile );
    if ( ! $user ) {
        // ثبت نام آنی با موبایل بدون دریافت اطلاعات اضافی
        $email = $mobile . '@user.reyhan'; // ایمیل مجازی
        $uid = wp_create_user( $mobile, wp_generate_password(), $email );
        if ( is_wp_error( $uid ) ) wp_send_json_error( $uid->get_error_message() );
        
        update_user_meta( $uid, 'mobile', $mobile );
        $user = get_user_by( 'id', $uid );
    }

    wp_set_current_user( $user->ID );
    wp_set_auth_cookie( $user->ID, true );
    wp_send_json_success( [ 'message' => 'خوش آمدید، در حال انتقال...', 'redirect' => home_url('/panel') ] );
}

    public function handle_send_email_otp_fp() {
    $this->check_limit();
    $this->check_nonce();

    $email = sanitize_email( $_POST['email'] ?? '' );
    if ( ! email_exists( $email ) ) {
        wp_send_json_error( 'کاربری با این ایمیل یافت نشد.' );
    }

    // تولید کد ۵ رقمی
    $code = rand( 10000, 99999 );
    
    // ذخیره در ترنزینت برای ۵ دقیقه (300 ثانیه)
    // کلید شامل ایمیل است تا منحصر به فرد باشد
    set_transient( 'rp_fp_otp_' . md5($email), $code, 300 );

    // ارسال ایمیل
    $subject = 'کد تایید بازیابی رمز عبور';
    $message = "کد تایید شما: {$code}\nاین کد تا ۵ دقیقه معتبر است.";
    $headers = array('Content-Type: text/html; charset=UTF-8');
    
    // نکته: بهتر است از قالب HTML زیبا برای ایمیل استفاده کنید
    wp_mail( $email, $subject, $message, $headers );

    wp_send_json_success( 'کد تایید به ایمیل شما ارسال شد.' );
}
    public function handle_check_otp_only() {
        $this->check_nonce();
        $email = sanitize_email( $_POST['email'] );
        $code = sanitize_text_field( $_POST['code'] );
        
        $saved = get_transient( 'rp_fp_' . md5($email) );
        if ( $saved && $saved == $code ) wp_send_json_success();
        
        wp_send_json_error( 'کد تایید اشتباه یا منقضی شده است.' );
    }

    public function handle_reset_password_fp() {
    $this->check_nonce();
    
    $email = sanitize_email( $_POST['email'] ?? '' );
    $code  = sanitize_text_field( $_POST['code'] ?? '' );
    $pass  = $_POST['pass'] ?? '';

    // بررسی کد تایید
    $saved_code = get_transient( 'rp_fp_otp_' . md5($email) );
    if ( empty( $saved_code ) || $saved_code != $code ) {
        wp_send_json_error( 'کد تایید اشتباه یا منقضی شده است.' );
    }

    // بررسی امنیت رمز عبور (همان منطق ثبت نام)
    if ( strlen($pass) < 8 || !preg_match('/[A-Z]/', $pass) || !preg_match('/[a-z]/', $pass) || !preg_match('/[!@#$%^&*)(]/', $pass) ) {
        wp_send_json_error( 'رمز عبور امنیت کافی را ندارد.' );
    }

    $user = get_user_by( 'email', $email );
    if ( ! $user ) wp_send_json_error( 'کاربر یافت نشد.' );

    // تغییر رمز
    wp_set_password( $pass, $user->ID );
    
    // حذف کد استفاده شده
    delete_transient( 'rp_fp_otp_' . md5($email) );

    // لاگین خودکار کاربر
    wp_set_current_user( $user->ID );
    wp_set_auth_cookie( $user->ID );

    wp_send_json_success( 'رمز عبور با موفقیت تغییر کرد.' );
}

    // ---------------------------------------------------
    // ۳. پروفایل کاربری و تغییرات (جدید)
    // ---------------------------------------------------

    public function handle_send_otp_request() {
        $this->check_nonce();
        if ( ! is_user_logged_in() ) wp_send_json_error( 'لطفاً وارد شوید.' );

        $type  = sanitize_text_field( $_POST['type'] ?? '' );
        $value = sanitize_text_field( $_POST['value'] ?? '' );
        $uid   = get_current_user_id();

        if ( $type === 'mobile' ) {
            if ( ! preg_match( '/^09[0-9]{9}$/', $value ) ) wp_send_json_error( 'فرمت موبایل صحیح نیست.' );
            
            $exists = get_users(['meta_key' => 'mobile', 'meta_value' => $value]);
            if ( ! empty($exists) ) wp_send_json_error( 'این شماره قبلاً ثبت شده است.' );

            $code = (string) wp_rand( 10000, 99999 );
            set_transient( 'rp_change_mob_' . $uid, [ 'val' => $value, 'code' => $code ], 120 ); // 2 دقیقه

            if ( class_exists( '\ReyhanPanel\Services\SMS' ) ) {
                \ReyhanPanel\Services\SMS::send_otp( $value, $code );
                wp_send_json_success( 'کد تایید پیامک شد.' );
            } else {
                wp_send_json_success( "کد تایید (تست): $code" );
            }

        } elseif ( $type === 'email' ) {
            if ( ! is_email( $value ) ) wp_send_json_error( 'ایمیل صحیح نیست.' );
            if ( email_exists( $value ) ) wp_send_json_error( 'این ایمیل تکراری است.' );

            $code = (string) wp_rand( 10000, 99999 );
            set_transient( 'rp_change_email_' . $uid, [ 'val' => $value, 'code' => $code ], 300 ); // 5 دقیقه

            wp_mail( $value, 'تغییر ایمیل', "کد تایید: $code" );
            wp_send_json_success( 'کد تایید ایمیل شد.' );
        }
        
        wp_send_json_error( 'نوع درخواست نامعتبر است.' );
    }

    public function handle_verify_contact_final() {
        $this->check_nonce();
        if ( ! is_user_logged_in() ) wp_send_json_error( 'لطفاً وارد شوید.' );

        $type = $_POST['type'] ?? '';
        $code = sanitize_text_field( $_POST['code'] ?? '' );
        $uid  = get_current_user_id();

        if ( $type === 'mobile' ) {
            $data = get_transient( 'rp_change_mob_' . $uid );
            if ( ! $data || empty( $data['code'] ) || ! hash_equals( (string) $data['code'], (string) $code ) ) wp_send_json_error( 'کد اشتباه است.' );

            update_user_meta( $uid, 'mobile', $data['val'] );
            delete_transient( 'rp_change_mob_' . $uid );
            wp_send_json_success( 'شماره موبایل تغییر کرد.' );

        } elseif ( $type === 'email' ) {
            $data = get_transient( 'rp_change_email_' . $uid );
            if ( ! $data || empty( $data['code'] ) || ! hash_equals( (string) $data['code'], (string) $code ) ) wp_send_json_error( 'کد اشتباه است.' );

            wp_update_user( [ 'ID' => $uid, 'user_email' => $data['val'] ] );
            delete_transient( 'rp_change_email_' . $uid );
            wp_send_json_success( 'ایمیل با موفقیت تغییر کرد.' );
        }
        wp_send_json_error( 'خطای ناشناخته.' );
    }

    public function handle_update_profile_info() {
        $this->check_nonce();
        if ( ! is_user_logged_in() ) wp_send_json_error( 'دسترسی غیرمجاز.' );

        $uid = get_current_user_id();
        $fname = sanitize_text_field( $_POST['first_name'] ?? '' );
        $lname = sanitize_text_field( $_POST['last_name'] ?? '' );

        // 1. ذخیره اطلاعات متنی
        wp_update_user( [ 'ID' => $uid, 'first_name' => $fname, 'last_name' => $lname, 'display_name' => "$fname $lname" ] );

        $fields = ['billing_state', 'billing_city', 'billing_address_1', 'billing_postcode'];
        foreach ( $fields as $field ) {
            if ( isset( $_POST[$field] ) ) {
                update_user_meta( $uid, $field, sanitize_text_field( $_POST[$field] ) );
            }
        }

        // 2. آپلود تصویر (با بارگذاری فایل‌های ضروری وردپرس)
        if ( ! empty( $_FILES['profile_image'] ) ) {
            $file = $_FILES['profile_image'];
            $check = wp_check_filetype( $file['name'] );
            
            if ( ! in_array( $check['ext'], ['jpg', 'jpeg', 'png'] ) ) {
                wp_send_json_error( 'فقط فرمت‌های JPG و PNG مجاز هستند.' );
            }

            // لود توابع مدیا که در AJAX پیش‌فرض لود نیستند
            if ( ! function_exists( 'media_handle_upload' ) ) {
                require_once( ABSPATH . 'wp-admin/includes/image.php' );
                require_once( ABSPATH . 'wp-admin/includes/file.php' );
                require_once( ABSPATH . 'wp-admin/includes/media.php' );
            }

            $attach_id = media_handle_upload( 'profile_image', 0 );
            
            if ( is_wp_error( $attach_id ) ) {
                wp_send_json_error( 'خطا در آپلود: ' . $attach_id->get_error_message() );
            } else {
                $url = wp_get_attachment_url( $attach_id );
                update_user_meta( $uid, 'reyhan_user_avatar', $url );
            }
        }

        wp_send_json_success( 'تغییرات با موفقیت ذخیره شد.' );
    }
}