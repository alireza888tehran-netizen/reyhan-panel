<?php
namespace ReyhanPanel\Ajax;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class AdminTicket extends Base {

    protected function register_actions() {
        $this->add_ajax_action( 'admin_load_tickets', 'handle_load_tickets' );
        $this->add_ajax_action( 'admin_load_conv',    'handle_load_conversation' );
        $this->add_ajax_action( 'admin_reply',        'handle_send_reply' );
        $this->add_ajax_action( 'tool_action',        'handle_tool_actions' );
        add_action( 'wp_ajax_reyhan_search_users', [ $this, 'handle_search_users' ] );
    }

    private function render_partial( $file, $args = [] ) {
        if ( ! empty( $args ) ) {
            extract( $args );
        }
        $path = REYHAN_DIR . 'templates/admin/partials/' . $file . '.php';
        if ( file_exists( $path ) ) {
            ob_start();
            include $path;
            return ob_get_clean();
        }
        return '';
    }

    public function handle_load_tickets() {
        $this->check_nonce( 'reyhan_admin_nonce' );
        $access = $this->get_agent_access();
        if ( ! $access['has_access'] ) {
            $this->send_error( __( 'شما دسترسی لازم را ندارید.', 'reyhan-panel' ) );
        }

        $status = sanitize_text_field( $_POST['status'] ?? 'active' );
        $args = [ 'post_type' => 'ticket', 'posts_per_page' => 50, 'post_status' => 'publish' ];

        if ( $status == 'closed' ) {
            $args['meta_query'][] = [ 'key' => '_ticket_status', 'value' => 'closed' ];
        } elseif ( $status == 'active' || $status == 'open' ) {
            $args['meta_query'][] = [ 'key' => '_ticket_status', 'value' => 'closed', 'compare' => '!=' ];
        }

        if ( ! $access['is_full'] ) {
            if ( empty( $access['depts'] ) ) {
                $args['post__in'] = [0];
            } else {
                $args['meta_query'][] = [ 'key' => '_ticket_department', 'value' => $access['depts'], 'compare' => 'IN' ];
            }
        }

        $tickets = get_posts( $args );
        $html = '';

        if ( $tickets ) {
            foreach ( $tickets as $t ) {
                $html .= $this->render_partial( 'item-ticket', [ 't' => $t ] );
            }
        } else {
            $html = '<div class="rp-empty-state"><p>' . __( 'هیچ تیکتی یافت نشد.', 'reyhan-panel' ) . '</p></div>';
        }

        $this->send_success( $html );
    }

    public function handle_load_conversation() {
        $this->check_nonce( 'reyhan_admin_nonce' );
        $tid = intval( $_POST['ticket_id'] ?? 0 );
        $ticket = get_post( $tid );

        if ( ! $ticket ) {
            $this->send_error( __( 'تیکت یافت نشد.', 'reyhan-panel' ) );
        }
        
        $access = $this->get_agent_access();
        if ( ! $access['has_access'] ) {
            $this->send_error( __( 'عدم دسترسی.', 'reyhan-panel' ) );
        }

        $u = get_userdata( $ticket->post_author );
        $display_name = __( 'کاربر حذف شده', 'reyhan-panel' ); 
        $mobile = '';
        if ( $u ) {
            $display_name = $u->display_name;
            $mobile = get_user_meta( $u->ID, 'mobile', true );
        }
        $dept = get_post_meta( $tid, '_ticket_department', true );

        $info = '<div class="rp-info-bar">
                    <span>👤 ' . esc_html( $display_name ) . '</span>
                    <span>📞 ' . esc_html( $mobile ) . '</span>
                    <span>🏢 ' . esc_html( $dept ) . '</span>
                 </div>';

        $chat = '';
        $chat .= $this->render_partial( 'item-chat-msg', [ 'comment' => $ticket, 'is_author' => true, 'is_first_msg' => true ]);

        $comments = get_comments( [ 'post_id' => $tid, 'order' => 'ASC' ] );
        foreach ( $comments as $c ) {
            $is_author = ( $c->user_id == $ticket->post_author );
            $chat .= $this->render_partial( 'item-chat-msg', [ 'comment' => $c, 'is_author' => $is_author ]);
        }

        $this->send_success( [ 'info' => $info, 'chat' => $chat ] );
    }

    public function handle_send_reply() {
        $this->check_nonce( 'reyhan_admin_nonce' );
        $tid = intval( $_POST['ticket_id'] ?? 0 );
        $uid = get_current_user_id();
        $msg = wp_kses_post( $_POST['message'] ?? '' );
        $st = sanitize_text_field( $_POST['status'] ?? 'answered' );

        $opts = get_option( 'reyhan_options' );
        $header = $opts['ticket_reply_header'] ?? '';
        $footer = $opts['ticket_reply_footer'] ?? '';
        
        if ( $header ) {
            $msg = $header . "\n\n" . $msg;
        }
        if ( $footer ) {
            $msg = $msg . "\n\n" . $footer;
        }

        $cid = wp_insert_comment([
            'comment_post_ID' => $tid, 
            'comment_content' => $msg, 
            'user_id' => $uid, 
            'comment_approved'=> 1
        ]);

        if ( $cid ) {
            update_post_meta( $tid, '_ticket_status', $st );
            if ( ! empty( $_FILES['reply_file']['name'] ) ) {
                $file_url = $this->handle_upload( 'reply_file' );
                if ( $file_url ) {
                    add_comment_meta( $cid, 'attachment', $file_url );
                }
            }
            do_action( 'reyhan_ticket_replied', $tid, $cid, $uid );
            do_action( 'reyhan_ticket_status_changed', $tid, $st );
            $this->send_success( __( 'پاسخ با موفقیت ارسال شد.', 'reyhan-panel' ) );
        }
        $this->send_error( __( 'خطا در ارسال پاسخ.', 'reyhan-panel' ) );
    }

    public function handle_search_users() {
        check_ajax_referer( 'reyhan_admin_nonce', 'security' );

        if ( ! current_user_can( 'manage_options' ) ) {
            $this->send_error( __('دسترسی غیرمجاز.', 'reyhan-panel') );
        }

        $term = sanitize_text_field( $_POST['term'] ?? '' );
        
        if ( empty( $term ) || strlen( $term ) < 2 ) {
            $this->send_error( __('عبارت جستجو کوتاه است.', 'reyhan-panel') );
        }

        $args = [
            'search'         => '*' . $term . '*',
            'search_columns' => [ 'user_login', 'user_email', 'display_name' ],
            'number'         => 10,
            'exclude'        => [ get_current_user_id() ], // حذف خود مدیر
            'fields'         => [ 'ID', 'display_name', 'user_email' ],
            'orderby'        => 'display_name',
            'order'          => 'ASC'
        ];

        $user_query = new \WP_User_Query( $args );
        $results = [];

        if ( ! empty( $user_query->get_results() ) ) {
            foreach ( $user_query->get_results() as $user ) {
                // 1. ابتدا تلاش برای گرفتن آواتار اختصاصی افزونه
                $custom_avatar = get_user_meta( $user->ID, 'reyhan_user_avatar', true );
                
                if ( ! empty( $custom_avatar ) ) {
                    $avatar_url = $custom_avatar;
                } else {
                    // 2. اگر نبود، گراواتار وردپرس
                    $avatar_url = get_avatar_url( $user->ID, ['size' => 128] );
                }

                // 3. اگر باز هم نبود، تصویر پیش‌فرض
                if ( ! $avatar_url ) {
                    $avatar_url = \REYHAN_URL . 'assets/images/user.png';
                }

                $results[] = [
                    'id'     => $user->ID,
                    'text'   => $user->display_name . ' (' . $user->user_email . ')',
                    'avatar' => $avatar_url
                ];
            }
        }

        $this->send_success( $results );
    }

    public function handle_tool_actions() {
        $this->check_nonce( 'reyhan_admin_nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            $this->send_error( __( 'دسترسی ندارید.', 'reyhan-panel' ) );
        }

        $tool = $_POST['tool_action'] ?? '';

        switch ( $tool ) {
            case 'test_sms': 
                $mob = sanitize_text_field( $_POST['mobile'] );
                if ( \ReyhanPanel\Services\SMS::send_otp( $mob, '12345' ) ) {
                    $this->send_success( __( 'ارسال پیامک تست موفقیت‌آمیز بود.', 'reyhan-panel' ) );
                } else {
                    $this->send_error( \ReyhanPanel\Services\SMS::$last_error );
                }
                break;
                
            case 'test_email': 
                $eml = sanitize_email( $_POST['email'] );
                if ( wp_mail( $eml, 'تست ریحان پنل', 'این یک ایمیل تستی است.' ) ) {
                    $this->send_success( __( 'ایمیل تست ارسال شد.', 'reyhan-panel' ) );
                } else {
                    $this->send_error( __( 'خطا در ارسال ایمیل. تابع wp_mail کار نمی‌کند.', 'reyhan-panel' ) );
                }
                break;
                
            case 'clear_otp': 
                global $wpdb;
                $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_rp_otp_%' OR option_name LIKE '_transient_timeout_rp_otp_%'" );
                $this->send_success( __( 'کدهای منقضی شده پاکسازی شدند.', 'reyhan-panel' ) );
                break;
                
            case 'factory_reset':
                delete_option( 'reyhan_options' );
                global $wpdb;
                $wpdb->query( "DELETE FROM {$wpdb->usermeta} WHERE meta_key IN ('rp_user_canned_responses', 'reyhan_user_avatar')" );
                $this->send_success( __( 'تنظیمات به حالت اولیه بازگشت.', 'reyhan-panel' ) );
                break;
                
            case 'nuke_tickets_single':
                wp_delete_post( intval( $_POST['id'] ), true );
                $this->send_success( __( 'تیکت حذف شد.', 'reyhan-panel' ) );
                break;
                
            case 'nuke_tickets':
                if ( function_exists( 'set_time_limit' ) ) {
                    set_time_limit( 300 );
                }
                $tickets = get_posts(['post_type'=>'ticket','posts_per_page'=>-1,'fields'=>'ids','post_status'=>'any']);
                $count = 0;
                if ( $tickets ) { 
                    foreach ( $tickets as $tid ) { 
                        wp_delete_post( $tid, true ); 
                        $count++; 
                    } 
                }
                $this->send_success( sprintf( __( '%d تیکت به طور کامل حذف شدند.', 'reyhan-panel' ), $count ) );
                break;
        }
    }

    private function get_agent_access() {
        $uid = get_current_user_id();
        $is_super_admin = current_user_can( 'manage_options' );
        
        $agents_raw = get_option('reyhan_heavy_ticket_support_agents_data');
        if ( ! $agents_raw ) {
            $opts = get_option('reyhan_options');
            $agents_raw = $opts['ticket_support_agents_data'] ?? '[]';
        }
        $agents = is_string($agents_raw) ? json_decode($agents_raw, true) : $agents_raw;
        if ( ! is_array( $agents ) ) {
            $agents = [];
        }

        $current_agent = null;
        foreach ( $agents as $a ) { 
            if ( intval( $a['id'] ) === intval( $uid ) ) { 
                $current_agent = $a; 
                break; 
            } 
        }
        
        if ( $current_agent ) {
            return [ 'has_access' => true, 'is_full' => ! empty( $current_agent['all_depts'] ), 'depts' => $current_agent['depts'] ?? [] ];
        }
        
        if ( $is_super_admin ) {
            return [ 'has_access' => true, 'is_full' => true, 'depts' => [] ];
        }
        
        return [ 'has_access' => false, 'is_full' => false, 'depts' => [] ];
    }
}