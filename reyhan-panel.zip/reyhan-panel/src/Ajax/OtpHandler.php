<?php
namespace ReyhanPanel\Ajax;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class OtpHandler {

    public function __construct() {
        add_action( 'wp_ajax_rp_send_otp', [ $this, 'send_otp' ] );
        add_action( 'wp_ajax_rp_verify_otp', [ $this, 'verify_otp' ] );
    }

    public function send_otp() {
        // 1. بررسی امنیت (Nonce Check)
        // نام نانس باید با آنچه در wp_localize_script تعریف کرده‌اید یکی باشد.
        // با توجه به فایل UserTicket.php، شما از 'reyhan_auth_nonce' استفاده می‌کنید.
        check_ajax_referer( 'reyhan_auth_nonce', 'security' );

        if ( ! is_user_logged_in() ) {
            wp_send_json_error( 'لطفاً وارد شوید.' );
        }
        
        $type = sanitize_text_field( $_POST['type'] ?? '' ); // mobile or email
        $value = sanitize_text_field( $_POST['value'] ?? '' );
        $user_id = get_current_user_id();

        if ( empty( $value ) || ! in_array( $type, ['mobile', 'email'] ) ) {
            wp_send_json_error( 'اطلاعات نامعتبر است.' );
        }

        // 2. تولید کد امن (Secure Random Integer)
        try {
            $code = (string) random_int( 10000, 99999 );
        } catch (\Exception $e) {
            $code = (string) wp_rand( 10000, 99999 ); // Fallback
        }
        
        // ذخیره موقت کد در دیتابیس برای 2 دقیقه
        $transient_key = 'rp_otp_' . $user_id . '_' . $type;
        set_transient( $transient_key, [ 'code' => $code, 'value' => $value ], 120 );

        if ( $type === 'mobile' ) {
            // فراخوانی کلاس ارسال پیامک (فرض بر این است که کلاس SMS شما وجود دارد)
            if ( class_exists( '\ReyhanPanel\Services\SMS' ) ) {
                $sent = \ReyhanPanel\Services\SMS::send_otp( $value, $code );
                if ( $sent === false ) {
                    // اگر ارسال پیامک شکست خورد، خطا را برگردانیم
                    $err = '';
                    if ( property_exists( '\\ReyhanPanel\\Services\\SMS', 'last_error' ) ) {
                        $err = \ReyhanPanel\Services\SMS::$last_error;
                    }
                    wp_send_json_error( $err ? $err : 'خطا در ارسال پیامک.' );
                }
            }
        } else {
            // ارسال ایمیل با هدرهای صحیح
            $headers = array('Content-Type: text/html; charset=UTF-8');
            wp_mail( $value, 'کد تایید تغییر ایمیل', "کد تایید شما: <strong>$code</strong>", $headers );
        }

        wp_send_json_success( [ 'msg' => 'کد تایید ارسال شد' ] );
    }

    public function verify_otp() {
        // 1. بررسی امنیت (Nonce Check)
        check_ajax_referer( 'reyhan_auth_nonce', 'security' );

        if ( ! is_user_logged_in() ) {
            wp_send_json_error( 'لطفاً وارد شوید.' );
        }

        $type = sanitize_text_field( $_POST['type'] ?? '' );
        $user_code = sanitize_text_field( $_POST['code'] ?? '' );
        $user_id = get_current_user_id();

        $transient_key = 'rp_otp_' . $user_id . '_' . $type;
        $saved_data = get_transient( $transient_key );

        if ( ! $saved_data || empty( $saved_data['code'] ) || ! hash_equals( (string) $saved_data['code'], (string) $user_code ) ) {
            wp_send_json_error( 'کد وارد شده اشتباه یا منقضی شده است.' );
        }

        // بررسی اینکه آیا کاربر همان شماره/ایمیل قبلی را تایید می‌کند (جلوگیری از دستکاری در لحظه آخر)
        // (این بخش اختیاری اما توصیه شده است، فعلا طبق منطق قبلی شما پیش می‌رویم)

        if ( $type === 'mobile' ) {
            update_user_meta( $user_id, 'rp_verified_mobile', $saved_data['value'] );
            update_user_meta( $user_id, 'mobile', $saved_data['value'] ); // سینک کردن شماره
        } else {
            update_user_meta( $user_id, 'rp_verified_email', $saved_data['value'] );
            wp_update_user([ 'ID' => $user_id, 'user_email' => $saved_data['value'] ]);
        }

        // پاک کردن کد مصرف شده
        delete_transient( $transient_key );

        wp_send_json_success( [ 'msg' => 'تغییرات با موفقیت ذخیره شد.' ] );
    }
}