<?php
namespace ReyhanPanel\Ajax;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class UserTicket {

    public function __construct() {
        // هوک‌های تیکت
        add_action( 'wp_ajax_reyhan_user_list_tickets',   [ $this, 'handle_list' ] );
        add_action( 'wp_ajax_reyhan_user_view_ticket',    [ $this, 'handle_view' ] );
        add_action( 'wp_ajax_reyhan_user_create_ticket',  [ $this, 'handle_submit' ] );
        add_action( 'wp_ajax_reyhan_user_reply_ticket',   [ $this, 'handle_reply' ] );
        add_action( 'wp_ajax_reyhan_user_close',          [ $this, 'handle_close' ] );

        // هوک‌های سفارشات
        add_action( 'wp_ajax_reyhan_user_list_orders',    [ $this, 'handle_list_orders' ] );
        add_action( 'wp_ajax_reyhan_user_view_order',     [ $this, 'handle_view_order' ] );
    }

    /**
     * بررسی امنیت بدون قطع کردن (Die)
     */
    private function check_auth() {
        if ( ! isset( $_POST['security'] ) || ! wp_verify_nonce( $_POST['security'], 'reyhan_auth_nonce' ) ) {
            wp_send_json_error( 'نشست امنیتی منقضی شده. رفرش کنید.' );
            exit;
        }
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( 'لطفاً وارد شوید.' );
            exit;
        }
    }

    // --- لیست تیکت‌ها ---
    public function handle_list() {
        $this->check_auth();
        
        $uid = get_current_user_id();
        $paged = isset($_POST['paged']) ? intval($_POST['paged']) : 1;
        
        $args = [
            'post_type'      => 'ticket',
            'posts_per_page' => 10,
            'paged'          => $paged,
            'author'         => $uid,
            'post_status'    => 'any', 
            'orderby'        => 'modified',
            'order'          => 'DESC',
        ];
        
        $query = new \WP_Query( $args );
        $tickets = $query->posts;

        ob_start();
        // مسیر فایل ویو
        $template = REYHAN_DIR . 'templates/frontend/view-tickets-list.php';
        if ( file_exists( $template ) ) {
            include $template;
        } else {
            echo '<div class="rp-error">قالب لیست تیکت یافت نشد.</div>';
        }
        $html = ob_get_clean();
        
        wp_send_json_success( ['html' => $html] );
    }

    // --- ثبت تیکت جدید ---
    public function handle_submit() {
        $this->check_auth();
        
        $uid = get_current_user_id();
        if ( get_transient( 'rp_flood_' . $uid ) ) {
            wp_send_json_error( 'لطفاً ۱ دقیقه صبر کنید.' );
            exit;
        }

        // اصلاح: دریافت title (نام فیلد در فرم HTML شما)
        $title = isset($_POST['title']) ? trim(sanitize_text_field($_POST['title'])) : '';
        // پشتیبانی از subject اگر در جایی دیگر استفاده شده
        if(empty($title) && isset($_POST['subject'])) $title = trim(sanitize_text_field($_POST['subject']));

        $msg = isset($_POST['message']) ? trim(sanitize_textarea_field($_POST['message'])) : '';
        $dept = isset($_POST['department']) ? sanitize_text_field($_POST['department']) : 'general';
        $prio = isset($_POST['priority']) ? sanitize_text_field($_POST['priority']) : 'medium';

        if ( empty($title) ) wp_send_json_error( 'موضوع تیکت الزامی است.' );
        if ( is_numeric($title) ) wp_send_json_error( 'موضوع نمی‌تواند فقط عدد باشد.' );
        if ( mb_strlen($msg) < 5 ) wp_send_json_error( 'متن تیکت کوتاه است.' );

        // آپلود فایل
        $att_id = 0;
        if ( ! empty( $_FILES['attachment']['name'] ) ) {
            $att_res = $this->handle_secure_upload( $_FILES['attachment'] );
            if ( is_wp_error( $att_res ) ) {
                wp_send_json_error( $att_res->get_error_message() );
                exit;
            }
            $att_id = $att_res;
        }

        // ثبت
        $pid = wp_insert_post([
            'post_title'   => $title,
            'post_content' => wp_kses_post($msg),
            'post_status'  => 'publish',
            'post_type'    => 'ticket',
            'post_author'  => $uid
        ]);

        if ( is_wp_error( $pid ) ) wp_send_json_error( 'خطا در ثبت.' );

        update_post_meta( $pid, '_ticket_department', $dept );
        update_post_meta( $pid, '_ticket_priority', $prio );
        update_post_meta( $pid, '_ticket_status', 'open' );
        update_post_meta( $pid, '_ticket_code', 'T-' . strtoupper(substr(md5($pid . time()), 0, 6)) );
        if($att_id) update_post_meta( $pid, '_ticket_attachment_id', $att_id );

        set_transient( 'rp_flood_' . $uid, true, 60 );

        wp_send_json_success( 'تیکت با موفقیت ثبت شد.' );
    }

    // --- مشاهده تیکت ---
    public function handle_view() {
        $this->check_auth();
        $tid = intval( $_POST['ticket_id'] ?? 0 );
        $post = get_post( $tid );
        
        if ( ! $post || $post->post_author != get_current_user_id() ) wp_send_json_error( 'تیکت نامعتبر.' );

        ob_start();
        include REYHAN_DIR . 'templates/frontend/view-single-ticket.php';
        wp_send_json_success( ob_get_clean() );
    }

    // --- پاسخ تیکت ---
    public function handle_reply() {
        $this->check_auth();
        $tid = intval( $_POST['ticket_id'] ?? 0 );
        $msg = trim( sanitize_textarea_field( $_POST['message'] ?? '' ) );
        
        if(!$tid) wp_send_json_error('تیکت نامعتبر است.');
        
        // 1. اعتبارسنجی پیام پاسخ
        if ( empty($msg) ) wp_send_json_error('متن پاسخ خالی است.');
        if ( mb_strlen($msg, 'UTF-8') < 20 ) wp_send_json_error('متن پاسخ باید حداقل ۲۰ کاراکتر باشد.');

        $post = get_post($tid);
        if(!$post || $post->post_author != get_current_user_id()) wp_send_json_error('دسترسی ندارید.');

        $att_id = 0;
        if(!empty($_FILES['attachment']['name'])) {
            $res = $this->handle_secure_upload($_FILES['attachment']);
            if(is_wp_error($res)) wp_send_json_error($res->get_error_message());
            $att_id = $res;
        }

        $cid = wp_insert_comment([
            'comment_post_ID' => $tid, 'comment_content' => wp_kses_post($msg),
            'user_id' => get_current_user_id(), 'comment_type' => 'ticket_reply', 'comment_approved' => 1
        ]);

        if($cid) {
            if($att_id) add_comment_meta($cid, '_attachment_id', $att_id);
            update_post_meta($tid, '_ticket_status', 'user_reply');
            update_post_meta($tid, '_ticket_updated', current_time('mysql'));
            wp_send_json_success('پاسخ ارسال شد.');
        }
        wp_send_json_error('خطا در ارسال.');
    }

    // --- بستن تیکت ---
    public function handle_close() {
        $this->check_auth();
        $tid = intval($_POST['ticket_id']);
        $p = get_post($tid);
        if($p && $p->post_author == get_current_user_id()) {
            update_post_meta($tid, '_ticket_status', 'closed');
            wp_send_json_success('بسته شد.');
        }
        wp_send_json_error('خطا');
    }

    // --- سفارشات ---
    public function handle_list_orders() {
        $this->check_auth();
        if(!class_exists('WooCommerce')) wp_send_json_error('ووکامرس نیست');
        $orders = wc_get_orders(['customer_id'=>get_current_user_id(), 'limit'=>-1]);
        ob_start();
        include REYHAN_DIR . 'templates/frontend/view-orders-list.php';
        wp_send_json_success(ob_get_clean());
    }

    public function handle_view_order() {
        $this->check_auth();
        $order = wc_get_order(intval($_POST['order_id']));
        if(!$order || $order->get_user_id() != get_current_user_id()) wp_send_json_error('خطا');
        ob_start();
        include REYHAN_DIR . 'templates/frontend/view-order-details.php';
        wp_send_json_success(ob_get_clean());
    }

    private function handle_secure_upload( $file ) {
        if(empty($file['name'])) return false;
        $opts = get_option('reyhan_options');
        $max = !empty($opts['ticket_max_file_size']) ? intval($opts['ticket_max_file_size']) : 2;
        
        if($file['size'] > $max * 1024 * 1024) return new \WP_Error('err', "حجم فایل زیاد است (حداکثر $max مگابایت)");

        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $blocked = ['php','exe','js','bat','sh'];
        if(in_array($ext, $blocked)) return new \WP_Error('err', 'فرمت غیرمجاز امنیتی');

        require_once(ABSPATH.'wp-admin/includes/image.php');
        require_once(ABSPATH.'wp-admin/includes/file.php');
        require_once(ABSPATH.'wp-admin/includes/media.php');
        return media_handle_upload('attachment', 0);
    }
}