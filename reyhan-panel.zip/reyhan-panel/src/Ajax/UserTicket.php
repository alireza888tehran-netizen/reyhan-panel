<?php
namespace ReyhanPanel\Ajax;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class UserTicket {

    public function __construct() {
        // --- بخش تیکت‌ها ---
        add_action( 'wp_ajax_reyhan_user_list',   [ $this, 'handle_list' ] );
        add_action( 'wp_ajax_reyhan_user_view',   [ $this, 'handle_view' ] );
        add_action( 'wp_ajax_reyhan_user_submit', [ $this, 'handle_submit' ] );
        add_action( 'wp_ajax_reyhan_user_reply',  [ $this, 'handle_reply' ] );
        add_action( 'wp_ajax_reyhan_user_close',  [ $this, 'handle_close' ] );

        // --- بخش سفارشات (جدید) ---
        add_action( 'wp_ajax_reyhan_user_list_orders', [ $this, 'handle_list_orders' ] );
        add_action( 'wp_ajax_reyhan_user_view_order',  [ $this, 'handle_view_order' ] );
    }

    // =========================================================================
    // بخش سفارشات (Orders Logic)
    // =========================================================================

    public function handle_list_orders() {
        $this->check_auth();
        
        if ( ! class_exists( 'WooCommerce' ) ) {
            wp_send_json_error( 'ووکامرس نصب نیست.' );
        }

        $uid = get_current_user_id();
        
        // دریافت سفارشات کاربر
        $args = [
            'customer_id' => $uid,
            'limit'       => -1, // نمایش همه
            'orderby'     => 'date',
            'order'       => 'DESC',
            'return'      => 'ids',
        ];
        $orders = wc_get_orders( $args );

        ob_start();
        // بارگذاری قالب لیست
        if ( file_exists( REYHAN_DIR . 'templates/frontend/view-orders-list.php' ) ) {
            include REYHAN_DIR . 'templates/frontend/view-orders-list.php';
        } else {
            echo 'فایل قالب سفارشات یافت نشد.';
        }
        $html = ob_get_clean();

        wp_send_json_success( $html );
    }

    public function handle_view_order() {
        $this->check_auth();

        if ( ! class_exists( 'WooCommerce' ) ) {
            wp_send_json_error( 'ووکامرس نصب نیست.' );
        }

        $order_id = intval( $_POST['order_id'] ?? 0 );
        if ( ! $order_id ) wp_send_json_error( 'شناسه سفارش نامعتبر است.' );

        $order = wc_get_order( $order_id );

        // بررسی دسترسی: آیا سفارش متعلق به همین کاربر است؟
        if ( ! $order || $order->get_user_id() !== get_current_user_id() ) {
            wp_send_json_error( 'شما اجازه دسترسی به این سفارش را ندارید.' );
        }

        ob_start();
        // بارگذاری قالب جزئیات
        if ( file_exists( REYHAN_DIR . 'templates/frontend/view-order-details.php' ) ) {
            include REYHAN_DIR . 'templates/frontend/view-order-details.php';
        } else {
            echo 'فایل قالب جزئیات سفارش یافت نشد.';
        }
        $html = ob_get_clean();

        wp_send_json_success( $html );
    }

    // =========================================================================
    // بخش تیکت‌ها (Tickets Logic) - حفظ کدهای قبلی با استاندارد جدید
    // =========================================================================

    public function handle_list() {
        $this->check_auth();
        $uid = get_current_user_id();
        
        // تنظیمات کوئری
        $args = [
            'post_type'      => 'ticket',
            'posts_per_page' => -1, // نمایش تمام تیکت‌ها
            'author'         => $uid,
            'post_status'    => [ 'publish', 'pending', 'draft', 'private', 'any' ], 
            'orderby'        => 'modified',
            'order'          => 'DESC',
        ];
        
        $query = new \WP_Query( $args );
        
        // ریختن پست‌ها در متغیر تیکت‌ها
        $tickets = $query->posts; 

        // اصلاحیه: دریافت سوالات متداول برای ارسال به قالب
        $opts = get_option('reyhan_options');
        $faqs = [];
        if ( !empty($opts['faq_items']) && is_array($opts['faq_items']) ) {
            $faqs = $opts['faq_items'];
        }
        
        ob_start();
        // بررسی وجود فایل قالب قبل از اینکلود
        $template_path = REYHAN_DIR . 'templates/frontend/view-tickets-list.php';
        if ( file_exists( $template_path ) ) {
            // حالا متغیر $faqs در فایل view-tickets-list.php در دسترس است
            include $template_path;
        } else {
            echo '<div class="rp-empty-state">فایل قالب لیست تیکت‌ها یافت نشد.</div>';
        }
        $html = ob_get_clean();
        
        wp_send_json_success( $html );
    }

    public function handle_view() {
        $this->check_auth();
        $tid = intval( $_POST['ticket_id'] ?? 0 );
        $uid = get_current_user_id();
        
        $post = get_post( $tid );
        if ( ! $post || $post->post_type !== 'ticket' || $post->post_author != $uid ) {
            wp_send_json_error( 'تیکت یافت نشد یا دسترسی ندارید.' );
        }

        ob_start();
        if ( file_exists( REYHAN_DIR . 'templates/frontend/view-single-ticket.php' ) ) {
            include REYHAN_DIR . 'templates/frontend/view-single-ticket.php';
        }
        $html = ob_get_clean();
        
        wp_send_json_success( $html );
    }

    public function handle_submit() {
        $this->check_auth();
        
        // کنترل اسپم (Flood Control)
        $this->check_flood_limit();

        $uid = get_current_user_id();
        $title = sanitize_text_field( $_POST['title'] ?? '' );
        $dept  = sanitize_text_field( $_POST['department'] ?? 'general' );
        $prio  = sanitize_text_field( $_POST['priority'] ?? 'medium' );
        $msg   = sanitize_textarea_field( $_POST['message'] ?? '' );

        if ( empty($title) || empty($msg) ) wp_send_json_error( 'لطفاً تمام فیلدها را پر کنید.' );

        // ایجاد تیکت
        $post_id = wp_insert_post([
            'post_title'   => $title,
            'post_content' => $msg,
            'post_status'  => 'publish',
            'post_type'    => 'ticket',
            'post_author'  => $uid
        ]);

        if ( is_wp_error( $post_id ) ) wp_send_json_error( 'خطا در ثبت تیکت.' );

        // ذخیره متادیتا
        update_post_meta( $post_id, '_ticket_department', $dept );
        update_post_meta( $post_id, '_ticket_priority', $prio );
        update_post_meta( $post_id, '_ticket_status', 'open' );
        update_post_meta( $post_id, '_ticket_updated', current_time('mysql') );

        // آپلود فایل (در صورت وجود)
        if ( ! empty( $_FILES['attachment'] ) ) {
            $this->handle_upload( $post_id, $_FILES['attachment'] );
        }

        // ذخیره زمان آخرین تیکت برای کنترل اسپم
        set_transient( 'rp_last_ticket_' . $uid, time(), 60 );

        wp_send_json_success( 'تیکت با موفقیت ثبت شد.' );
    }

    public function handle_reply() {
        $this->check_auth();
        $tid = intval( $_POST['ticket_id'] ?? 0 );
        $msg = sanitize_textarea_field( $_POST['message'] ?? '' );
        $uid = get_current_user_id();

        if ( ! $tid || empty($msg) ) wp_send_json_error( 'پیام خالی است.' );

        // بررسی مالکیت
        $post = get_post( $tid );
        if ( ! $post || $post->post_author != $uid ) wp_send_json_error( 'دسترسی غیرمجاز.' );

        // ثبت پاسخ به عنوان کامنت
        $comment_id = wp_insert_comment([
            'comment_post_ID' => $tid,
            'comment_content' => $msg,
            'user_id'         => $uid,
            'comment_approved'=> 1,
            'comment_type'    => 'ticket_reply'
        ]);

        if ( ! $comment_id ) wp_send_json_error( 'خطا در ثبت پاسخ.' );

        // آپلود فایل
        if ( ! empty( $_FILES['attachment'] ) ) {
            $attach_id = $this->handle_upload( 0, $_FILES['attachment'] ); // 0 چون اتچمنت به کامنت وصل میشه (منطق ساده‌تر: لینک در متن)
            if ( $attach_id ) {
                $url = wp_get_attachment_url( $attach_id );
                $new_content = $msg . "\n\n" . sprintf( '<a href="%s" target="_blank" class="rp-attachment-link">📎 دانلود ضمیمه</a>', $url );
                wp_update_comment([ 'comment_ID' => $comment_id, 'comment_content' => $new_content ]);
            }
        }

        // بروزرسانی وضعیت تیکت
        update_post_meta( $tid, '_ticket_status', 'user_reply' );
        update_post_meta( $tid, '_ticket_updated', current_time('mysql') );

        wp_send_json_success( 'پاسخ ارسال شد.' );
    }

    public function handle_close() {
        $this->check_auth();
        $tid = intval( $_POST['ticket_id'] ?? 0 );
        $uid = get_current_user_id();
        
        $post = get_post( $tid );
        if ( ! $post || $post->post_author != $uid ) wp_send_json_error( 'خطا.' );

        update_post_meta( $tid, '_ticket_status', 'closed' );
        wp_send_json_success( 'تیکت بسته شد.' );
    }

    // --- توابع کمکی ---

    private function check_auth() {
        check_ajax_referer( 'reyhan_auth_nonce', 'security' );
        if ( ! is_user_logged_in() ) wp_send_json_error( 'لطفاً وارد شوید.' );
    }

    private function check_flood_limit() {
        $uid = get_current_user_id();
        if ( get_transient( 'rp_last_ticket_' . $uid ) ) {
            wp_send_json_error( 'لطفاً کمی صبر کنید و مجدد تلاش کنید.' );
        }
    }

    private function handle_upload( $post_id, $file ) {
        if ( empty( $file['name'] ) ) return false;

        // --- اعتبارسنجی امنیتی فایل (سایز/فرمت/محتوا) ---
        $opts = get_option( 'reyhan_options' );

        $max_size_mb = ! empty( $opts['file_max_size'] ) ? floatval( $opts['file_max_size'] ) : 2;
        if ( ! empty( $file['size'] ) && $file['size'] > $max_size_mb * 1024 * 1024 ) {
            return false;
        }

        $file_check = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'] );
        if ( empty( $file_check['ext'] ) || empty( $file_check['type'] ) ) {
            return false;
        }

        $allowed_exts_str = ! empty( $opts['file_allowed_extensions'] ) ? $opts['file_allowed_extensions'] : 'jpg,png,pdf';
        $allowed_array = array_map( 'trim', explode( ',', strtolower( $allowed_exts_str ) ) );

        $blocked_exts = [ 'php','phtml','phar','js','jsx','ts','tsx','exe','sh','bat','cmd','com','cpl','scr','jar','vb','vbs','msi','htaccess','svg','svgz' ];
        $ext_lower = strtolower( (string) $file_check['ext'] );

        if ( in_array( $ext_lower, $blocked_exts, true ) ) {
            return false;
        }

        if ( ! in_array( $ext_lower, $allowed_array, true ) ) {
            return false;
        }

        // --- آپلود به کتابخانه رسانه وردپرس ---
        require_once( ABSPATH . 'wp-admin/includes/image.php' );
        require_once( ABSPATH . 'wp-admin/includes/file.php' );
        require_once( ABSPATH . 'wp-admin/includes/media.php' );

        $attach_id = media_handle_upload( 'attachment', $post_id );
        if ( is_wp_error( $attach_id ) ) return false;

        return $attach_id;
    }
}