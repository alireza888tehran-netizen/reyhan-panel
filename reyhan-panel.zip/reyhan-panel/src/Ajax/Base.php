<?php
namespace ReyhanPanel\Ajax;
if ( ! defined( 'ABSPATH' ) ) { exit; }

abstract class Base {

    protected $prefix = 'reyhan_';

    public function __construct() {
        $this->register_actions();
    }

    abstract protected function register_actions();

    protected function add_ajax_action( $tag, $method, $nopriv = false ) {
        $action_name = $this->prefix . $tag;
        add_action( 'wp_ajax_' . $action_name, [ $this, $method ] );
        if ( $nopriv ) {
            add_action( 'wp_ajax_nopriv_' . $action_name, [ $this, $method ] );
        }
    }

    protected function check_nonce( $action_name = 'reyhan_auth_nonce', $query_arg = 'security' ) {
        if ( ! check_ajax_referer( $action_name, $query_arg, false ) ) {
            $this->send_error( __('خطای امنیتی: درخواست نامعتبر است.', 'reyhan-panel'), 403 );
        }
    }

    protected function send_success( $data = null ) {
        wp_send_json_success( $data );
    }

    protected function send_error( $message, $code = 400 ) {
        wp_send_json_error( $message, $code );
    }

    protected function handle_upload( $file_key ) {
        if ( empty( $_FILES[ $file_key ]['name'] ) ) return false;

        $file = $_FILES[ $file_key ];
        $opts = get_option( 'reyhan_options' );

        $max_size_mb = ! empty( $opts['file_max_size'] ) ? floatval( $opts['file_max_size'] ) : 2;
        if ( $file['size'] > $max_size_mb * 1024 * 1024 ) {
            $this->send_error( sprintf(__('حجم فایل نباید بیشتر از %s مگابایت باشد.', 'reyhan-panel'), $max_size_mb) );
        }

        $file_check = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'] );
        if ( ! $file_check['ext'] || ! $file_check['type'] ) {
             $this->send_error( __('این نوع فایل مجاز نیست (فرمت یا محتوای غیرمجاز).', 'reyhan-panel') );
        }

        $allowed_exts_str = ! empty( $opts['file_allowed_extensions'] ) ? $opts['file_allowed_extensions'] : 'jpg,png,pdf,zip';
        $allowed_array = array_map( 'trim', explode( ',', strtolower( $allowed_exts_str ) ) );
        
        if ( ! in_array( strtolower( $file_check['ext'] ), $allowed_array ) ) {
            $this->send_error( __('فرمت فایل توسط مدیر مسدود شده است.', 'reyhan-panel') );
        }

        if ( ! function_exists( 'wp_handle_upload' ) ) require_once( ABSPATH . 'wp-admin/includes/file.php' );

        $upload_overrides = [ 'test_form' => false ];
        $movefile = wp_handle_upload( $file, $upload_overrides );

        if ( $movefile && ! isset( $movefile['error'] ) ) return $movefile['url']; 
        else $this->send_error( isset( $movefile['error'] ) ? $movefile['error'] : __('خطا در آپلود فایل.', 'reyhan-panel') );

        return false;
    }
}