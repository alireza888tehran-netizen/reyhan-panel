<?php
namespace ReyhanPanel\Admin;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class StandardProfile {

    public function __construct() {
        // هوک‌های نمایش
        add_action( 'show_user_profile', [ $this, 'render_modern_dashboard' ] );
        add_action( 'edit_user_profile', [ $this, 'render_modern_dashboard' ] );

        // هوک‌های ذخیره (مخصوص مدیر)
        add_action( 'personal_options_update', [ $this, 'save_fields_by_admin' ] );
        add_action( 'edit_user_profile_update', [ $this, 'save_fields_by_admin' ] );

        // هوک AJAX برای بررسی تکراری بودن (جدید)
        add_action( 'wp_ajax_rp_check_duplicate_data', [ $this, 'ajax_check_duplicate' ] );
    }

    /**
     * بررسی AJAX تکراری بودن ایمیل یا موبایل
     */
    public function ajax_check_duplicate() {
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'دسترسی غیرمجاز' );
        
        $type = sanitize_text_field( $_POST['type'] ); // 'mobile' or 'email'
        $value = sanitize_text_field( $_POST['value'] );
        $current_user_id = intval( $_POST['user_id'] );

        if ( empty( $value ) ) wp_send_json_success(); // خالی بودن مشکلی ندارد

        $args = [
            'number' => 1,
            'exclude' => [ $current_user_id ], // خود کاربر را نادیده بگیر
            'fields' => ['ID', 'display_name']
        ];

        if ( $type === 'email' ) {
            $args['search'] = $value;
            $args['search_columns'] = ['user_email'];
        } else {
            // برای موبایل باید در متا جستجو کنیم
            $args['meta_query'] = [
                'relation' => 'OR',
                [ 'key' => 'mobile', 'value' => $value, 'compare' => '=' ],
                [ 'key' => 'billing_phone', 'value' => $value, 'compare' => '=' ],
                [ 'key' => 'rp_verified_mobile', 'value' => $value, 'compare' => '=' ]
            ];
        }

        $users = get_users( $args );

        if ( ! empty( $users ) ) {
            $found_user = $users[0];
            wp_send_json_error( sprintf( 'این %s قبلاً برای کاربر <strong>%s</strong> ثبت شده است!', ($type=='email'?'ایمیل':'شماره'), $found_user->display_name ) );
        }

        wp_send_json_success();
    }

    public function render_modern_dashboard( $user ) {
        $phone       = get_user_meta( $user->ID, 'billing_phone', true ) ?: get_user_meta( $user->ID, 'mobile', true );
        $first_name  = $user->first_name;
        $last_name   = $user->last_name;
        $state       = get_user_meta( $user->ID, 'billing_state', true );
        $city        = get_user_meta( $user->ID, 'billing_city', true );
        $address     = get_user_meta( $user->ID, 'billing_address_1', true );
        $postcode    = get_user_meta( $user->ID, 'billing_postcode', true );
        $email       = $user->user_email;

        $is_admin = current_user_can( 'manage_options' );
        
        // آیا مدیر دارد پروفایل خودش را ویرایش می‌کند؟
        $is_editing_self = ( get_current_user_id() === $user->ID );

        wp_nonce_field( 'rp_profile_update', 'rp_profile_nonce_field' );
        $iran_states = $this->get_iran_states();
        ?>
        
        <div class="rp-modern-dashboard" data-user-id="<?php echo esc_attr($user->ID); ?>">
            <div class="rp-dash-header">
                <div class="rp-dash-title">
                    <span class="dashicons dashicons-id-alt"></span>
                    <h3>اطلاعات هویتی و تماس</h3>
                </div>
                <?php if($is_admin): ?><span class="rp-dash-badge">مدیر کل</span><?php endif; ?>
            </div>

            <div class="rp-dash-content">
                <div class="rp-form-row">
                    <div class="rp-field-box">
                        <label>نام</label>
                        <input type="text" name="first_name" value="<?php echo esc_attr($first_name); ?>" class="rp-input" <?php disabled(!$is_admin); ?>>
                    </div>
                    <div class="rp-field-box">
                        <label>نام خانوادگی</label>
                        <input type="text" name="last_name" value="<?php echo esc_attr($last_name); ?>" class="rp-input" <?php disabled(!$is_admin); ?>>
                    </div>
                </div>

                <div class="rp-form-row">
                    <div class="rp-field-box highlight">
                        <label>شماره موبایل</label>
                        <div class="rp-rel-wrapper">
                            <?php if($is_admin): ?>
                                <input type="text" name="billing_phone" value="<?php echo esc_attr($phone); ?>" class="rp-input rp-check-duplicate" data-type="mobile" placeholder="09xxxxxxxxx">
                                <div class="rp-validation-msg"></div> <?php else: ?>
                                <input type="text" value="<?php echo esc_attr($phone); ?>" class="rp-input disabled" disabled>
                                <button type="button" class="rp-btn-trigger-otp" data-type="mobile">تغییر</button>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="rp-field-box highlight">
                        <label>ایمیل کاربری (Login)</label>
                        <div class="rp-rel-wrapper">
                            <?php if ( $is_admin && ! $is_editing_self ): ?>
                                <input type="email" name="user_email" value="<?php echo esc_attr($email); ?>" class="rp-input rp-check-duplicate" data-type="email">
                                <div class="rp-validation-msg"></div>
                            
                            <?php elseif ( $is_admin && $is_editing_self ): ?>
                                <input type="text" value="<?php echo esc_attr($email); ?>" class="rp-input disabled" disabled title="برای تغییر ایمیل لاگین خود، از بخش تنظیمات وردپرس اقدام کنید">
                                <small style="color:#d32f2f; font-size:11px; margin-top:4px;">
                                    <span class="dashicons dashicons-lock" style="font-size:12px;width:12px;height:12px;"></span>
                                    ایمیل لاگین خودتان را از اینجا تغییر ندهید (باعث خروج می‌شود).
                                </small>
                            <?php else: ?>
                                <input type="text" value="<?php echo esc_attr($email); ?>" class="rp-input disabled" disabled>
                                <button type="button" class="rp-btn-trigger-otp" data-type="email">تغییر</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="rp-form-row">
                    <div class="rp-field-box">
                        <label>استان</label>
                        <select name="billing_state" id="rp_admin_state" class="rp-input rp-select2" <?php disabled(!$is_admin); ?>>
                            <option value="">انتخاب استان...</option>
                            <?php foreach($iran_states as $key => $label): ?>
                                <option value="<?php echo esc_attr($key); ?>" <?php selected($state, $key); ?>><?php echo esc_html($label); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="rp-field-box">
                        <label>شهر</label>
                        <select name="billing_city" id="rp_admin_city" class="rp-input rp-select2" <?php disabled(!$is_admin); ?> data-default="<?php echo esc_attr($city); ?>">
                            <option value="">انتخاب شهر...</option>
                        </select>
                    </div>
                </div>

                <div class="rp-form-row">
                    <div class="rp-field-box" style="flex:2;">
                        <label>آدرس پستی</label>
                        <input type="text" name="billing_address_1" value="<?php echo esc_attr($address); ?>" class="rp-input" <?php disabled(!$is_admin); ?>>
                    </div>
                    <div class="rp-field-box" style="flex:1;">
                        <label>کد پستی</label>
                        <input type="text" name="billing_postcode" value="<?php echo esc_attr($postcode); ?>" class="rp-input" <?php disabled(!$is_admin); ?>>
                    </div>
                </div>
            </div>

            <div id="rp-otp-modal-wrap" style="display:none;"><div class="rp-otp-overlay"></div><div class="rp-otp-card"><div class="rp-otp-head"><h4>تغییر اطلاعات</h4><span class="rp-close-modal dashicons dashicons-no-alt"></span></div><div class="rp-otp-main"><div id="rp-step-1"><p>مقدار جدید:</p><input type="text" id="rp-new-value-input" class="rp-big-input"><button type="button" id="rp-send-otp-ajax" class="rp-primary-btn">ارسال کد</button></div><div id="rp-step-2" style="display:none;"><p>کد تایید:</p><input type="text" id="rp-otp-code-input" class="rp-big-input"><button type="button" id="rp-verify-otp-ajax" class="rp-primary-btn">تایید</button></div></div></div></div>
        </div>
        <?php
    }

    public function save_fields_by_admin( $user_id ) {
        if ( ! current_user_can( 'manage_options' ) ) return;
        if ( ! isset( $_POST['rp_profile_nonce_field'] ) || ! wp_verify_nonce( $_POST['rp_profile_nonce_field'], 'rp_profile_update' ) ) return;

        $fields = ['billing_phone', 'billing_state', 'billing_city', 'billing_address_1', 'billing_postcode', 'first_name', 'last_name'];
        foreach ( $fields as $field ) {
            if ( isset( $_POST[$field] ) ) update_user_meta( $user_id, $field, sanitize_text_field( $_POST[$field] ) );
        }
        
        // فقط اگر کاربر "خودش" نبود، ایمیل را آپدیت کن
        if ( isset( $_POST['user_email'] ) && get_current_user_id() !== $user_id ) {
            $email = sanitize_email( $_POST['user_email'] );
            if ( is_email( $email ) ) wp_update_user([ 'ID' => $user_id, 'user_email' => $email ]);
        }
    }

    private function get_iran_states() {
        return [ 'Alborz'=>'البرز', 'Ardabil'=>'اردبیل', 'Bushehr'=>'بوشهر', 'Chaharmahal and Bakhtiari'=>'چهارمحال و بختیاری', 'East Azerbaijan'=>'آذربایجان شرقی', 'Fars'=>'فارس', 'Gilan'=>'گیلان', 'Golestan'=>'گلستان', 'Hamadan'=>'همدان', 'Hormozgan'=>'هرمزگان', 'Ilam'=>'ایلام', 'Isfahan'=>'اصفهان', 'Kerman'=>'کرمان', 'Kermanshah'=>'کرمانشاه', 'Khuzestan'=>'خوزستان', 'Kohgiluyeh and Boyer-Ahmad'=>'کهگیلویه و بویراحمد', 'Kurdistan'=>'کردستان', 'Lorestan'=>'لرستان', 'Markazi'=>'مرکزی', 'Mazandaran'=>'مازندران', 'North Khorasan'=>'خراسان شمالی', 'Qazvin'=>'قزوین', 'Qom'=>'قم', 'Razavi Khorasan'=>'خراسان رضوی', 'Semnan'=>'سمنان', 'Sistan and Baluchestan'=>'سیستان و بلوچستان', 'South Khorasan'=>'خراسان جنوبی', 'Tehran'=>'تهران', 'West Azerbaijan'=>'آذربایجان غربی', 'Yazd'=>'یزد', 'Zanjan'=>'زنجان' ];
    }
}