<?php
namespace ReyhanPanel\Admin;

use ReyhanPanel\Core\License;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Wizard {

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'register_wizard_page' ) );
        add_action( 'admin_init', array( $this, 'redirect_to_wizard' ) );
        
        // هندلرهای ایجکس
        add_action( 'wp_ajax_reyhan_wizard_save', array( $this, 'save_wizard_data' ) );
        add_action( 'wp_ajax_reyhan_check_license_wizard', array( $this, 'handle_license_check' ) );
        
        if ( isset( $_GET['page'] ) && $_GET['page'] == 'reyhan-setup' ) {
            add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_wizard_assets' ) );
        }
    }

    public function register_wizard_page() {
        add_dashboard_page(
            __( 'راه‌اندازی ریحان پنل', 'reyhan-panel' ),
            __( 'راه‌اندازی ریحان پنل', 'reyhan-panel' ),
            'manage_options',
            'reyhan-setup',
            array( $this, 'render_wizard' )
        );
    }

    public function redirect_to_wizard() {
        if ( get_option( 'reyhan_do_activation_redirect', false ) ) {
            delete_option( 'reyhan_do_activation_redirect' );
            if ( ! isset( $_GET['activate-multi'] ) ) {
                wp_safe_redirect( admin_url( 'index.php?page=reyhan-setup' ) );
                exit;
            }
        }
    }

    public function render_wizard() {
        wp_enqueue_media();
        // بخش استایل‌های اینلاین فونت حذف شد چون اکنون توسط admin-core.css بارگذاری می‌شوند
        ?>
        <style>
            /* تنظیم فونت پیش‌فرض برای ویزارد با استفاده از نام فونت‌های تعریف شده در Core */
            body, .rw-wrapper { font-family: 'ReyhanFont', Tahoma, sans-serif; }
            #btn-next { display: none; }
        </style>
        <?php
        include REYHAN_DIR . 'templates/admin/view-wizard.php';
    }

    public function enqueue_wizard_assets() {
        wp_enqueue_style( 'reyhan-wizard-css', REYHAN_URL . 'assets/css/wizard.css', ['rp-admin-core'], '1.0' );
        wp_enqueue_script( 'reyhan-wizard-js', REYHAN_URL . 'assets/js/admin/wizard.js', [ 'jquery' ], '1.0', true );
        
        $is_license_active = License::is_active();

        wp_localize_script( 'reyhan-wizard-js', 'reyhan_wizard_obj', [
            'ajax_url'       => admin_url( 'admin-ajax.php' ),
            'nonce'          => wp_create_nonce( 'reyhan_wizard_nonce' ),
            'license_status' => $is_license_active
        ]);
    }

    public function handle_license_check() {
        if ( ! check_ajax_referer( 'reyhan_wizard_nonce', 'security', false ) ) {
             wp_send_json_error( __( 'نشست امنیتی منقضی شده است.', 'reyhan-panel' ) );
        }


        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( __( 'دسترسی ندارید.', 'reyhan-panel' ) );
        }

        $license = sanitize_text_field( $_POST['license'] ?? '' );
        if ( License::activate_license( $license ) ) {
            wp_send_json_success( __( 'لایسنس فعال شد.', 'reyhan-panel' ) );
        } else {
            wp_send_json_error( __( 'کد نامعتبر است.', 'reyhan-panel' ) );
        }
    }

    /**
     * متد ذخیره ویزارد - نسخه نهایی و هماهنگ با تنظیمات
     */
    public function save_wizard_data() {
        if ( ! check_ajax_referer( 'reyhan_wizard_nonce', 'security', false ) ) {
            wp_send_json_error( __( 'خطای امنیتی.', 'reyhan-panel' ) );
        }
        
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( __( 'دسترسی ندارید.', 'reyhan-panel' ) );
        }

        // دریافت تنظیمات موجود
        $opts = get_option( 'reyhan_options', [] );
        if ( ! is_array( $opts ) ) {
            $opts = [];
        }

        // --- بخش حیاتی: ساخت برگه و هماهنگ‌سازی ---
        if ( isset( $_POST['create_page'] ) && $_POST['create_page'] === '1' ) {
            
            $target_page_id = 0;

            // 1. بررسی: آیا برگه‌ای با اسلاگ 'login' از قبل وجود دارد؟
            $query = new \WP_Query([
                'pagename' => 'login',
                'post_type' => 'page',
                'post_status' => 'publish'
            ]);

            if ( $query->have_posts() ) {
                $target_page_id = $query->posts[0]->ID;
            } else {
                // 2. اگر وجود نداشت، بساز
                $new_id = wp_insert_post([
                    'post_title'     => __('پنل کاربری', 'reyhan-panel'),
                    'post_name'      => 'login',
                    'post_content'   => '[reyhan_panel]',
                    'post_status'    => 'publish',
                    'post_type'      => 'page',
                    'comment_status' => 'closed',
                    'ping_status'    => 'closed'
                ]);

                if ( ! is_wp_error( $new_id ) && $new_id > 0 ) {
                    $target_page_id = $new_id;
                }
            }

            // 3. اعمال تنظیمات
            if ( $target_page_id > 0 ) {
                $opts['login_page_id'] = $target_page_id;
                $opts['exclusive_login_active'] = '1';

                if ( function_exists('WC') ) {
                    update_option( 'woocommerce_myaccount_page_id', $target_page_id );
                }
            }
        }

        // ذخیره سایر فیلدها
        if ( isset( $_POST['login_title'] ) ) {
            $opts['login_title'] = sanitize_text_field( $_POST['login_title'] );
        }
        
        if ( isset( $_POST['login_logo'] ) ) {
            $opts['login_logo'] = sanitize_text_field( $_POST['login_logo'] );
        }

        // ذخیره نهایی در دیتابیس
        update_option( 'reyhan_options', $opts );

        wp_send_json_success( __( 'تنظیمات با موفقیت اعمال شد.', 'reyhan-panel' ) );
    }
}