<?php
namespace ReyhanPanel\Admin;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class MenuManager {

    private $settings_obj;

    public function __construct( $settings_instance ) {
        $this->settings_obj = $settings_instance;

        add_action( 'admin_menu', [ $this, 'add_admin_menus' ] );
        add_action( 'admin_menu', [ $this, 'cleanup_menus_for_pure_agents' ], 999 );
        
        // --- حذف شد: دکمه پشتیبانی از نوار ابزار بالا ---
        // add_action( 'admin_bar_menu', [ $this, 'add_agent_toolbar_items' ], 100 );
        
        add_action( 'init', [ $this, 'force_show_admin_bar_for_agents' ] );
        add_action( 'admin_init', [ $this, 'redirect_pure_agent_dashboard' ] );
        add_action( 'template_redirect', [ $this, 'redirect_woocommerce_to_reyhan' ] );
        add_action( 'current_screen', [ $this, 'prevent_unauthorized_access' ] );
        add_filter( 'woocommerce_prevent_admin_access', [ $this, 'allow_agent_admin_access' ] );
    }

    public function is_support_agent() {
        if ( ! is_user_logged_in() ) return false;
        $uid = get_current_user_id();
        
        $agents_raw = get_option('reyhan_heavy_ticket_support_agents_data');
        if ( ! $agents_raw ) {
            $opts = get_option('reyhan_options');
            $agents_raw = $opts['ticket_support_agents_data'] ?? '[]';
        }
        $agents_data = is_string($agents_raw) ? json_decode($agents_raw, true) : $agents_raw;
        
        if ( is_array($agents_data) ) {
            foreach ( $agents_data as $agent ) {
                if ( isset($agent['id']) && intval($agent['id']) === intval($uid) ) return true;
            }
        }
        return false;
    }

    /**
     * بررسی اینکه آیا کاربر نقش مدیریتی دیگری (مثل نویسنده) دارد؟
     * اگر این تابع true باشد، یعنی نباید دسترسی‌هایش را محدود کنیم.
     */
    public function has_other_admin_roles() {
        return ( current_user_can('edit_posts') || current_user_can('upload_files') || current_user_can('edit_products') );
    }

    public function add_admin_menus() {
        $is_super_admin = current_user_can('manage_options');
        $is_agent = $this->is_support_agent();

        if ( $is_super_admin ) {
            add_menu_page(__('تنظیمات ریحان پنل', 'reyhan-panel'), __('ریحان پنل', 'reyhan-panel'), 'manage_options', 'reyhan-settings', [ $this->settings_obj, 'render_general_page' ], \REYHAN_URL . 'assets/images/icon-panel.svg', 50);
            add_submenu_page('reyhan-settings', __('تنظیمات عمومی', 'reyhan-panel'), __('تنظیمات عمومی', 'reyhan-panel'), 'manage_options', 'reyhan-settings', [ $this->settings_obj, 'render_general_page' ]);
            add_submenu_page('reyhan-settings', __('استایل پنل کاربری', 'reyhan-panel'), __('استایل پنل کاربری', 'reyhan-panel'), 'manage_options', 'reyhan-user-panel', [ $this->settings_obj, 'render_user_panel_page' ]);
            add_submenu_page('reyhan-settings', __('اطلاعیه پنل کاربری', 'reyhan-panel'), __('اطلاعیه پنل کاربری', 'reyhan-panel'), 'manage_options', 'reyhan-notifications', [ $this->settings_obj, 'render_notifications_page' ]);
            add_menu_page(__('مدیریت تیکت‌ها', 'reyhan-panel'), __('تیکت ها', 'reyhan-panel'), 'manage_options', 'reyhan-tickets', [ $this->settings_obj, 'render_tickets_manager' ], \REYHAN_URL . 'assets/images/icon-ticket.svg', 51);
        }
        else if ( $is_agent ) {
            // منوی تیکت برای ایجنت اضافه می‌شود (بدون حذف بقیه منوها)
            add_menu_page(__('پنل پشتیبان', 'reyhan-panel'), __('پشتیبانی', 'reyhan-panel'), 'read', 'reyhan-agent-panel', [ $this->settings_obj, 'render_tickets_manager' ], \REYHAN_URL . 'assets/images/icon-agent.svg', 50);
            add_submenu_page('reyhan-agent-panel', __('تیکت‌های من', 'reyhan-panel'), __('تیکت‌های من', 'reyhan-panel'), 'read', 'reyhan-tickets', [ $this->settings_obj, 'render_tickets_manager' ]);
            add_submenu_page('reyhan-agent-panel', __('پروفایل', 'reyhan-panel'), __('پروفایل', 'reyhan-panel'), 'read', 'reyhan-agent-profile', [ $this->settings_obj, 'render_agent_profile_page' ]);
            remove_submenu_page('reyhan-agent-panel', 'reyhan-agent-panel');
        }
    }

    public function cleanup_menus_for_pure_agents() {
        if ( ! is_user_logged_in() || current_user_can('manage_options') ) return;

        // شرط مهم: ایجنت باشد + نقش دیگری نداشته باشد
        if ( $this->is_support_agent() && ! $this->has_other_admin_roles() ) {
            remove_menu_page( 'index.php' );
            remove_menu_page( 'profile.php' );
            remove_menu_page( 'edit.php' ); 
            remove_menu_page( 'upload.php' );
            remove_menu_page( 'woocommerce' );
            remove_menu_page( 'wc-admin' );
        }
        
        if ( ! current_user_can('manage_options') ) {
            remove_menu_page( 'reyhan-settings' );
        }
    }

    public function prevent_unauthorized_access() {
        $screen = get_current_screen();
        if ( ! $screen ) return;

        // محافظت فقط از تیکت‌ها
        if ( $screen->post_type === 'ticket' ) {
            $is_admin = current_user_can('manage_options');
            $is_agent = $this->is_support_agent();
            if ( ! $is_admin && ! $is_agent ) {
                wp_die('<h1>دسترسی غیرمجاز</h1><p>شما مجوز دسترسی به تیکت‌ها را ندارید.</p>', 'Access Denied', ['response' => 403, 'back_link' => true]);
            }
        }
    }

    public function force_show_admin_bar_for_agents() {
        // نوار ابزار را برای ایجنت‌ها فعال کن (حتی اگر کاربر عادی باشند)
        if ( $this->is_support_agent() ) {
            add_filter( 'show_admin_bar', '__return_true', 999 );
        }
    }

    /* public function add_agent_toolbar_items( $wp_admin_bar ) {
        // این تابع غیرفعال شده است تا آیتم پشتیبانی در نوار بالا نمایش داده نشود.
        if ( ! $this->is_support_agent() ) return;
        $wp_admin_bar->add_node([
            'id'    => 'rp-toolbar-tickets',
            'title' => '<span class="ab-icon dashicons dashicons-email-alt"></span> ' . __('پشتیبانی', 'reyhan-panel'),
            'href'  => admin_url( 'admin.php?page=reyhan-tickets' )
        ]);
    }
    */

    public function redirect_pure_agent_dashboard() {
        global $pagenow;
        // ریدایرکت فقط برای کسانی که نقش دیگری ندارند
        if ( $this->is_support_agent() && ! current_user_can('manage_options') && ! $this->has_other_admin_roles() ) {
            if ( $pagenow == 'index.php' ) {
                wp_redirect( admin_url( 'admin.php?page=reyhan-tickets' ) );
                exit;
            }
        }
    }

    public function redirect_woocommerce_to_reyhan() {
        if ( class_exists('WooCommerce') && is_account_page() ) {
            $opts = get_option('reyhan_options');
            $panel_page_id = $opts['login_page_id'] ?? 0;
            if ( $panel_page_id && ! is_page($panel_page_id) ) { wp_redirect( get_permalink($panel_page_id) ); exit; }
        }
    }

    public function allow_agent_admin_access( $prevent_access ) {
        if ( $this->is_support_agent() ) return false; 
        return $prevent_access;
    }
}