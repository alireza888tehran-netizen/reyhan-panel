<?php
namespace ReyhanPanel\Admin;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Settings {

    private $options;
    private $renderer;
    private $menu_manager;
    private $profile_manager;

    public function __construct() {
        $this->renderer = new FieldRenderer(); 
        $this->menu_manager = new MenuManager( $this ); 
        
        if ( class_exists( 'ReyhanPanel\Admin\ProfileManager' ) ) {
            $this->profile_manager = new ProfileManager();
        }

        add_action( 'admin_init', [ $this, 'register_settings' ] );
        add_filter( 'admin_body_class', [ $this, 'add_font_body_class' ] ); 
        add_action( 'wp_ajax_reyhan_create_login_page_ajax', [ $this, 'handle_ajax_create_page' ] );
        add_action( 'admin_init', [ $this, 'handle_create_page_action' ] );
    }

    public function load_wp_assets( $hook ) {
        if ( strpos( $hook, 'reyhan' ) === false ) return;

        wp_enqueue_media();
        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_script( 'wp-color-picker' );
        wp_enqueue_script( 'jquery-ui-sortable' );
        
        wp_enqueue_style( 'reyhan-admin-css', \REYHAN_URL . 'assets/css/admin.css', [], \REYHAN_VERSION );
        wp_enqueue_script( 'reyhan-admin-js', \REYHAN_URL . 'assets/js/admin/core.js', ['jquery', 'wp-color-picker', 'jquery-ui-sortable'], \REYHAN_VERSION, true );

        $uid = get_current_user_id();
        $personal_canned = get_user_meta($uid, 'rp_user_canned_responses', true);
        
        // ارسال داده‌ها به جاوااسکریپت
        wp_localize_script( 'reyhan-admin-js', 'reyhan_admin_ajax', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'reyhan_admin_nonce' ),
            'canned_responses' => !empty($personal_canned) ? array_values($personal_canned) : [],
            'default_avatar'   => \REYHAN_URL . 'assets/images/user.png' // <--- خط جدید: آدرس تصویر پیش‌فرض
        ]);
    }

    public function add_font_body_class( $classes ) {
        $opts = get_option('reyhan_options');
        $font = $opts['plugin_selected_font'] ?? 'yekan';
        $classes .= ' rp-font-' . esc_attr($font);
        return $classes;
    }

    public function register_settings() {
        register_setting('reyhan_master_group', 'reyhan_options', ['sanitize_callback' => [$this, 'sanitize_options']]);

        // --- بخش ورود و ثبت نام ---
        add_settings_section('sec_login', '', null, 'reyhan-general');
        add_settings_field('login_sec_general', '', [$this->renderer,'section_title'], 'reyhan-general', 'sec_login', ['title'=>__('مدیریت دسترسی', 'reyhan-panel'), 'desc'=>__('تنظیمات صفحه ورود و ثبت نام', 'reyhan-panel')]);
        
        add_settings_field('exclusive_login_active', __('ورود اختصاصی', 'reyhan-panel'), [$this->renderer, 'checkbox_toggle_wrapper'], 'reyhan-general', 'sec_login', ['id'=>'exclusive_login_active', 'label'=>__('فعالسازی حالت ورود کاملاً اختصاصی', 'reyhan-panel'), 'desc'=>__('با فعالسازی این گزینه، تمامی ورودها به پنل اختصاصی هدایت می‌شوند.', 'reyhan-panel'), 'wrapper_id'=>'wrap_exclusive_desc']);
        add_settings_field('login_page_manager', __('برگه پنل کاربری', 'reyhan-panel'), [$this, 'login_page_manager_render'], 'reyhan-general', 'sec_login'); 
        add_settings_field('auth_method', __('روش ورود و عضویت', 'reyhan-panel'), [$this->renderer,'select_auth'], 'reyhan-general', 'sec_login', ['id'=>'auth_method']);

        add_settings_field(
            'force_profile_completion', 
            __('تکمیل اجباری پروفایل', 'reyhan-panel'), 
            [$this->renderer, 'render_force_profile_completion'], // <--- تغییر مهم: فراخوانی تابع اختصاصی
            'reyhan-general', 
            'sec_login', 
            [
                'id' => 'force_profile_completion',
                'label' => __('فعالسازی دریافت اجباری اطلاعات', 'reyhan-panel'),
                'wrapper_id' => 'wrap_force_completion',
                // دیگر نیازی به ارسال desc نیست چون در رندرکننده تعریف شده است
            ]
        );

        add_settings_field('terms_page_id', __('برگه قوانین و مقررات', 'reyhan-panel'), [$this->renderer,'select_page'], 'reyhan-general', 'sec_login', ['id'=>'terms_page_id', 'desc'=>__('نمایش چک‌باکس قوانین در فرم ثبت نام', 'reyhan-panel')]);
        add_settings_field('login_sec_red', '', [$this->renderer,'section_title'], 'reyhan-general', 'sec_login', ['title'=>__('تغییر مسیرها (Redirect)', 'reyhan-panel'), 'desc'=>__('رفتار سیستم پس از ورود و خروج', 'reyhan-panel')]);
        add_settings_field('login_redirect_url', __('لینک بعد از ورود', 'reyhan-panel'), [$this->renderer,'text'], 'reyhan-general', 'sec_login', ['id'=>'login_redirect_url', 'desc'=>__('کاربر بعد از ورود به سایت به این آدرس منتقل میشود', 'reyhan-panel')]);
        add_settings_field('logout_redirect_url', __('لینک بعد از خروج', 'reyhan-panel'), [$this->renderer,'text'], 'reyhan-general', 'sec_login', ['id'=>'logout_redirect_url', 'desc'=>__('کاربر بعد خروج از پنل کاربری به این آدرس منتقل میشود', 'reyhan-panel')]);

        // --- بخش پیامک ---
        add_settings_section('sec_sms', '', null, 'reyhan-general');
        add_settings_field('sms_sec_gateway', '', [$this->renderer,'section_title'], 'reyhan-general', 'sec_sms', ['title'=>__('درگاه پیامکی', 'reyhan-panel'), 'desc'=>__('اتصال به پنل SMS', 'reyhan-panel')]);
        add_settings_field('sms_provider', __('سامانه پیامکی', 'reyhan-panel'), [$this->renderer,'select_provider'], 'reyhan-general', 'sec_sms');
        add_settings_field('sms_apikey', __('کلید دسترسی (API Key)', 'reyhan-panel'), [$this->renderer,'text'], 'reyhan-general', 'sec_sms', ['id'=>'sms_apikey']);
        add_settings_field('sms_username', __('نام کاربری سامانه', 'reyhan-panel'), [$this->renderer,'text'], 'reyhan-general', 'sec_sms', ['id'=>'sms_username']);
        add_settings_field('sms_password', __('رمز عبور سامانه', 'reyhan-panel'), [$this->renderer,'text'], 'reyhan-general', 'sec_sms', ['id'=>'sms_password']);
        add_settings_field('sms_from', __('شماره فرستنده', 'reyhan-panel'), [$this->renderer,'text'], 'reyhan-general', 'sec_sms', ['id'=>'sms_from']);
        add_settings_field('sms_sec_global', '', [$this->renderer,'section_title'], 'reyhan-general', 'sec_sms', ['title'=>__('ارسال سراسری', 'reyhan-panel'), 'desc'=>__('تنظیمات الگوی پیامک‌های عمومی', 'reyhan-panel')]);
        add_settings_field('sms_global_config', __('تنظیمات ارسال', 'reyhan-panel'), [$this->renderer,'global_sms_integrated'], 'reyhan-general', 'sec_sms');
        add_action( 'wp_ajax_reyhan_check_sms_credit', [ '\ReyhanPanel\Services\SMS', 'check_credit_ajax' ] );
        
        // --- بخش ایمیل ---
        add_settings_section('sec_email', '', null, 'reyhan-general');
        add_settings_field('email_sec_sender', '', [$this->renderer,'section_title'], 'reyhan-general', 'sec_email', ['title'=>__('فرستنده ایمیل', 'reyhan-panel'), 'desc'=>__('مشخصات ظاهری ایمیل‌های ارسالی', 'reyhan-panel')]);
        add_settings_field('email_from_name', __('نام فرستنده', 'reyhan-panel'), [$this->renderer,'text'], 'reyhan-general', 'sec_email', ['id'=>'email_from_name']);

// 1. محاسبه دامنه برای نمایش در مثال‌ها
        $site_domain = ( isset($_SERVER['SERVER_NAME']) ) ? preg_replace('/^www\./', '', $_SERVER['SERVER_NAME']) : 'yoursite.com';

        // 2. تعریف کد HTML باکس راهنمای زرد
        $email_guide_html = '
        <div class="rp-guide-box">
            <div class="rp-guide-title">
                <span class="dashicons dashicons-warning"></span> نکته مهم (جلوگیری از اسپم)
            </div>
            <p>برای اینکه ایمیل‌های ارسالی شما به پوشه اسپم (Spam) کاربر نرود، حتماً از ایمیلی استفاده کنید که متعلق به دامنه همین سایت باشد.</p>
            <div class="rp-var-list">
                <div class="rp-var-item"><span>مثال صحیح:</span> <span class="rp-var-code">info@' . $site_domain . '</span></div>
                <div class="rp-var-item"><span>مثال دیگر:</span> <span class="rp-var-code">noreply@' . $site_domain . '</span></div>
            </div>
        </div>';

        // 3. تعریف فیلد و ارسال باکس راهنما به عنوان توضیحات (desc)
        add_settings_field(
            'email_from_address', 
            __('ایمیل فرستنده', 'reyhan-panel'), 
            [$this->renderer, 'text'], 
            'reyhan-general', 
            'sec_email', 
            [
                'id' => 'email_from_address', 
                'desc' => $email_guide_html // ارسال HTML به رندر کننده
            ]
        );


        add_settings_field('email_sec_events', '', [$this->renderer,'section_title'], 'reyhan-general', 'sec_email', ['title'=>__('اطلاع‌رسانی‌ها', 'reyhan-panel'), 'desc'=>__('ایمیل‌های خودکار سیستم', 'reyhan-panel')]);
        add_settings_field('email_user_reg_active', __('ایمیل خوش‌آمدگویی کاربر', 'reyhan-panel'), [$this->renderer, 'checkbox_toggle_wrapper'], 'reyhan-general', 'sec_email', ['id'=>'email_user_reg_active', 'label'=>__('فعالسازی', 'reyhan-panel'), 'wrapper_id'=>'wrap_email_user_reg']);
        add_settings_field('email_user_reg_fields', '', [$this->renderer, 'render_email_welcome_user'], 'reyhan-general', 'sec_email', []);
        add_settings_field('email_admin_reg_active', __('ایمیل اطلاع‌رسانی مدیر', 'reyhan-panel'), [$this->renderer, 'checkbox_toggle_wrapper'], 'reyhan-general', 'sec_email', ['id'=>'email_admin_reg_active', 'label'=>__('فعالسازی', 'reyhan-panel'), 'wrapper_id'=>'wrap_email_admin_reg']);
        add_settings_field('email_admin_reg_fields', '', [$this->renderer, 'render_email_notify_admin'], 'reyhan-general', 'sec_email', []);

        // --- بخش تیکت ---
        add_settings_section('sec_ticket', '', null, 'reyhan-general');
        add_settings_field('ticket_sec_agents', '', [$this->renderer,'section_title'], 'reyhan-general', 'sec_ticket', ['title'=>__('تنظیمات پاسخگویی مدیر', 'reyhan-panel'), 'desc'=>__('تنظیماتی که فقط برای مدیر تنظیم میشوند', 'reyhan-panel')]);
        add_settings_field('ticket_support_name', __('نام و نام خانوادگی', 'reyhan-panel'), [$this->renderer,'text'], 'reyhan-general', 'sec_ticket', ['id'=>'ticket_support_name']);
        
        add_settings_field(
            'ticket_support_avatar', 
            __('تصویر پروفایل', 'reyhan-panel'), 
            [$this->renderer, 'media_upload'], 
            'reyhan-general', 
            'sec_ticket', 
            [
                'id' => 'ticket_support_avatar',
                'title' => __('تصویر پروفایل مدیر', 'reyhan-panel'), // عنوان صحیح باکس
                // ادغام توضیحات هر دو بخش برای کامل بودن راهنما
                'desc' => __('این تصویر در هدر تیکت به کاربر نمایش داده می‌شود.<br><span style="color:#d63638; font-size:11px;">فقط فرمت‌های JPG, PNG, WEBP مجاز هستند.</span>', 'reyhan-panel')
            ]
        );

        add_settings_field('ticket_canned_personal', __('پاسخ‌های آماده (شخصی)', 'reyhan-panel'), [$this->renderer,'canned_responses_personal'], 'reyhan-general', 'sec_ticket', ['id'=>'rp_user_canned_responses', 'btn_text'=>__('افزودن پاسخ', 'reyhan-panel'), 'fields'=>['title'=>__('عنوان', 'reyhan-panel'), 'content'=>__('متن', 'reyhan-panel')]]);
        add_settings_field('ticket_support_agents', __('کارشناسان پاسخگو', 'reyhan-panel'), [$this->renderer,'user_search_manager'], 'reyhan-general', 'sec_ticket', ['id'=>'ticket_support_agents']);
        add_settings_field('ticket_sec_notif', '', [$this->renderer,'section_title'], 'reyhan-general', 'sec_ticket', ['title'=>__('اطلاع‌رسانی تیکت به کاربر', 'reyhan-panel'), 'desc'=>__('تنظیمات ایمیل و پیامک وضعیت تیکت', 'reyhan-panel')]);
        add_settings_field('ticket_email_submit_active', __('ایمیل ثبت تیکت', 'reyhan-panel'), [$this->renderer, 'checkbox_toggle_wrapper'], 'reyhan-general', 'sec_ticket', ['id'=>'ticket_email_submit_active', 'label'=>__('فعالسازی', 'reyhan-panel'), 'wrapper_id'=>'wrap_ticket_email_submit']);
        add_settings_field('ticket_email_submit_fields', '', [$this->renderer, 'render_ticket_email_submit'], 'reyhan-general', 'sec_ticket', []);
        add_settings_field('ticket_email_reply_active', __('ایمیل پاسخ تیکت', 'reyhan-panel'), [$this->renderer, 'checkbox_toggle_wrapper'], 'reyhan-general', 'sec_ticket', ['id'=>'ticket_email_reply_active', 'label'=>__('فعالسازی', 'reyhan-panel'), 'wrapper_id'=>'wrap_ticket_email_reply']);
        add_settings_field('ticket_email_reply_fields', '', [$this->renderer, 'render_ticket_email_reply'], 'reyhan-general', 'sec_ticket', []);
        add_settings_field('ticket_sms_submit_active', __('پیامک ثبت تیکت', 'reyhan-panel'), [$this->renderer, 'checkbox_toggle_wrapper'], 'reyhan-general', 'sec_ticket', ['id'=>'ticket_sms_submit_active', 'label'=>__('فعالسازی', 'reyhan-panel'), 'wrapper_id'=>'wrap_ticket_sms_submit']);
        add_settings_field('ticket_sms_submit_fields', '', [$this->renderer, 'render_ticket_sms_submit'], 'reyhan-general', 'sec_ticket', []);
        add_settings_field('ticket_sms_reply_active', __('پیامک پاسخ تیکت', 'reyhan-panel'), [$this->renderer, 'checkbox_toggle_wrapper'], 'reyhan-general', 'sec_ticket', ['id'=>'ticket_sms_reply_active', 'label'=>__('فعالسازی', 'reyhan-panel'), 'wrapper_id'=>'wrap_ticket_sms_reply']);
        add_settings_field('ticket_sms_reply_fields', '', [$this->renderer, 'render_ticket_sms_reply'], 'reyhan-general', 'sec_ticket', []);
        add_settings_field('ticket_sec_data', '', [$this->renderer,'section_title'], 'reyhan-general', 'sec_ticket', ['title'=>__('داده‌های تیکت', 'reyhan-panel'), 'desc'=>__('مدیریت محتوای فرم تیکت', 'reyhan-panel')]);
        add_settings_field('ticket_departments', __('دپارتمان‌ها', 'reyhan-panel'), [$this->renderer,'repeater_general'], 'reyhan-general', 'sec_ticket', ['id'=>'ticket_departments', 'btn_text'=>__('افزودن', 'reyhan-panel'), 'fields'=>['name'=>__('نام دپارتمان', 'reyhan-panel')]]);
        add_settings_field('ticket_faqs', __('سوالات متداول', 'reyhan-panel'), [$this->renderer,'repeater_general'], 'reyhan-general', 'sec_ticket', ['id'=>'ticket_faqs', 'btn_text'=>__('افزودن سوال', 'reyhan-panel'), 'fields'=>['q'=>__('سوال', 'reyhan-panel'), 'a'=>__('پاسخ', 'reyhan-panel')]]);
        add_settings_field('ticket_signatures', __('قالب‌بندی پاسخ‌ها', 'reyhan-panel'), [$this->renderer,'ticket_signatures'], 'reyhan-general', 'sec_ticket');

        // --- بخش امنیت ---
        add_settings_section('sec_security', '', null, 'reyhan-general');
        add_settings_field('sec_title_login', '', [$this->renderer,'section_title'], 'reyhan-general', 'sec_security', ['title'=>__('محدودیت تلاش ورود', 'reyhan-panel'), 'desc'=>__('جلوگیری از حملات Brute Force', 'reyhan-panel')]);
        add_settings_field('recaptcha_active', __('گوگل ریکپچا (v3)', 'reyhan-panel'), [$this->renderer,'checkbox_toggle_wrapper'], 'reyhan-general', 'sec_security', ['id'=>'recaptcha_active', 'label'=>__('فعال‌سازی جلوگیری از ربات', 'reyhan-panel'), 'wrapper_id'=>'wrap_recaptcha']);
        add_settings_field('recaptcha_keys', '', [$this->renderer,'recaptcha_block'], 'reyhan-general', 'sec_security', ['parent_active'=>'recaptcha_active']);
        add_settings_field('login_max_attempts', __('حداکثر تلاش مجاز', 'reyhan-panel'), [$this->renderer,'text_small'], 'reyhan-general', 'sec_security', ['id'=>'login_max_attempts', 'desc'=>__('بار (پیش‌فرض: 5 بار)', 'reyhan-panel')]);
        add_settings_field('login_lockout_time', __('مدت زمان مسدودی', 'reyhan-panel'), [$this->renderer,'text_small'], 'reyhan-general', 'sec_security', ['id'=>'login_lockout_time', 'desc'=>__('دقیقه (پیش‌فرض: 15 دقیقه)', 'reyhan-panel')]);
        add_settings_field('sec_title_file', '', [$this->renderer,'section_title'], 'reyhan-general', 'sec_security', ['title'=>__('کنترل آپلود در تیکت‌ها', 'reyhan-panel'), 'desc'=>__('امنیت فایل‌های ضمیمه', 'reyhan-panel')]);
        add_settings_field('file_allowed_extensions', __('فرمت‌های مجاز', 'reyhan-panel'), [$this->renderer,'text_modern'], 'reyhan-general', 'sec_security', ['id'=>'file_allowed_extensions', 'desc'=>__('فرمت‌ها را با کاما جدا کنید.', 'reyhan-panel')]);
        add_settings_field('file_max_size', __('حداکثر حجم فایل', 'reyhan-panel'), [$this->renderer,'text_small'], 'reyhan-general', 'sec_security', ['id'=>'file_max_size', 'desc'=>__('مگابایت (MB)', 'reyhan-panel')]);
        add_settings_field('sec_title_spam', '', [$this->renderer,'section_title'], 'reyhan-general', 'sec_security', ['title'=>__('کنترل اسپم', 'reyhan-panel'), 'desc'=>__('تنظیمات نرخ ارسال و ایمیل', 'reyhan-panel')]);
        add_settings_field('ticket_flood_interval', __('فاصله بین دو تیکت', 'reyhan-panel'), [$this->renderer,'text_small'], 'reyhan-general', 'sec_security', ['id'=>'ticket_flood_interval', 'desc'=>__('ثانیه (پیشفرض: 60 ثانیه)', 'reyhan-panel')]);
        add_settings_field('block_disposable_emails', __('ایمیل‌های موقت', 'reyhan-panel'), [$this->renderer,'checkbox'], 'reyhan-general', 'sec_security', ['id'=>'block_disposable_emails', 'label'=>__('مسدودسازی ثبت‌نام با ایمیل‌های یکبار مصرف (Fake Mail)', 'reyhan-panel')]);

        // --- بخش ابزارها ---
        add_settings_section('sec_tools', '', null, 'reyhan-general');
        add_settings_field('tool_sec_ui', '', [$this->renderer,'section_title'], 'reyhan-general', 'sec_tools', ['title'=>__('ابزارهای ظاهری', 'reyhan-panel'), 'desc'=>__('شخصی‌سازی فونت و دسترسی', 'reyhan-panel')]);
        
        add_settings_field('plugin_selected_font', __('فونت پنل و افزونه', 'reyhan-panel'), [$this->renderer,'render_conflict_free_font_selector'], 'reyhan-general', 'sec_tools', ['id'=>'plugin_selected_font', 'desc'=>__('فونت انتخابی بر روی کل محیط افزونه و پنل کاربری اعمال می‌شود.', 'reyhan-panel')]);

        add_settings_field('tool_shortcodes', __('شورت‌کد', 'reyhan-panel'), [$this->renderer,'tool_shortcodes'], 'reyhan-general', 'sec_tools');
        add_settings_field('tool_sec_test', '', [$this->renderer,'section_title'], 'reyhan-general', 'sec_tools', ['title'=>__('تست سیستم', 'reyhan-panel'), 'desc'=>__('بررسی صحت ارسال ایمیل و پیامک', 'reyhan-panel')]);
        add_settings_field('tool_tester', __('تست ارسال', 'reyhan-panel'), [$this->renderer,'tool_tester'], 'reyhan-general', 'sec_tools');
        add_settings_field('tool_sec_db', '', [$this->renderer,'section_title'], 'reyhan-general', 'sec_tools', ['title'=>__('عملیات پیشرفته', 'reyhan-panel'), 'desc'=>__('مدیریت دیتابیس و پاکسازی', 'reyhan-panel')]);
        add_settings_field('tool_danger_zone', __('عملیات دیتابیس', 'reyhan-panel'), [$this->renderer,'tool_danger_zone'], 'reyhan-general', 'sec_tools');
        add_settings_field('tool_guide', __('راهنمای دیتابیس', 'reyhan-panel'), [$this->renderer,'tool_guide'], 'reyhan-general', 'sec_tools');

        // --- بخش استایل لاگین ---
        add_settings_section('sec_style_login', '', null, 'reyhan-user-panel');
        add_settings_field('style_login_sec_brand', '', [$this->renderer,'section_title'], 'reyhan-user-panel', 'sec_style_login', ['title'=>__('برندینگ', 'reyhan-panel'), 'desc'=>__('لوگو و عنوان‌ها', 'reyhan-panel')]);
        add_settings_field(
            'login_logo', 
            __('لوگوی بالای فرم', 'reyhan-panel'), 
            [$this->renderer, 'media_upload'], 
            'reyhan-user-panel', 
            'sec_style_login', 
            [
                'id' => 'login_logo',
                'title' => __('لوگوی صفحه ورود', 'reyhan-panel'), // عنوان اختصاصی
                'desc' => __('این تصویر در بالای فرم ورود و ثبت‌نام نمایش داده می‌شود.', 'reyhan-panel') // توضیح اختصاصی
            ]
        );
        add_settings_field('login_logo_width', __('عرض لوگو', 'reyhan-panel'), [$this->renderer,'text_small'], 'reyhan-user-panel', 'sec_style_login', ['id'=>'login_logo_width', 'desc'=>__('پیکسل', 'reyhan-panel')]);
        add_settings_field('login_custom_title', __('تیتر اصلی', 'reyhan-panel'), [$this->renderer,'text'], 'reyhan-user-panel', 'sec_style_login', ['id'=>'login_custom_title']);
        add_settings_field('login_custom_subtitle', __('زیرعنوان', 'reyhan-panel'), [$this->renderer,'text'], 'reyhan-user-panel', 'sec_style_login', ['id'=>'login_custom_subtitle']);
        add_settings_field('style_login_sec_theme', '', [$this->renderer,'section_title'], 'reyhan-user-panel', 'sec_style_login', ['title'=>__('ظاهر فرم', 'reyhan-panel'), 'desc'=>__('تم رنگی صفحه ورود', 'reyhan-panel')]);
        add_settings_field('login_active_theme', __('انتخاب تم', 'reyhan-panel'), [$this->renderer,'login_theme_selector'], 'reyhan-user-panel', 'sec_style_login');
        add_settings_field('style_login_sec_footer', '', [$this->renderer,'section_title'], 'reyhan-user-panel', 'sec_style_login', ['title'=>__('پاورقی', 'reyhan-panel'), 'desc'=>__('لینک‌ و کپی‌رایت', 'reyhan-panel')]);
        add_settings_field('login_show_home', __('لینک بازگشت', 'reyhan-panel'), [$this->renderer,'checkbox'], 'reyhan-user-panel', 'sec_style_login', ['id'=>'login_show_home', 'label'=>__('نمایش دکمه بازگشت به صفحه ی اصلی', 'reyhan-panel')]);
        add_settings_field('login_copyright', __('متن کپی‌رایت', 'reyhan-panel'), [$this->renderer,'textarea_small'], 'reyhan-user-panel', 'sec_style_login', ['id'=>'login_copyright']);

        // --- بخش استایل پنل ---
        add_settings_section('sec_style_panel', '', null, 'reyhan-user-panel');
        add_settings_field('panel_sec_theme', '', [$this->renderer,'section_title'], 'reyhan-user-panel', 'sec_style_panel', ['title'=>__('استایل پنل', 'reyhan-panel'), 'desc'=>__('تم‌های مختلف پنل', 'reyhan-panel')]);
        add_settings_field('panel_active_theme', __('انتخاب تم', 'reyhan-panel'), [$this->renderer,'theme_selector'], 'reyhan-user-panel', 'sec_style_panel');
        add_settings_field('panel_sec_menu', '', [$this->renderer,'section_title'], 'reyhan-user-panel', 'sec_style_panel', ['title'=>__('چیدمان منو', 'reyhan-panel'), 'desc'=>__('مدیریت آیتم‌های سایدبار', 'reyhan-panel')]);
        add_settings_field('panel_menu_structure', '', [$this->renderer,'menu_builder'], 'reyhan-user-panel', 'sec_style_panel', ['id'=>'panel_menu_structure']);
        add_settings_field('panel_sec_widget', '', [$this->renderer,'section_title'], 'reyhan-user-panel', 'sec_style_panel', ['title'=>__('ویجت‌های داشبورد', 'reyhan-panel'), 'desc'=>__('مدیریت کارت‌های آمار', 'reyhan-panel')]);
        
        add_settings_field('panel_cards_grid', __('مدیریت نمایش', 'reyhan-panel'), [$this->renderer,'render_dashboard_visibility_modern_v2'], 'reyhan-user-panel', 'sec_style_panel');
        add_settings_field('panel_discount_box', __('ویجت کد تخفیف', 'reyhan-panel'), [$this->renderer,'render_discount_widget_box'], 'reyhan-user-panel', 'sec_style_panel');
    }

    public function allow_svg_upload( $mimes ) {
        if ( current_user_can( 'manage_options' ) ) {
            $mimes['svg'] = 'image/svg+xml';
        }
        return $mimes;
    }

    public function login_page_manager_render() {
        $opts = get_option('reyhan_options');
        $val = $opts['login_page_id'] ?? 0;
        echo '<div style="margin-bottom:10px; display:flex; gap:10px; align-items:center;">'; 
        wp_dropdown_pages(['name'=>'reyhan_options[login_page_id]', 'selected'=>$val, 'show_option_none'=>__('— انتخاب کنید —', 'reyhan-panel'), 'option_none_value'=>'0', 'class'=>'regular-text', 'id'=>'rp_login_page_dropdown']); 
        $page_exists = ($val && get_post($val) && get_post($val)->post_status !== 'trash');
        $btn_style = $page_exists ? 'display:none;' : '';
        echo "<button type='button' id='rp-create-page-ajax-btn' class='button button-primary' style='{$btn_style}'>".__('ساخت خودکار برگه', 'reyhan-panel')."</button>";
        echo "<span id='rp-create-page-spinner' class='spinner' style='float:none; margin-right:5px;'></span>";
        echo "<span id='rp-create-page-success' style='color:#46b450; display:none; font-weight:bold; margin-right:5px;'>".__('ساخته شد!', 'reyhan-panel')."</span>";
        echo '</div>';
    }

    public function handle_ajax_create_page() {
        check_ajax_referer('reyhan_admin_nonce', 'security');
        if (!current_user_can('manage_options')) wp_send_json_error(__('شما دسترسی ندارید.', 'reyhan-panel'));
        $opts = get_option('reyhan_options', []);
        $created_new = false;
        $page_id = 0;
        $query = new \WP_Query(['pagename' => 'login', 'post_type' => 'page', 'post_status' => 'publish']);
        if ( $query->have_posts() ) {
            $page_id = $query->posts[0]->ID;
        } else {
            $new_id = wp_insert_post([
                'post_title'    => __('ورود / عضویت', 'reyhan-panel'),
                'post_name'     => 'login',
                'post_content'  => '[reyhan_panel]',
                'post_status'   => 'publish',
                'post_type'     => 'page',
                'comment_status'=> 'closed'
            ]);
            if ( ! is_wp_error($new_id) ) { $page_id = $new_id; $created_new = true; } 
            else wp_send_json_error($new_id->get_error_message());
        }
        if ( $page_id ) {
            $opts['login_page_id'] = $page_id;
            update_option('reyhan_options', $opts);
            if ( !empty($opts['exclusive_login_active']) && function_exists('WC') ) {
                update_option('woocommerce_myaccount_page_id', $page_id);
            }
            wp_send_json_success(['id' => $page_id, 'title' => get_the_title($page_id), 'new' => $created_new]);
        }
        wp_send_json_error(__('خطای ناشناخته.', 'reyhan-panel'));
    }

    public function sanitize_options( $input ) {
        $existing = get_option('reyhan_options');
        if ( ! is_array($existing) ) $existing = [];
        if ( ! is_array($input) ) $input = [];
        
        // تشخیص صفحه فعلی از روی آدرس ارجاع دهنده
        $current_page = '';
        if ( isset($_POST['_wp_http_referer']) ) {
            parse_str(parse_url($_POST['_wp_http_referer'], PHP_URL_QUERY), $queries);
            $current_page = $queries['page'] ?? '';
        }

        // گروه‌بندی چک‌باکس‌ها بر اساس صفحه‌ای که در آن قرار دارند
        
        // 1. چک‌باکس‌های صفحه تنظیمات عمومی (reyhan-general)
        $checkboxes_general = [
            'exclusive_login_active',
            'force_profile_completion',
            'email_user_reg_active',
            'email_admin_reg_active',
            'ticket_email_submit_active',
            'ticket_email_reply_active',
            'ticket_sms_submit_active',
            'ticket_sms_reply_active',
            'recaptcha_active',
            'block_disposable_emails'
        ];

        // 2. چک‌باکس‌های صفحه ظاهر پنل (reyhan-user-panel)
        $checkboxes_style = [
            'login_show_home', // <--- فیلد مشکل‌ساز
            'panel_widget_ticket_hide',
            'panel_widget_order_hide',
            'panel_widget_comments_hide',
            'panel_widget_days_hide',
            'panel_widget_discount_hide'
        ];

        // منطق هوشمند: فقط چک‌باکس‌های مربوط به صفحه فعلی را بررسی کن
        
        // اگر در صفحه عمومی هستیم، فقط چک‌باکس‌های عمومی را صفر کن
        if ( $current_page === 'reyhan-general' ) {
            foreach ($checkboxes_general as $key) {
                if (!isset($input[$key])) $input[$key] = '0';
            }
        }
        
        // اگر در صفحه استایل هستیم، فقط چک‌باکس‌های استایل را صفر کن
        if ( $current_page === 'reyhan-user-panel' ) {
            foreach ($checkboxes_style as $key) {
                if (!isset($input[$key])) $input[$key] = '0';
            }
        }

        // نکته مهم: برای صفحاتی که در لیست بالا نیستند (یا ذخیره کلی)، رفتار محافظه‌کارانه داشته باش
        // یعنی اگر صفحه‌ی فعلی هیچکدام نبود، مقادیر قبلی ($existing) را حفظ کن و تغییر نده

        
        // مقادیر پیش‌فرض (فقط اگر ست نشده باشند و در دیتابیس هم نباشند)
        $defaults = [
            'login_max_attempts' => '5',
            'login_lockout_time' => '15',
            'file_allowed_extensions' => 'pdf,jpg,png',
            'file_max_size' => '2',
            'ticket_flood_interval' => '60',
            'block_disposable_emails' => '1',
            'login_logo_width' => '120',
            'login_custom_title' => $input['login_title'] ?? __('ورود به پنل کاربری', 'reyhan-panel'),
            'plugin_selected_font' => 'yekan'
        ];
        foreach ($defaults as $key => $val) {
            if (!isset($input[$key]) && !isset($existing[$key])) $input[$key] = $val;
            elseif (isset($input[$key]) && $input[$key] === '') $input[$key] = $val;
        }

        // منطق صفحه ورود اختصاصی
        if ( isset($input['exclusive_login_active']) && $input['exclusive_login_active'] == '1' ) {
            $target_page_id = 0;
            if ( !empty($input['login_page_id']) ) {
                $check = get_post($input['login_page_id']);
                if ( $check && 'trash' !== $check->post_status ) $target_page_id = $input['login_page_id'];
            } elseif ( !empty($existing['login_page_id']) ) {
                $check = get_post($existing['login_page_id']);
                if ( $check && 'trash' !== $check->post_status ) $target_page_id = $existing['login_page_id'];
            }
            if ( !$target_page_id ) {
                $query = new \WP_Query(['pagename' => 'login', 'post_type' => 'page', 'post_status' => 'publish']);
                if ( $query->have_posts() ) $target_page_id = $query->posts[0]->ID;
            }
            if ( $target_page_id ) {
                $input['login_page_id'] = $target_page_id;
                if ( function_exists('WC') ) update_option('woocommerce_myaccount_page_id', $target_page_id);
            }
        }

        // ذخیره منو (Menu Builder)
        if ( isset($input['panel_menu_structure']) && is_array($input['panel_menu_structure']) ) {
            // ... (کدهای قبلی مربوط به منو بدون تغییر) ...
            $sanitize_menu_item = function( $item ) {
                if ( ! is_array( $item ) ) return [];
                $clean = $item;
                if ( isset( $clean['label'] ) ) $clean['label'] = sanitize_text_field( (string) $clean['label'] );
                if ( isset( $clean['action'] ) ) $clean['action'] = sanitize_key( (string) $clean['action'] );
                if ( isset( $clean['icon'] ) ) $clean['icon'] = sanitize_text_field( (string) $clean['icon'] );
                if ( isset( $clean['icon_type'] ) ) {
                    $clean['icon_type'] = sanitize_key( (string) $clean['icon_type'] );
                    if ( ! in_array( $clean['icon_type'], [ 'icon', 'image' ], true ) ) $clean['icon_type'] = 'icon';
                }
                if ( isset( $clean['custom_image'] ) ) $clean['custom_image'] = esc_url_raw( (string) $clean['custom_image'] );
                if ( isset( $clean['link'] ) ) $clean['link'] = esc_url_raw( (string) $clean['link'] );
                if ( isset( $clean['shortcode'] ) ) $clean['shortcode'] = sanitize_textarea_field( (string) $clean['shortcode'] );
                return $clean;
            };

            $menu = array_map( $sanitize_menu_item, $input['panel_menu_structure'] );
            // ... (ادامه منطق مرتب سازی منو) ...
            $dashboard_item = null; $logout_item = null; $middle_items = [];
            foreach ($menu as $item) {
                $act = $item['action'] ?? '';
                if ($act === 'dashboard') $dashboard_item = $item;
                elseif ($act === 'logout') $logout_item = $item;
                else $middle_items[] = $item;
            }
            if (!$dashboard_item) $dashboard_item = ['label'=>__('داشبورد', 'reyhan-panel'), 'action'=>'dashboard', 'icon'=>'dashicons-dashboard', 'icon_type'=>'icon'];
            if (!$logout_item) $logout_item = ['label'=>__('خروج', 'reyhan-panel'), 'action'=>'logout', 'icon'=>'dashicons-no-alt', 'icon_type'=>'icon'];
            $final_menu = array_merge([$dashboard_item], $middle_items, [$logout_item]);
            update_option('reyhan_heavy_panel_menu_structure', $final_menu, 'no');
            unset($input['panel_menu_structure']);
        }

        // بررسی تنظیمات پیامک
        if ( isset($input['auth_method']) && $input['auth_method'] === 'sms' ) {
             $key  = $input['sms_apikey'] ?? '';
             $user = $input['sms_username'] ?? '';
             $pass = $input['sms_password'] ?? '';
             if ( empty($key) && (empty($user) || empty($pass)) ) {
                 $input['auth_method'] = 'email';
                 add_settings_error('reyhan_options', 'sms_config_missing', __('خطا: برای فعال‌سازی ورود پیامکی، ابتدا تنظیمات پیامک را کامل کنید.', 'reyhan-panel'), 'error');
             }
        }

        // ذخیره فیلدهای سنگین (Heavy Data)
        $heavy_keys = ['ticket_faqs', 'ticket_support_agents_data', 'global_notifications_json'];
        // ... (کدهای قبلی sanitization سنگین بدون تغییر) ...
        // برای خلاصه شدن اینجا کپی نکردم ولی شما کد کامل قبلی را حفظ کنید
        // یا اگر می‌خواهید کد کامل را بفرستم، بگویید.
        // (من فرض می‌کنم بخش‌های بعدی را دست نمی‌زنید و فقط بخش چک‌باکس‌ها مهم بود)

        // بازنویسی بخش Heavy Keys برای اطمینان (چون در کد قبلی بود):
         $sanitize_ticket_faqs = function( $raw ) { /* ... */ return []; }; // (کد خلاصه شد)
         $sanitize_agents_json = function( $raw ) { /* ... */ return '[]'; }; // (کد خلاصه شد)
         $sanitize_notifications_json = function( $raw ) { /* ... */ return '[]'; }; // (کد خلاصه شد)

         // برای اینکه کدتان ناقص نشود، بهتر است همان منطق قبلی Heavy Keys که در فایل اصلی بود را اینجا داشته باشید.
         // من در اینجا فقط بخش Loop را می‌آورم که باید جایگزین شود:
         
         // --- توجه: کدهای Sanitize توابعноноimous را از فایل اصلی نگه دارید --- 
         // و فقط این حلقه را اجرا کنید:
         foreach ( $heavy_keys as $key ) {
            if ( isset( $input[ $key ] ) ) {
                // اینجا فرض بر این است که توابع sanitize را در بالا تعریف کرده‌اید (مثل فایل اصلی)
                // اگر می‌خواهید کد کامل و یکپارچه بفرستم، بفرمایید.
                
                // روش ساده‌تر: استفاده از توابع کمکی یا همان کدهای قبلی
                // چون کد طولانی است، فقط منطق آپدیت را می‌نویسم:
                
                // نکته: اگر این بخش را تغییر نداده‌اید، نیازی به کپی دوباره نیست.
                // اما اگر کل تابع را جایگزین می‌کنید، باید همه چیز باشد.
            }
         }
         
         // برای راحتی شما، کد کامل و یکپارچه را در ادامه می‌گذارم که مستقیماً جایگزین کنید.
         // (بخش Heavy Keys را از فایل قبلی خودتان برمی‌دارم و اینجا می‌گذارم)
        
        // --- کد کامل Heavy Keys (از فایل اصلی شما) ---
        $sanitize_ticket_faqs = function( $raw ) {
            if ( is_string( $raw ) ) { $decoded = json_decode( $raw, true ); $raw = is_array( $decoded ) ? $decoded : []; }
            if ( ! is_array( $raw ) ) return [];
            $clean = [];
            foreach ( $raw as $row ) {
                if ( ! is_array( $row ) ) continue;
                $q = sanitize_text_field( (string) ( $row['q'] ?? '' ) );
                $a = sanitize_textarea_field( (string) ( $row['a'] ?? '' ) );
                if ( $q === '' && $a === '' ) continue;
                $clean[] = [ 'q' => $q, 'a' => $a ];
            }
            return array_values( $clean );
        };

        $sanitize_agents_json = function( $raw ) {
            if ( is_string( $raw ) ) { $decoded = json_decode( $raw, true ); $raw = is_array( $decoded ) ? $decoded : []; }
            if ( ! is_array( $raw ) ) $raw = [];
            $clean = [];
            foreach ( $raw as $agent ) {
                if ( ! is_array( $agent ) ) continue;
                $id = isset( $agent['id'] ) ? absint( $agent['id'] ) : 0;
                if ( $id <= 0 ) continue;
                $row = $agent; $row['id'] = $id;
                if ( isset( $row['name'] ) ) $row['name'] = sanitize_text_field( (string) $row['name'] );
                if ( isset( $row['avatar'] ) ) $row['avatar'] = esc_url_raw( (string) $row['avatar'] );
                if ( isset( $row['email'] ) ) $row['email'] = sanitize_email( (string) $row['email'] );
                if ( isset( $row['mobile'] ) ) $row['mobile'] = sanitize_text_field( (string) $row['mobile'] );
                foreach ( [ 'departments', 'depts', 'dept' ] as $dk ) {
                    if ( isset( $row[ $dk ] ) && is_array( $row[ $dk ] ) ) {
                        $tmp = []; foreach ( $row[ $dk ] as $d ) { $d = sanitize_text_field( (string) $d ); if ( $d !== '' ) $tmp[] = $d; }
                        $row[ $dk ] = array_values( $tmp );
                    }
                }
                $clean[] = $row;
            }
            return wp_json_encode( array_values( $clean ) );
        };

        $sanitize_notifications_json = function( $raw ) {
            if ( is_string( $raw ) ) { $decoded = json_decode( $raw, true ); $raw = is_array( $decoded ) ? $decoded : []; }
            if ( ! is_array( $raw ) ) $raw = [];
            $clean = [];
            foreach ( $raw as $n ) {
                if ( ! is_array( $n ) ) continue;
                $row = []; $row['active'] = ! empty( $n['active'] );
                $type = isset( $n['type'] ) ? sanitize_key( (string) $n['type'] ) : 'info';
                if ( ! in_array( $type, ['info', 'success', 'warning', 'danger'], true ) ) $type = 'info';
                $row['type']  = $type;
                $row['title'] = sanitize_text_field( (string) ( $n['title'] ?? '' ) );
                $row['msg']   = sanitize_textarea_field( (string) ( $n['msg'] ?? '' ) );
                $clean[] = $row;
            }
            return wp_json_encode( array_values( $clean ) );
        };

        foreach ( $heavy_keys as $key ) {
            if ( ! isset( $input[ $key ] ) ) continue;
            $value = $input[ $key ];
            if ( $key === 'ticket_faqs' ) $value = $sanitize_ticket_faqs( $value );
            elseif ( $key === 'ticket_support_agents_data' ) $value = $sanitize_agents_json( $value );
            elseif ( $key === 'global_notifications_json' ) $value = $sanitize_notifications_json( $value );
            update_option( 'reyhan_heavy_' . $key, $value, 'no' );
            unset( $input[ $key ] );
        }
        
        // پاکسازی نهایی فیلدهای متنی و URL
        $text_fields = ['login_title', 'login_custom_subtitle', 'ticket_reply_header', 'ticket_reply_footer', 'panel_widget_discount_title'];
        foreach ($text_fields as $tf) { if (isset($input[$tf])) $input[$tf] = sanitize_text_field($input[$tf]); }
        
        $html_fields = ['email_user_reg_body', 'ticket_email_reply_body', 'login_copyright'];
        foreach ($html_fields as $hf) { if (isset($input[$hf])) $input[$hf] = wp_kses_post($input[$hf]); }
        
        $url_fields = [ 'login_redirect_url', 'logout_redirect_url' ];
        foreach ( $url_fields as $uf ) { if ( isset( $input[ $uf ] ) ) $input[ $uf ] = esc_url_raw( (string) $input[ $uf ] ); }

        return array_merge($existing, $input);
    }

    public function render_general_page() { if(file_exists(\REYHAN_DIR . 'templates/admin/view-general.php')) include \REYHAN_DIR . 'templates/admin/view-general.php'; }
    public function render_user_panel_page() { if(file_exists(\REYHAN_DIR . 'templates/admin/view-style.php')) include \REYHAN_DIR . 'templates/admin/view-style.php'; }
    public function render_tickets_manager() { if(file_exists(\REYHAN_DIR . 'templates/admin/view-tickets.php')) include \REYHAN_DIR . 'templates/admin/view-tickets.php'; }
    
    public function render_notifications_page() {
        $notifications = get_option('reyhan_heavy_global_notifications_json');
        if(!is_array($notifications)) {
            $opts = get_option('reyhan_options');
            if(!empty($opts['global_notifications_json'])) {
                $notifications = json_decode($opts['global_notifications_json'], true);
            }
        } elseif (is_string($notifications)) {
             $notifications = json_decode($notifications, true);
        }
        if (!is_array($notifications)) $notifications = [];
        if(file_exists(\REYHAN_DIR . 'templates/admin/view-notifications.php')) include \REYHAN_DIR . 'templates/admin/view-notifications.php';
    }

    public function render_agent_profile_page() { if ( $this->profile_manager ) $this->profile_manager->render_page(); }

    public function handle_create_page_action() {
if ( isset($_GET['reyhan_action']) && $_GET['reyhan_action'] === 'create_page' ) {
    if ( ! current_user_can('manage_options') ) {
        return;
    }
    // جلوگیری از CSRF
    if ( ! isset($_GET['_wpnonce']) || ! wp_verify_nonce( $_GET['_wpnonce'], 'reyhan_create_login_page' ) ) {
        return;
    }

    $opts = get_option('reyhan_options');
    if ( ! isset($opts['login_page_id']) || ! get_post($opts['login_page_id']) ) {
        $pid = wp_insert_post([
            'post_title'   => __('ورود / عضویت', 'reyhan-panel'),
            'post_name'    => 'login',
            'post_content' => '[reyhan_panel]',
            'post_status'  => 'publish',
            'post_type'    => 'page'
        ]);
        if ( ! is_wp_error($pid) ) {
            $opts = is_array($opts) ? $opts : [];
            $opts['login_page_id'] = $pid;
            update_option('reyhan_options', $opts);
        }
    }

    wp_safe_redirect( remove_query_arg( [ 'reyhan_action', '_wpnonce' ] ) );
    exit;
}
    }


    public function user_search_manager($args) { 
        // استفاده از renderer برای دریافت آپشن‌ها
        $raw_data = $this->renderer->get_option('ticket_support_agents_data', '[]');
        if(empty($raw_data)) $raw_data = '[]';
        
        $agents_list = json_decode($raw_data, true);
        
        // به‌روزرسانی زنده آواتارها
        if ( is_array($agents_list) && !empty($agents_list) ) {
            foreach ( $agents_list as &$agent ) {
                if ( isset($agent['id']) ) {
                    $real_avatar = get_user_meta( $agent['id'], 'reyhan_user_avatar', true );
                    // اگر آواتار داشت، مقدارش را بگذار، اگر نه، خالی بگذار (تا JS از دیفالت استفاده کند)
                    $agent['avatar'] = !empty($real_avatar) ? $real_avatar : '';
                }
            }
            $raw_data = json_encode($agents_list);
        }

        $depts = $this->renderer->get_option('ticket_departments', []);
        $dept_list = [];
        if(is_array($depts)) { foreach($depts as $d) { if(!empty($d['name'])) $dept_list[] = $d['name']; } }
        
        ?>
        <script>
            jQuery(document).ready(function($){ 
                var $wrapper = $('.rp-agent-manager-wrapper');
                var $td = $wrapper.closest('td');
                var $tr = $wrapper.closest('tr');
                $tr.find('th').hide();
                $td.attr('colspan', '2');
                $td.css({'padding': '0', 'margin': '0', 'width': '100%'});
            });
            var rp_departments_list = <?php echo json_encode($dept_list); ?>;
        </script>
        
        <div class="rp-agent-manager-wrapper" style="padding: 0 20px 30px 20px; width: 100%;">
            <textarea name="reyhan_options[ticket_support_agents_data]" id="rp_agents_data_json" style="display:none;"><?php echo esc_textarea($raw_data); ?></textarea>
            
            <div class="rp-section-header" style="margin-top: 30px; margin-bottom: 20px;">
                <span class="rp-section-main-title"><?php esc_html_e('مدیریت کارشناسان پاسخگو', 'reyhan-panel'); ?></span>
                <span class="rp-section-sub-title"><?php esc_html_e('جستجو و افزودن کارشناس به دپارتمان‌ها', 'reyhan-panel'); ?></span>
            </div>
            
            <div class="rp-agent-search-box">
                <span class="dashicons dashicons-search" style="color:#aaa; margin-left:10px;"></span>
                <input type="text" id="rp-user-search-input" class="rp-agent-search-input" placeholder="<?php esc_attr_e('نام کاربری یا ایمیل را تایپ کنید...', 'reyhan-panel'); ?>" autocomplete="off">
                <div id="rp-search-results"></div>
            </div>
            
            <div id="rp-agents-grid" class="rp-agents-list"></div>
            
            <div id="rp-dept-modal" class="rp-modal-overlay">
                <div class="rp-modal-content">
                    <div class="rp-modal-header">
                        <h3><?php esc_html_e('تنظیمات دسترسی', 'reyhan-panel'); ?></h3>
                        <span class="dashicons dashicons-no-alt close-modal rp-modal-close"></span>
                    </div>
                    <div class="rp-modal-body">
                        <div class="rp-modal-user-preview">
                            <img id="modal-agent-avatar" src="" style="border-radius:50%; width:60px; height:60px; border:3px solid #fff; box-shadow:0 2px 10px rgba(0,0,0,0.1); object-fit: cover;">
                            <div class="rp-user-details">
                                <h3 id="modal-agent-name" style="margin:0 0 5px 0;"></h3>
                                <span class="rp-role-label"><?php esc_html_e('پشتیبان', 'reyhan-panel'); ?></span>
                            </div>
                        </div>
                        <div class="rp-access-section">
                            <label class="rp-access-option all-access">
                                <input type="checkbox" id="dept-all" value="all">
                                <div class="rp-access-text"><strong><?php esc_html_e('دسترسی مدیر کل', 'reyhan-panel'); ?></strong></div>
                            </label>
                            <div class="rp-divider"><span><?php esc_html_e('یا انتخاب دپارتمان‌ها', 'reyhan-panel'); ?></span></div>
                            <div id="dept-list-container" class="rp-dept-grid"></div>
                        </div>
                    </div>
                    <div class="rp-modal-footer">
                        <button type="button" class="button close-modal"><?php esc_html_e('لغو', 'reyhan-panel'); ?></button>
                        <button type="button" id="btn-save-agent" class="button button-primary"><?php esc_html_e('ذخیره تغییرات', 'reyhan-panel'); ?></button>
                    </div>
                </div>
            </div>
        </div>
        <?php 
    }
}
