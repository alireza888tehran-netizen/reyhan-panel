<?php
namespace ReyhanPanel\Services;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class SMS {
    
    public static $last_error = '';

    /**
     * ارسال پیامک تایید (OTP)
     */
    public static function send_otp( $mobile, $code ) {
        // 1. بررسی محدودیت زمانی (ابتدا چک میکنیم که کاربر بلاک نباشد)
        $transient_key = 'rp_sms_limit_' . md5($mobile);
        if ( get_transient($transient_key) ) {
            self::$last_error = 'لطفا کمی صبر کنید و سپس مجددا درخواست کد دهید.';
            return false;
        }

        $opts = get_option('reyhan_options');
        if ( empty($opts) || !is_array($opts) ) { self::$last_error = 'تنظیمات خالی است.'; return false; }
        self::$last_error = ''; 

        $provider = $opts['sms_provider'] ?? 'none';
        if ( $provider === 'none' || empty($provider) ) {
            self::$last_error = 'سامانه پیامکی غیرفعال است.';
            return false;
        }

        $api_key  = trim($opts['sms_apikey'] ?? '');
        $username = trim($opts['sms_username'] ?? '');
        $password = trim($opts['sms_password'] ?? '');
        $from     = trim($opts['sms_from'] ?? '');
        $method   = $opts['sms_send_method'] ?? 'pattern';
        $pattern  = trim($opts['sms_pattern_otp'] ?? '');

        if ( empty($api_key) && !empty($username) ) $api_key = $username;
        if ( empty($api_key) && !in_array($provider, ['melipayamak', 'other', 'payamresan']) ) {
            self::$last_error = 'API Key الزامی است.';
            return false;
        }

        // 2. انجام عملیات ارسال و ذخیره نتیجه در متغیر $result
        $result = false;

        switch ( $provider ) {
            case 'melipayamak':
                $result = self::process_melipayamak($mobile, $code, $method, $username, $password, $pattern);
                break; // مهم: اینجا break میگذاریم تا از switch خارج شود و به پایین برود

            case 'smsir':
                $result = self::process_smsir($mobile, $code, $method, $api_key, $from, $pattern);
                break;

            case 'kaveh': 
                $result = self::process_kavehnegar($mobile, $code, $method, $api_key, $pattern);
                break;

            case 'faraz':
            case 'payamito':
            case 'ippanel':
                $result = self::process_ippanel($mobile, $code, $method, $api_key, $from, $pattern);
                break;

            case 'payamresan':
            case 'other':
                $url_tpl = $opts['sms_generic_url'] ?? '';
                $result = self::process_generic_url($mobile, $code, $method, $url_tpl);
                break;

            default: 
                self::$last_error = "سامانه تعریف نشده است.";
                $result = false;
        }

        // 3. اعمال محدودیت فقط در صورت موفقیت
        if ( $result === true ) {
            // کاربر را برای 2 دقیقه (120 ثانیه) بلاک کن که دوباره نتواند بفرستد
            set_transient($transient_key, 1, 120);
        }

        return $result;
    }

    /**
     * بررسی اعتبار پنل (AJAX)
     */
    public static function check_credit_ajax() {
        check_ajax_referer( 'reyhan_admin_nonce', 'security' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'شما دسترسی کافی ندارید.' );
        }

        $opts     = get_option('reyhan_options');
        $provider = $opts['sms_provider'] ?? 'none';
        
        $api_key  = trim($opts['sms_apikey'] ?? '');
        $username = trim($opts['sms_username'] ?? '');
        $password = trim($opts['sms_password'] ?? '');

        if ( empty($api_key) && !empty($username) ) $api_key = $username;

        $balance = '---';
        $success = false;
        $msg     = '';

        try {
            switch ( $provider ) {
                case 'none':
                    throw new \Exception('هیچ سامانه پیامکی انتخاب نشده است.');

                case 'melipayamak':
                    $res = self::get_balance_melipayamak($username, $password);
                    $balance = number_format((float)$res) . ' ریال';
                    $success = true;
                    break;

                case 'smsir':
                    $res = self::get_balance_smsir($api_key);
                    $balance = number_format((float)$res) . ' پیامک';
                    $success = true;
                    break;

                case 'kaveh':
                    $res = self::get_balance_kaveh($api_key);
                    $balance = number_format((float)$res) . ' ریال';
                    $success = true;
                    break;

                case 'faraz':
                case 'payamito':
                case 'ippanel':
                    $res = self::get_balance_ippanel($api_key);
                    $balance = number_format((float)$res) . ' ریال';
                    $success = true;
                    break;

                case 'payamresan':
                case 'other':
                    throw new \Exception('در روش وب‌سرویس عمومی، امکان دریافت مانده حساب وجود ندارد.');

                default:
                    throw new \Exception('پنل انتخاب شده معتبر نیست.');
            }
        } catch ( \Exception $e ) {
            $msg = $e->getMessage();
        }

        if ( $success ) {
            wp_send_json_success([ 'msg' => "اتصال موفق! اعتبار: <b>{$balance}</b>" ]);
        } else {
            wp_send_json_error( $msg );
        }
    }

    // =========================================================================
    //  توابع پردازشگر ارسال (Send Processors)
    // =========================================================================

    private static function process_melipayamak($mobile, $code, $method, $u, $p, $pattern) {
        if(empty($u) || empty($p)) { self::$last_error = 'نام کاربری و رمز عبور الزامی است.'; return false; }
        if ( $method === 'pattern' ) {
            if ( empty($pattern) ) { self::$last_error = 'کد متن (BodyId) وارد نشده است.'; return false; }
            $url = "https://rest.payamak-panel.com/api/SendSMS/BaseServiceNumber";
            $body = [ "username" => $u, "password" => $p, "text" => strval($code), "to" => $mobile, "bodyId" => (int)$pattern ];
            return self::call_api($url, '', $body);
        } else {
            $url = "https://rest.payamak-panel.com/api/SendSMS/SendSMS";
            $msg = self::get_msg_template($code);
            $body = [ "username" => $u, "password" => $p, "to" => $mobile, "from" => "1000...", "text" => $msg, "isFlash" => false ];
            return self::call_api($url, '', $body);
        }
    }

    private static function process_smsir($mobile, $code, $method, $api_key, $from, $pattern) {
        if ( $method === 'pattern' ) {
            $url = 'https://api.sms.ir/v1/send/verify';
            $body = [ "mobile" => $mobile, "templateId" => (int)$pattern, "parameters" => [ ["name" => "Code", "value" => strval($code)] ] ];
            return self::call_api($url, $api_key, $body, true);
        } else {
            $msg = self::get_msg_template($code);
            $url = 'https://api.sms.ir/v1/send/bulk';
            $body = [ "lineNumber" => $from, "messageText" => $msg, "mobiles" => [$mobile] ];
            return self::call_api($url, $api_key, $body, true);
        }
    }

    private static function process_kavehnegar($mobile, $code, $method, $api_key, $pattern) {
        if ( $method === 'pattern' ) {
            $url = "https://api.kavenegar.com/v1/$api_key/verify/lookup.json?receptor=$mobile&token=$code&template=$pattern";
            $response = wp_remote_get($url, ['timeout' => 30]);
            if (is_wp_error($response)) { self::$last_error = $response->get_error_message(); return false; }
            $body = json_decode(wp_remote_retrieve_body($response), true);
            if(isset($body['return']['status']) && $body['return']['status'] == 200) return true;
            self::$last_error = $body['return']['message'] ?? 'خطای کاوه نگار';
            return false;
        }
        self::$last_error = "کاوه نگار فقط از متد پترن پشتیبانی می‌کند."; return false;
    }

    private static function process_ippanel($mobile, $code, $method, $api_key, $from, $pattern) {
        if ( $method === 'pattern' ) {
            $url = "https://api.ippanel.com/api/v1/messages/patterns/send";
            $sender = !empty($from) ? $from : "+983000505";
            $body = [ "pattern_code" => $pattern, "originator" => $sender, "recipient" => $mobile, "values" => [ "code" => strval($code) ] ];
            return self::call_api($url, $api_key, $body);
        } else {
            $msg = self::get_msg_template($code);
            $url = "https://api.ippanel.com/api/v1/messages/send";
            $body = [ "originator" => $from, "recipients" => [$mobile], "message" => $msg ];
            return self::call_api($url, $api_key, $body);
        }
    }

    private static function process_generic_url($mobile, $code, $method, $url_tpl) {
        if ( empty($url_tpl) ) { self::$last_error = 'لینک وب‌سرویس وارد نشده است.'; return false; }
        $msg_text = self::get_msg_template($code);
        $final_url = str_replace(['%mobile%', '%text%', '%code%'], [$mobile, urlencode($msg_text), $code], $url_tpl);
        
        $response = wp_safe_remote_get($final_url, ['timeout' => 30]);
        if ( is_wp_error($response) ) { self::$last_error = $response->get_error_message(); return false; }
        
        $http_code = wp_remote_retrieve_response_code($response);
        if ( $http_code >= 200 && $http_code < 300 ) return true;
        
        self::$last_error = "خطای HTTP $http_code";
        return false;
    }

    // =========================================================================
    //  توابع دریافت اعتبار (Balance Getters)
    // =========================================================================

    private static function get_balance_ippanel($api_key) {
        if(empty($api_key)) throw new \Exception('کلید API خالی است.');
        $response = wp_remote_get( "https://api.ippanel.com/api/v1/credit", [
            'headers' => [ 'Authorization' => "AccessKey {$api_key}" ], 'timeout' => 15
        ]);
        if ( is_wp_error($response) ) throw new \Exception($response->get_error_message());
        $body = json_decode( wp_remote_retrieve_body($response), true );
        if ( isset($body['data']['credit']) ) return $body['data']['credit'];
        throw new \Exception('عدم دسترسی (API Key اشتباه است)');
    }

    private static function get_balance_smsir($api_key) {
        if(empty($api_key)) throw new \Exception('کلید API خالی است.');
        $response = wp_remote_get( "https://api.sms.ir/v1/credit", [
            'headers' => [ 'X-API-KEY' => $api_key ], 'timeout' => 15
        ]);
        if ( is_wp_error($response) ) throw new \Exception($response->get_error_message());
        $body = json_decode( wp_remote_retrieve_body($response), true );
        if ( isset($body['data']) ) return $body['data'];
        throw new \Exception($body['message'] ?? 'خطای sms.ir');
    }

    private static function get_balance_kaveh($api_key) {
        $url = "https://api.kavenegar.com/v1/{$api_key}/account/info.json";
        $response = wp_remote_get($url, ['timeout' => 15]);
        if ( is_wp_error($response) ) throw new \Exception($response->get_error_message());
        $body = json_decode( wp_remote_retrieve_body($response), true );
        if ( isset($body['entries']['remaincredit']) ) return $body['entries']['remaincredit'];
        throw new \Exception('API Key کاوه نگار اشتباه است.');
    }

    private static function get_balance_melipayamak($u, $p) {
        if(empty($u) || empty($p)) throw new \Exception('نام کاربری/رمز عبور وارد نشده است.');
        $response = wp_remote_post( "https://rest.payamak-panel.com/api/SendSMS/GetCredit", [
            'body' => [ 'username' => $u, 'password' => $p ], 'timeout' => 15
        ]);
        if ( is_wp_error($response) ) throw new \Exception($response->get_error_message());
        $body = json_decode( wp_remote_retrieve_body($response), true );
        if ( isset($body['Value']) && is_numeric($body['Value']) ) return $body['Value'];
        throw new \Exception('نام کاربری یا رمز عبور اشتباه است.');
    }

    // =========================================================================
    //  ابزارها (Helpers)
    // =========================================================================

    private static function get_msg_template($code) {
        $opts = get_option('reyhan_options');
        $tpl = $opts['sms_text_template'] ?? 'کد: %code%';
        return str_replace('%code%', $code, $tpl);
    }

    private static function call_api($url, $key, $data, $is_smsir = false) {
        $args = [ 'body' => json_encode($data), 'headers' => [ 'Content-Type' => 'application/json' ], 'timeout' => 30 ];
        if ($is_smsir) { $args['headers']['X-API-KEY'] = $key; }
        elseif (!empty($key)) { $args['headers']['Authorization'] = "AccessKey $key"; }
        
        $response = wp_remote_post($url, $args);
        if ( is_wp_error($response) ) { self::$last_error = $response->get_error_message(); return false; }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($is_smsir) { return (isset($body['status']) && $body['status'] == 1); }
        if(isset($body['RetStatus'])) { return ($body['RetStatus'] == 1); }
        
        $code = wp_remote_retrieve_response_code($response);
        return ($code >= 200 && $code < 300);
    }
}