<?php
/*
Plugin Name: ریحان پنل
Description: ریحان پنل یک افزونه ی جامع و کاربردی برای اختصاصی کردن پنل کاربری شما میباشد. همچنین سیستم تیکتینگ این افزونه کاربردش را دو چندان کرده است.
Version: 1.0
Author: AliREYHANI
Text Domain: ریحان پنل
*/

if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ثابت‌ها: فقط یکبار تعریف شوند */
define( 'REYHAN_VERSION', 1.0 );
define( 'REYHAN_DIR', plugin_dir_path( __FILE__ ) );
define( 'REYHAN_URL', plugin_dir_url( __FILE__ ) );
define( 'REYHAN_UPLOAD_DIR', wp_upload_dir()['basedir'] . '/reyhan-safe' );

/* لود فایل‌های کلاس‌های اصلی */
require_once REYHAN_DIR . 'includes/class-reyhan-cpt.php';
// require_once REYHAN_DIR . 'includes/class-reyhan-ajax.php'; // <-- حذف شد چون فایلش را پاک کردیم
require_once REYHAN_DIR . 'includes/class-reyhan-sms.php';
require_once REYHAN_DIR . 'includes/class-reyhan-auth.php';
require_once REYHAN_DIR . 'includes/class-reyhan-frontend.php';
require_once REYHAN_DIR . 'includes/class-reyhan-settings.php';

/* فعال‌سازی افزونه */
function reyhan_activate() {
    add_option( 'reyhan_do_activation_redirect', true );
    if ( ! file_exists( REYHAN_UPLOAD_DIR ) ) {
        mkdir( REYHAN_UPLOAD_DIR, 0755, true );
    }
    // ایجاد فایل htaccess برای امنیت پوشه آپلود
    if ( ! file_exists( REYHAN_UPLOAD_DIR . '/.htaccess' ) ) {
        file_put_contents( REYHAN_UPLOAD_DIR . '/.htaccess', "Order Deny,Allow\nDeny from all" );
    }
    if ( ! file_exists( REYHAN_UPLOAD_DIR . '/index.php' ) ) {
        file_put_contents( REYHAN_UPLOAD_DIR . '/index.php', '<?php // Silence' );
    }

    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'reyhan_activate' );

function reyhan_init() {
    // 1. کلاس‌های مدیریت داده و منطق
    new Reyhan_CPT();
    new Reyhan_SMS();
    new Reyhan_Auth();
    
    // 2. مدیریت فایل‌های استاتیک (جدید)
    require_once REYHAN_DIR . 'includes/class-reyhan-assets.php';
    new Reyhan_Assets();

    // 3. رابط کاربری و تنظیمات
    new Reyhan_Settings();
    new Reyhan_Frontend();

    // 4. سیستم ایجکس
    require_once REYHAN_DIR . 'includes/ajax/class-base-ajax.php';
    require_once REYHAN_DIR . 'includes/ajax/class-ticket-ajax.php';
    require_once REYHAN_DIR . 'includes/ajax/class-admin-ticket-ajax.php';
    require_once REYHAN_DIR . 'includes/ajax/class-auth-ajax.php';

    new \Reyhan\Ajax\Ticket_Ajax();
    new \Reyhan\Ajax\Admin_Ticket_Ajax();
    new \Reyhan\Ajax\Auth_Ajax();

    // 5. ویزارد
    if ( file_exists( REYHAN_DIR . 'includes/class-reyhan-wizard.php' ) ) {
        require_once REYHAN_DIR . 'includes/class-reyhan-wizard.php';
        new Reyhan_Wizard();
    }
}
add_action( 'plugins_loaded', 'reyhan_init' );