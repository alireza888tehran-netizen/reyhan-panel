<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Reyhan_Frontend {

    public function __construct() {
        add_shortcode( 'reyhan_panel',   [ $this, 'render_master_panel' ] );
        add_shortcode( 'reyhan_support', [ $this, 'render_support_area_only' ] );
        add_action( 'wp_footer', [ $this, 'render_profile_completion_popup' ] );
    }

    public function render_profile_completion_popup() {
        if (!is_user_logged_in()) return;

        $user_id = get_current_user_id();
        $fname = get_user_meta($user_id, 'first_name', true);
        $lname = get_user_meta($user_id, 'last_name', true);

        if (empty($fname) || empty($lname)) {
            // برای سادگی، این پاپ‌آپ کوچک را اینجا نگه می‌داریم یا می‌توانید آن را هم به ویو ببرید
            // با توجه به حجم کم، فعلاً مشکلی ایجاد نمی‌کند.
            $font_dir_url = plugins_url( '../assets/fonts/', __FILE__ );
            ?>
            <style>
                @font-face { font-family: 'ReyhanPopupFont'; src: url('<?php echo $font_dir_url; ?>Regular.woff2') format('woff2'); font-weight: normal; font-style: normal; }
                @font-face { font-family: 'ReyhanPopupFont'; src: url('<?php echo $font_dir_url; ?>SemiBold.woff2') format('woff2'); font-weight: bold; font-style: normal; }
                #reyhan-profile-modal { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(30, 30, 30, 0.85); backdrop-filter: blur(5px); z-index: 9999999; display: flex; justify-content: center; align-items: center; opacity: 0; visibility: hidden; transition: all 0.4s ease; direction: rtl; }
                #reyhan-profile-modal * { font-family: 'ReyhanPopupFont', Tahoma, sans-serif !important; }
                #reyhan-profile-modal.is-visible { opacity: 1; visibility: visible; }
                .reyhan-modal-box { background: #fff; width: 90%; max-width: 380px; padding: 35px 30px; border-radius: 20px; box-shadow: 0 15px 40px rgba(0,0,0,0.4); text-align: center; transform: scale(0.95); transition: all 0.3s ease; position: relative; }
                #reyhan-profile-modal.is-visible .reyhan-modal-box { transform: scale(1); }
                .r-icon { font-size: 45px; margin-bottom: 10px; display: block; }
                .r-input { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 10px; margin-bottom: 15px; display:block; box-sizing: border-box;}
                .r-btn { width: 100%; padding: 12px; background: #6c5ce7; color: #fff; border: none; border-radius: 10px; cursor: pointer; font-weight: bold; }
                .r-btn:hover { background: #5a4bcf; }
                .r-msg { margin-top: 10px; font-size: 12px; color: #e74c3c; min-height: 18px; }
                .r-label { text-align: right; display: block; margin-bottom: 5px; font-weight: bold; font-size: 12px; color:#444;}
            </style>
            <div id="reyhan-profile-modal"><div class="reyhan-modal-box"><span class="r-icon">👤</span><h3 style="margin-top:0; font-weight:bold;">تکمیل اطلاعات</h3><p style="font-size:13px; color:#666; margin-bottom:20px">برای باز شدن دسترسی پنل، لطفا نام و نام خانوادگی خود را وارد کنید.</p><form id="reyhan-final-form"><label class="r-label">نام</label><input type="text" id="rf_fname" class="r-input" required><label class="r-label">نام خانوادگی</label><input type="text" id="rf_lname" class="r-input" required><button type="submit" class="r-btn">ثبت اطلاعات</button><div class="r-msg" id="r_status_msg"></div></form></div></div>
            <script>jQuery(document).ready(function($){setTimeout(function(){$('#reyhan-profile-modal').addClass('is-visible');},500);$('#reyhan-final-form').on('submit',function(e){e.preventDefault();var btn=$(this).find('.r-btn'),msg=$('#r_status_msg');var fname=$('#rf_fname').val(),lname=$('#rf_lname').val();if(fname.length<2||lname.length<2){msg.text('نام معتبر نیست.');return;}btn.text('...').prop('disabled',true);$.ajax({url:'<?php echo admin_url("admin-ajax.php"); ?>',type:'POST',dataType:'json',data:{action:'reyhan_save_details_final_action',firstname:fname,lastname:lname},success:function(res){if(res.success){location.reload();}else{msg.text(res.data);btn.text('تلاش مجدد').prop('disabled',false);}},error:function(){msg.text('خطا در ارتباط');btn.text('تلاش مجدد').prop('disabled',false);}});});});</script>
            <?php
        }
    }

    public function render_master_panel() {
        ob_start();
        echo '<div id="reyhan-app-root">';
        if ( ! is_user_logged_in() ) { 
            $this->load_view( 'view-login', $this->get_login_data() );
        } else { 
            $this->load_view( 'view-dashboard', $this->get_dashboard_data() );
        }
        echo '</div>';
        return ob_get_clean();
    }

    public function render_support_area_only() {
        if ( ! is_user_logged_in() ) return '<div class="rp-alert rp-alert-warning">برای دسترسی به پشتیبانی ابتدا وارد شوید.</div>';
        
        $opts = get_option('reyhan_options');
        ob_start();
        $this->load_view('view-support', [
            'opts' => $opts,
            'depts' => $opts['ticket_departments'] ?? []
        ]);
        return ob_get_clean();
    }

    // --- متد کمکی برای لود ویو ---
    private function load_view( $view_name, $args = [] ) {
        if ( ! empty( $args ) && is_array( $args ) ) {
            extract( $args );
        }
        $file = REYHAN_DIR . 'templates/frontend/' . $view_name . '.php';
        if ( file_exists( $file ) ) {
            include $file;
        }
    }

    // --- آماده‌سازی داده‌های لاگین ---
    private function get_login_data() {
        $opts = get_option('reyhan_options');
        $active_theme = $opts['login_active_theme'] ?? 'default';
        $palettes = $this->get_palettes();

        return [
            'opts' => $opts,
            'logo' => $opts['login_logo'] ?? '',
            'logo_w' => !empty($opts['login_logo_width']) ? intval($opts['login_logo_width']) : 100,
            'method' => $opts['auth_method'] ?? 'sms',
            'title' => $opts['login_custom_title'] ?: ($opts['login_title'] ?? 'ورود به حساب کاربری'),
            'sub' => $opts['login_custom_subtitle'] ?: 'اطلاعات خود را وارد کنید',
            'p' => $palettes[$active_theme] ?? $palettes['default'],
            'bg_mode' => $opts['login_bg_mode'] ?? 'image',
            'bg_image' => $opts['login_bg_image'] ?? '',
            'bg_color' => $opts['login_bg_color'] ?? '',
            'terms_id' => $opts['terms_page_id'] ?? 0
        ];
    }

    // --- آماده‌سازی داده‌های داشبورد ---
    private function get_dashboard_data() {
        $u = wp_get_current_user();
        $opts = get_option('reyhan_options');
        $active_theme = $opts['panel_active_theme'] ?? 'default';
        $palettes = $this->get_palettes();

        $fname = get_user_meta($u->ID, 'first_name', true) ?: 'کاربر';
        $lname = get_user_meta($u->ID, 'last_name', true) ?: 'جدید';
        $role_label = user_can($u, 'administrator') ? 'مدیر سایت' : 'کاربر عادی';
        $custom_avatar = get_user_meta($u->ID, 'reyhan_user_avatar', true);

        // منوها
        $menu_items = $opts['panel_menu_structure'] ?? [];
        if(empty($menu_items)) {
            $menu_items = [
                ['label'=>'داشبورد', 'icon'=>'dashicons-dashboard', 'action'=>'dashboard'],
                ['label'=>'پشتیبانی', 'icon'=>'dashicons-email-alt', 'action'=>'tickets'],
                ['label'=>'سفارشات', 'icon'=>'dashicons-cart', 'action'=>'orders'],
                ['label'=>'ویرایش حساب', 'icon'=>'dashicons-id', 'action'=>'profile'], 
                ['label'=>'خروج', 'icon'=>'dashicons-no-alt', 'action'=>'logout']
            ];
        }

        // آمار
        $tickets_open = $this->get_post_count('ticket', $u->ID, [['key'=>'_ticket_status', 'value'=>'closed', 'compare'=>'!=']]);
        $orders_count = class_exists('WooCommerce') ? count(wc_get_orders(['customer_id'=>$u->ID, 'return'=>'ids'])) : 0;
        $comments_count = get_comments(['user_id'=>$u->ID, 'count'=>true, 'status'=>'approve']);
        $days_diff = floor((time() - strtotime($u->user_registered)) / (60 * 60 * 24));

        return [
            'u' => $u,
            'opts' => $opts,
            'p' => $palettes[$active_theme] ?? $palettes['default'],
            'sb_img' => $opts['panel_sidebar_bg_image'] ?? '',
            'sb_overlay' => $opts['panel_sidebar_overlay_color'] ?? '',
            'display_name' => $fname . ' ' . $lname,
            'role_label' => $role_label,
            'is_agent_user' => user_can($u, 'manage_options') || in_array($u->ID, (array)($opts['ticket_support_agents'] ?? [])),
            'avatar_url' => $custom_avatar ?: REYHAN_URL . 'assets/images/user.png',
            'menu_items' => $menu_items,
            'notifications' => $opts['global_notifications'] ?? [],
            'count_tickets_open' => $tickets_open,
            'count_orders' => $orders_count,
            'count_comments' => $comments_count,
            'days_diff' => $days_diff,
            'faqs' => $opts['ticket_faqs'] ?? [],
            'depts' => $opts['ticket_departments'] ?? [],
            'auth_method' => $opts['auth_method'] ?? 'sms'
        ];
    }

    private function get_palettes() {
        return [
            'default' => [ 'gradient' => 'radial-gradient( circle farthest-corner at 10% 20%,  rgba(253, 187, 5, 1) 0%, rgba(245,139,139,1) 100.3% )', 'btn_bg' => '#FF5722', 'text_col' => '#FF5722', 'shadow' => 'rgba(255, 87, 34, 0.3)' ],
            'theme_1' => [ 'gradient' => 'radial-gradient( circle farthest-corner at -0.1% 0.5%,  rgba(15, 170, 64, 1) 0.1%, rgba(16, 170, 144, 1) 100.2% )', 'btn_bg' => '#0f8a40', 'text_col' => '#0f8a40', 'shadow' => 'rgba(15, 170, 64, 0.3)' ],
            'theme_2' => [ 'gradient' => 'linear-gradient( 103deg,  rgba(54,209,220,1) 15.7%, rgba(91,134,229,1) 88.8% )', 'btn_bg' => '#3f5efb', 'text_col' => '#3f5efb', 'shadow' => 'rgba(63, 94, 251, 0.3)' ],
            'theme_3' => [ 'gradient' => 'radial-gradient( circle farthest-corner at 10% 20%,  rgba(254,113,210,1) 0%, rgba(184,96,255,1) 90% )', 'btn_bg' => '#833ab4', 'text_col' => '#833ab4', 'shadow' => 'rgba(131, 58, 180, 0.3)' ],
            'theme_4' => [ 'gradient' => 'radial-gradient( circle 1106px at 91% 53.8%,  rgba(221,147,179,1) 9%, rgba(240,246,215,1) 68.1% )', 'btn_bg' => '#ae94e9', 'text_col' => '#9c7ddb', 'shadow' => 'rgba(148, 187, 233, 0.4)' ]
        ];
    }

    private function get_post_count($type, $author, $meta_query = []) {
        $args = [ 'post_type' => $type, 'posts_per_page' => -1, 'author' => $author, 'fields' => 'ids' ];
        if(!empty($meta_query)) $args['meta_query'] = $meta_query;
        $q = new WP_Query($args);
        return $q->found_posts;
    }
}