<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Reyhan_Auth {

    public function __construct() {
        // هوک‌های مربوط به ریدایرکت و امنیت ورود (بدون ایجکس)
        add_action( 'init', array( $this, 'redirect_wp_login_page' ) );
        add_filter( 'login_redirect', array( $this, 'custom_login_redirect' ), 10, 3 );
        add_action( 'wp_logout', array( $this, 'custom_logout_redirect' ) );
    }

    // --- مخفی کردن صفحه wp-login.php ---
    public function redirect_wp_login_page() {
        $opts = get_option('reyhan_options');
        
        // اگر تیک "مخفی کردن wp-admin" فعال باشد
        if ( !empty($opts['hide_wp_admin']) ) {
            global $pagenow;
            
            // چک می‌کنیم آیا کاربر لاگین کرده و آیا پشتیبان است؟
            $is_agent = false;
            if ( is_user_logged_in() ) {
                $uid = get_current_user_id();
                
                // بررسی دسترسی ایجنت (سازگار با سیستم جدید JSON)
                $agents_raw = $opts['ticket_support_agents_data'] ?? '[]';
                $agents_data = json_decode($agents_raw, true);
                
                if (is_array($agents_data)) {
                    foreach($agents_data as $a) {
                        if(intval($a['id']) === intval($uid)) {
                            $is_agent = true;
                            break;
                        }
                    }
                }
                
                if ( current_user_can('manage_options') ) {
                    $is_agent = true;
                }
            }

            // قانون: اگر در صفحه لاگین است + درخواست لاگین نیست + کاربر مجاز نیست -> ریدایرکت شود
            if ( $pagenow == 'wp-login.php' && !isset($_GET['action']) && !isset($_POST['log']) && !$is_agent ) {
                
                $page_id = $opts['login_page_id'] ?? 0;
                if ( $page_id ) {
                    wp_redirect( get_permalink($page_id) );
                    exit;
                }
            }
        }
    }

    // --- ریدایرکت بعد از ورود ---
    public function custom_login_redirect( $redirect_to, $request, $user ) {
        $opts = get_option('reyhan_options');
        
        // ۱. اولویت اول: آدرس تنظیم شده در پنل
        if ( !empty($opts['login_redirect_url']) ) {
            return $opts['login_redirect_url'];
        }
        
        // ۲. اولویت دوم: داشبورد ریحان
        $page_id = $opts['login_page_id'] ?? 0;
        if( $page_id ) {
            return get_permalink($page_id);
        }
        
        return $redirect_to;
    }

    // --- ریدایرکت بعد از خروج ---
    public function custom_logout_redirect() {
        $opts = get_option('reyhan_options');
        $url = !empty($opts['logout_redirect_url']) ? $opts['logout_redirect_url'] : home_url();
        wp_redirect( $url );
        exit;
    }
}