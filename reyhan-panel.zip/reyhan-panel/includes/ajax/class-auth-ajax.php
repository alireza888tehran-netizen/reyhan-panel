<?php
namespace Reyhan\Ajax;

if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once 'class-base-ajax.php';

class Auth_Ajax extends Base_Ajax {

    protected function register_actions() {
        // احراز هویت (ورود/عضویت/OTP)
        // آرگومان سوم true یعنی کاربر مهمان (لاگین نشده) هم دسترسی دارد
        $this->add_ajax_action( 'send_otp',        'handle_send_otp', true );
        $this->add_ajax_action( 'verify_otp',      'handle_verify_otp', true );
        $this->add_ajax_action( 'email_login',     'handle_email_login', true );
        $this->add_ajax_action( 'email_register',  'handle_email_register', true );

        // مدیریت پروفایل (فقط لاگین شده)
        $this->add_ajax_action( 'update_avatar',       'handle_update_avatar' );
        $this->add_ajax_action( 'update_general_info', 'handle_update_general_info' );
        $this->add_ajax_action( 'update_password',     'handle_update_password' );
        $this->add_ajax_action( 'send_otp_update',     'handle_send_otp_update' );
        $this->add_ajax_action( 'verify_otp_update',   'handle_verify_otp_update' );
        $this->add_ajax_action( 'save_details_final_action', 'handle_save_details_final', true );
    }

    // --- لاگین ایمیل ---
    public function handle_email_login() {
        $this->check_limit();
        $this->check_nonce();

        $email = sanitize_email( $_POST['log'] ?? '' );
        $pass  = $_POST['pwd'] ?? '';

        if ( ! is_email( $email ) ) $this->send_error( 'لطفاً یک ایمیل معتبر وارد کنید.' );

        $user = wp_signon( [
            'user_login'    => $email,
            'user_password' => $pass,
            'remember'      => true
        ], false );

        if ( is_wp_error( $user ) ) {
            $this->send_error( 'اطلاعات ورود اشتباه است.' );
        }
        $this->send_success( 'ورود موفقیت‌آمیز بود. در حال انتقال...' );
    }

    // --- لاگین OTP ---
    public function handle_send_otp() {
        $this->check_limit();
        $this->check_nonce();

        $mobile = sanitize_text_field( $_POST['mobile'] ?? '' );
        if ( ! preg_match( '/^09[0-9]{9}$/', $mobile ) ) {
            $this->send_error( 'شماره موبایل معتبر نیست' );
        }

        $code = rand( 12345, 98765 );
        set_transient( 'rp_otp_' . $mobile, $code, 120 ); // اعتبار 2 دقیقه

        if ( \Reyhan_SMS::send_otp( $mobile, $code ) ) {
            $this->send_success( 'کد ارسال شد' );
        } else {
            $this->send_error( 'خطا در ارسال پیامک' );
        }
    }

    public function handle_verify_otp() {
        $this->check_nonce();
        
        $mobile = sanitize_text_field( $_POST['mobile'] ?? '' );
        $code   = sanitize_text_field( $_POST['code'] ?? '' );
        
        if ( get_transient( 'rp_otp_' . $mobile ) != $code ) {
            $this->send_error( 'کد اشتباه است' );
        }
        
        delete_transient( 'rp_otp_' . $mobile );
        
        // لاگین یا ثبت نام
        $user = get_user_by( 'login', $mobile );
        if ( ! $user ) {
            $uid = wp_create_user( $mobile, wp_generate_password(), $mobile );
            update_user_meta( $uid, 'mobile', $mobile );
            $user = get_user_by( 'id', $uid );
        }
        
        wp_set_current_user( $user->ID, $user->user_login );
        wp_set_auth_cookie( $user->ID, true );
        $this->send_success( 'خوش آمدید' );
    }

    // --- ثبت نام ایمیل ---
    public function handle_email_register() {
        $this->check_limit();
        $this->check_nonce();

        $email = sanitize_email( $_POST['email'] ?? '' );
        $pass  = $_POST['pwd'] ?? '';
        $name  = sanitize_text_field( $_POST['name'] ?? '' );

        if ( ! is_email( $email ) ) $this->send_error( 'ایمیل معتبر نیست.' );
        if ( email_exists( $email ) || username_exists( $email ) ) $this->send_error( 'این ایمیل قبلاً ثبت شده است.' );
        if ( strlen( $pass ) < 6 ) $this->send_error( 'رمز عبور باید حداقل ۶ کاراکتر باشد.' );

        // بررسی ایمیل موقت
        $opts = get_option( 'reyhan_options' );
        if ( ! empty( $opts['block_disposable_emails'] ) ) {
            $domain = substr( strrchr( $email, "@" ), 1 );
            $blocked = [ 'temp-mail.org', '10minutemail.com', 'yopmail.com', 'mailinator.com' ]; // لیست نمونه
            if ( in_array( $domain, $blocked ) ) $this->send_error( 'ثبت‌نام با ایمیل موقت مجاز نیست.' );
        }

        $uid = wp_create_user( $email, $pass, $email );
        if ( is_wp_error( $uid ) ) $this->send_error( $uid->get_error_message() );

        // آپدیت نام
        if ( ! empty( $name ) ) {
            wp_update_user([ 'ID' => $uid, 'display_name' => $name, 'first_name' => $name ]);
        }

        // لاگین خودکار
        wp_set_current_user( $uid );
        wp_set_auth_cookie( $uid );
        
        // ارسال ایمیل خوش‌آمد (در گام‌های بعدی اضافه می‌شود)
        
        $this->send_success( 'ثبت‌نام موفقیت‌آمیز بود.' );
    }

    // --- پروفایل: آپلود آواتار ---
    public function handle_update_avatar() {
        $this->check_nonce();
        if ( ! is_user_logged_in() ) $this->send_error( 'وارد شوید.' );

        $file_url = $this->handle_upload( 'avatar' );
        if ( $file_url ) {
            update_user_meta( get_current_user_id(), 'reyhan_user_avatar', $file_url );
            $this->send_success( 'تصویر پروفایل تغییر کرد.' );
        }
        $this->send_error( 'خطا در آپلود.' );
    }

    // --- پروفایل: اطلاعات عمومی ---
    public function handle_update_general_info() {
        $this->check_nonce();
        $uid = get_current_user_id();
        $email = sanitize_email( $_POST['email'] ?? '' );
        
        if ( ! is_email( $email ) ) $this->send_error( 'ایمیل نامعتبر.' );
        if ( email_exists( $email ) && email_exists( $email ) != $uid ) $this->send_error( 'ایمیل تکراری است.' );

        $fname = sanitize_text_field( $_POST['first_name'] );
        $lname = sanitize_text_field( $_POST['last_name'] );

        wp_update_user([
            'ID'           => $uid,
            'first_name'   => $fname,
            'last_name'    => $lname,
            'user_email'   => $email,
            'display_name' => $fname . ' ' . $lname
        ]);
        $this->send_success( 'اطلاعات ذخیره شد.' );
    }

    // --- پروفایل: تغییر رمز ---
    public function handle_update_password() {
        $this->check_nonce();
        $pass = $_POST['pass'] ?? '';
        if ( strlen( $pass ) < 6 ) $this->send_error( 'رمز کوتاه است.' );
        
        wp_set_password( $pass, get_current_user_id() );
        $this->send_success( 'رمز عبور تغییر کرد.' );
    }

    // --- پروفایل: تغییر موبایل (ارسال کد) ---
    public function handle_send_otp_update() {
        $this->check_nonce();
        $mobile = sanitize_text_field( $_POST['mobile'] ?? '' );
        
        if ( ! preg_match( '/^09[0-9]{9}$/', $mobile ) ) $this->send_error( 'شماره موبایل صحیح نیست.' );
        
        $users = get_users( [ 'meta_key' => 'mobile', 'meta_value' => $mobile ] );
        if ( ! empty( $users ) ) $this->send_error( 'این شماره تکراری است.' );

        $code = rand( 12345, 98765 );
        set_transient( 'rp_update_otp_' . get_current_user_id(), [ 'mobile' => $mobile, 'code' => $code ], 300 );
        
        if ( \Reyhan_SMS::send_otp( $mobile, $code ) ) {
            $this->send_success( 'کد ارسال شد.' );
        } else {
            $this->send_error( 'خطا در ارسال پیامک.' );
        }
    }

    // --- پروفایل: تایید موبایل جدید ---
    public function handle_verify_otp_update() {
        $this->check_nonce();
        $uid = get_current_user_id();
        $code = sanitize_text_field( $_POST['code'] ?? '' );
        
        $data = get_transient( 'rp_update_otp_' . $uid );
        if ( ! $data || $data['code'] != $code ) {
            $this->send_error( 'کد اشتباه است.' );
        }
        
        update_user_meta( $uid, 'mobile', $data['mobile'] );
        delete_transient( 'rp_update_otp_' . $uid );
        $this->send_success( 'شماره موبایل تغییر کرد.' );
    }

    // --- تکمیل پروفایل اجباری ---
    public function handle_save_details_final() {
        $fname = sanitize_text_field( $_POST['firstname'] ?? '' );
        $lname = sanitize_text_field( $_POST['lastname'] ?? '' );
        
        if ( ! is_user_logged_in() ) $this->send_error( 'وارد نشده‌اید.' );
        if ( empty( $fname ) || empty( $lname ) ) $this->send_error( 'نام ناقص است.' );

        $uid = get_current_user_id();
        wp_update_user([ 
            'ID'           => $uid, 
            'first_name'   => $fname, 
            'last_name'    => $lname,
            'display_name' => "$fname $lname"
        ]);
        $this->send_success( 'انجام شد' );
    }

    // --- محدودیت تلاش (Rate Limit) ---
    private function check_limit() {
        $ip = $_SERVER['REMOTE_ADDR'];
        $transient = 'rp_limit_' . md5( $ip );
        $attempts = get_transient( $transient ) ?: 0;
        
        if ( $attempts >= 5 ) {
            $this->send_error( 'تعداد تلاش‌های شما بیش از حد مجاز است. لطفاً ۱۵ دقیقه صبر کنید.' );
        }
        set_transient( $transient, $attempts + 1, 15 * 60 );
    }
}