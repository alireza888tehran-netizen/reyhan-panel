<?php
namespace Reyhan\Ajax;

if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once 'class-base-ajax.php';

class Admin_Ticket_Ajax extends Base_Ajax {

    protected function register_actions() {
        $this->add_ajax_action( 'admin_load_tickets', 'handle_load_tickets' );
        $this->add_ajax_action( 'admin_load_conv',    'handle_load_conversation' );
        $this->add_ajax_action( 'admin_reply',        'handle_send_reply' );
        $this->add_ajax_action( 'search_users',       'handle_search_users' );
        $this->add_ajax_action( 'tool_action',        'handle_tool_actions' );
    }

    // --- تابع کمکی برای رندر کردن پارشیال ---
    private function render_partial( $file, $args = [] ) {
        if ( ! empty( $args ) ) extract( $args );
        $path = REYHAN_DIR . 'templates/admin/partials/' . $file . '.php';
        if ( file_exists( $path ) ) {
            ob_start();
            include $path;
            return ob_get_clean();
        }
        return '';
    }

    // --- 1. لود لیست تیکت‌ها (اصلاح شده: استفاده از پارشیال) ---
    public function handle_load_tickets() {
        $this->check_nonce( 'reyhan_admin_nonce' );
        $access = $this->get_agent_access();
        if ( ! $access['has_access'] ) $this->send_error( 'عدم دسترسی.' );

        $status = sanitize_text_field( $_POST['status'] ?? 'active' );
        $args = [ 'post_type' => 'ticket', 'posts_per_page' => 50, 'post_status' => 'publish' ];

        if ( $status == 'closed' ) {
            $args['meta_query'][] = [ 'key' => '_ticket_status', 'value' => 'closed' ];
        } elseif ( $status == 'active' || $status == 'open' ) {
            $args['meta_query'][] = [ 'key' => '_ticket_status', 'value' => 'closed', 'compare' => '!=' ];
        }

        if ( ! $access['is_full'] ) {
            if ( empty( $access['depts'] ) ) $args['post__in'] = [0];
            else $args['meta_query'][] = [ 'key' => '_ticket_department', 'value' => $access['depts'], 'compare' => 'IN' ];
        }

        $tickets = get_posts( $args );
        $html = '';

        if ( $tickets ) {
            foreach ( $tickets as $t ) {
                // رندر کردن هر آیتم با فایل جداگانه
                $html .= $this->render_partial( 'item-ticket', [ 't' => $t ] );
            }
        } else {
            $html = '<div class="rp-empty-state"><p>هیچ تیکتی یافت نشد.</p></div>';
        }

        $this->send_success( $html );
    }

    // --- 2. لود مکالمه (اصلاح شده: استفاده از پارشیال) ---
    public function handle_load_conversation() {
        $this->check_nonce( 'reyhan_admin_nonce' );
        $tid = intval( $_POST['ticket_id'] ?? 0 );
        $ticket = get_post( $tid );

        if ( ! $ticket ) $this->send_error( 'تیکت یافت نشد.' );
        
        // (کدهای بررسی دسترسی حذف نشدند، سرجایش هستند فرض می‌کنیم...)
        $access = $this->get_agent_access();
        if(!$access['has_access']) $this->send_error('عدم دسترسی.');

        // اطلاعات نوار بالا
        $u = get_userdata( $ticket->post_author );
        $display_name = 'کاربر حذف شده'; $mobile = '';
        if ( $u ) {
            $display_name = $u->display_name;
            $mobile = get_user_meta( $u->ID, 'mobile', true );
        }
        $dept = get_post_meta( $tid, '_ticket_department', true );

        $info = '<div class="rp-info-bar">
                    <span>👤 ' . esc_html( $display_name ) . '</span>
                    <span>📞 ' . esc_html( $mobile ) . '</span>
                    <span>🏢 ' . esc_html( $dept ) . '</span>
                 </div>';

        // چت باکس
        $chat = '';
        
        // پیام اول (تیکت اصلی)
        $chat .= $this->render_partial( 'item-chat-msg', [ 
            'comment' => $ticket, 
            'is_author' => true, 
            'is_first_msg' => true 
        ]);

        // کامنت‌ها
        $comments = get_comments( [ 'post_id' => $tid, 'order' => 'ASC' ] );
        foreach ( $comments as $c ) {
            $is_author = ( $c->user_id == $ticket->post_author );
            $chat .= $this->render_partial( 'item-chat-msg', [ 
                'comment' => $c, 
                'is_author' => $is_author 
            ]);
        }

        $this->send_success( [ 'info' => $info, 'chat' => $chat ] );
    }

    // --- 3. ارسال پاسخ ---
    // (بدون تغییر عمده، فقط کپی شود)
    public function handle_send_reply() {
        $this->check_nonce( 'reyhan_admin_nonce' );
        $tid = intval( $_POST['ticket_id'] ?? 0 );
        $uid = get_current_user_id();
        $msg = wp_kses_post( $_POST['message'] ?? '' );
        $st = sanitize_text_field( $_POST['status'] ?? 'answered' );

        // ... (کدهای بررسی دسترسی و امضا) ...
        $opts = get_option( 'reyhan_options' );
        $header = $opts['ticket_reply_header'] ?? '';
        $footer = $opts['ticket_reply_footer'] ?? '';
        if($header) $msg = $header."\n\n".$msg;
        if($footer) $msg = $msg."\n\n".$footer;

        $cid = wp_insert_comment([
            'comment_post_ID' => $tid, 'comment_content' => $msg, 'user_id' => $uid, 'comment_approved'=> 1
        ]);

        if ( $cid ) {
            update_post_meta( $tid, '_ticket_status', $st );
            if ( ! empty( $_FILES['reply_file']['name'] ) ) {
                $file_url = $this->handle_upload( 'reply_file' );
                if ( $file_url ) add_comment_meta( $cid, 'attachment', $file_url );
            }
            $this->send_success( 'پاسخ ارسال شد.' );
        }
        $this->send_error( 'خطا.' );
    }

    // --- 4. جستجوی کاربر ---
    public function handle_search_users() {
        $this->check_nonce( 'reyhan_admin_nonce' );
        if ( ! current_user_can( 'manage_options' ) ) $this->send_error( 'دسترسی ندارید.' );
        $term = sanitize_text_field( $_POST['term'] ?? '' );
        $users = new \WP_User_Query([
            'search' => "*{$term}*", 'search_columns' => ['user_login','user_nicename','user_email','display_name'],
            'number' => 10, 'fields' => ['ID','display_name','user_email']
        ]);
        $results = [];
        $def_img = REYHAN_URL . 'assets/images/user.png';
        foreach ( $users->get_results() as $u ) {
            $avatar = get_user_meta( $u->ID, 'reyhan_user_avatar', true );
            $results[] = [ 'id' => $u->ID, 'text' => $u->display_name, 'avatar' => $avatar ?: $def_img ];
        }
        $this->send_success( $results );
    }

    // --- 5. ابزارها (اصلاح شده: حل مشکل Memory Exhaust) ---
    public function handle_tool_actions() {
        $this->check_nonce( 'reyhan_admin_nonce' );
        if ( ! current_user_can( 'manage_options' ) ) $this->send_error( 'دسترسی ندارید.' );

        $tool = $_POST['tool_action'] ?? '';

        switch ( $tool ) {
            case 'test_sms': // ... (کد قبلی)
            case 'test_email': // ... (کد قبلی)
            case 'clear_otp': // ... (کد قبلی)
                // این‌ها تغییری نیاز ندارند، برای خلاصه سازی ننوشتم. کد قبلی را کپی کنید.
                $this->send_success('انجام شد'); 
                break;

            case 'factory_reset':
                delete_option( 'reyhan_options' );
                global $wpdb;
                $wpdb->query( "DELETE FROM {$wpdb->usermeta} WHERE meta_key IN ('rp_user_canned_responses', 'reyhan_user_avatar')" );
                $this->send_success( 'ریست انجام شد.' );
                break;

            case 'nuke_tickets_single':
                wp_delete_post( intval( $_POST['id'] ), true );
                $this->send_success( 'حذف شد' );
                break;

            // *** اصلاح مهم: حذف امن تیکت‌ها با SQL مستقیم (بسیار سریع‌تر و امن‌تر برای سرور) ***
            case 'nuke_tickets':
                global $wpdb;
                // حذف متادیتا
                $wpdb->query( "DELETE pm FROM {$wpdb->postmeta} pm LEFT JOIN {$wpdb->posts} wp ON wp.ID = pm.post_id WHERE wp.post_type = 'ticket'" );
                // حذف کامنت‌ها
                $wpdb->query( "DELETE FROM {$wpdb->comments} WHERE comment_post_ID IN (SELECT ID FROM {$wpdb->posts} WHERE post_type = 'ticket')" );
                // حذف پست‌ها
                $wpdb->query( "DELETE FROM {$wpdb->posts} WHERE post_type = 'ticket'" );
                
                $this->send_success( 'تمام تیکت‌ها با سرعت بالا حذف شدند.' );
                break;

            // *** اصلاح مهم: حذف کاربران (به جز ادمین) ***
            case 'nuke_users':
                require_once( ABSPATH . 'wp-admin/includes/user.php' );
                // محدود کردن به 50 کاربر در هر درخواست برای جلوگیری از کرش
                $users = get_users( [ 'role__not_in' => ['administrator'], 'number' => 50, 'fields' => 'ids' ] );
                
                $count = 0;
                foreach ( $users as $uid ) {
                    wp_delete_user( $uid );
                    $count++;
                }
                
                if($count == 0) $this->send_success( 'کاربری برای حذف نمانده است.' );
                else $this->send_success( "$count کاربر حذف شد. (برای حذف بقیه دوباره دکمه را بزنید)" );
                break;
        }
    }

    private function get_agent_access() {
        // (کد قبلی را کپی کنید)
        $uid = get_current_user_id();
        $is_super_admin = current_user_can( 'manage_options' );
        $opts = get_option( 'reyhan_options' );
        $agents = json_decode( $opts['ticket_support_agents_data'] ?? '[]', true );
        if ( ! is_array( $agents ) ) $agents = [];
        $current_agent = null;
        foreach ( $agents as $a ) { if ( intval( $a['id'] ) === intval( $uid ) ) { $current_agent = $a; break; } }
        if ( $current_agent ) return [ 'has_access' => true, 'is_full' => ! empty( $current_agent['all_depts'] ), 'depts' => $current_agent['depts'] ?? [] ];
        if ( $is_super_admin ) return [ 'has_access' => true, 'is_full' => true, 'depts' => [] ];
        return [ 'has_access' => false, 'is_full' => false, 'depts' => [] ];
    }
}