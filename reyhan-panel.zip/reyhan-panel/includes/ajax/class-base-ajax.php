<?php
namespace Reyhan\Ajax;

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * کلاس پایه انتزاعی برای مدیریت درخواست‌های ایجکس
 */
abstract class Base_Ajax {

    protected $prefix = 'reyhan_';

    public function __construct() {
        $this->register_actions();
    }

    abstract protected function register_actions();

    protected function add_ajax_action( $tag, $method, $nopriv = false ) {
        $action_name = $this->prefix . $tag;
        add_action( 'wp_ajax_' . $action_name, [ $this, $method ] );
        if ( $nopriv ) {
            add_action( 'wp_ajax_nopriv_' . $action_name, [ $this, $method ] );
        }
    }

    protected function check_nonce( $action_name = 'reyhan_auth_nonce', $query_arg = 'security' ) {
        if ( ! check_ajax_referer( $action_name, $query_arg, false ) ) {
            $this->send_error( 'خطای امنیتی: درخواست نامعتبر است.', 403 );
        }
    }

    protected function send_success( $data = null ) {
        wp_send_json_success( $data );
    }

    protected function send_error( $message, $code = 400 ) {
        wp_send_json_error( $message, $code );
    }

    /**
     * مدیریت امن آپلود فایل
     * * @param string $file_key کلید فایل در آرایه $_FILES
     * @return int|false شناسه attachment یا false در صورت خطا
     */
    protected function handle_upload( $file_key ) {
        if ( empty( $_FILES[ $file_key ]['name'] ) ) {
            return false;
        }

        $file = $_FILES[ $file_key ];
        $opts = get_option( 'reyhan_options' );

        // 1. بررسی حجم (تبدیل مگابایت به بایت)
        $max_size_mb = ! empty( $opts['file_max_size'] ) ? floatval( $opts['file_max_size'] ) : 2;
        if ( $file['size'] > $max_size_mb * 1024 * 1024 ) {
            $this->send_error( "حجم فایل نباید بیشتر از $max_size_mb مگابایت باشد." );
        }

        // 2. بررسی فرمت‌های مجاز از تنظیمات
        $allowed_exts_str = ! empty( $opts['file_allowed_extensions'] ) ? $opts['file_allowed_extensions'] : 'jpg,png,pdf,zip';
        $allowed_array = array_map( 'trim', explode( ',', strtolower( $allowed_exts_str ) ) );
        
        $file_info = wp_check_filetype( $file['name'] );
        if ( ! in_array( strtolower( $file_info['ext'] ), $allowed_array ) ) {
            $this->send_error( 'فرمت فایل مجاز نیست.' );
        }

        // 3. استفاده از توابع وردپرس برای آپلود امن
        if ( ! function_exists( 'wp_handle_upload' ) ) {
            require_once( ABSPATH . 'wp-admin/includes/file.php' );
        }

        $upload_overrides = [ 'test_form' => false ];
        $movefile = wp_handle_upload( $file, $upload_overrides );

        if ( $movefile && ! isset( $movefile['error'] ) ) {
            // فایل با موفقیت آپلود شد، حالا آن را به عنوان Attachment ثبت می‌کنیم (برای امنیت بیشتر و دسترسی راحت‌تر)
            // اگر نمی‌خواهید در Media Library دیده شود، می‌توانید این بخش را تغییر دهید، اما استاندارد وردپرس این است.
            
            // البته در کد قبلی شما فقط URL ذخیره می‌شد. اینجا هم می‌توانیم URL برگردانیم.
            // اما برای سازگاری با کدهای فرانت شما که URL می‌خواهند:
            return $movefile['url']; 
        } else {
            $this->send_error( isset( $movefile['error'] ) ? $movefile['error'] : 'خطا در آپلود فایل.' );
        }

        return false;
    }
}