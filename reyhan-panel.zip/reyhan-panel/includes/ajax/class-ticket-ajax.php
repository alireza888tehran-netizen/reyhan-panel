<?php
namespace Reyhan\Ajax;

if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once 'class-base-ajax.php';

class Ticket_Ajax extends Base_Ajax {

    protected function register_actions() {
        $this->add_ajax_action( 'user_submit', 'handle_submit_ticket' );
        $this->add_ajax_action( 'user_list',   'handle_get_tickets' );
        $this->add_ajax_action( 'user_view',   'handle_view_ticket' );
        $this->add_ajax_action( 'user_reply',  'handle_reply_ticket' );
        $this->add_ajax_action( 'user_close',  'handle_close_ticket' );
    }

    // --- متد کمکی لود قالب (مشابه ادمین) ---
    private function load_view( $view, $args = [] ) {
        if ( ! empty( $args ) ) extract( $args );
        
        // مسیر فایل‌های پارشیال یا ویو اصلی
        $path = REYHAN_DIR . 'templates/frontend/' . $view . '.php';
        
        if ( file_exists( $path ) ) {
            ob_start();
            include $path;
            return ob_get_clean();
        }
        return '';
    }

    // 1. ثبت تیکت (بدون تغییر)
    public function handle_submit_ticket() {
        $this->check_nonce();
        $uid = get_current_user_id();
        if ( ! $uid ) $this->send_error( 'لطفاً وارد شوید.' );

        if ( $this->is_flooding( $uid ) ) $this->send_error( 'لطفاً کمی صبر کنید.' );

        $title = sanitize_text_field( $_POST['title'] ?? '' );
        $msg   = sanitize_textarea_field( $_POST['message'] ?? '' );
        $dept  = sanitize_text_field( $_POST['department'] ?? '' );
        $prio  = sanitize_text_field( $_POST['priority'] ?? 'medium' );

        if ( empty( $title ) || empty( $msg ) ) $this->send_error( 'موضوع و متن الزامی است.' );
        if ( mb_strlen( $msg, 'UTF-8' ) < 10 ) $this->send_error( 'متن پیام بسیار کوتاه است.' );

        $post_id = wp_insert_post([
            'post_title' => $title, 'post_content' => $msg, 'post_status' => 'publish',
            'post_type' => 'ticket', 'post_author' => $uid
        ]);

        if ( is_wp_error( $post_id ) ) $this->send_error( 'خطا در ثبت تیکت.' );

        update_post_meta( $post_id, '_ticket_department', $dept );
        update_post_meta( $post_id, '_ticket_priority', $prio );
        update_post_meta( $post_id, '_ticket_status', 'open' );
        update_user_meta( $uid, '_reyhan_last_ticket_time', time() );

        if ( ! empty( $_FILES['attachment']['name'] ) ) {
            $file_url = $this->handle_upload( 'attachment' );
            if ( $file_url ) update_post_meta( $post_id, '_ticket_attachment', $file_url );
        }

        $this->send_success( 'تیکت شما با موفقیت ثبت شد.' );
    }

    // 2. لیست تیکت‌ها (اصلاح شده: استفاده از پارشیال)
    public function handle_get_tickets() {
        $this->check_nonce();
        $uid = get_current_user_id();
        if ( ! $uid ) $this->send_error( 'وارد شوید.' );

        $tickets = get_posts([ 'post_type' => 'ticket', 'author' => $uid, 'posts_per_page' => 50, 'post_status' => 'publish' ]);

        if ( empty( $tickets ) ) {
            $this->send_success( '<div style="text-align:center; padding:30px; color:#999;">هیچ تیکتی یافت نشد.</div>' );
            return;
        }

        ob_start();
        echo '<table class="rp-ticket-table"><thead><tr><th>#</th><th>موضوع</th><th style="text-align:center;">وضعیت</th><th style="text-align:center;">تاریخ</th><th style="text-align:center;">عملیات</th></tr></thead><tbody>';
        
        foreach( $tickets as $t ) {
            // استفاده از پارشیال برای هر سطر
            echo $this->load_view( 'partials/row-ticket', [ 't' => $t ] );
        }
        
        echo '</tbody></table>';
        $this->send_success( ob_get_clean() );
    }

    // 3. مشاهده تیکت (اصلاح شده: استفاده از ویو کامل)
    public function handle_view_ticket() {
        $this->check_nonce();
        $tid = intval( $_POST['ticket_id'] ?? 0 );
        $uid = get_current_user_id();
        $ticket = get_post( $tid );

        if ( ! $ticket || $ticket->post_author != $uid ) $this->send_error( 'دسترسی غیرمجاز.' );

        // آماده‌سازی داده‌ها برای ویو
        $data = [
            'ticket'   => $ticket,
            'status'   => get_post_meta( $tid, '_ticket_status', true ),
            'dept'     => get_post_meta( $tid, '_ticket_department', true ),
            'comments' => get_comments(['post_id' => $tid, 'order' => 'ASC'])
        ];

        // لود کردن کل ویو به صورت یکجا
        $html = $this->load_view( 'view-single-ticket', $data );
        $this->send_success( $html );
    }

    // 4. پاسخ تیکت (بدون تغییر)
    public function handle_reply_ticket() {
        $this->check_nonce();
        $tid = intval( $_POST['ticket_id'] ?? 0 );
        $msg = sanitize_textarea_field( $_POST['reply_message'] ?? '' );
        $uid = get_current_user_id();

        $ticket = get_post( $tid );
        if ( ! $ticket || $ticket->post_author != $uid ) $this->send_error( 'دسترسی غیرمجاز.' );
        if ( empty( $msg ) ) $this->send_error( 'متن خالی است.' );

        $cid = wp_insert_comment([
            'comment_post_ID' => $tid, 'comment_content' => $msg, 'user_id' => $uid, 'comment_approved'=> 1
        ]);

        if ( $cid ) {
            update_post_meta( $tid, '_ticket_status', 'open' );
            if ( ! empty( $_FILES['reply_attachment']['name'] ) ) {
                $url = $this->handle_upload( 'reply_attachment' );
                if ( $url ) add_comment_meta( $cid, 'attachment', $url );
            }
            $this->send_success( 'ارسال شد' );
        }
        $this->send_error( 'خطا.' );
    }

    // 5. بستن تیکت (بدون تغییر)
    public function handle_close_ticket() {
        $this->check_nonce();
        $tid = intval( $_POST['ticket_id'] ?? 0 );
        $uid = get_current_user_id();
        $ticket = get_post( $tid );
        if ( ! $ticket || $ticket->post_author != $uid ) $this->send_error( 'دسترسی غیرمجاز.' );

        update_post_meta( $tid, '_ticket_status', 'closed' );
        $this->send_success( 'تیکت بسته شد.' );
    }

    private function is_flooding( $user_id ) {
        $opts = get_option( 'reyhan_options' );
        $interval = ! empty( $opts['ticket_flood_interval'] ) ? intval( $opts['ticket_flood_interval'] ) : 60;
        $last = get_user_meta( $user_id, '_reyhan_last_ticket_time', true );
        return ( $last && ( time() - $last < $interval ) );
    }
}