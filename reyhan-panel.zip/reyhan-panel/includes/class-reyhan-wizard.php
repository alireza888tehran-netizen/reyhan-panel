<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Reyhan_Wizard {

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'register_wizard_page' ) );
        add_action( 'admin_init', array( $this, 'redirect_to_wizard' ) );
        add_action( 'wp_ajax_reyhan_wizard_save', array( $this, 'save_wizard_data' ) );
        
        // لود استایل و اسکریپت فقط در صفحه ویزارد
        if ( isset($_GET['page']) && $_GET['page'] == 'reyhan-setup' ) {
            add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_wizard_assets' ) );
        }
    }

    public function register_wizard_page() {
        add_dashboard_page( 'راه‌اندازی ریحان پنل', 'راه‌اندازی ریحان پنل', 'manage_options', 'reyhan-setup', array( $this, 'render_wizard' ) );
    }

    public function redirect_to_wizard() {
        if ( get_option( 'reyhan_do_activation_redirect', false ) ) {
            delete_option( 'reyhan_do_activation_redirect' );
            if ( ! isset( $_GET['activate-multi'] ) ) {
                wp_safe_redirect( admin_url( 'index.php?page=reyhan-setup' ) );
                exit;
            }
        }
    }

    public function enqueue_wizard_assets() {
        wp_enqueue_media();
        wp_enqueue_style( 'reyhan-wizard-css', REYHAN_URL . 'assets/css/wizard.css', array(), REYHAN_VERSION );
        wp_enqueue_script( 'reyhan-wizard-js', REYHAN_URL . 'assets/js/wizard.js', array('jquery'), REYHAN_VERSION, true );
    }

    public function render_wizard() {
        // فراخوانی ویو
        $file = REYHAN_DIR . 'templates/admin/view-wizard.php';
        if ( file_exists( $file ) ) {
            include $file;
        }
    }

    public function save_wizard_data() {
        // (این بخش منطق دیتابیس است و بدون تغییر می‌ماند)
        $opts = get_option('reyhan_options');
        if(!is_array($opts)) $opts = [];

        if ( isset($_POST['create_page']) && $_POST['create_page'] == '1' ) {
            $page_id = wp_insert_post(array(
                'post_title'    => 'پنل کاربری',
                'post_content'  => '[reyhan_panel]',
                'post_status'   => 'publish',
                'post_type'     => 'page',
                'comment_status'=> 'closed'
            ));
            if(!is_wp_error($page_id)) {
                $opts['login_page_id'] = $page_id;
            }
        }

        if(!empty($_POST['login_logo'])) $opts['login_logo'] = sanitize_text_field($_POST['login_logo']);
        if(!empty($_POST['login_title'])) $opts['login_custom_title'] = sanitize_text_field($_POST['login_title']);

        update_option('reyhan_options', $opts);
        wp_send_json_success();
    }
}