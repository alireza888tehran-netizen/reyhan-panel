<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Reyhan_Settings {

    private $options;

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_admin_menus' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        add_action( 'admin_init', array( $this, 'handle_create_page_action' ) );
        add_action( 'admin_menu', array( $this, 'restrict_agent_menus' ), 999 );
        add_action( 'init', array( $this, 'force_show_admin_bar_for_agents' ) );
        add_action( 'admin_init', array( $this, 'redirect_agent_from_dashboard' ) );
        add_action( 'admin_bar_menu', array( $this, 'add_agent_toolbar_items' ), 100 );
        add_filter( 'woocommerce_prevent_admin_access', array( $this, 'allow_agent_admin_access' ) );
        add_action( 'template_redirect', array( $this, 'redirect_woocommerce_to_reyhan' ) );
        add_action( 'admin_init', array( $this, 'handle_agent_profile_save' ) );
    }

    public function is_support_agent() {
        if ( ! is_user_logged_in() ) return false;
        
        $uid = get_current_user_id();
        $opts = get_option('reyhan_options');
        
        // 1. بررسی در سیستم جدید (JSON)
        $agents_raw = $opts['ticket_support_agents_data'] ?? '[]';
        $agents_data = json_decode($agents_raw, true);
        
        if ( is_array($agents_data) ) {
            foreach ( $agents_data as $agent ) {
                // مقایسه شناسه کاربر
                if ( isset($agent['id']) && intval($agent['id']) === intval($uid) ) {
                    return true;
                }
            }
        }
        
        // 2. بررسی در سیستم قدیمی (برای پشتیبانی از قبل)
        $old_agents = $opts['ticket_support_agents'] ?? [];
        if ( is_array($old_agents) && in_array($uid, $old_agents) ) {
            return true;
        }
        
        return false;
    }

    public function restrict_agent_menus() {
        if ( ! is_user_logged_in() || current_user_can('manage_options') ) {
            return;
        }

        $is_agent = $this->is_support_agent();

        if ( $is_agent ) {
            $is_content_creator = ( current_user_can('edit_posts') || current_user_can('publish_posts') );

            // اگر کاربر عادی است
            if ( ! $is_content_creator ) {
                remove_menu_page( 'index.php' );
                remove_menu_page( 'edit.php' );
                remove_menu_page( 'upload.php' );
                remove_menu_page( 'edit.php?post_type=page' );
                remove_menu_page( 'edit-comments.php' );
                remove_menu_page( 'themes.php' );
                remove_menu_page( 'plugins.php' );
                remove_menu_page( 'users.php' );
                remove_menu_page( 'tools.php' );
                remove_menu_page( 'options-general.php' );
                remove_menu_page( 'profile.php' ); 
            }
            
            remove_menu_page( 'reyhan-settings' );
        }
    }

    public function force_show_admin_bar_for_agents() {
        // اگر کاربر پشتیبان است و ادمین نیست
        if ( $this->is_support_agent() && !current_user_can('manage_options') ) {
            // اجبار به نمایش نوار مدیریت با اولویت بالا
            add_filter( 'show_admin_bar', '__return_true', 999 );
        }
    }

    public function add_agent_toolbar_items( $wp_admin_bar ) {
        // اگر پشتیبان نیست، یا اگر مدیر کل (Administrator) است، چیزی نشان نده
        if ( ! $this->is_support_agent() || current_user_can('manage_options') ) {
            return;
        }

        $wp_admin_bar->add_node( array(
            'id'    => 'rp-toolbar-tickets',
            'title' => '<span class="ab-icon dashicons dashicons-email-alt"></span> تیکت‌های پشتیبانی',
            'href'  => admin_url( 'admin.php?page=reyhan-tickets' ),
            'meta'  => array( 'class' => 'rp-toolbar-item' )
        ));
        
        $wp_admin_bar->add_node( array(
            'id'    => 'rp-toolbar-profile',
            'title' => '<span class="ab-icon dashicons dashicons-id-alt"></span> ویرایش پروفایل',
            'href'  => admin_url( 'profile.php' ),
            'meta'  => array( 'class' => 'rp-toolbar-item' )
        ));
    }

    public function redirect_woocommerce_to_reyhan() {
        if ( class_exists('WooCommerce') && is_account_page() ) {
            
            $opts = get_option('reyhan_options');
            $panel_page_id = $opts['login_page_id'] ?? 0;

            if ( $panel_page_id ) {
                if ( is_page($panel_page_id) ) return;

                wp_redirect( get_permalink($panel_page_id) );
                exit;
            }
        }
    }

    public function allow_agent_admin_access( $prevent_access ) {
        if ( $this->is_support_agent() ) {
            return false;
        }
        return $prevent_access;
    }

    public function redirect_agent_from_dashboard() {
        global $pagenow;
        
        // اگر کاربر پشتیبان است و ادمین نیست
        if ( $this->is_support_agent() && !current_user_can('manage_options') ) {
            
            // اگر کاربر عادی (غیر نویسنده) است و می‌خواهد پیشخوان را ببیند -> ریدایرکت به تیکت‌ها
            if ( !current_user_can('edit_posts') && $pagenow == 'index.php' ) {
                wp_redirect( admin_url( 'admin.php?page=reyhan-tickets' ) );
                exit;
            }
        }
    }

    public function add_admin_menus() {
        $is_super_admin = current_user_can('manage_options');
        $is_agent = $this->is_support_agent();

        // --- حالت ۱: برای مدیر کل (Admin) ---
        if ( $is_super_admin ) {
            add_menu_page(
            'تنظیمات ریحان پنل', 
            'ریحان پنل', 
            'manage_options', 
            'reyhan-settings', 
            array( $this, 'render_general_page' ), 
            REYHAN_URL . 'assets/images/icon-panel.png', // آدرس آیکون جدید
            50
            );
            add_submenu_page('reyhan-settings', 'تنظیمات عمومی', 'تنظیمات عمومی', 'manage_options', 'reyhan-settings', array( $this, 'render_general_page' ));
            add_submenu_page('reyhan-settings', 'استایل پنل کاربری', 'استایل پنل کاربری', 'manage_options', 'reyhan-user-panel', array( $this, 'render_user_panel_page' ));
            add_submenu_page('reyhan-settings', 'اطلاعیه پنل کاربری', 'اطلاعیه پنل کاربری', 'manage_options', 'reyhan-notifications', array( $this, 'render_notifications_page' ));
            // مدیر هم به تیکت‌ها دسترسی دارد اما در منوی جداگانه
            add_menu_page(
            'مدیریت تیکت‌ها', 
            'تیکت ها', 
            'manage_options', 
            'reyhan-tickets', 
            array( $this, 'render_tickets_manager' ), 
            REYHAN_URL . 'assets/images/icon-ticket.png', // آدرس آیکون جدید
            51
            );
        }
        
        // --- حالت ۲: برای پشتیبان (Agent) که مدیر نیست ---
        else if ( $is_agent ) {
            // ۱. منوی مادر (ریحان پنل)
            add_menu_page(
            'پنل پشتیبان', 
            'ریحان پنل', 
            'read', 
            'reyhan-agent-panel', 
            array( $this, 'render_tickets_manager' ), 
            REYHAN_URL . 'assets/images/icon-panel.png', // <--- تغییر آیکون در اینجا
            50
            );
            
            // ۲. زیرمنوی تیکت‌ها (به عنوان پیش‌فرض)
            add_submenu_page('reyhan-agent-panel', 'تیکت‌های پشتیبانی', 'تیکت‌های پشتیبانی', 'read', 'reyhan-tickets', array( $this, 'render_tickets_manager' ));
            
            // ۳. زیرمنوی ویرایش پروفایل (جدید)
            add_submenu_page('reyhan-agent-panel', 'ویرایش پروفایل', 'ویرایش پروفایل', 'read', 'reyhan-agent-profile', array( $this, 'render_agent_profile_page' ));
            
            // حذف آیتم تکراری منوی مادر
            remove_submenu_page('reyhan-agent-panel', 'reyhan-agent-panel');
        }
    }

    public function maybe_show_notification() {
        if ( isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true' ) {
            // ساختار جدید HTML برای توست
            echo '<div id="reyhan-toast-msg" class="rp-modern-toast">
                    <span class="dashicons dashicons-saved"></span> 
                    <span>تغییرات با موفقیت ذخیره شد.</span>
                  </div>';
        }
    }

    public function handle_create_page_action() {
        if ( isset($_GET['reyhan_action']) && $_GET['reyhan_action'] == 'create_page' && current_user_can('manage_options') ) {
            $opts = get_option('reyhan_options');
            $existing_id = $opts['login_page_id'] ?? 0;
            
            if ( ! ($existing_id && get_post($existing_id)) ) {
                $page_id = wp_insert_post(array('post_title'=>'ورود به پنل', 'post_content'=>'[reyhan_panel]', 'post_status'=>'publish', 'post_type'=>'page', 'post_name'=>'login', 'comment_status'=>'closed'));
                if ( !is_wp_error($page_id) ) {
                    if(!is_array($opts)) $opts = [];
                    $opts['login_page_id'] = $page_id;
                    update_option('reyhan_options', $opts);
                }
            }
            wp_redirect( remove_query_arg('reyhan_action') ); exit;
        }
    }

    public function render_general_page() {
        $this->options = get_option('reyhan_options');
        $defaults = array(
            'recaptcha_active'        => '0',            // گوگل ریکپچا: غیرفعال
            'login_max_attempts'      => '5',            // حداکثر تلاش: 5
            'login_lockout_time'      => '15',           // زمان مسدودی: 15
            'file_allowed_extensions' => 'pdf,jpg,png',  // فرمت‌ها
            'file_max_size'           => '1',            // حجم: 1 مگابایت
            'ticket_flood_interval'   => '60',           // فاصله تیکت: 60
            'block_disposable_emails' => '1'             // ایمیل موقت: فعال
        );
        if ( ! is_array($this->options) ) { $this->options = array(); }
        $this->options = wp_parse_args( $this->options, $defaults );

        $guide_style = 'color:#666; font-size:13px; margin-bottom:20px; background:#fffbe5; padding:10px; border:1px solid #ffe58f; border-radius:5px; line-height:1.6;';
        ?>
        
        <div class="wrap ticketina-wrap">
            <div class="rp-title-area">
                <h1><span class="dashicons dashicons-email-alt"></span> تنظیمات عمومی</h1>
                <p style="color:#777; margin-top:5px; font-size:12px;">در این بخش تنظیمات عمومی ریحان پنل را تنظیم کنید.</p>
            </div>
            <?php $this->maybe_show_notification(); ?>
            <form method="post" action="options.php">
                <?php settings_fields('reyhan_master_group'); ?>
                
                <div class="rp-settings-container"> 
                    <div class="rp-settings-sidebar">
                        <div class="rp-sidebar-logo"><img src="<?php echo REYHAN_URL . 'assets/images/logo.png'; ?>" alt="Logo"></div>
                        <ul class="rp-tabs-nav" id="rp-main-nav">
                            <li class="active" data-tab="tab-login"><span class="dashicons dashicons-admin-users"></span> ورود و عضویت</li>
                            <li data-tab="tab-sms"><span class="dashicons dashicons-smartphone"></span> پیامک پنل کاربری</li>
                            <li data-tab="tab-email"><span class="dashicons dashicons-email"></span> ایمیل پنل کاربری</li>
                            <li data-tab="tab-ticket"><span class="dashicons dashicons-tickets-alt"></span> تنظیمات تیکت</li>
                            <li data-tab="tab-security"><span class="dashicons dashicons-shield"></span> امنیت</li>
                            <li data-tab="tab-tools"><span class="dashicons dashicons-admin-tools"></span> ابزارها</li>
                        </ul>
                        <div class="rp-save-box">
                            <?php submit_button('ذخیره تغییرات', 'primary', 'submit', false); ?>
                            <div class="rp-version-info">نسخه <?php echo REYHAN_VERSION; ?></div>
                        </div>
                    </div> 
                    <div class="rp-settings-content">
                        
                        <div id="tab-login" class="rp-tab-pane active">
                            <h2>تنظیمات ورود و عضویت</h2>
                            <p style="<?php echo $guide_style; ?>">💡 <strong>راهنما:</strong> تنظیمات ورود و عضویت رو اینجا انجام بده</p>
                            <table class="form-table"><?php do_settings_fields('reyhan-general', 'sec_login'); ?></table>
                        </div>

                        <div id="tab-sms" class="rp-tab-pane">
                            <h2>تنظیمات پیامک اطلاع رسانی</h2>
                            <p style="<?php echo $guide_style; ?>">💡 <strong>راهنما:</strong> تنظیمات پیامکی برای پنل ورود رو اینجا انجام بده</p>
                            <table class="form-table"><?php do_settings_fields('reyhan-general', 'sec_sms'); ?></table>
                        </div>

                        <div id="tab-email" class="rp-tab-pane">
                            <h2>تنظیمات ایمیل اطلاع رسانی</h2>
                            <p style="<?php echo $guide_style; ?>">💡 <strong>راهنما:</strong> تنظیمات ایمیل های اطلاع رسانی رو اینجا انجام بده</p>
                            <table class="form-table"><?php do_settings_fields('reyhan-general', 'sec_email'); ?></table>
                        </div>

                        <div id="tab-ticket" class="rp-tab-pane">
                            <h2>تنظیمات تیکت سایت</h2>
                            <p style="<?php echo $guide_style; ?>">💡 <strong>راهنما:</strong> تنظیمات سیستم تیکت سایت رو اینجا انجام بده</p>
                            <table class="form-table"><?php do_settings_fields('reyhan-general', 'sec_ticket'); ?></table>
                        </div>

                        <div id="tab-security" class="rp-tab-pane">
                            <h2>تنظیمات امنیتی</h2>
                            <p style="<?php echo $guide_style; ?>">💡 <strong>راهنما:</strong> تنظیمات امنیتی افزونه رو اینجا انجام بده</p>
                            <table class="form-table"><?php do_settings_fields('reyhan-general', 'sec_security'); ?></table>
                        </div>

                        <div id="tab-tools" class="rp-tab-pane">
                            <h2>ابزار های مفید افزونه</h2>
                            <p style="<?php echo $guide_style; ?>">💡 <strong>راهنما:</strong> ابزار های مختلف افزونه رو اینجا میتونی ببینی</p>
                            <table class="form-table"><?php do_settings_fields('reyhan-general', 'sec_tools'); ?></table>
                        </div>

                    </div> 
                </div> 
            </form>
        </div>
        <?php
    }

    public function render_user_panel_page() { 
        $this->options = get_option('reyhan_options'); 
        ?> 
        <div class="wrap ticketina-wrap">
            <div class="rp-title-area">
                <h1><span class="dashicons dashicons-email-alt"></span> تنظیمات ظاهر</h1>
                <p style="color:#777; margin-top:5px; font-size:12px;">در این بخش تنظیمات استایل پنل کاربری و درگاه ورود و عضویت را انجام دهید.</p>
            </div>
            <?php $this->maybe_show_notification(); ?>
            <form method="post" action="options.php">
                <?php settings_fields('reyhan_master_group'); ?>
                <div class="rp-settings-container">
                    <div class="rp-settings-sidebar">
                        <div class="rp-sidebar-logo"><img src="<?php echo REYHAN_URL . 'assets/images/logo.png'; ?>" alt="Logo"></div>
                        <ul class="rp-tabs-nav">
                            <li class="active" data-tab="tab-style-login"><span class="dashicons dashicons-lock"></span>استایل ورود / عضویت</li>
                            <li data-tab="tab-style-panel"><span class="dashicons dashicons-layout"></span>استایل پنل کاربری</li>
                        </ul>
                        <div class="rp-save-box">
                            <?php submit_button('ذخیره تغییرات', 'primary', 'submit', false); ?>
                            <div class="rp-version-info">نسخه <?php echo REYHAN_VERSION; ?></div>
                        </div>
                    </div>
                    <div class="rp-settings-content">
                        <div id="tab-style-login" class="rp-tab-pane active">
                            <h2>ظاهر صفحه ورود</h2>
                            <p style="color:#666;font-size:13px;margin-bottom:20px;background:#fffbe5;padding:10px;border:1px solid #ffe58f;border-radius:5px;">💡 <strong>راهنما:</strong> تنظیمات استایل درگاه ورود و عضویت رو اینجا انجام بده</p>
                            <table class="form-table"><?php do_settings_fields('reyhan-user-panel', 'sec_style_login'); ?></table>
                        </div>
                        <div id="tab-style-panel" class="rp-tab-pane">
                            <h2>ظاهر داشبورد</h2>
                            <p style="color:#666;font-size:13px;margin-bottom:20px;background:#fffbe5;padding:10px;border:1px solid #ffe58f;border-radius:5px;">💡 <strong>راهنما:</strong> تنظیمات استایل پنل کاربری رو اینجا انجام بده</p>
                            <table class="form-table"><?php do_settings_fields('reyhan-user-panel', 'sec_style_panel'); ?></table>
                        </div>
                    </div>
                </div>
            </form>
        </div> 
        <?php 
    }

    public function render_notifications_page() { 
        $this->options = get_option('reyhan_options'); 
        $items = array_values($this->options['global_notifications'] ?? []);
        
        echo '<script>var rp_server_data='.wp_json_encode($items).';</script>';
        ?> 
        <div class="wrap ticketina-wrap">
            <div class="rp-title-area">
                <h1><span class="dashicons dashicons-email-alt"></span> اطلاعیه های سراسری</h1>
                <p style="color:#777; margin-top:5px; font-size:12px;">در این بخش میتوانید اطلاعیه های خود را ثبت، ویرایش یا حذف کنید.</p>
            </div>
            
            <?php $this->maybe_show_notification(); ?>
            
            <form method="post" action="options.php" id="rp-notif-main-form">
                <?php settings_fields('reyhan_master_group'); ?>
                
                <textarea name="reyhan_options[global_notifications_json]" id="rp_notif_data_json" style="display:none;"></textarea>
                
                <div class="rp-notif-container">
                    
                    <div class="rp-notif-top-bar">
                        <div class="rp-top-info">
                            <h2>لیست پیام‌ها</h2>
                            <p>این پیام‌ها در داشبورد کاربران نمایش داده می‌شوند.</p>
                        </div>
                        <button type="button" id="rp-btn-add-new" class="rp-btn-primary-large">
                            <span class="dashicons dashicons-plus"></span> ایجاد اطلاعیه جدید
                        </button>
                    </div>

                    <div id="rp-editor-wrapper" class="rp-editor-wrapper" style="display:none;">
                        <div class="rp-editor-card">
                            
                            <div class="rp-editor-header">
                                <div class="rp-ed-head-title">
                                    <span class="dashicons dashicons-edit"></span> <span id="rp-editor-title">افزودن اطلاعیه</span>
                                </div>
                                <button type="button" id="rp-btn-cancel" class="rp-btn-close" title="بستن"><span class="dashicons dashicons-no-alt"></span></button>
                            </div>
                            
                            <div class="rp-editor-body">
                                <div class="rp-row-grid-modern">
                                    
                                    <div class="rp-field-group title-group">
                                        <label>عنوان پیام</label>
                                        <div class="rp-input-icon-wrap">
                                            <span class="dashicons dashicons-heading"></span>
                                            <input type="text" id="edit-title" class="rp-input-modern" placeholder="مثال: جشنواره نوروزی...">
                                        </div>
                                    </div>
                                    
                                    <div class="rp-field-group type-group">
                                        <label>رنگ و نوع</label>
                                        <div class="rp-select-wrap">
                                            <select id="edit-type" class="rp-input-modern">
                                                <option value="info">🔵 آبی (اطلاع‌رسانی)</option>
                                                <option value="success">🟢 سبز (موفقیت)</option>
                                                <option value="warning">🟡 زرد (هشدار)</option>
                                                <option value="danger">🔴 قرمز (خطر)</option>
                                            </select>
                                        </div>
                                    </div>

                                </div>
                                
                                <div class="rp-field-group">
                                    <label>متن کامل پیام</label>
                                    <textarea id="edit-msg" rows="5" class="rp-input-modern" placeholder="متن پیام خود را اینجا بنویسید..."></textarea>
                                </div>
                            </div>

                            <div class="rp-editor-footer">
                                <button type="button" id="rp-btn-save-item" class="rp-btn-save">
                                    <span class="dashicons dashicons-saved"></span> ثبت در لیست
                                </button>
                                <span class="rp-hint"><span class="dashicons dashicons-info"></span> پس از ثبت در لیست، حتماً دکمه <strong>"ذخیره تغییرات نهایی"</strong> پایین صفحه را بزنید.</span>
                            </div>
                        </div>
                    </div>

                    <div id="rp-notif-grid" class="rp-notif-grid"></div>
                    
                    <div id="rp-empty-state" style="display:none;">
                        <div class="rp-empty-icon"><span class="dashicons dashicons-megaphone"></span></div>
                        <h3>هیچ اطلاعیه‌ای وجود ندارد</h3>
                        <p>با زدن دکمه بالا، اولین پیام خود را بسازید.</p>
                    </div>

                </div>

                <div class="rp-sticky-save-bar">
                    <div class="rp-save-info">تغییرات شما آماده ذخیره سازی است.</div>
                    <?php submit_button('ذخیره تغییرات نهایی', 'primary', 'submit', false); ?>
                </div>

            </form>
        </div>
        <?php 
    }

    public function render_tickets_manager() { 
        // استفاده از فایل ویو جدید در پوشه templates
        $this->load_view('view-tickets');
    }

    public function sanitize_options( $input ) {
        $existing = get_option('reyhan_options');
        if ( ! is_array($existing) ) $existing = array();
        if ( ! is_array($input) ) $input = array();

        // --- بخش اصلاح شده: فقط مقادیر حیاتی سیستمی پیش‌فرض داشته باشند ---
        // (حذف فیلدهای تلاش ورود از این لیست تا بتوانند خالی بمانند)
        $defaults_check = array(
            'file_allowed_extensions' => 'pdf,jpg,png',
            'file_max_size'           => '1',
            'ticket_flood_interval'   => '60',
        );

        foreach ( $defaults_check as $key => $default_value ) {
            if ( isset( $input[$key] ) && trim( $input[$key] ) === '' ) {
                $input[$key] = $default_value;
            }
        }
        // -----------------------------------------------------------

        // 1. پردازش پاسخ‌های آماده شخصی
        if ( isset($input['ticket_canned_personal_temp']) ) {
            $personal_data = $input['ticket_canned_personal_temp'];
            if ( ! is_array($personal_data) ) $personal_data = [];
            $personal_data = array_values($personal_data);
            update_user_meta( get_current_user_id(), 'rp_user_canned_responses', $personal_data );
            unset($input['ticket_canned_personal_temp']);
        }

        // 2. پردازش JSON اطلاعیه‌ها
        if ( isset($input['global_notifications_json']) ) {
            $json = wp_unslash($input['global_notifications_json']);
            if ( empty( trim($json) ) ) {
                $input['global_notifications'] = [];
            } else {
                $decoded = json_decode($json, true);
                if ( is_array($decoded) ) {
                    $input['global_notifications'] = $decoded;
                }
            }
            unset($input['global_notifications_json']);
        } else {
            if(isset($existing['global_notifications'])) {
                $input['global_notifications'] = $existing['global_notifications'];
            }
        }

        return array_merge($existing, $input);
    }

    public function register_settings() {
        register_setting('reyhan_master_group', 'reyhan_options', array('type' => 'array', 'sanitize_callback' => array($this, 'sanitize_options')));

        // ---------------------------------------------------------
        // تب 1: ورود
        // ---------------------------------------------------------
        add_settings_section('sec_login', '', null, 'reyhan-general');
        
        // تیتر 1
        add_settings_field('login_sec_general', '', array($this,'field_section_title'), 'reyhan-general', 'sec_login', ['title'=>'مدیریت دسترسی', 'desc'=>'تنظیمات صفحه ورود و ثبت نام']);
        add_settings_field('login_page_manager', 'برگه پنل کاربری', array($this,'field_login_page_manager'), 'reyhan-general', 'sec_login');
        add_settings_field('hide_wp_admin', 'مخفی کردن wp-admin', array($this,'field_checkbox'), 'reyhan-general', 'sec_login', ['id'=>'hide_wp_admin', 'label'=>'تمامی کاربران به صفحه ی ورود اختصاصی افزونه منتقل میشوند']);
        add_settings_field('auth_method', 'روش ورود و عضویت', array($this,'field_select_auth'), 'reyhan-general', 'sec_login', ['id'=>'auth_method']);
        add_settings_field('terms_page_id', 'برگه قوانین و مقررات', array($this,'field_select_page'), 'reyhan-general', 'sec_login', ['id'=>'terms_page_id', 'desc'=>'اگر انتخاب شود، چک باکس قوانین را تایید میکنم در فرم ثبت نام ظاهر میشود']);
        
        // تیتر 2
        add_settings_field('login_sec_red', '', array($this,'field_section_title'), 'reyhan-general', 'sec_login', ['title'=>'تغییر مسیرها (Redirect)', 'desc'=>'رفتار سیستم پس از ورود و خروج']);
        add_settings_field('login_redirect_url', 'لینک بعد از ورود', array($this,'field_text'), 'reyhan-general', 'sec_login', ['id'=>'login_redirect_url', 'desc'=>'کاربر بعد از ورود به سایت به این آدرس منتقل میشود']);
        add_settings_field('logout_redirect_url', 'لینک بعد از خروج', array($this,'field_text'), 'reyhan-general', 'sec_login', ['id'=>'logout_redirect_url', 'desc'=>'کاربر بعد خروج از پنل کاربری به این آدرس منتقل میشود']);

        // ---------------------------------------------------------
        // تب 2: پیامک
        // ---------------------------------------------------------
        add_settings_section('sec_sms', '', null, 'reyhan-general');
        
        // تیتر 1
        add_settings_field('sms_sec_gateway', '', array($this,'field_section_title'), 'reyhan-general', 'sec_sms', ['title'=>'درگاه پیامکی', 'desc'=>'اتصال به پنل SMS']);
        add_settings_field('sms_provider', 'سامانه پیامکی', array($this,'field_select_provider'), 'reyhan-general', 'sec_sms');
        add_settings_field('sms_apikey', 'کلید دسترسی (API Key)', array($this,'field_text'), 'reyhan-general', 'sec_sms', ['id'=>'sms_apikey']);
        add_settings_field('sms_username', 'نام کاربری سامانه', array($this,'field_text'), 'reyhan-general', 'sec_sms', ['id'=>'sms_username']);
        add_settings_field('sms_password', 'رمز عبور سامانه', array($this,'field_text'), 'reyhan-general', 'sec_sms', ['id'=>'sms_password']);
        add_settings_field('sms_from', 'شماره فرستنده', array($this,'field_text'), 'reyhan-general', 'sec_sms', ['id'=>'sms_from']);
        
        // تیتر 2
        add_settings_field('sms_sec_global', '', array($this,'field_section_title'), 'reyhan-general', 'sec_sms', ['title'=>'ارسال سراسری', 'desc'=>'تنظیمات الگوی پیامک‌های عمومی']);
        add_settings_field('sms_global_config', 'تنظیمات ارسال', array($this,'field_global_sms_integrated'), 'reyhan-general', 'sec_sms');

        // ---------------------------------------------------------
        // تب 3: ایمیل
        // ---------------------------------------------------------
        add_settings_section('sec_email', '', null, 'reyhan-general');
        
        // تیتر 1
        add_settings_field('email_sec_sender', '', array($this,'field_section_title'), 'reyhan-general', 'sec_email', ['title'=>'فرستنده ایمیل', 'desc'=>'مشخصات ظاهری ایمیل‌های ارسالی']);
        add_settings_field('email_from_name', 'نام فرستنده', array($this,'field_text'), 'reyhan-general', 'sec_email', ['id'=>'email_from_name']);
        add_settings_field('email_from_address', 'ایمیل فرستنده', array($this,'field_text'), 'reyhan-general', 'sec_email', ['id'=>'email_from_address']);
        
        // تیتر 2
        add_settings_field('email_sec_events', '', array($this,'field_section_title'), 'reyhan-general', 'sec_email', ['title'=>'اطلاع‌رسانی‌ها', 'desc'=>'ایمیل‌های خودکار سیستم']);
        add_settings_field('email_user_reg_active', 'ایمیل خوش‌آمدگویی کاربر', array($this,'field_checkbox_toggle_wrapper'), 'reyhan-general', 'sec_email', ['id'=>'email_user_reg_active', 'label'=>'فعالسازی', 'wrapper_id'=>'wrap_email_user_reg']);
        add_settings_field('email_user_reg_fields', '', array($this,'field_email_config_block'), 'reyhan-general', 'sec_email', ['base_id'=>'email_user_reg', 'parent_active'=>'email_user_reg_active', 'help'=>'شورت‌کدها: %username%, %mobile%, %site_name%']);
        add_settings_field('email_admin_reg_active', 'ایمیل اطلاع‌رسانی مدیر', array($this,'field_checkbox_toggle_wrapper'), 'reyhan-general', 'sec_email', ['id'=>'email_admin_reg_active', 'label'=>'فعالسازی', 'wrapper_id'=>'wrap_email_admin_reg']);
        add_settings_field('email_admin_reg_fields', '', array($this,'field_email_config_block'), 'reyhan-general', 'sec_email', ['base_id'=>'email_admin_reg', 'parent_active'=>'email_admin_reg_active', 'help'=>'شورت‌کدها: %username%, %mobile%']);

        // ---------------------------------------------------------
        // تب 4: تیکت
        // ---------------------------------------------------------
        add_settings_section('sec_ticket', '', null, 'reyhan-general');
        
        // تیتر 1
        add_settings_field('ticket_sec_agents', '', array($this,'field_section_title'), 'reyhan-general', 'sec_ticket', ['title'=>'تنظیمات پاسخگویی مدیر', 'desc'=>'تنظیماتی که فقط برای مدیر تنظیم میشوند']);
        add_settings_field('ticket_support_name', 'نام و نام خانوادگی', array($this,'field_text'), 'reyhan-general', 'sec_ticket', ['id'=>'ticket_support_name']);
        add_settings_field('ticket_support_avatar', 'تصویر پروفایل', array($this,'field_media_upload'), 'reyhan-general', 'sec_ticket', ['id'=>'ticket_support_avatar']);
        add_settings_field('ticket_canned_personal', 'پاسخ‌های آماده (شخصی)', array($this,'field_canned_responses_personal'), 'reyhan-general', 'sec_ticket', ['id'=>'rp_user_canned_responses', 'btn_text'=>'افزودن پاسخ', 'fields'=>['title'=>'عنوان', 'content'=>'متن']]);

        add_settings_field('ticket_support_agents', 'کارشناسان پاسخگو', array($this,'field_user_search'), 'reyhan-general', 'sec_ticket', ['id'=>'ticket_support_agents']);
        
        // تیتر 2
        add_settings_field('ticket_sec_notif', '', array($this,'field_section_title'), 'reyhan-general', 'sec_ticket', ['title'=>'اطلاع‌رسانی تیکت به کاربر', 'desc'=>'تنظیمات ایمیل و پیامک وضعیت تیکت']);
        add_settings_field('ticket_email_submit_active', 'ایمیل ثبت تیکت', array($this,'field_checkbox_toggle_wrapper'), 'reyhan-general', 'sec_ticket', ['id'=>'ticket_email_submit_active', 'label'=>'فعالسازی', 'wrapper_id'=>'wrap_ticket_email_submit']);
        add_settings_field('ticket_email_submit_fields', '', array($this,'field_email_config_block'), 'reyhan-general', 'sec_ticket', ['base_id'=>'ticket_email_submit', 'parent_active'=>'ticket_email_submit_active', 'help'=>'شورت‌کدها: %ticket_id%, %subject%, %user_name%']);
        add_settings_field('ticket_email_reply_active', 'ایمیل پاسخ تیکت', array($this,'field_checkbox_toggle_wrapper'), 'reyhan-general', 'sec_ticket', ['id'=>'ticket_email_reply_active', 'label'=>'فعالسازی', 'wrapper_id'=>'wrap_ticket_email_reply']);
        add_settings_field('ticket_email_reply_fields', '', array($this,'field_email_config_block'), 'reyhan-general', 'sec_ticket', ['base_id'=>'ticket_email_reply', 'parent_active'=>'ticket_email_reply_active', 'help'=>'شورت‌کدها: %ticket_id%, %subject%, %reply_content%']);
        add_settings_field('ticket_sms_submit_active', 'پیامک ثبت تیکت', array($this,'field_checkbox_toggle_wrapper'), 'reyhan-general', 'sec_ticket', ['id'=>'ticket_sms_submit_active', 'label'=>'فعالسازی', 'wrapper_id'=>'wrap_ticket_sms_submit']);
        add_settings_field('ticket_sms_submit_fields', '', array($this,'field_sms_config_block'), 'reyhan-general', 'sec_ticket', ['base_id'=>'ticket_sms_submit', 'parent_active'=>'ticket_sms_submit_active']);
        add_settings_field('ticket_sms_reply_active', 'پیامک پاسخ تیکت', array($this,'field_checkbox_toggle_wrapper'), 'reyhan-general', 'sec_ticket', ['id'=>'ticket_sms_reply_active', 'label'=>'فعالسازی', 'wrapper_id'=>'wrap_ticket_sms_reply']);
        add_settings_field('ticket_sms_reply_fields', '', array($this,'field_sms_config_block'), 'reyhan-general', 'sec_ticket', ['base_id'=>'ticket_sms_reply', 'parent_active'=>'ticket_sms_reply_active']);
        
        // تیتر 3
        add_settings_field('ticket_sec_data', '', array($this,'field_section_title'), 'reyhan-general', 'sec_ticket', ['title'=>'داده‌های تیکت', 'desc'=>'مدیریت محتوای فرم تیکت']);
        add_settings_field('ticket_departments', 'دپارتمان‌ها', array($this,'field_repeater_general'), 'reyhan-general', 'sec_ticket', ['id'=>'ticket_departments', 'btn_text'=>'افزودن', 'fields'=>['name'=>'نام دپارتمان']]);
        add_settings_field('ticket_faqs', 'سوالات متداول', array($this,'field_repeater_general'), 'reyhan-general', 'sec_ticket', ['id'=>'ticket_faqs', 'btn_text'=>'افزودن سوال', 'fields'=>['q'=>'سوال', 'a'=>'پاسخ']]);

        add_settings_field('ticket_signatures', 'قالب‌بندی پاسخ‌ها', array($this,'field_ticket_signatures'), 'reyhan-general', 'sec_ticket');

        // ---------------------------------------------------------
        // تب 5: امنیت
        // ---------------------------------------------------------
        add_settings_section('sec_security', '', null, 'reyhan-general');
        
        // تیتر 1
        add_settings_field('sec_title_login', '', array($this,'field_section_title'), 'reyhan-general', 'sec_security', ['title'=>'محدودیت تلاش ورود', 'desc'=>'جلوگیری از حملات Brute Force']);
        add_settings_field('recaptcha_active', 'گوگل ریکپچا (v3)', array($this,'field_checkbox_toggle_wrapper'), 'reyhan-general', 'sec_security', ['id'=>'recaptcha_active', 'label'=>'فعال‌سازی جلوگیری از ربات', 'wrapper_id'=>'wrap_recaptcha']);
        add_settings_field('recaptcha_keys', '', array($this,'field_recaptcha_block'), 'reyhan-general', 'sec_security', ['parent_active'=>'recaptcha_active']);
        add_settings_field('login_max_attempts', 'حداکثر تلاش مجاز', array($this,'field_text_small'), 'reyhan-general', 'sec_security', ['id'=>'login_max_attempts', 'desc'=>'بار (پیش‌فرض: 5 بار)']);
        add_settings_field('login_lockout_time', 'مدت زمان مسدودی', array($this,'field_text_small'), 'reyhan-general', 'sec_security', ['id'=>'login_lockout_time', 'desc'=>'دقیقه (پیش‌فرض: 15 دقیقه)']);
        
        // تیتر 2
        add_settings_field('sec_title_file', '', array($this,'field_section_title'), 'reyhan-general', 'sec_security', ['title'=>'کنترل آپلود در تیکت‌ها', 'desc'=>'امنیت فایل‌های ضمیمه']);
        add_settings_field('file_allowed_extensions', 'فرمت‌های مجاز', array($this,'field_text_modern'), 'reyhan-general', 'sec_security', ['id'=>'file_allowed_extensions', 'desc'=>'فرمت‌ها را با کاما جدا کنید.']);
        add_settings_field('file_max_size', 'حداکثر حجم فایل', array($this,'field_text_small'), 'reyhan-general', 'sec_security', ['id'=>'file_max_size', 'desc'=>'مگابایت (MB)']);
        
        // تیتر 3
        add_settings_field('sec_title_spam', '', array($this,'field_section_title'), 'reyhan-general', 'sec_security', ['title'=>'کنترل اسپم' , 'desc'=>'تنظیمات نرخ ارسال و ایمیل']);
        add_settings_field('ticket_flood_interval', 'فاصله بین دو تیکت', array($this,'field_text_small'), 'reyhan-general', 'sec_security', ['id'=>'ticket_flood_interval', 'desc'=>'ثانیه (پیشفرض: 60 ثانیه)']);
        add_settings_field('block_disposable_emails', 'ایمیل‌های موقت', array($this,'field_checkbox'), 'reyhan-general', 'sec_security', ['id'=>'block_disposable_emails', 'label'=>'مسدودسازی ثبت‌نام با ایمیل‌های یکبار مصرف (Fake Mail)']);

        // ---------------------------------------------------------
        // تب 6: ابزارها
        // ---------------------------------------------------------
        add_settings_section('sec_tools', '', null, 'reyhan-general');
        
        // تیتر 1
        add_settings_field('tool_sec_ui', '', array($this,'field_section_title'), 'reyhan-general', 'sec_tools', ['title'=>'ابزارهای ظاهری', 'desc'=>'شخصی‌سازی فونت و دسترسی']);
        add_settings_field('active_plugin_font', 'فونت اختصاصی افزونه', array($this,'field_toggle_modern'), 'reyhan-general', 'sec_tools', ['id'=>'active_plugin_font', 'desc'=>'با فعالسازی این مورد فونت افزونه و درگاه ورود و عضویت به یکان بخ تبدیل میشود']);
        add_settings_field('tool_shortcodes', 'شورت‌کد', array($this,'field_tool_shortcodes'), 'reyhan-general', 'sec_tools');
        
        // تیتر 2
        add_settings_field('tool_sec_test', '', array($this,'field_section_title'), 'reyhan-general', 'sec_tools', ['title'=>'تست سیستم', 'desc'=>'بررسی صحت ارسال ایمیل و پیامک']);
        add_settings_field('tool_tester', 'تست ارسال', array($this,'field_tool_tester'), 'reyhan-general', 'sec_tools');
        
        // تیتر 3
        add_settings_field('tool_sec_db', '', array($this,'field_section_title'), 'reyhan-general', 'sec_tools', ['title'=>'عملیات پیشرفته', 'desc'=>'مدیریت دیتابیس و پاکسازی']);
        add_settings_field('tool_danger_zone', 'عملیات دیتابیس', array($this,'field_tool_danger_zone'), 'reyhan-general', 'sec_tools');
        add_settings_field('tool_guide', 'راهنمای دیتابیس', array($this,'field_tool_guide'), 'reyhan-general', 'sec_tools');

        // ---------------------------------------------------------
        // بخش استایل‌ها (تب 1: ورود) - اصلاح شده
        // ---------------------------------------------------------
        add_settings_section('sec_style_login', '', null, 'reyhan-user-panel');
        
        // تیتر 1: برندینگ (حفظ شد)
        add_settings_field('style_login_sec_brand', '', array($this,'field_section_title'), 'reyhan-user-panel', 'sec_style_login', ['title'=>'برندینگ', 'desc'=>'لوگو و عنوان‌ها']);
        add_settings_field('login_logo', 'لوگوی بالای فرم', array($this,'field_media_upload'), 'reyhan-user-panel', 'sec_style_login', ['id'=>'login_logo']);
        add_settings_field('login_logo_width', 'عرض لوگو', array($this,'field_text_small'), 'reyhan-user-panel', 'sec_style_login', ['id'=>'login_logo_width', 'desc'=>'پیکسل']);
        add_settings_field('login_custom_title', 'تیتر اصلی', array($this,'field_text'), 'reyhan-user-panel', 'sec_style_login', ['id'=>'login_custom_title']);
        add_settings_field('login_custom_subtitle', 'زیرعنوان', array($this,'field_text'), 'reyhan-user-panel', 'sec_style_login', ['id'=>'login_custom_subtitle']);
        
        // تیتر 2: انتخاب تم (جایگزین تنظیمات دستی)
        add_settings_field('style_login_sec_theme', '', array($this,'field_section_title'), 'reyhan-user-panel', 'sec_style_login', ['title'=>'ظاهر فرم', 'desc'=>'تم رنگی صفحه ورود']);
        add_settings_field('login_active_theme', 'انتخاب تم', array($this,'field_login_theme_selector'), 'reyhan-user-panel', 'sec_style_login');
        
        // تیتر 3: پاورقی (حفظ شد)
        add_settings_field('style_login_sec_footer', '', array($this,'field_section_title'), 'reyhan-user-panel', 'sec_style_login', ['title'=>'پاورقی', 'desc'=>'لینک‌ و کپی‌رایت']);
        add_settings_field('login_show_home', 'لینک بازگشت', array($this,'field_checkbox'), 'reyhan-user-panel', 'sec_style_login', ['id'=>'login_show_home', 'label'=>'نمایش دکمه بازگشت به صفحه ی اصلی']);
        add_settings_field('login_copyright', 'متن کپی‌رایت', array($this,'field_textarea_small'), 'reyhan-user-panel', 'sec_style_login', ['id'=>'login_copyright']);

        // ---------------------------------------------------------
        // بخش استایل‌ها (تب 2: پنل) - انتخاب تم
        // ---------------------------------------------------------
        add_settings_section('sec_style_panel', '', null, 'reyhan-user-panel');
        
        // تیتر جدید
        add_settings_field('panel_sec_theme', '', array($this,'field_section_title'), 'reyhan-user-panel', 'sec_style_panel', ['title'=>'استایل پنل', 'desc'=>'تم‌های مختلف پنل']);
        
        // فیلد انتخابگر تم
        add_settings_field('panel_active_theme', 'انتخاب تم', array($this,'field_theme_selector'), 'reyhan-user-panel', 'sec_style_panel');
        
        // تیتر چیدمان منو (سایر تنظیمات بدون تغییر)
        add_settings_field('panel_sec_menu', '', array($this,'field_section_title'), 'reyhan-user-panel', 'sec_style_panel', ['title'=>'چیدمان منو', 'desc'=>'مدیریت آیتم‌های سایدبار']);
        add_settings_field('panel_menu_structure', '', array($this,'field_menu_builder'), 'reyhan-user-panel', 'sec_style_panel', ['id'=>'panel_menu_structure']);
        
        // تیتر ویجت‌ها
        add_settings_field('panel_sec_widget', '', array($this,'field_section_title'), 'reyhan-user-panel', 'sec_style_panel', ['title'=>'ویجت‌های داشبورد', 'desc'=>'مدیریت کارت‌های آمار']);
        add_settings_field('panel_cards_grid', 'مدیریت نمایش', array($this,'field_dashboard_cards_grid'), 'reyhan-user-panel', 'sec_style_panel');
        add_settings_field('panel_widget_discount_text', 'کد تخفیف عمومی', array($this,'field_text'), 'reyhan-user-panel', 'sec_style_panel', ['id'=>'panel_widget_discount_text']);
        
        // تیتر 5
        add_settings_field('panel_sec_widget', '', array($this,'field_section_title'), 'reyhan-user-panel', 'sec_style_panel', ['title'=>'ویجت‌های داشبورد', 'desc'=>'مدیریت کارت‌های آمار']);
        add_settings_field('panel_cards_grid', 'مدیریت نمایش', array($this,'field_dashboard_cards_grid'), 'reyhan-user-panel', 'sec_style_panel');
        add_settings_field('panel_widget_discount_text', 'کد تخفیف عمومی', array($this,'field_text'), 'reyhan-user-panel', 'sec_style_panel', ['id'=>'panel_widget_discount_text']);
        
        // اطلاعیه سراسری
        add_settings_section('sec_global_notif', '', null, 'reyhan-notifications'); 
        add_settings_field('global_notifications_list', 'لیست اطلاعیه‌ها', array($this,'field_notifications_manager'), 'reyhan-notifications', 'sec_global_notif');
    }

    // --- توابع کمکی ---

    // فیلد تاگل مدرن (برای فونت)
    public function field_toggle_modern($args) {
        $key = $args['id'];
        // پیش‌فرض روی 1 (فعال) تنظیم شده است
        $val = $this->options[$key] ?? '1'; 
        
        echo '<div style="display:flex; align-items:center; gap:15px;">';
        echo '<label class="rp-switch">
                <input type="hidden" name="reyhan_options['.$key.']" value="0">
                <input type="checkbox" name="reyhan_options['.$key.']" value="1" '.checked($val, '1', false).'>
                <span class="rp-slider round"></span>
              </label>';
        echo '<span class="rp-toggle-label">'. ($val=='1' ? 'فعال' : 'غیرفعال') .'</span>';
        echo '</div>';
        if(!empty($args['desc'])) echo '<p class="description" style="margin-top:8px;">'.$args['desc'].'</p>';
    }

    public function field_media_upload($args) {
        $id = $args['id'];
        $val = $this->options[$id] ?? '';
        $default_image = REYHAN_URL . 'assets/images/user.png'; 
        
        $preview_src = !empty($val) ? esc_url($val) : $default_image;
        $has_image_class = !empty($val) ? 'has-image' : '';
        ?>
        <div class="rp-media-upload-modern-wrap <?php echo $has_image_class; ?>" data-id="<?php echo esc_attr($id); ?>">
            
            <div class="rp-media-preview-box">
                <div class="rp-preview-circle">
                    <img src="<?php echo $preview_src; ?>" data-default="<?php echo $default_image; ?>" class="rp-preview-img">
                    <div class="rp-preview-overlay">
                        <span class="dashicons dashicons-camera"></span>
                    </div>
                </div>
            </div>

            <div class="rp-media-controls">
                <h4 class="rp-media-title">تصویر پروفایل شما</h4>
                <p class="rp-media-desc">این تصویر در بالای چت تیکت‌ها برای کاربران نمایش داده می‌شود.</p>
                
                <div class="rp-media-buttons">
                    <input type="text" name="reyhan_options[<?php echo esc_attr($id); ?>]" value="<?php echo esc_attr($val); ?>" class="rp-media-input" style="display:none;">
                    
                    <button type="button" class="button rp-upload-btn-modern">
                        <span class="dashicons dashicons-upload"></span> انتخاب / تغییر تصویر
                    </button>
                    
                    <button type="button" class="button rp-remove-btn-modern" style="<?php echo empty($val) ? 'display:none;' : ''; ?>">
                        <span class="dashicons dashicons-trash"></span> حذف تصویر
                    </button>
                </div>
            </div>
        </div>
        
        <style>
            /* همان کدهای CSS مرحله قبل را اینجا تصور کنید یا نگه دارید */
            .rp-media-upload-modern-wrap { display: flex; align-items: center; gap: 30px; background: #fff; border: 2px dashed #e0e0e0; border-radius: 24px; padding: 30px; max-width: 600px; transition: all 0.3s ease; position: relative; overflow: hidden; }
            .rp-media-upload-modern-wrap:hover { border-color: #FFAB91; background: #fafafa; box-shadow: 0 10px 30px rgba(0,0,0,0.03); }
            .rp-media-upload-modern-wrap.has-image { border-style: solid; border-color: #f0f0f0; }
            .rp-media-preview-box { flex-shrink: 0; }
            .rp-preview-circle { width: 110px; height: 110px; border-radius: 50%; border: 5px solid #fff; box-shadow: 0 8px 25px rgba(255, 87, 34, 0.2); position: relative; overflow: hidden; background: #f0f0f0; cursor: pointer; }
            .rp-preview-img { width: 100%; height: 100%; object-fit: cover; transition: 0.5s; }
            .rp-preview-overlay { position: absolute; top:0; left:0; width:100%; height:100%; background: rgba(0,0,0,0.4); display: flex; align-items: center; justify-content: center; opacity: 0; transition: 0.3s; }
            .rp-preview-overlay .dashicons { color: #fff; font-size: 32px; height: auto; width: auto; }
            .rp-upload-btn-modern:hover + .rp-media-preview-box .rp-preview-circle, .rp-preview-circle:hover .rp-preview-overlay { opacity: 1; }
            .rp-preview-circle:hover .rp-preview-img { transform: scale(1.1); }
            .rp-media-controls { flex-grow: 1; }
            .rp-media-title { margin: 0 0 10px 0; font-size: 18px; font-weight: 800; color: #333; }
            .rp-media-desc { margin: 0 0 20px 0; font-size: 13px; color: #888; line-height: 1.6; }
            .rp-media-buttons { display: flex; flex-wrap: wrap; gap: 15px; }
            .rp-upload-btn-modern { background: linear-gradient(135deg, #FF5722, #FF8A65) !important; border: none !important; color: #fff !important; padding: 12px 30px !important; border-radius: 50px !important; font-weight: 600 !important; font-size: 14px !important; box-shadow: 0 5px 15px rgba(255, 87, 34, 0.3) !important; transition: 0.3s !important; display: inline-flex; align-items: center; gap: 8px; height: auto !important; }
            .rp-upload-btn-modern:hover { transform: translateY(-3px); box-shadow: 0 8px 25px rgba(255, 87, 34, 0.5) !important; background: linear-gradient(135deg, #E64A19, #FF5722) !important; }
            .rp-upload-btn-modern .dashicons { font-size: 18px; height: auto; width: auto; }
            .rp-remove-btn-modern { background: transparent !important; border: 2px solid #eee !important; color: #999 !important; padding: 10px 25px !important; border-radius: 50px !important; font-weight: 500 !important; font-size: 13px !important; transition: 0.3s !important; display: inline-flex; align-items: center; gap: 8px; height: auto !important; }
            .rp-remove-btn-modern:hover { border-color: #FFCDD2 !important; color: #D32F2F !important; background: #FFEBEE !important; }
            .rp-remove-btn-modern .dashicons { font-size: 16px; height: auto; width: auto; }
            @media (max-width: 600px) { .rp-media-upload-modern-wrap { flex-direction: column; text-align: center; padding: 20px; } .rp-media-buttons { justify-content: center; } }
        </style>
        <?php
    }

    public function field_global_sms_integrated() {
        // دریافت مقادیر ذخیره شده
        $method = $this->options['sms_send_method'] ?? 'pattern';
        $pattern = esc_attr($this->options['sms_pattern_otp'] ?? '');
        $text = esc_textarea($this->options['sms_text_template'] ?? '');
        
        // اینپوت مخفی برای ذخیره وضعیت تب فعال
        // جاوااسکریپت (admin.js) با هر بار کلیک روی تب‌ها، مقدار این فیلد را به pattern یا text تغییر می‌دهد
        // بنابراین هنگام ذخیره، دقیقا همان تبی که باز است ذخیره می‌شود.
        echo '<input type="hidden" name="reyhan_options[sms_send_method]" id="rp_sms_method_input" value="'.$method.'">';
        ?>
        <div class="rp-mini-tabs-wrapper">
            <ul class="rp-mini-tabs-nav">
                <li data-method="pattern" class="<?php echo ($method === 'pattern') ? 'active' : ''; ?>">
                    <span class="dashicons dashicons-grid-view"></span> ارسال با پترن (الگو)
                </li>
                <li data-method="text" class="<?php echo ($method === 'text') ? 'active' : ''; ?>">
                    <span class="dashicons dashicons-text"></span> ارسال عادی
                </li>
            </ul>

            <div class="rp-mini-tab-content content-pattern" id="content-pattern" style="display: <?php echo ($method === 'pattern') ? 'block' : 'none'; ?>;">
                <div class="rp-input-group">
                    <label style="display:block; margin-bottom:8px; font-weight:bold; color:#333;">کد پترن (Template ID):</label>
                    <input type="text" name="reyhan_options[sms_pattern_otp]" value="<?php echo $pattern; ?>" class="regular-text rp-input-modern" placeholder="مثال: 123456" style="width:100%;">
                </div>
                <p class="rp-field-desc"><span class="dashicons dashicons-info"></span>در این روش، فقط کد الگو را وارد کنید. متن پیامک باید در پنل اس‌ام‌اس تنظیم شده باشد. متغیر مربوط به کد تایید باید %code% باشد.</p>
            </div>

            <div class="rp-mini-tab-content content-text" id="content-text" style="display: <?php echo ($method === 'text') ? 'block' : 'none'; ?>;">
                <div class="rp-input-group">
                    <label style="display:block; margin-bottom:8px; font-weight:bold; color:#333;">متن کامل پیامک:</label>
                    <textarea name="reyhan_options[sms_text_template]" rows="4" class="large-text rp-input-modern" placeholder="متن پیام خود را بنویسید..." style="width:100%;"><?php echo $text; ?></textarea>
                </div>
                <p class="rp-field-desc"><span class="dashicons dashicons-info"></span>متن کامل پیامک را اینجا بنویسید. برای جایگذاری کد تایید از %code% استفاده کنید. (توصیه: اگر خط خدماتی دارید از این بخش استفاده کنید).</p>
            </div>
        </div>
        <?php
    }

    public function field_user_search($args) { 
        $raw_data = $this->options['ticket_support_agents_data'] ?? '[]';
        if(empty($raw_data)) $raw_data = '[]';

        $depts = $this->options['ticket_departments'] ?? [];
        $dept_list = [];
        if(is_array($depts)) {
            foreach($depts as $d) { if(!empty($d['name'])) $dept_list[] = $d['name']; }
        }
        
        $default_avatar_url = REYHAN_URL . 'assets/images/user.png';
        ?>
        
        <script>
            jQuery(document).ready(function($){
                var $wrap = $('.rp-agent-manager-wrapper');
                var $td = $wrap.closest('td');
                if($td.length) {
                    $td.attr('colspan', '2').css('padding', '0');
                    $td.siblings('th').hide();
                }
            });
        </script>

        <div class="rp-agent-manager-wrapper">
            <textarea name="reyhan_options[ticket_support_agents_data]" id="rp_agents_data_json" style="display:none;"><?php echo esc_textarea($raw_data); ?></textarea>
            
            <script>
                var rp_departments_list = <?php echo json_encode($dept_list); ?>;
                var rp_default_avatar = "<?php echo esc_url($default_avatar_url); ?>";
            </script>

            <div class="rp-agent-header">
                <h3>مدیریت کارشناسان پاسخگو</h3>
                <p>جستجو و افزودن کارشناس به دپارتمان‌ها</p>
            </div>

            <div class="rp-agent-search-box">
                <input type="text" id="rp-user-search-input" class="rp-modern-search" placeholder="جستجوی نام کاربری یا ایمیل پشتیبان...">
                <span class="dashicons dashicons-search search-icon"></span>
                <div id="rp-search-results"></div>
            </div>

            <div id="rp-agents-grid" class="rp-agents-grid"></div>

            <div id="rp-dept-modal" class="rp-modal-overlay" style="display:none;">
                <div class="rp-modal-content">
                    <div class="rp-modal-header">
                        <span class="rp-modal-title">تنظیمات دسترسی</span>
                        <span class="dashicons dashicons-no-alt close-modal"></span>
                    </div>
                    <div class="rp-modal-body">
                        <div class="rp-modal-user-preview">
                            <img id="modal-agent-avatar" src="">
                            <div class="rp-user-details">
                                <h3 id="modal-agent-name"></h3>
                                <span class="rp-role-label">پشتیبان</span>
                            </div>
                        </div>
                        
                        <div class="rp-access-section">
                            <label class="rp-access-option all-access">
                                <input type="checkbox" id="dept-all" value="all">
                                <div class="rp-access-text">
                                    <strong>دسترسی مدیر کل</strong>
                                    <p>مشاهده همه تیکت‌های تمام دپارتمان‌ها</p>
                                </div>
                            </label>
                            <div class="rp-divider"><span>یا انتخاب دپارتمان‌ها</span></div>
                            <div id="dept-list-container" class="rp-dept-grid"></div>
                        </div>
                    </div>
                    <div class="rp-modal-footer">
                        <button type="button" class="button close-modal" style="background:transparent; border:none; color:#777;">لغو</button>
                        <button type="button" id="btn-save-agent" class="button button-primary">ذخیره تغییرات</button>
                    </div>
                </div>
            </div>
        </div>

        <style>
            .rp-agent-manager-wrapper { background: #fff; padding: 40px; }
            
            /* --- اصلاح هدر (خط نارنجی و فاصله) --- */
            .rp-agent-header {
                margin-right: -20px; /* تراز با سایر بخش‌ها */
                border-right: 4px solid #FF5722; /* خط نارنجی */
                padding-right: 15px;
                margin-bottom: 40px; /* افزایش فاصله با سرچ بار */
                display: flex;
                flex-direction: column;
            }
            .rp-agent-header h3 { font-size: 18px; font-weight: 900; margin: 0 0 8px 0; color: #333; }
            .rp-agent-header p { color: #888; margin: 0; font-size: 13px; }
            
            /* --- سرچ بار --- */
            .rp-agent-search-box { position: relative; margin-bottom: 40px; max-width: 600px; margin-left: auto; margin-right: auto; }
            .rp-modern-search { width: 100% !important; padding: 15px 50px 15px 20px !important; border-radius: 15px !important; border: 2px solid #eee !important; background: #fcfcfc !important; font-size: 14px !important; transition:0.3s; box-shadow: 0 5px 15px rgba(0,0,0,0.03) !important; }
            .rp-modern-search:focus { background:#fff !important; border-color:#FF5722 !important; box-shadow:0 10px 30px rgba(255,87,34,0.15) !important; outline:none !important; transform: translateY(-2px); }
            .search-icon { position: absolute; right: 20px; top: 50%; transform: translateY(-50%); color: #bbb; font-size: 24px; }
            
            /* --- نتایج جستجو --- */
            #rp-search-results { display:none; position:absolute; top:115%; right:0; left:0; background:#fff; z-index:100; box-shadow:0 15px 60px rgba(0,0,0,0.1); border-radius:15px; max-height:300px; overflow-y:auto; border:1px solid #eee; }
            #rp-search-results li { padding:15px 20px; border-bottom:1px solid #f9f9f9; cursor:pointer; display:flex; align-items:center; gap:15px; transition:0.2s; }
            #rp-search-results li:hover { background:#fff8e1; padding-right: 25px; }
            #rp-search-results img { width: 40px !important; height: 40px !important; border-radius: 50% !important; object-fit: cover !important; border:2px solid #fff; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }

            /* --- گرید کارت‌ها --- */
            .rp-agents-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 25px; }
            
            /* --- استایل مدرن و زیبای کارت ادمین ثبت شده --- */
            .rp-agent-card { 
                background: #fff; 
                border: 1px solid #f0f0f0; 
                border-radius: 20px; 
                padding: 20px; 
                display: flex; 
                align-items: center; 
                gap: 20px; 
                position: relative; 
                transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
                box-shadow: 0 10px 30px rgba(0,0,0,0.04);
            }
            
            /* افکت هاور کارت */
            .rp-agent-card:hover { 
                transform: translateY(-7px); 
                box-shadow: 0 20px 40px rgba(255, 87, 34, 0.15); 
                border-color: #FFCCBC;
            }
            
            /* وضعیت دسترسی با نوار رنگی ظریف */
            .rp-agent-card::before {
                content: ''; position: absolute; left: 0; top: 20px; bottom: 20px; width: 4px;
                border-radius: 0 4px 4px 0; background: #eee; transition: 0.3s;
            }
            .rp-agent-card.full-access::before { background: #4CAF50; box-shadow: 2px 0 10px rgba(76, 175, 80, 0.4); }
            .rp-agent-card.limited::before { background: #FF9800; box-shadow: 2px 0 10px rgba(255, 152, 0, 0.4); }
            
            .rp-agent-avatar img { 
                width: 65px !important; 
                height: 65px !important; 
                border-radius: 50% !important; 
                object-fit: cover !important; 
                border: 3px solid #fff; 
                box-shadow: 0 8px 20px rgba(0,0,0,0.1); /* سایه نرم */
            }
            
            .rp-agent-info { display: flex; flex-direction: column; justify-content: center; }
            .rp-agent-info h4 { margin: 0 0 5px 0; font-size: 16px; color: #333; font-weight: 800; }
            .rp-agent-depts { 
                font-size: 11px; 
                color: #555; 
                background: #f5f5f5; 
                padding: 4px 10px; 
                border-radius: 10px; 
                display: inline-block;
                max-width: 100%;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }
            
            .rp-agent-actions { margin-right: auto; display: flex; gap: 8px; opacity: 0.6; transition: 0.3s; }
            .rp-agent-card:hover .rp-agent-actions { opacity: 1; }
            
            .rp-btn-icon { width: 35px; height: 35px; border-radius: 10px; border: 1px solid #eee; background: #fff; cursor: pointer; display: flex; align-items: center; justify-content: center; color: #777; transition:0.3s; }
            .rp-btn-icon:hover { transform: scale(1.1); box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
            .rp-btn-icon:hover .dashicons-edit { color: #2196F3; }
            .rp-btn-icon:hover .dashicons-trash { color: #F44336; }

            /* --- استایل مودال (ثابت مانده با اصلاحات قبلی) --- */
            .rp-modal-overlay { position: fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.6); z-index:99999; display:flex; align-items:center; justify-content:center; backdrop-filter:blur(8px); }
            .rp-modal-content { background:#fff; width:480px; max-width:90%; border-radius:24px; overflow:hidden; box-shadow:0 25px 80px rgba(0,0,0,0.3); animation: popIn 0.3s cubic-bezier(0.34, 1.56, 0.64, 1); display: flex; flex-direction: column; }
            .rp-modal-header { background: linear-gradient(135deg, #FF5722, #FF7043); padding: 25px 30px; display:flex; justify-content:space-between; align-items:center; color: #fff; }
            .rp-modal-title { font-size: 18px; font-weight: 800; }
            .close-modal { cursor:pointer; color: rgba(255,255,255,0.8); transition: 0.3s; font-size: 22px; }
            .close-modal:hover { color: #fff; transform: rotate(90deg); }
            .rp-modal-body { padding: 35px 30px; background: #fff; flex-grow: 1; }
            .rp-modal-user-preview { display: flex; align-items: center; gap: 20px; margin-bottom: 35px; padding-bottom: 25px; border-bottom: 1px solid #f0f0f0; }
            .rp-modal-user-preview img { width: 75px !important; height: 75px !important; border-radius: 50%; border: 4px solid #fff; box-shadow: 0 8px 20px rgba(255, 87, 34, 0.15); object-fit: cover; }
            .rp-user-details h3 { margin: 0 0 8px 0; font-size: 18px; font-weight: 900; color: #333; }
            .rp-role-label { font-size: 12px; background: #FFF3E0; color: #E64A19; padding: 4px 12px; border-radius: 20px; font-weight: bold; }
            .rp-access-section { margin-top: 10px; }
            .rp-access-option { display: flex; align-items: center; gap: 15px; padding: 18px; border: 2px solid #f0f0f0; border-radius: 16px; cursor: pointer; transition: 0.2s; position: relative; background: #fafafa; }
            .rp-access-option:hover { border-color: #FFAB91; background: #fff; box-shadow: 0 5px 15px rgba(0,0,0,0.03); }
            .rp-access-option input:checked + .rp-access-text { color: #D84315; }
            .rp-access-text strong { display: block; font-size: 15px; margin-bottom: 5px; color: #444; }
            .rp-access-text p { margin: 0; font-size: 12px; color: #888; line-height: 1.5; }
            .rp-divider { text-align: center; margin: 30px 0; position: relative; }
            .rp-divider::before { content: ''; position: absolute; top: 50%; left: 0; right: 0; height: 1px; background: #eee; }
            .rp-divider span { background: #fff; padding: 0 15px; color: #aaa; font-size: 12px; position: relative; font-weight: 500; }
            .rp-dept-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
            .rp-dept-check-item { display: flex; align-items: center; gap: 10px; padding: 12px 15px; background: #fff; border: 1px solid #eee; border-radius: 10px; font-size: 13px; cursor: pointer; transition: 0.2s; }
            .rp-dept-check-item:hover { border-color: #FFCCBC; background: #FFFBE6; }
            .rp-modal-footer { padding: 25px 30px; background: #fafafa; display: flex; justify-content: space-between; align-items: center; border-top: 1px solid #f0f0f0; }
            
            @keyframes popIn { from{transform:scale(0.9) translateY(30px); opacity:0} to{transform:scale(1) translateY(0); opacity:1} }
        </style>
        <?php 
    }

    public function field_email_config_block($args) { 
        $base = $args['base_id']; 
        $isActive = !empty($this->options[$args['parent_active']]); 
        $style = $isActive ? '' : 'display:none;'; 
        
        $subject = esc_attr($this->options[$base.'_subject'] ?? ''); 
        $body = $this->options[$base.'_body'] ?? ''; 
        
        echo "<div id='wrap_{$base}' class='rp-conditional-block' style='{$style}'>";
        echo "<p><label style='font-weight:bold;'>موضوع:</label><br><input type='text' name='reyhan_options[{$base}_subject]' value='{$subject}' class='regular-text' style='width:100%;'></p>";
        echo "<p style='font-weight:bold;'>متن:</p>";
        
        // اصلاح مورد ۹: فعال‌سازی دکمه افزودن مدیا
        wp_editor($body, $base.'_body', [
            'textarea_name' => "reyhan_options[$base"."_body]", 
            'textarea_rows' => 10, 
            'media_buttons' => true, // این خط دکمه افزودن پرونده چندرسانه‌ای را فعال می‌کند
            'teeny'         => false // حالت استاندارد ادیتور وردپرس
        ]); 
        
        if(!empty($args['help'])) echo "<p class='description' style='margin-top:10px;'>{$args['help']}</p>"; 
        echo "</div>"; 
    }

    public function field_sms_config_block($args) { 
        $base = $args['base_id']; 
        $isActive = !empty($this->options[$args['parent_active']]); 
        $style = $isActive ? '' : 'display:none;'; 
        
        // دریافت مقادیر ذخیره شده
        $method = $this->options[$base.'_method'] ?? 'pattern'; 
        $pattern = esc_attr($this->options[$base.'_pattern'] ?? ''); 
        $text = esc_textarea($this->options[$base.'_text'] ?? ''); 
        
        echo "<div id='wrap_{$base}' class='rp-conditional-block' style='{$style}'>";
        
        // اینپوت مخفی برای ذخیره متد انتخاب شده (پترن یا متن)
        // ما کلاس rp-sms-method-input را اضافه کردیم تا در JS بتوانیم پیدایش کنیم
        echo '<input type="hidden" name="reyhan_options['.$base.'_method]" class="rp-sms-method-input" value="'.$method.'">';
        
        ?>
        <div class="rp-mini-tabs-wrapper">
            <ul class="rp-mini-tabs-nav">
                <li data-method="pattern" class="<?php echo ($method === 'pattern') ? 'active' : ''; ?>">
                    <span class="dashicons dashicons-grid-view"></span> ارسال با پترن (الگو)
                </li>
                <li data-method="text" class="<?php echo ($method === 'text') ? 'active' : ''; ?>">
                    <span class="dashicons dashicons-text"></span> ارسال عادی
                </li>
            </ul>
            
            <div class="rp-mini-tab-content content-pattern" style="display: <?php echo ($method === 'pattern') ? 'block' : 'none'; ?>;">
                <div class="rp-input-group">
                    <label>کد پترن (Template ID):</label>
                    <input type="text" name="reyhan_options[<?php echo $base; ?>_pattern]" value="<?php echo $pattern; ?>" class="regular-text" placeholder="مثال: 123456">
                </div>
                <p class="rp-field-desc"><span class="dashicons dashicons-info"></span>در این روش، فقط کد الگو را وارد کنید. متن پیامک باید در پنل اس‌ام‌اس تنظیم شده باشد.</p>
            </div>
            
            <div class="rp-mini-tab-content content-text" style="display: <?php echo ($method === 'text') ? 'block' : 'none'; ?>;">
                <div class="rp-input-group">
                    <label>متن کامل پیامک:</label>
                    <textarea name="reyhan_options[<?php echo $base; ?>_text]" rows="3" class="large-text" placeholder="متن پیام..."><?php echo $text; ?></textarea>
                </div>
                <p class="rp-field-desc"><span class="dashicons dashicons-info"></span>متن کامل پیامک را اینجا بنویسید. (توصیه: اگر خط خدماتی دارید از این بخش استفاده کنید).</p>
            </div>
        </div>
        <?php
        echo "</div>"; 
    }

    public function field_repeater_general($args) {
        $items = $this->options[$args['id']] ?? []; 
        if(!is_array($items)) $items = []; 
        $fields = $args['fields'];
        
        echo '<input type="hidden" name="reyhan_options['.$args['id'].']" value="">';
        // اضافه کردن کلاس rp-repeater-section برای خط جداکننده
        echo '<div class="rp-repeater-wrap rp-repeater-section" data-id="'.$args['id'].'"><div class="rp-repeater-list">';
        
        foreach($items as $index => $item) {
            echo '<div class="rp-repeater-item">';
            
            // بخش ورودی‌ها (سمت راست)
            echo '<div class="rp-repeater-inputs">';
            foreach($fields as $key => $label) {
                $val = esc_attr($item[$key] ?? ''); 
                $name = 'reyhan_options['.$args['id'].']['.$index.']['.$key.']';
                
                echo '<div class="rp-input-group-row">';
                // نمایش لیبل بالای فیلد
                echo '<label class="rp-input-label">'.$label.'</label>';
                
                if($key=='content'||$key=='a') {
                    echo '<textarea name="'.$name.'" rows="2" class="rp-full-width">'.$val.'</textarea>';
                } else {
                    echo '<input type="text" name="'.$name.'" value="'.$val.'" class="rp-full-width">';
                }
                echo '</div>';
            }
            echo '</div>'; // پایان ورودی‌ها
            
            // دکمه حذف (سمت چپ - در یک خط)
            echo '<div class="rp-repeater-actions">';
            echo '<button type="button" class="button rp-remove-row" title="حذف"><span class="dashicons dashicons-no"></span></button>';
            echo '</div>';
            
            echo '</div>'; // پایان آیتم
        }
        
        echo '</div><button type="button" class="button rp-add-row" data-fields=\''.json_encode($fields).'\'>+ '.$args['btn_text'].'</button></div>';
    }

    public function field_recaptcha_block($args) {
        $isActive = !empty($this->options[$args['parent_active']]); $style = $isActive ? '' : 'display:none;';
        $site = esc_attr($this->options['recaptcha_site_key'] ?? ''); $secret = esc_attr($this->options['recaptcha_secret_key'] ?? '');
        echo "<div id='wrap_recaptcha' class='rp-conditional-block' style='{$style}'><p><label>Site Key (کلید سایت):</label><br><input type='text' name='reyhan_options[recaptcha_site_key]' value='{$site}' class='regular-text' style='width:100%'></p><p><label>Secret Key (کلید مخفی):</label><br><input type='text' name='reyhan_options[recaptcha_secret_key]' value='{$secret}' class='regular-text' style='width:100%'></p></div>";
    }

    public function field_section_title($args) {
        $title = $args['title']; // تیتر اصلی (بولد)
        $desc = $args['desc'] ?? ''; // توضیحات (کمرنگ)
        
        echo '<div class="rp-section-header">';
        echo '<span class="rp-section-main-title">' . esc_html($title) . '</span>';
        if($desc) {
            echo '<span class="rp-section-sub-title">' . esc_html($desc) . '</span>';
        }
        echo '</div>';
    }
    public function field_text_modern($args) {
        $val = esc_attr($this->options[$args['id']] ?? '');
        // در اینجا متن placeholder را تغییر دادیم تا مطمئن شویم کد جدید است
        echo '<div class="rp-modern-input-wrap">';
        echo '<span class="dashicons dashicons-media-code rp-input-icon"></span>';
        echo '<input type="text" name="reyhan_options['.$args['id'].']" value="'.$val.'" class="rp-modern-text-field" placeholder="مثال: jpg, png, zip">';
        echo '</div>';
        if(!empty($args['desc'])) {
            echo '<p class="rp-modern-desc">'.$args['desc'].'</p>';
        }
    }
    public function field_text($args) { $val = esc_attr($this->options[$args['id']] ?? ''); echo "<input type='text' name='reyhan_options[{$args['id']}]' value='$val' class='regular-text' id='{$args['id']}'>"; if(!empty($args['desc'])) echo "<p class='description'>{$args['desc']}</p>"; }
    public function field_textarea($args) { $val = esc_textarea($this->options[$args['id']] ?? ''); echo "<textarea name='reyhan_options[{$args['id']}]' rows='5' class='large-text'>$val</textarea>"; }
    public function field_text_small($args) { $val = esc_attr($this->options[$args['id']] ?? ''); echo "<input type='text' name='reyhan_options[{$args['id']}]' value='{$val}' style='width:80px; text-align:center;'> " . ($args['desc'] ?? ''); }
    public function field_checkbox($args) {
        $key = $args['id'];
        $val = $this->options[$key] ?? 0;
        
        echo '<div style="display:flex; align-items:center; gap:10px;">';
        // اینپوت مخفی
        echo '<input type="hidden" name="reyhan_options['.$key.']" value="0">';
        echo '<input type="checkbox" id="'.$key.'" name="reyhan_options['.$key.']" value="1" '.checked($val, 1, false).'>';
        // لیبل که تبدیل به سوئیچ می‌شود
        echo '<label for="'.$key.'"></label>';
        // متن توضیحات
        echo '<span class="rp-toggle-label" style="margin-right:10px;">'.$args['label'].'</span>';
        echo '</div>';
    }
    public function field_checkbox_toggle_wrapper($args) {
        $key = $args['id'];
        $val = $this->options[$key] ?? 0;
        
        echo '<div style="display:flex; align-items:center; gap:10px;">';
        echo '<input type="hidden" name="reyhan_options['.$key.']" value="0">';
        echo '<input type="checkbox" id="'.$key.'" name="reyhan_options['.$key.']" value="1" '.checked($val, 1, false).' class="rp-section-toggle" data-target="'.$args['wrapper_id'].'">';
        echo '<label for="'.$key.'"></label>';
        echo '<span class="rp-toggle-label" style="margin-right:10px;">'.$args['label'].'</span>';
        echo '</div>';
    }
    public function field_color_wp($args) { echo '<input type="text" name="reyhan_options['.$args['id'].']" value="'.esc_attr($this->options[$args['id']]??'').'" class="rp-color-picker" data-default-color="">'; }
    public function field_select_provider() { $val = $this->options['sms_provider'] ?? 'ippanel'; echo "<select name='reyhan_options[sms_provider]'><option value='ippanel' ".selected($val,'ippanel',false).">IPPanel</option><option value='smsir' ".selected($val,'smsir',false).">SMS.ir</option><option value='kaveh' ".selected($val,'kaveh',false).">کاوه نگار</option><option value='melli' ".selected($val,'melli',false).">ملی پیامک</option></select>"; }
    public function field_select_auth($args) { $val = $this->options[$args['id']] ?? 'sms'; echo "<select name='reyhan_options[{$args['id']}]'><option value='sms' ".selected($val,'sms',false).">شماره همراه</option><option value='email' ".selected($val,'email',false).">ایمیل</option></select>"; }
    public function field_textarea_sms($args) { $val = esc_textarea($this->options[$args['id']] ?? ''); echo "<textarea name='reyhan_options[{$args['id']}]' rows='3' class='large-text'>$val</textarea><p class='description'>{$args['desc']}</p>"; }
    public function field_select_shadow($args) { $val=$this->options[$args['id']]??'medium'; echo "<select name='reyhan_options[{$args['id']}]'><option value='none' ".selected($val,'none',false).">بدون سایه</option><option value='light' ".selected($val,'light',false).">کم</option><option value='medium' ".selected($val,'medium',false).">متوسط</option><option value='heavy' ".selected($val,'heavy',false).">زیاد</option></select>"; }
    public function field_textarea_small($args) { $val=esc_textarea($this->options[$args['id']]??''); echo "<textarea name='reyhan_options[{$args['id']}]' rows='2' class='large-text'>$val</textarea>"; }

    public function field_login_page_manager() {
        $val = $this->options['login_page_id'] ?? 0;
        echo '<div style="margin-bottom:10px;">'; wp_dropdown_pages(['name'=>'reyhan_options[login_page_id]', 'selected'=>$val, 'show_option_none'=>'— انتخاب کنید —', 'option_none_value'=>'0', 'class'=>'regular-text']); echo '</div>';
        if($val && get_post($val)) { $link=get_permalink($val); $edit=get_edit_post_link($val); echo "<a href='$link' target='_blank' class='button'>مشاهده</a> <a href='$edit' target='_blank' class='button'>ویرایش</a>"; }
        else { echo "<a href='".admin_url('admin.php?page=reyhan-settings&reyhan_action=create_page')."' class='button button-primary'>ساخت خودکار برگه</a>"; }
    }
    public function field_select_page($args) { $val=$this->options[$args['id']]??0; wp_dropdown_pages(['name'=>"reyhan_options[{$args['id']}]",'selected'=>$val,'show_option_none'=>'— غیرفعال —']); }
    
    public function field_menu_builder($args) {
        // --- کد اصلاحی برای تمام عرض کردن (Full Width) ---
        echo '<script>
            jQuery(document).ready(function($){ 
                var $wrap = $("#rp-menu-builder-wrap"); 
                if($wrap.length){ 
                    // حذف ستون تیتر و ادغام سلول‌ها
                    var $td = $wrap.closest("td");
                    $td.attr("colspan", "2").css("padding", "0");
                    $td.siblings("th").remove();
                    $wrap.css("width", "100%");
                } 
            });
        </script>';
        
        $items = $this->options[$args['id']] ?? [];
        if(empty($items)) $items = [['label'=>'داشبورد', 'action'=>'dashboard'], ['label'=>'خروج', 'action'=>'logout']];
        
        echo '<input type="hidden" name="reyhan_options['.$args['id'].']" value="">';
        echo '<div id="rp-menu-builder-wrap" data-id="'.$args['id'].'">';
        echo '<div class="rp-menu-list">';
        
        foreach($items as $idx => $item) $this->render_menu_item_row($args['id'], $idx, $item);
        
        echo '</div><button type="button" class="button rp-add-menu-item" style="margin-top:10px;">+ افزودن آیتم جدید</button></div>';
    }

    private function render_menu_item_row($base_id, $idx, $item) {
        $label = esc_attr($item['label'] ?? ''); $act = $item['action'] ?? 'link';
        $icon = esc_attr($item['icon'] ?? 'dashicons-marker'); $icon_type = $item['icon_type'] ?? 'icon'; $custom_image = esc_attr($item['custom_image'] ?? '');
        $link = esc_attr($item['link'] ?? ''); $shortcode = esc_textarea($item['shortcode'] ?? '');
        $display_title = $label ? $label : '(بدون عنوان)';

        echo '<div class="rp-repeater-item rp-menu-item-row closed">';
        echo '<div class="rp-item-header"><span class="dashicons dashicons-move rp-sort-handle"></span><span class="rp-item-title">'.$display_title.'</span><div class="rp-header-controls"><span class="rp-item-type-badge">'.$act.'</span><button type="button" class="rp-toggle-item"><span class="dashicons dashicons-arrow-down-alt2"></span></button><button type="button" class="rp-remove-row"><span class="dashicons dashicons-trash"></span></button></div></div>';
        echo '<div class="rp-item-body" style="display:none;"><div class="rp-row-flex"><div class="rp-col-half"><label>عنوان</label><input type="text" name="reyhan_options['.$base_id.']['.$idx.'][label]" value="'.$label.'" class="rp-full-input rp-live-title"></div><div class="rp-col-half"><label>عملکرد</label><select name="reyhan_options['.$base_id.']['.$idx.'][action]" class="rp-full-input rp-menu-action-select"><option value="dashboard" '.selected($act,'dashboard',false).'>داشبورد</option><option value="tickets" '.selected($act,'tickets',false).'>تیکت‌ها</option><option value="orders" '.selected($act,'orders',false).'>سفارشات</option><option value="profile" '.selected($act,'profile',false).'>ویرایش حساب</option><option value="content" '.selected($act,'content',false).'>محتوا</option><option value="link" '.selected($act,'link',false).'>لینک</option><option value="logout" '.selected($act,'logout',false).'>خروج</option></select></div></div>';
        echo '<div class="rp-icon-settings-box"><div class="rp-icon-type-switch"><label><input type="radio" name="reyhan_options['.$base_id.']['.$idx.'][icon_type]" value="icon" '.checked($icon_type,'icon',false).' class="rp-icon-type-radio"> آیکون</label><label><input type="radio" name="reyhan_options['.$base_id.']['.$idx.'][icon_type]" value="image" '.checked($icon_type,'image',false).' class="rp-icon-type-radio"> SVG </label></div><div class="rp-icon-picker-area" style="'.($icon_type=='icon'?'':'display:none').'"><div class="rp-icon-picker-wrap"><button type="button" class="button rp-icon-select-btn"><span class="dashicons '.$icon.' preview-icon"></span> انتخاب</button><input type="hidden" name="reyhan_options['.$base_id.']['.$idx.'][icon]" value="'.$icon.'" class="rp-icon-input"><div class="rp-icon-dropdown"></div></div></div><div class="rp-image-uploader-area" style="'.($icon_type=='image'?'':'display:none').'"><div style="display:flex;gap:10px"><input type="text" name="reyhan_options['.$base_id.']['.$idx.'][custom_image]" value="'.$custom_image.'" class="regular-text rp-image-url"><button type="button" class="button rp-media-upload-btn">انتخاب</button></div></div></div>';
        echo '<div class="rp-menu-extra-settings"><div class="rp-menu-link-row" style="'.($act=='link'?'':'display:none').'"><label>لینک:</label><input type="text" name="reyhan_options['.$base_id.']['.$idx.'][link]" value="'.$link.'" class="rp-full-input" dir="ltr"></div><div class="rp-menu-shortcode-row" style="'.($act=='content'?'':'display:none').'"><label>شورت‌کد:</label><textarea name="reyhan_options['.$base_id.']['.$idx.'][shortcode]" class="rp-full-input" dir="ltr">'.$shortcode.'</textarea></div></div>';
        echo '</div></div>';
    }

    public function field_colors_row($args) {
        echo '<div style="display:flex; flex-wrap:wrap; gap:20px; align-items:flex-end;">';
        foreach($args['items'] as $item) {
            $val = esc_attr($this->options[$item['id']] ?? '');
            echo '<div style="text-align:center;"><label style="display:block;margin-bottom:5px;font-size:12px;font-weight:bold;">'.$item['label'].'</label><input type="text" name="reyhan_options['.$item['id'].']" value="'.$val.'" class="rp-color-picker" data-default-color=""></div>';
        }
        echo '</div>';
    }

    public function field_dashboard_cards_grid() {
        $items = [['id'=>'panel_widget_ticket_hide','label'=>'تیکت'],['id'=>'panel_widget_order_hide','label'=>'سفارش'],['id'=>'panel_widget_comments_hide','label'=>'نظر'],['id'=>'panel_widget_days_hide','label'=>'روز عضویت'],['id'=>'panel_widget_discount_hide','label'=>'کد تخفیف']];
        echo '<div style="display:grid; grid-template-columns:repeat(3,1fr); gap:15px;">';
        foreach($items as $item) {
            echo '<div style="background:#fff; border:1px solid #ddd; padding:10px;"><input type="hidden" name="reyhan_options['.$item['id'].']" value="0"><label><input type="checkbox" name="reyhan_options['.$item['id'].']" value="1" '.checked($this->options[$item['id']]??0,1,false).'> مخفی کردن '.$item['label'].'</label></div>';
        }
        echo '</div>';
    }


    // فیلد شورت‌کد (بروزرسانی شده)
    public function field_tool_shortcodes() { 
        $codes = [
            ['code' => '[reyhan_panel]', 'desc' => 'شورت کد پنل کاربری - درگاه ورود - درگاه عضویت'],
            ['code' => '[reyhan_support]', 'desc' => 'شورت کد ثبت تیکت - لیست تیکت ها'],
        ];

        echo '<div style="display:flex; flex-direction:column; gap:10px;">';
        foreach($codes as $item) {
            echo '<div class="rp-code-box" style="justify-content:space-between;">
                    <div style="display:flex; align-items:center; gap:10px;">
                        <span class="dashicons dashicons-shortcode"></span>
                        <code dir="ltr" style="font-size:14px;">'.$item['code'].'</code>
                    </div>
                    <span style="font-size:12px; color:#abb2bf; opacity:0.8;">'.$item['desc'].'</span>
                  </div>';
        }
        echo '</div>';
        echo '<p class="description" style="margin-top:15px;">این شورت‌کدها را می‌توانید در هر برگه یا نوشته‌ای قرار دهید.</p>'; 
    }

    // فیلد تست ارسال
    public function field_tool_tester() {
        echo '<div class="rp-tool-box" style="background:#e3f2fd; padding:15px; border-radius:8px; border:1px solid #bbdefb;">
                <div style="margin-bottom:10px; display:flex; gap:10px; align-items:center;">
                    <input type="text" id="test_mobile_input" placeholder="شماره موبایل (مثال: 0912...)" class="regular-text">
                    <button type="button" class="button button-primary rp-run-tool" data-action="test_sms">تست پیامک</button>
                </div>
                <div style="display:flex; gap:10px; align-items:center;">
                    <input type="text" id="test_email_input" placeholder="ایمیل (مثال: test@mail.com)" class="regular-text">
                    <button type="button" class="button button-primary rp-run-tool" data-action="test_email">تست ایمیل</button>
                </div>
                <div id="rp-test-result" style="margin-top:15px; font-weight:bold; color:#d32f2f;"></div>
              </div>';
    }

    // عملیات دیتابیس
    public function field_tool_danger_zone() { 
        echo '<div class="rp-tool-box rp-danger-box">
                <div class="rp-tool-row">
                    <span><span class="dashicons dashicons-trash"></span> پاکسازی کدهای تایید (OTP) منقضی</span>
                    <button type="button" class="button rp-run-tool" data-action="clear_otp">اجرا</button>
                </div>
                <div class="rp-tool-row">
                    <span><span class="dashicons dashicons-update"></span> بازنشانی کل تنظیمات افزونه</span>
                    <button type="button" class="button rp-run-tool" data-action="factory_reset">اجرا</button>
                </div>
                <hr style="margin:15px 0; border:0; border-top:1px dashed #ffcdd2;">
                <div class="rp-tool-row">
                    <span><span class="dashicons dashicons-email-alt"></span> حذف تمام تیکت‌ها</span>
                    <button type="button" class="button button-link-delete rp-run-tool" data-action="nuke_tickets">حذف همه</button>
                </div>
                <div class="rp-tool-row">
                    <span><span class="dashicons dashicons-admin-users"></span> حذف تمام کاربران (به جز مدیر)</span>
                    <button type="button" class="button button-link-delete rp-run-tool" data-action="nuke_users">حذف همه</button>
                </div>
              </div>'; 
    }

    // راهنمای دیتابیس
    public function field_tool_guide() { 
        echo '<div class="rp-info-box">
                <h4><span class="dashicons dashicons-info-outline"></span> راهنمای عملیات</h4>
                <ul>
                    <li><strong>پاکسازی کدها:</strong> حذف کدهای یکبار مصرف منقضی شده برای کاهش حجم دیتابیس.</li>
                    <li><strong>بازنشانی تنظیمات:</strong> بازگشت تمام تنظیمات افزونه به حالت اولیه نصب.</li>
                    <li><strong>حذف تیکت‌ها:</strong> حذف کامل تمام تیکت‌های پشتیبانی.</li>
                    <li><strong>حذف کاربران:</strong> حذف تمام کاربران سایت (به جز مدیران کل).</li>
                </ul>
              </div>'; 
    }

    // تابع جدید: انتخابگر پس‌زمینه (تصویر یا رنگ)
    public function field_background_selector_modern() {
        // دریافت مقادیر ذخیره شده
        $mode = $this->options['login_bg_mode'] ?? 'image'; // حالت پیش‌فرض: تصویر
        $bg_image = esc_attr($this->options['login_bg_image'] ?? '');
        $bg_color = esc_attr($this->options['login_bg_color'] ?? '');
        
        // اینپوت مخفی برای ذخیره حالت انتخاب شده (image یا color)
        // کلاس rp-sms-method-input باعث می‌شود جاوااسکریپت تب‌ها روی این فیلد کار کند
        echo '<input type="hidden" name="reyhan_options[login_bg_mode]" class="rp-sms-method-input" value="'.$mode.'">';
        
        ?>
        <div class="rp-mini-tabs-wrapper">
            <ul class="rp-mini-tabs-nav">
                <li data-method="image" class="<?php echo ($mode === 'image') ? 'active' : ''; ?>">
                    <span class="dashicons dashicons-format-image"></span> انتخاب تصویر
                </li>
                <li data-method="color" class="<?php echo ($mode === 'color') ? 'active' : ''; ?>">
                    <span class="dashicons dashicons-art"></span> انتخاب رنگ
                </li>
            </ul>
            
            <div class="rp-mini-tab-content content-image" style="display: <?php echo ($mode === 'image') ? 'block' : 'none'; ?>;">
                <div style="display:flex; gap:10px; align-items:center;">
                    <input type="text" name="reyhan_options[login_bg_image]" id="login_bg_image" value="<?php echo $bg_image; ?>" class="regular-text" dir="ltr" placeholder="آدرس تصویر...">
                    <button type="button" class="button rp-media-upload" data-target="login_bg_image">انتخاب</button>
                    <?php if($bg_image): ?>
                    <button type="button" class="button rp-remove-media" data-target="login_bg_image" title="حذف"><span class="dashicons dashicons-no-alt"></span></button>
                    <?php endif; ?>
                </div>
                <div id="preview-login_bg_image" style="margin-top:10px;">
                    <?php if($bg_image) echo '<img src="'.$bg_image.'" style="max-width:100px; border-radius:5px; box-shadow:0 2px 5px rgba(0,0,0,0.1);">'; ?>
                </div>
            </div>
            
            <div class="rp-mini-tab-content content-color" style="display: <?php echo ($mode === 'color') ? 'block' : 'none'; ?>;">
                <div class="rp-input-group">
                    <label>رنگ پس‌زمینه:</label>
                    <input type="text" name="reyhan_options[login_bg_color]" value="<?php echo $bg_color; ?>" class="rp-color-picker" data-default-color="#f0f0f1">
                </div>
                <p class="rp-field-desc"><span class="dashicons dashicons-info"></span>در این حالت، به جای تصویر از رنگ یکدست استفاده می‌شود.</p>
            </div>
        </div>
        <?php
    }

    public function field_theme_selector() {
        // اگر تنظیمی ذخیره نشده بود، روی 'default' باشد
        $current = $this->options['panel_active_theme'] ?? 'default';
        
        $themes = [
            'default' => ['name'=>'پیش‌فرض (آتشین)', 'img'=>'t0.png'], // تم جدید اضافه شده
            'theme_1' => ['name'=>'سبز (طبیعت)', 'img'=>'t1.png'],
            'theme_2' => ['name'=>'آبی (اقیانوس)', 'img'=>'t2.png'],
            'theme_3' => ['name'=>'بنفش (غروب)', 'img'=>'t3.png'],
            'theme_4' => ['name'=>'یاسی (رویا)', 'img'=>'t4.png'],
        ];
        ?>
        <style>
            .rp-theme-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 20px; margin-top: 10px; }
            .rp-theme-card { 
                border: 2px solid #eee; border-radius: 12px; overflow: hidden; cursor: pointer; 
                transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1); position: relative; background: #fff;
            }
            .rp-theme-card:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.08); }
            .rp-theme-card.active { border-color: #FF5722; box-shadow: 0 0 0 3px rgba(255, 87, 34, 0.2); }
            .rp-theme-card.active::after {
                content: '\f147'; font-family: dashicons; position: absolute; top: 10px; left: 10px;
                background: #FF5722; color: #fff; border-radius: 50%; width: 24px; height: 24px;
                display: flex; align-items: center; justify-content: center; font-size: 16px;
            }
            .rp-theme-img { width: 100%; height: 120px; object-fit: cover; background: #f5f5f5; display: block; }
            .rp-theme-name { padding: 12px; text-align: center; font-weight: bold; color: #555; font-size: 13px; border-top: 1px solid #f0f0f0; }
        </style>

        <div class="rp-theme-grid">
            <?php foreach($themes as $key => $theme): 
                $active_class = ($current === $key) ? 'active' : '';
                $img_url = REYHAN_URL . 'assets/images/' . $theme['img'];
            ?>
                <div class="rp-theme-card <?php echo $active_class; ?>" onclick="selectRpTheme('<?php echo $key; ?>', this)">
                    <img src="<?php echo esc_url($img_url); ?>" class="rp-theme-img" alt="<?php echo $theme['name']; ?>">
                    <div class="rp-theme-name"><?php echo $theme['name']; ?></div>
                </div>
            <?php endforeach; ?>
            <input type="hidden" name="reyhan_options[panel_active_theme]" id="rp_active_theme_input" value="<?php echo esc_attr($current); ?>">
        </div>

        <script>
            function selectRpTheme(themeKey, el) {
                jQuery('.rp-theme-card').removeClass('active');
                jQuery(el).addClass('active');
                jQuery('#rp_active_theme_input').val(themeKey);
            }
        </script>
        <?php
    }

    public function field_login_theme_selector() {
        $current = $this->options['login_active_theme'] ?? 'default';
        
        $themes = [
            'default' => ['name'=>'پیش‌فرض (آتشین)', 'img'=>'t0.png'],
            'theme_1' => ['name'=>'سبز (طبیعت)', 'img'=>'t1.png'],
            'theme_2' => ['name'=>'آبی (اقیانوس)', 'img'=>'t2.png'],
            'theme_3' => ['name'=>'بنفش (غروب)', 'img'=>'t3.png'],
            'theme_4' => ['name'=>'یاسی (رویا)', 'img'=>'t4.png'],
        ];
        ?>
        <style>
            .rp-theme-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 15px; margin-top: 10px; }
            .rp-theme-card { border: 2px solid #eee; border-radius: 10px; overflow: hidden; cursor: pointer; transition: all 0.2s; position: relative; }
            .rp-theme-card:hover { transform: translateY(-3px); box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
            .rp-theme-card.active { border-color: #FF5722; box-shadow: 0 0 0 3px rgba(255, 87, 34, 0.2); }
            .rp-theme-card.active::after { content: '\f147'; font-family: dashicons; position: absolute; top: 5px; left: 5px; background: #FF5722; color: #fff; border-radius: 50%; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; font-size: 14px; }
            .rp-theme-img { width: 100%; height: 100px; object-fit: cover; display: block; }
            .rp-theme-name { padding: 8px; text-align: center; font-weight: bold; color: #555; font-size: 12px; background: #fff; border-top: 1px solid #eee; }
        </style>

        <div class="rp-theme-grid">
            <?php foreach($themes as $key => $theme): 
                $active_class = ($current === $key) ? 'active' : '';
                $img_url = REYHAN_URL . 'assets/images/' . $theme['img'];
            ?>
                <div class="rp-theme-card <?php echo $active_class; ?>" onclick="selectLoginTheme('<?php echo $key; ?>', this)">
                    <img src="<?php echo esc_url($img_url); ?>" class="rp-theme-img" alt="<?php echo $theme['name']; ?>">
                    <div class="rp-theme-name"><?php echo $theme['name']; ?></div>
                </div>
            <?php endforeach; ?>
            <input type="hidden" name="reyhan_options[login_active_theme]" id="rp_login_theme_input" value="<?php echo esc_attr($current); ?>">
        </div>

        <script>
            function selectLoginTheme(themeKey, el) {
                jQuery(el).siblings().removeClass('active');
                jQuery(el).addClass('active');
                jQuery('#rp_login_theme_input').val(themeKey);
            }
        </script>
        <?php
    }

    public function field_ticket_signatures() {
        $header = esc_textarea($this->options['ticket_reply_header'] ?? '');
        $footer = esc_textarea($this->options['ticket_reply_footer'] ?? '');
        ?>
        <div class="rp-signature-grid">
            <div class="rp-sig-box header">
                <div class="rp-sig-title"><span class="dashicons dashicons-arrow-up-alt2"></span> پیشوند (شروع پیام)</div>
                <textarea name="reyhan_options[ticket_reply_header]" class="rp-modern-textarea" placeholder="مثال: با سلام و احترام،&#10;از تماس شما متشکریم..."><?php echo $header; ?></textarea>
                <p class="rp-sig-desc">این متن به صورت خودکار در ابتدای پاسخ شما قرار می‌گیرد.</p>
            </div>
            
            <div class="rp-sig-icon"><span class="dashicons dashicons-plus"></span></div>
            
            <div class="rp-sig-content-placeholder">
                متن پاسخ شما
            </div>

            <div class="rp-sig-icon"><span class="dashicons dashicons-plus"></span></div>

            <div class="rp-sig-box footer">
                <div class="rp-sig-title"><span class="dashicons dashicons-arrow-down-alt2"></span> پسوند (امضاء / پایان پیام)</div>
                <textarea name="reyhan_options[ticket_reply_footer]" class="rp-modern-textarea" placeholder="مثال: ارادتمند شما&#10;تیم پشتیبانی ریحان پنل"><?php echo $footer; ?></textarea>
                <p class="rp-sig-desc">این متن به صورت خودکار در انتهای پاسخ شما قرار می‌گیرد.</p>
            </div>
        </div>
        <?php
    }

    // فیلد پاسخ‌های آماده شخصی (ذخیره در متای کاربر)
    public function field_canned_responses_personal($args) {
        // دریافت شناسه کاربر جاری
        $uid = get_current_user_id();
        // دریافت اطلاعات از متای کاربر
        $items = get_user_meta($uid, 'rp_user_canned_responses', true);
        if(!is_array($items)) $items = []; 
        
        $fields = $args['fields'];
        // یک شناسه موقت برای فرم استفاده می‌کنیم تا در sanitize آن را بگیریم
        $temp_id = 'ticket_canned_personal_temp';
        
        echo '<input type="hidden" name="reyhan_options['.$temp_id.']" value="">';
        echo '<div class="rp-repeater-wrap rp-repeater-section" data-id="'.$temp_id.'"><div class="rp-repeater-list">';
        
        foreach($items as $index => $item) {
            echo '<div class="rp-repeater-item">';
            echo '<div class="rp-repeater-inputs">';
            foreach($fields as $key => $label) {
                $val = esc_attr($item[$key] ?? ''); 
                $name = 'reyhan_options['.$temp_id.']['.$index.']['.$key.']';
                
                echo '<div class="rp-input-group-row">';
                echo '<label class="rp-input-label">'.$label.'</label>';
                if($key=='content') {
                    echo '<textarea name="'.$name.'" rows="2" class="rp-full-width">'.$val.'</textarea>';
                } else {
                    echo '<input type="text" name="'.$name.'" value="'.$val.'" class="rp-full-width">';
                }
                echo '</div>';
            }
            echo '</div>';
            echo '<div class="rp-repeater-actions">';
            echo '<button type="button" class="button rp-remove-row" title="حذف"><span class="dashicons dashicons-no"></span></button>';
            echo '</div>';
            echo '</div>';
        }
        
        echo '</div><button type="button" class="button rp-add-row" data-fields=\''.json_encode($fields).'\'>+ '.$args['btn_text'].'</button></div>';
        echo '<p class="description">این پاسخ‌ها اختصاصی برای شما هستند و سایر مدیران پاسخ‌های مخصوص خودشان را می‌بینند.</p>';
    }

    // --- هندلر ذخیره اطلاعات پروفایل ایجنت ---
    public function handle_agent_profile_save() {
        if ( isset($_POST['rp_agent_profile_nonce']) && wp_verify_nonce($_POST['rp_agent_profile_nonce'], 'save_agent_profile') ) {
            $uid = get_current_user_id();
            
            // 1. ذخیره نام و نام خانوادگی
            if(isset($_POST['first_name'])) update_user_meta($uid, 'first_name', sanitize_text_field($_POST['first_name']));
            if(isset($_POST['last_name'])) update_user_meta($uid, 'last_name', sanitize_text_field($_POST['last_name']));
            
            $display_name = trim(sanitize_text_field($_POST['first_name']) . ' ' . sanitize_text_field($_POST['last_name']));
            if(!empty($display_name)) {
                wp_update_user([ 'ID' => $uid, 'display_name' => $display_name ]);
            }

            // 2. آپلود و ذخیره آواتار (روش جدید: مستقیم از سیستم کاربر)
            if ( !empty($_FILES['agent_avatar_file']['name']) ) {
                require_once( ABSPATH . 'wp-admin/includes/image.php' );
                require_once( ABSPATH . 'wp-admin/includes/file.php' );
                require_once( ABSPATH . 'wp-admin/includes/media.php' );

                $attachment_id = media_handle_upload( 'agent_avatar_file', 0 );

                if ( ! is_wp_error( $attachment_id ) ) {
                    $image_url = wp_get_attachment_url( $attachment_id );
                    update_user_meta($uid, 'reyhan_user_avatar', $image_url);
                }
            }
            // اگر کاربر دکمه حذف را زده بود (مقدار اینپوت مخفی خالی شده بود)
            elseif ( isset($_POST['reyhan_user_avatar_status']) && $_POST['reyhan_user_avatar_status'] === 'removed' ) {
                delete_user_meta($uid, 'reyhan_user_avatar');
            }

            // 3. ذخیره پاسخ‌های آماده
            if ( isset($_POST['reyhan_options']['rp_user_canned_responses']) ) {
                $canned = $_POST['reyhan_options']['rp_user_canned_responses'];
                if(is_array($canned)) {
                    $canned = array_values($canned);
                    update_user_meta($uid, 'rp_user_canned_responses', $canned);
                }
            } else {
                delete_user_meta($uid, 'rp_user_canned_responses');
            }

            wp_redirect( add_query_arg( 'updated', 'true', admin_url('admin.php?page=reyhan-agent-profile') ) );
            exit;
        }
    }

    // --- رندر صفحه ویرایش پروفایل (نسخه ایزوله شده نهایی) ---
    public function render_agent_profile_page() {
        $uid = get_current_user_id();
        
        $fname = get_user_meta($uid, 'first_name', true);
        $lname = get_user_meta($uid, 'last_name', true);
        $avatar = get_user_meta($uid, 'reyhan_user_avatar', true);
        $default_avatar = REYHAN_URL . 'assets/images/user.png';
        $preview_src = !empty($avatar) ? $avatar : $default_avatar;
        
        $canned = get_user_meta($uid, 'rp_user_canned_responses', true);
        if(!is_array($canned)) $canned = [];

        ?>
        <div class="wrap ticketina-wrap rp-agent-profile-wrap">
            <h1>ویرایش پروفایل پاسخگو</h1>
            
            <?php if(isset($_GET['updated'])): ?>
                <div id="reyhan-toast-msg" class="rp-modern-toast">
                    <span class="dashicons dashicons-yes-alt"></span> 
                    <span>اطلاعات پروفایل با موفقیت بروزرسانی شد.</span>
                </div>
            <?php endif; ?>

            <form method="post" action="" enctype="multipart/form-data">
                <?php wp_nonce_field('save_agent_profile', 'rp_agent_profile_nonce'); ?>
                
                <div class="rp-profile-layout">
                    
                    <div class="rp-card-modern">
                        <div class="rp-card-header">
                            <div class="rp-header-icon"><span class="dashicons dashicons-id-alt"></span></div>
                            <h3>اطلاعات نمایش داده شده</h3>
                        </div>
                        <div class="rp-card-body">
                            
                            <div class="rp-profile-flex-container">
                                <div class="rp-avatar-upload-section">
                                    <div class="rp-agent-preview-circle" id="trigger-img-click">
                                        <img src="<?php echo esc_url($preview_src); ?>" id="agent-profile-img" data-default="<?php echo esc_url($default_avatar); ?>">
                                        <div class="rp-avatar-overlay">
                                            <span class="dashicons dashicons-camera"></span>
                                        </div>
                                    </div>
                                    
                                    <div class="rp-avatar-actions">
                                        <input type="file" name="agent_avatar_file" id="real_file_input" style="display:none;" accept="image/*" onchange="previewLocalImage(this)">
                                        
                                        <input type="hidden" name="reyhan_user_avatar_status" id="avatar_status_input" value="kept">

                                        <button type="button" id="btn-trigger-sys-upload" class="button rp-sys-upload-btn">
                                            <span class="dashicons dashicons-upload"></span> تغییر تصویر
                                        </button>
                                        
                                        <button type="button" class="button rp-sys-remove-btn" id="btn-remove-sys-avatar" style="<?php echo empty($avatar) ? 'display:none;' : ''; ?>">
                                            <span class="dashicons dashicons-trash"></span> حذف
                                        </button>
                                    </div>
                                </div>

                                <div class="rp-fields-section">
                                    <div class="rp-form-row">
                                        <div class="rp-col">
                                            <label>نام کوچک</label>
                                            <input type="text" name="first_name" value="<?php echo esc_attr($fname); ?>" class="rp-input-modern">
                                        </div>
                                        <div class="rp-col">
                                            <label>نام خانوادگی</label>
                                            <input type="text" name="last_name" value="<?php echo esc_attr($lname); ?>" class="rp-input-modern">
                                        </div>
                                    </div>
                                    <p class="rp-helper-text">این نام و تصویر در بالای چت تیکت‌ها به کاربر نمایش داده می‌شود.</p>
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="rp-card-modern">
                        <div class="rp-card-header">
                            <div class="rp-header-icon blue"><span class="dashicons dashicons-format-chat"></span></div>
                            <h3>پاسخ‌های آماده شخصی</h3>
                        </div>
                        <div class="rp-card-body">
                            <p class="rp-helper-text" style="margin-bottom:20px;">جملات پرکاربرد خود را اینجا ذخیره کنید.</p>
                            
                            <div class="rp-repeater-wrap rp-repeater-section" data-id="rp_user_canned_responses">
                                <div class="rp-repeater-list">
                                    <?php foreach($canned as $idx => $item): ?>
                                    <div class="rp-repeater-item">
                                        <div class="rp-repeater-inputs">
                                            <div class="rp-input-group-row">
                                                <label class="rp-input-label">عنوان کوتاه</label>
                                                <input type="text" name="reyhan_options[rp_user_canned_responses][<?php echo $idx; ?>][title]" value="<?php echo esc_attr($item['title']??''); ?>" class="rp-full-width">
                                            </div>
                                            <div class="rp-input-group-row">
                                                <label class="rp-input-label">متن پاسخ</label>
                                                <textarea name="reyhan_options[rp_user_canned_responses][<?php echo $idx; ?>][content]" rows="2" class="rp-full-width"><?php echo esc_textarea($item['content']??''); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="rp-repeater-actions">
                                            <button type="button" class="button rp-remove-row"><span class="dashicons dashicons-no"></span></button>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                                <button type="button" class="button rp-add-row" data-fields='{"title":"عنوان","content":"متن"}'>
                                    <span class="dashicons dashicons-plus"></span> افزودن پاسخ جدید
                                </button>
                            </div>

                        </div>
                    </div>

                </div>

                <div class="rp-save-bar-fixed">
                    <div class="rp-save-info"><span class="dashicons dashicons-info"></span> تغییرات پس از ذخیره اعمال می‌شود.</div>
                    <button type="submit" class="button button-primary rp-save-btn">ذخیره تغییرات پروفایل</button>
                </div>

            </form>
        </div>

        <script>
            // تابع پیش‌نمایش
            function previewLocalImage(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        jQuery('#agent-profile-img').attr('src', e.target.result);
                        jQuery('#btn-remove-sys-avatar').fadeIn();
                        jQuery('#avatar_status_input').val('changed');
                    }
                    reader.readAsDataURL(input.files[0]);
                }
            }

            jQuery(document).ready(function($){
                
                // 1. باز کردن آپلودر سیستم (با قطع کردن تمام ایونت‌های قبلی)
                $('#btn-trigger-sys-upload, #trigger-img-click').off('click').on('click', function(e){
                    e.preventDefault();
                    e.stopPropagation(); 
                    e.stopImmediatePropagation(); // حیاتی: جلوگیری از اجرای کدهای admin.js
                    
                    $('#real_file_input').click(); // باز کردن دیالوگ فایل
                });

                // 2. دکمه حذف
                $('#btn-remove-sys-avatar').off('click').on('click', function(e){
                    e.preventDefault();
                    var def = $('#agent-profile-img').data('default');
                    $('#real_file_input').val(''); 
                    $('#agent-profile-img').attr('src', def);
                    $('#avatar_status_input').val('removed');
                    $(this).fadeOut();
                });

                // 3. محو شدن پیام موفقیت
                var $toast = $('.rp-notice-success');
                if($toast.length > 0) {
                    setTimeout(function(){ $toast.fadeOut(500); }, 3000);
                }
            });
        </script>

        <style>
            .rp-agent-profile-wrap { margin: 20px; max-width: 1200px; }
            .rp-profile-layout { display: flex; flex-direction: column; gap: 30px; margin-bottom: 80px; }
            .rp-card-modern { background: #fff; border-radius: 16px; box-shadow: 0 5px 20px rgba(0,0,0,0.03); border: 1px solid #e0e0e0; overflow: hidden; }
            .rp-card-header { padding: 20px 25px; border-bottom: 1px solid #eee; display: flex; align-items: center; gap: 15px; background: #fafafa; }
            .rp-header-icon { width: 40px; height: 40px; background: #FFF3E0; color: #FF5722; border-radius: 10px; display: flex; align-items: center; justify-content: center; }
            .rp-header-icon.blue { background: #E3F2FD; color: #2196F3; }
            .rp-header-icon .dashicons { font-size: 20px; width: 20px; height: 20px; }
            .rp-card-header h3 { margin: 0; font-size: 16px; font-weight: 800; color: #333; }
            .rp-card-body { padding: 30px; }
            
            .rp-profile-flex-container { display: flex; gap: 40px; align-items: flex-start; }
            .rp-avatar-upload-section { flex-shrink: 0; display: flex; flex-direction: column; align-items: center; width: 150px; }
            
            .rp-agent-preview-circle { width: 130px; height: 130px; border-radius: 50%; position: relative; overflow: hidden; border: 5px solid #fff; box-shadow: 0 8px 25px rgba(0,0,0,0.1); cursor: pointer; background: #f0f0f0; }
            .rp-agent-preview-circle img { width: 100% !important; height: 100% !important; object-fit: cover; transition: 0.3s; }
            .rp-avatar-overlay { position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.4); display: flex; align-items: center; justify-content: center; opacity: 0; transition: 0.3s; }
            .rp-avatar-overlay .dashicons { color: #fff; font-size: 30px; }
            .rp-agent-preview-circle:hover .rp-avatar-overlay { opacity: 1; }
            
            .rp-avatar-actions { margin-top: 15px; text-align: center; display:flex; flex-direction:column; gap:10px; width:100%; }
            
            /* کلاس‌های جدید دکمه‌ها */
            .rp-sys-upload-btn { background: #FF5722 !important; border: none !important; color: #fff !important; border-radius: 50px !important; font-size: 13px !important; padding: 8px 15px !important; display:inline-flex !important; align-items:center; justify-content:center; gap:5px; }
            .rp-sys-upload-btn:hover { background: #E64A19 !important; }
            
            .rp-sys-remove-btn { border: 1px solid #ddd !important; background: transparent !important; color: #d32f2f !important; border-radius: 50px !important; font-size: 12px !important; padding: 5px 15px !important; display:inline-flex !important; align-items:center; justify-content:center; gap:5px; }
            .rp-sys-remove-btn:hover { background: #ffebee !important; border-color: #ef5350 !important; }

            .rp-fields-section { flex-grow: 1; }
            .rp-form-row { display: flex; gap: 20px; margin-bottom: 15px; }
            .rp-col { flex: 1; }
            .rp-col label { display: block; font-weight: bold; margin-bottom: 8px; color: #555; }
            .rp-input-modern { width: 100%; padding: 12px 15px; border: 2px solid #eee; border-radius: 10px; font-size: 14px; transition: 0.3s; background: #fdfdfd; }
            .rp-input-modern:focus { border-color: #FF5722; background: #fff; box-shadow: 0 5px 15px rgba(255,87,34,0.1); outline: none; }
            .rp-helper-text { color: #888; font-size: 13px; line-height: 1.6; margin-top: 5px; }
            .rp-save-bar-fixed { position: fixed; bottom: 0; left: 0; right: 0; background: #fff; border-top: 1px solid #ddd; padding: 15px 40px; display: flex; justify-content: space-between; align-items: center; z-index: 999; box-shadow: 0 -5px 20px rgba(0,0,0,0.05); padding-left: 180px; }
            .rp-save-info { display: flex; align-items: center; gap: 5px; color: #666; font-size: 13px; }
            .rp-save-btn { background: linear-gradient(135deg, #FF5722, #F4511E) !important; border: none !important; padding: 10px 30px !important; height: 45px !important; font-size: 15px !important; font-weight: bold !important; box-shadow: 0 5px 15px rgba(255, 87, 34, 0.3) !important; border-radius: 8px !important; transition: 0.3s !important; }
            .rp-save-btn:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(255, 87, 34, 0.4) !important; }
            @media screen and (max-width: 782px) { .rp-profile-flex-container { flex-direction: column; align-items: center; } .rp-form-row { flex-direction: column; gap: 15px; } .rp-save-bar-fixed { padding-left: 20px; flex-direction: column; gap: 10px; text-align: center; } }
            .rp-notice-success { background: #E8F5E9; border-left: 4px solid #4CAF50; color: #2E7D32; padding: 15px 20px; border-radius: 8px; margin-bottom: 20px; font-weight: bold; display: flex; align-items: center; gap: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        </style>
        <?php
    }

    // --- متد کمکی برای فراخوانی قالب‌ها ---
    private function load_view( $view_name, $args = [] ) {
        if ( ! empty( $args ) && is_array( $args ) ) {
            extract( $args ); 
        }
        
        $file = REYHAN_DIR . 'templates/admin/' . $view_name . '.php';
        if ( file_exists( $file ) ) {
            include $file;
        } else {
            echo '<div class="error"><p>فایل قالب پیدا نشد: ' . esc_html( $view_name ) . '</p></div>';
        }
    }

}