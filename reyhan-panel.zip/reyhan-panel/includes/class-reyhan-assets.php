<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Reyhan_Assets {

    private $version;
    private $url;

    public function __construct() {
        $this->version = REYHAN_VERSION;
        $this->url     = REYHAN_URL;

        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin' ] );
        add_action( 'wp_enqueue_scripts',    [ $this, 'enqueue_frontend' ] );
    }

    /**
     * بارگذاری فایل‌های سمت مدیریت
     */
    public function enqueue_admin( $hook ) {
        // فقط در صفحات مربوط به افزونه لود شود
        if ( strpos( $hook, 'reyhan' ) === false ) {
            return;
        }

        // کتابخانه‌های پیش‌فرض وردپرس
        wp_enqueue_media();
        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_script( 'wp-color-picker' );
        wp_enqueue_script( 'jquery-ui-sortable' );

        // استایل اصلی ادمین
        wp_enqueue_style( 'reyhan-admin-css', $this->url . 'assets/css/admin.css', [], $this->version );
        $this->inject_custom_font( 'reyhan-admin-css' );

        // اسکریپت اصلی ادمین
        wp_enqueue_script( 'reyhan-admin-js', $this->url . 'assets/js/admin.js', [ 'jquery', 'wp-color-picker', 'jquery-ui-sortable' ], $this->version, true );

        // انتقال داده‌ها به JS
        $uid = get_current_user_id();
        $canned = get_user_meta( $uid, 'rp_user_canned_responses', true );
        
        wp_localize_script( 'reyhan-admin-js', 'reyhan_admin_ajax', [
            'ajax_url'         => admin_url( 'admin-ajax.php' ),
            'nonce'            => wp_create_nonce( 'reyhan_admin_nonce' ),
            'canned_responses' => ! empty( $canned ) ? array_values( $canned ) : []
        ]);
    }

    /**
     * بارگذاری فایل‌های سمت کاربر
     */
    public function enqueue_frontend() {
        if ( ! $this->should_load_frontend() ) {
            return;
        }

        $opts = get_option( 'reyhan_options' );

        wp_enqueue_style( 'dashicons' );
        wp_enqueue_style( 'reyhan-front-css', $this->url . 'assets/css/frontend.css', [], $this->version );
        $this->inject_custom_font( 'reyhan-front-css' );

        wp_enqueue_script( 'reyhan-front-js', $this->url . 'assets/js/frontend.js', [ 'jquery' ], $this->version, true );

        // آماده‌سازی داده‌های JS
        $raw_faqs = ! empty( $opts['ticket_faqs'] ) ? $opts['ticket_faqs'] : [];
        
        wp_localize_script( 'reyhan-front-js', 'reyhan_front_obj', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'reyhan_auth_nonce' ),
            'faqs'     => is_array( $raw_faqs ) ? array_values( $raw_faqs ) : [],
            'labels'   => [ 'wait' => 'لطفاً صبر کنید...', 'success' => 'عملیات موفقیت‌آمیز بود.' ],
            'limits'   => [
                'size' => ! empty( $opts['file_max_size'] ) ? $opts['file_max_size'] : 2,
                'exts' => ! empty( $opts['file_allowed_extensions'] ) ? $opts['file_allowed_extensions'] : 'jpg,png,pdf,zip'
            ]
        ]);

        // گوگل ریکپچا
        if ( ! empty( $opts['recaptcha_active'] ) && ! empty( $opts['recaptcha_site_key'] ) ) {
            wp_enqueue_script( 'google-recaptcha', 'https://www.google.com/recaptcha/api.js?render=' . esc_attr( $opts['recaptcha_site_key'] ), [], null, true );
            wp_localize_script( 'reyhan-front-js', 'reyhan_captcha', [ 'site_key' => $opts['recaptcha_site_key'] ] );
        }
    }

    /**
     * بررسی شرایط لود شدن در فرانت
     */
    private function should_load_frontend() {
        global $post;
        $opts = get_option( 'reyhan_options' );
        $login_page_id = $opts['login_page_id'] ?? 0;

        // 1. اگر در برگه اختصاصی پنل هستیم
        if ( is_page() && ! empty( $login_page_id ) && get_the_ID() == $login_page_id ) {
            return true;
        }

        // 2. اگر شورت‌کد در محتوا وجود دارد
        if ( is_a( $post, 'WP_Post' ) ) {
            if ( has_shortcode( $post->post_content, 'reyhan_panel' ) || has_shortcode( $post->post_content, 'reyhan_support' ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * تزریق CSS فونت سفارشی (برای جلوگیری از تکرار کد)
     */
    private function inject_custom_font( $handle ) {
        $opts = get_option( 'reyhan_options' );
        if ( isset( $opts['active_plugin_font'] ) && $opts['active_plugin_font'] != '1' ) {
            return;
        }

        $font_reg  = $this->url . 'assets/fonts/Regular.woff2';
        $font_bold = $this->url . 'assets/fonts/SemiBold.woff2';

        $css = "
            @font-face { font-family: 'ReyhanFont'; src: url('$font_reg') format('woff2'); font-weight: normal; font-style: normal; font-display: swap; }
            @font-face { font-family: 'ReyhanFontBold'; src: url('$font_bold') format('woff2'); font-weight: bold; font-style: normal; font-display: swap; }
            #reyhan-app-root *:not(.dashicons), .reyhanpanel-wrap, .rp-settings-container { font-family: 'ReyhanFont', Tahoma, sans-serif !important; }
            #reyhan-app-root h1, #reyhan-app-root h2, #reyhan-app-root h3, #reyhan-app-root .rp-btn-primary, .reyhanpanel-wrap h1, .reyhanpanel-wrap h2 { font-family: 'ReyhanFontBold', Tahoma, sans-serif !important; }
            #reyhan-app-root .dashicons { font-family: dashicons !important; }
        ";
        
        wp_add_inline_style( $handle, $css );
    }
}