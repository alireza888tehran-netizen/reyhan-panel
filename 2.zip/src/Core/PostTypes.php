<?php
namespace ReyhanPanel\Core;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class PostTypes {

    public function __construct() {
        add_action( 'init', array( $this, 'register_post_type' ) );
        add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );
        add_action( 'save_post_ticket', array( $this, 'save_meta_boxes' ) );
        add_filter( 'views_edit-ticket', array( $this, 'remove_add_new_link' ) );
        add_action( 'admin_menu', array( $this, 'add_menu_notification' ), 999 );
    }

    public function register_post_type() {
        register_post_type( 'ticket', array(
            'labels' => array(
                'name' => __('تیکت‌ها', 'reyhan-panel'),
                'singular_name' => __('تیکت', 'reyhan-panel'),
                'all_items' => __('همه تیکت‌ها', 'reyhan-panel'),
                'edit_item' => __('بررسی تیکت', 'reyhan-panel'),
                'view_item' => __('مشاهده', 'reyhan-panel'),
                'search_items' => __('جستجو', 'reyhan-panel'),
                'not_found' => __('تیکتی نیست', 'reyhan-panel'),
                'not_found_in_trash' => __('زباله‌دان خالی است', 'reyhan-panel')
            ),
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => false, 
            'supports' => array('title', 'editor', 'author', 'comments', 'custom-fields'),
            'capability_type' => 'post',
            'menu_icon' => 'dashicons-email-alt'
        ));
    }

    public function add_meta_boxes() {
        add_meta_box( 'ticket_status', __('وضعیت تیکت', 'reyhan-panel'), array($this, 'render_status_box'), 'ticket', 'side' );
    }

    public function render_status_box($post) {
        $status = get_post_meta($post->ID, '_ticket_status', true);
        $file = REYHAN_DIR . 'templates/admin/partials/metabox-status.php';
        if ( file_exists( $file ) ) { include $file; }
    }

    public function save_meta_boxes($post_id) {
        if(isset($_POST['ticket_status'])) {
            update_post_meta($post_id, '_ticket_status', sanitize_text_field($_POST['ticket_status']));
        }
    }

    public function remove_add_new_link($views) { return $views; }

    public function add_menu_notification() {
        $count = $this->get_unreviewed_count();
        if ($count > 0) {
            global $menu;
            foreach ( $menu as $key => $item ) {
                if ( isset($item[2]) && $item[2] == 'reyhan-tickets' ) {
                    $menu[$key][0] .= ' <span class="awaiting-mod count-1"><span class="pending-count">' . $count . '</span></span>';
                    break;
                }
            }
        }
    }

    private function get_unreviewed_count() {
        $uid = get_current_user_id();
        $transient_key = 'rp_pending_count_' . $uid;
        $cached = get_transient($transient_key);
        if ($cached !== false) return (int) $cached;

        $is_admin = current_user_can('manage_options');
        
        // *** اصلاح: خواندن از دیتای جدا شده ***
        $agents_raw = get_option('reyhan_heavy_ticket_support_agents_data');
        if ( ! $agents_raw ) {
            $opts = get_option('reyhan_options');
            $agents_raw = $opts['ticket_support_agents_data'] ?? '[]';
        }
        $agents_data = is_string($agents_raw) ? json_decode($agents_raw, true) : $agents_raw;
        if (!is_array($agents_data)) $agents_data = [];

        $current_agent = null;
        foreach ($agents_data as $agent) {
            if (isset($agent['id']) && intval($agent['id']) === intval($uid)) {
                $current_agent = $agent;
                break;
            }
        }

        $has_full_access = false;
        $allowed_depts = [];

        if ($current_agent) {
            if (!empty($current_agent['all_depts'])) {
                $has_full_access = true;
            } else {
                $allowed_depts = $current_agent['depts'] ?? [];
            }
        } elseif ($is_admin) {
            $has_full_access = true;
        } else {
            set_transient($transient_key, 0, 10 * MINUTE_IN_SECONDS);
            return 0;
        }

        $args = array(
            'post_type' => 'ticket', 
            'post_status' => 'publish', 
            'fields' => 'ids',
            'meta_query' => array( array('key' => '_ticket_status', 'value' => 'open') )
        );

        if (!$has_full_access) {
            if (empty($allowed_depts)) {
                set_transient($transient_key, 0, 10 * MINUTE_IN_SECONDS);
                return 0;
            }
            $args['meta_query'][] = array(
                'key' => '_ticket_department', 'value' => $allowed_depts, 'compare' => 'IN'
            );
        }

        $query = new \WP_Query($args);
        $count = $query->found_posts;
        set_transient($transient_key, $count, 10 * MINUTE_IN_SECONDS);
        return $count;
    }
}