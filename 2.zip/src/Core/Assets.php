<?php
namespace ReyhanPanel\Core;
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Assets {
    private $version;
    private $url;

    public function __construct() {
        $this->version = defined('REYHAN_VERSION') ? REYHAN_VERSION : '3.0.0';
        $this->url     = defined('REYHAN_URL') ? REYHAN_URL : plugin_dir_url( dirname( dirname( __FILE__ ) ) );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin' ] );
        add_action( 'wp_enqueue_scripts',    [ $this, 'enqueue_frontend' ] );
    }

    public function enqueue_admin( $hook ) {
        if ( strpos( $hook, 'reyhan' ) === false ) return;
        wp_enqueue_media(); wp_enqueue_style( 'wp-color-picker' ); wp_enqueue_script( 'wp-color-picker' ); wp_enqueue_script( 'jquery-ui-sortable' );
        wp_enqueue_style( 'reyhan-admin-css', $this->url . 'assets/css/admin.css', [], $this->version );
        wp_enqueue_script( 'reyhan-admin-js', $this->url . 'assets/js/admin.js', [ 'jquery', 'wp-color-picker', 'jquery-ui-sortable' ], $this->version, true );
        $uid = get_current_user_id();
        $canned = get_user_meta( $uid, 'rp_user_canned_responses', true );
        wp_localize_script( 'reyhan-admin-js', 'reyhan_admin_ajax', [ 'ajax_url' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'reyhan_admin_nonce' ), 'canned_responses' => ! empty( $canned ) ? array_values( $canned ) : [] ]);
    }

    public function enqueue_frontend() {
        if ( ! $this->should_load_frontend() ) return;
        $opts = get_option( 'reyhan_options' );
        wp_enqueue_style( 'dashicons' );
        wp_enqueue_style( 'reyhan-front-css', $this->url . 'assets/css/frontend.css', [], $this->version );
        
        // اینجکت فونت برای فرانت‌اند
        $this->inject_custom_font( 'reyhan-front-css', '#reyhan-app-root' );
        
        wp_enqueue_script( 'reyhan-front-js', $this->url . 'assets/js/frontend.js', [ 'jquery' ], $this->version, true );
        $raw_faqs = get_option('reyhan_heavy_ticket_faqs'); 
        if(!$raw_faqs) $raw_faqs = ! empty( $opts['ticket_faqs'] ) ? $opts['ticket_faqs'] : [];
        wp_localize_script( 'reyhan-front-js', 'reyhan_front_obj', [ 'ajax_url' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'reyhan_auth_nonce' ), 'faqs' => is_array( $raw_faqs ) ? array_values( $raw_faqs ) : [], 'labels' => [ 'wait' => __('لطفاً صبر کنید...', 'reyhan-panel'), 'success' => __('عملیات موفقیت‌آمیز بود.', 'reyhan-panel') ] ]);
        if ( ! empty( $opts['recaptcha_active'] ) && ! empty( $opts['recaptcha_site_key'] ) ) {
            wp_enqueue_script( 'google-recaptcha', 'https://www.google.com/recaptcha/api.js?render=' . esc_attr( $opts['recaptcha_site_key'] ), [], null, true );
            wp_localize_script( 'reyhan-front-js', 'reyhan_captcha', [ 'site_key' => $opts['recaptcha_site_key'] ] );
        }
    }

    private function should_load_frontend() {
        global $post; $opts = get_option( 'reyhan_options' ); $login_page_id = $opts['login_page_id'] ?? 0;
        if ( is_page() && ! empty( $login_page_id ) && get_the_ID() == $login_page_id ) return true;
        if ( is_a( $post, 'WP_Post' ) && ( has_shortcode( $post->post_content, 'reyhan_panel' ) || has_shortcode( $post->post_content, 'reyhan_support' ) ) ) return true;
        return false;
    }

    private function inject_custom_font( $handle, $selector_prefix ) {
        $opts = get_option( 'reyhan_options' );
        if ( isset( $opts['active_plugin_font'] ) && $opts['active_plugin_font'] != '1' ) return;
        
        $font_reg  = $this->url . 'assets/fonts/Regular.woff2';
        $font_bold = $this->url . 'assets/fonts/SemiBold.woff2';
        
        // CSS اصلاح شده برای فرانت‌اند (حل مشکل آیکون‌ها)
        $css = "
            @font-face { font-family: 'ReyhanFont'; src: url('$font_reg') format('woff2'); font-weight: normal; font-display: swap; } 
            @font-face { font-family: 'ReyhanFontBold'; src: url('$font_bold') format('woff2'); font-weight: bold; font-display: swap; } 
            
            /* فونت Regular برای همه المان‌ها به جز آیکون‌ها */
            {$selector_prefix}, 
            {$selector_prefix} *:not(.dashicons):not(.fa) { 
                font-family: 'ReyhanFont', Tahoma, sans-serif !important; 
            }
            
            /* فونت Bold فقط برای تیترها و عناوین */
            {$selector_prefix} h1, {$selector_prefix} h2, {$selector_prefix} h3, 
            {$selector_prefix} h4, {$selector_prefix} h5, {$selector_prefix} h6,
            {$selector_prefix} strong, {$selector_prefix} b,
            {$selector_prefix} .rp-user-name, {$selector_prefix} .rp-card-stat strong,
            {$selector_prefix} .rp-btn-primary { 
                font-family: 'ReyhanFontBold', Tahoma, sans-serif !important; 
            }
            
            /* بازنشانی فونت آیکون‌ها */
            {$selector_prefix} .dashicons, {$selector_prefix} .dashicons-before:before { 
                font-family: dashicons !important; 
            }
        ";
        wp_add_inline_style( $handle, $css );
    }
}