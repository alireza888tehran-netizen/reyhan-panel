<?php
namespace ReyhanPanel\Ajax;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class UserTicket extends Base {

    protected function register_actions() {
        $this->add_ajax_action( 'user_submit', 'handle_submit_ticket' );
        $this->add_ajax_action( 'user_list',   'handle_get_tickets' );
        $this->add_ajax_action( 'user_view',   'handle_view_ticket' );
        $this->add_ajax_action( 'user_reply',  'handle_reply_ticket' );
        $this->add_ajax_action( 'user_close',  'handle_close_ticket' );
        $this->add_ajax_action( 'user_list_orders', 'handle_user_list_orders' );
        $this->add_ajax_action( 'user_view_order',  'handle_user_view_order' );
    }

    private function load_view( $view, $args = [] ) {
        if ( ! empty( $args ) ) extract( $args );
        $path = REYHAN_DIR . 'templates/frontend/' . $view . '.php';
        if ( file_exists( $path ) ) { ob_start(); include $path; return ob_get_clean(); }
        return '';
    }

    // --- مدیریت سفارشات ---
    
    public function handle_user_list_orders() {
        $this->check_nonce();
        $uid = get_current_user_id();
        if (!$uid) $this->send_error(__('وارد شوید', 'reyhan-panel'));
        if (!class_exists('WooCommerce')) $this->send_error(__('ووکامرس نصب نیست.', 'reyhan-panel'));

        $orders = wc_get_orders([ 'customer_id' => $uid, 'limit' => 20 ]);
        
        // بارگذاری تمپلیت جدید و ارسال متغیر orders به آن
        $html = $this->load_view('view-orders-list', ['orders' => $orders]);
        
        $this->send_success($html);
    }

    public function handle_user_view_order() {
        $this->check_nonce();
        $uid = get_current_user_id();
        $order_id = intval($_POST['order_id']);
        
        $order = wc_get_order($order_id);
        
        if (!$order || $order->get_user_id() != $uid) {
            $this->send_error(__('سفارش یافت نشد یا دسترسی ندارید.', 'reyhan-panel'));
        }

        // بارگذاری فایل تمپلیت جدید
        $html = $this->load_view('view-order-details', ['order' => $order]);
        $this->send_success($html);
    }

    // --- مدیریت تیکت‌ها ---

    public function handle_submit_ticket() {
        $this->check_nonce();
        $uid = get_current_user_id();
        if ( ! $uid ) $this->send_error( __('لطفاً وارد شوید.', 'reyhan-panel') );

        $title = sanitize_text_field( $_POST['title'] ?? '' );
        $msg   = sanitize_textarea_field( $_POST['message'] ?? '' );
        $dept  = sanitize_text_field( $_POST['department'] ?? '' );
        $prio  = sanitize_text_field( $_POST['priority'] ?? 'medium' );

        if ( empty( $title ) || !preg_match('/[^\d\s]/u', $title) ) $this->send_error( __('عنوان تیکت نامعتبر است.', 'reyhan-panel') );
        if ( empty( $msg ) ) $this->send_error( __('متن تیکت الزامی است.', 'reyhan-panel') );

        if ( ! empty( $_FILES['attachment']['name'] ) ) {
            $this->validate_file($_FILES['attachment']);
        }

        $post_id = wp_insert_post([ 'post_title' => $title, 'post_content' => $msg, 'post_status' => 'publish', 'post_type' => 'ticket', 'post_author' => $uid ]);
        if ( is_wp_error( $post_id ) ) $this->send_error( __('خطا در ثبت.', 'reyhan-panel') );

        update_post_meta( $post_id, '_ticket_department', $dept );
        update_post_meta( $post_id, '_ticket_priority', $prio );
        update_post_meta( $post_id, '_ticket_status', 'open' );
        
        if ( ! empty( $_FILES['attachment']['name'] ) ) {
            $file_url = $this->handle_upload( 'attachment' );
            if ( $file_url ) update_post_meta( $post_id, '_ticket_attachment', $file_url );
        }
        $this->send_success( __('تیکت با موفقیت ثبت شد.', 'reyhan-panel') );
    }

    public function handle_get_tickets() {
        $this->check_nonce();
        $uid = get_current_user_id();
        
        $tickets = get_posts([ 
            'post_type'      => 'ticket', 
            'author'         => $uid, 
            'posts_per_page' => 50 
        ]);

        // بارگذاری تمپلیت جدید لیست تیکت‌ها
        $html = $this->load_view('view-tickets-list', ['tickets' => $tickets]);
        
        $this->send_success( $html );
    }
    
    public function handle_view_ticket() {
        $this->check_nonce();
        $tid = intval($_POST['ticket_id']);
        $ticket = get_post($tid);
        if(!$ticket || $ticket->post_author != get_current_user_id()) $this->send_error('Error');
        $html = $this->load_view('view-single-ticket', ['ticket'=>$ticket, 'status'=>get_post_meta($tid,'_ticket_status',true), 'comments'=>get_comments(['post_id'=>$tid])]);
        $this->send_success($html);
    }

    public function handle_reply_ticket() {
        $this->check_nonce();
        $uid = get_current_user_id();
        $tid = intval($_POST['ticket_id']);
        
        // --- شروع بخش امنیتی اضافه شده ---
        // بررسی اینکه تیکت وجود دارد و متعلق به کاربر جاری است
        $ticket = get_post($tid);
        if ( ! $ticket || $ticket->post_author != $uid || $ticket->post_type !== 'ticket' ) {
            $this->send_error( __('دسترسی غیرمجاز. شما اجازه پاسخ به این تیکت را ندارید.', 'reyhan-panel') );
        }
        // --- پایان بخش امنیتی ---

        $msg = sanitize_textarea_field($_POST['reply_message']);
        if(empty($msg)) $this->send_error(__('متن پاسخ خالی است.', 'reyhan-panel'));
        
        if ( ! empty( $_FILES['reply_attachment']['name'] ) ) { 
            $this->validate_file($_FILES['reply_attachment']); 
        }
        
        $cid = wp_insert_comment([
            'comment_post_ID' => $tid, 
            'comment_content' => $msg, 
            'user_id'         => $uid,
            'comment_type'    => 'ticket_reply' // اختیاری: برای تمایز بهتر در دیتابیس
        ]);

        if($cid) { 
            update_post_meta($tid, '_ticket_status', 'open'); // تغییر وضعیت به باز (منتظر پاسخ پشتیبان)
            
            if ( ! empty( $_FILES['reply_attachment']['name'] ) ) {
                $file_url = $this->handle_upload( 'reply_attachment' );
                if ( $file_url ) add_comment_meta( $cid, 'attachment', $file_url );
            }
            $this->send_success(__('پاسخ شما ارسال شد.', 'reyhan-panel')); 
        }
        
        $this->send_error('خطا در ارسال پاسخ');
    }

    public function handle_close_ticket() {
        $this->check_nonce();
        $tid = intval( $_POST['ticket_id'] ?? 0 );
        $uid = get_current_user_id();
        $ticket = get_post( $tid );
        if ( ! $ticket || $ticket->post_author != $uid ) $this->send_error( __('دسترسی غیرمجاز.', 'reyhan-panel') );
        update_post_meta( $tid, '_ticket_status', 'closed' );
        do_action( 'reyhan_ticket_status_changed', $tid, 'closed' );
        $this->send_success( __('تیکت بسته شد.', 'reyhan-panel') );
    }

    // تابع اعتبارسنجی فایل (Private Helper)
    private function validate_file($file) {
        $opts = get_option('reyhan_options');
        $max_size_mb = !empty($opts['file_max_size']) ? floatval($opts['file_max_size']) : 2;
        if ( $file['size'] > $max_size_mb * 1024 * 1024 ) {
            $this->send_error( sprintf(__('حجم فایل بیش از حد مجاز است (%s MB).', 'reyhan-panel'), $max_size_mb) );
        }
        $allowed_exts = !empty($opts['file_allowed_extensions']) ? $opts['file_allowed_extensions'] : 'jpg,png,pdf';
        $allowed_array = array_map('trim', explode(',', strtolower($allowed_exts)));
        $file_info = wp_check_filetype($file['name']);
        if ( !in_array(strtolower($file_info['ext']), $allowed_array) ) {
            $this->send_error( __('فرمت فایل مجاز نیست.', 'reyhan-panel') );
        }
    }
}