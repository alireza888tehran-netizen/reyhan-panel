<?php
namespace ReyhanPanel\Ajax;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Auth extends Base {

    protected function register_actions() {
        $this->add_ajax_action( 'send_otp',        'handle_send_otp', true );
        $this->add_ajax_action( 'verify_otp',      'handle_verify_otp', true );
        $this->add_ajax_action( 'check_email_status', 'handle_check_email_status', true );
        $this->add_ajax_action( 'email_login',        'handle_email_login', true );
        $this->add_ajax_action( 'email_register_full','handle_email_register_full', true );
        $this->add_ajax_action( 'send_email_otp_fp',  'handle_send_email_otp_fp', true );
        $this->add_ajax_action( 'check_otp_only',     'handle_check_otp_only', true );
        $this->add_ajax_action( 'reset_password_fp',  'handle_reset_password_fp', true );
        $this->add_ajax_action( 'update_avatar',       'handle_update_avatar' );
        $this->add_ajax_action( 'update_general_info', 'handle_update_general_info' );
        $this->add_ajax_action( 'update_password',     'handle_update_password' );
        $this->add_ajax_action( 'save_details_final_action', 'handle_save_details_final', true );
    }

    // 1. بررسی وضعیت ایمیل
    public function handle_check_email_status() {
        $this->check_limit();
        $this->check_nonce();
        $email = sanitize_email( $_POST['email'] ?? '' );
        if ( ! is_email( $email ) ) $this->send_error( __('ایمیل نامعتبر است.', 'reyhan-panel') );
        
        $exists = email_exists( $email ) || username_exists( $email );
        $this->send_success( [ 'exists' => $exists ] );
    }

    // 2. لاگین
    public function handle_email_login() {
        $this->check_limit();
        $this->check_nonce();
        $email = sanitize_email( $_POST['log'] ?? '' );
        $pass  = $_POST['pwd'] ?? '';

        $user = wp_signon( [ 'user_login' => $email, 'user_password' => $pass, 'remember' => true ], false );

        if ( is_wp_error( $user ) ) {
            $this->send_error( __('اطلاعات ورود اشتباه است.', 'reyhan-panel') );
        }
        do_action( 'reyhan_user_logged_in', $user->ID );
        $this->send_success();
    }

    // 3. ثبت نام
    public function handle_email_register_full() {
        $this->check_limit();
        $this->check_nonce();

        $email = sanitize_email( $_POST['email'] ?? '' );
        $pass  = $_POST['pwd'] ?? '';
        $fname = sanitize_text_field( $_POST['fname'] ?? '' );
        $lname = sanitize_text_field( $_POST['lname'] ?? '' );

        if ( ! is_email( $email ) ) $this->send_error( __('ایمیل نامعتبر است.', 'reyhan-panel') );
        if ( email_exists( $email ) ) $this->send_error( __('این ایمیل قبلاً ثبت شده است.', 'reyhan-panel') );
        
        if ( strlen($pass) < 8 || !preg_match('/[A-Z]/', $pass) || !preg_match('/[a-z]/', $pass) || !preg_match('/[^a-zA-Z0-9]/', $pass) ) {
            $this->send_error( __('رمز عبور به اندازه کافی قوی نیست.', 'reyhan-panel') );
        }

        $uid = wp_create_user( $email, $pass, $email );
        if ( is_wp_error( $uid ) ) $this->send_error( $uid->get_error_message() );

        wp_update_user([ 'ID' => $uid, 'first_name' => $fname, 'last_name' => $lname, 'display_name' => "$fname $lname" ]);

        wp_set_current_user( $uid );
        wp_set_auth_cookie( $uid );
        do_action( 'reyhan_user_registered', $uid );
        
        $this->send_success();
    }

    // 4. ارسال کد فراموشی رمز
    public function handle_send_email_otp_fp() {
        $this->check_nonce();
        $email = sanitize_email( $_POST['email'] ?? '' );
        if(!email_exists($email)) $this->send_error( __('کاربری با این ایمیل یافت نشد.', 'reyhan-panel') );

        $opts = get_option('reyhan_options');
        $from_name = !empty($opts['email_from_name']) ? $opts['email_from_name'] : '';
        $from_addr = !empty($opts['email_from_address']) ? $opts['email_from_address'] : '';

        if ( empty($from_name) || empty($from_addr) ) {
            $this->send_error( __('خطای سرور داخلی (تنظیمات ایمیل ناقص است).', 'reyhan-panel') );
        }

        try {
            $code = random_int( 12345, 98765 );
        } catch (\Exception $e) {
            $code = rand( 12345, 98765 );
        }
        set_transient( 'rp_fp_' . md5($email), $code, 5 * 60 );

        $headers = [ 'Content-Type: text/html; charset=UTF-8', "From: $from_name <$from_addr>" ];
        $subject = 'فراموشی رمز عبور';
        $message = sprintf(__('کد تایید شما: %s', 'reyhan-panel'), $code);
        
        $mail_sent = wp_mail( $email, $subject, $message, $headers );

        if( $mail_sent ) {
            $this->send_success( __('کد تایید به ایمیل شما ارسال شد.', 'reyhan-panel') );
        } else {
            $whitelist = array( '127.0.0.1', '::1', 'localhost' );
            if ( in_array( $_SERVER['REMOTE_ADDR'], $whitelist ) || ( defined('WP_DEBUG') && WP_DEBUG ) ) {
                $this->send_success( __('(مود دیباگ/لوکال) کد تایید: ', 'reyhan-panel') . $code );
            } else {
                $this->send_error( __('خطای سرور داخلی.', 'reyhan-panel') );
            }
        }
    }

    public function handle_check_otp_only() {
        $this->check_nonce();
        $email = sanitize_email( $_POST['email'] );
        $code = sanitize_text_field( $_POST['code'] );
        $saved = get_transient( 'rp_fp_' . md5($email) );
        if ( $saved && $saved == $code ) $this->send_success();
        $this->send_error( __('کد تایید اشتباه یا منقضی شده است.', 'reyhan-panel') );
    }

    public function handle_reset_password_fp() {
        $this->check_nonce();
        $email = sanitize_email( $_POST['email'] );
        $code = sanitize_text_field( $_POST['code'] );
        $pass = $_POST['pass'];

        $saved = get_transient( 'rp_fp_' . md5($email) );
        if ( !$saved || $saved != $code ) $this->send_error( __('کد نامعتبر است.', 'reyhan-panel') );

        $user = get_user_by( 'email', $email );
        if($user) {
            wp_set_password( $pass, $user->ID );
            delete_transient( 'rp_fp_' . md5($email) );
            wp_set_current_user( $user->ID ); wp_set_auth_cookie( $user->ID );
            $this->send_success( __('رمز عبور با موفقیت تغییر کرد.', 'reyhan-panel') );
        }
        $this->send_error( __('خطای ناشناخته.', 'reyhan-panel') );
    }

    public function handle_send_otp() {
        $this->check_limit(); $this->check_nonce();
        $mobile = sanitize_text_field( $_POST['mobile'] ?? '' );
        if ( ! preg_match( '/^09[0-9]{9}$/', $mobile ) ) $this->send_error( __('شماره موبایل معتبر نیست.', 'reyhan-panel') );
        try {
            $code = random_int( 12345, 98765 );
        } catch (\Exception $e) {
            $code = rand( 12345, 98765 );
        }
        set_transient( 'rp_otp_' . $mobile, $code, 120 );
        if ( \ReyhanPanel\Services\SMS::send_otp( $mobile, $code ) ) $this->send_success( __('کد تایید ارسال شد.', 'reyhan-panel') );
        else $this->send_error( sprintf(__('خطا در ارسال: %s', 'reyhan-panel'), \ReyhanPanel\Services\SMS::$last_error) );
    }

    public function handle_verify_otp() {
        $this->check_nonce();
        $mobile = sanitize_text_field( $_POST['mobile'] ?? '' );
        $code   = sanitize_text_field( $_POST['code'] ?? '' );
        if ( get_transient( 'rp_otp_' . $mobile ) != $code ) $this->send_error( __('کد اشتباه است.', 'reyhan-panel') );
        delete_transient( 'rp_otp_' . $mobile );
        $user = get_user_by( 'login', $mobile );
        $is_new = false;
        if ( ! $user ) {
            $uid = wp_create_user( $mobile, wp_generate_password(), $mobile );
            if(is_wp_error($uid)) $this->send_error( $uid->get_error_message() );
            update_user_meta( $uid, 'mobile', $mobile );
            $user = get_user_by( 'id', $uid );
            $is_new = true;
        }
        wp_set_current_user( $user->ID, $user->user_login ); wp_set_auth_cookie( $user->ID, true );
        if($is_new) do_action('reyhan_user_registered', $user->ID);
        do_action('reyhan_user_logged_in', $user->ID);
        $this->send_success();
    }

    public function handle_update_avatar() {
        $this->check_nonce();
        if(!is_user_logged_in()) $this->send_error(__('وارد شوید', 'reyhan-panel'));
        $url = $this->handle_upload('avatar');
        if($url) { update_user_meta(get_current_user_id(), 'reyhan_user_avatar', $url); $this->send_success(); }
    }

    public function handle_update_general_info() {
        $this->check_nonce(); $uid = get_current_user_id();
        $email = sanitize_email($_POST['email']);
        if(!is_email($email)) $this->send_error(__('ایمیل نامعتبر', 'reyhan-panel'));
        if(email_exists($email) && email_exists($email)!=$uid) $this->send_error(__('ایمیل تکراری', 'reyhan-panel'));
        wp_update_user(['ID'=>$uid, 'user_email'=>$email, 'first_name'=>sanitize_text_field($_POST['first_name']), 'last_name'=>sanitize_text_field($_POST['last_name'])]);
        $this->send_success(__('ذخیره شد', 'reyhan-panel'));
    }

    public function handle_update_password() {
        $this->check_nonce();
        $p = $_POST['pass'];
        if(strlen($p)<6) $this->send_error(__('رمز کوتاه', 'reyhan-panel'));
        wp_set_password($p, get_current_user_id());
        $this->send_success(__('رمز تغییر کرد', 'reyhan-panel'));
    }

    // این متد در فایل Auth.php باید آپدیت شود یا اضافه شود
    public function handle_save_details_final() {
        $this->check_nonce(); // فرض بر اینکه متد check_nonce در Base.php هست
        if(!is_user_logged_in()) $this->send_error(__('وارد شوید', 'reyhan-panel'));
        
        $uid = get_current_user_id();
        $field = $_POST['field'] ?? '';

        if ($field === 'mobile') {
            $mobile = sanitize_text_field($_POST['value']);
            if(!preg_match('/^09[0-9]{9}$/', $mobile)) $this->send_error(__('شماره معتبر نیست', 'reyhan-panel'));
            update_user_meta($uid, 'mobile', $mobile);
        } elseif ($field === 'fullname') {
            $f = sanitize_text_field($_POST['firstname']);
            $l = sanitize_text_field($_POST['lastname']);
            wp_update_user(['ID'=>$uid, 'first_name'=>$f, 'last_name'=>$l, 'display_name'=>"$f $l"]);
        }

        $this->send_success();
    }

    private function check_limit() {
        $ip = $_SERVER['REMOTE_ADDR'];
        $tr = 'rp_limit_' . md5($ip);
        $att = get_transient($tr) ?: 0;
        if($att >= 15) $this->send_error(__('تلاش بیش از حد. ۱۵ دقیقه صبر کنید.', 'reyhan-panel'));
        set_transient($tr, $att+1, 900);
    }
}