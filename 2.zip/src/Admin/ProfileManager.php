<?php
namespace ReyhanPanel\Admin;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class ProfileManager {

    public function __construct() {
        add_action( 'admin_init', [ $this, 'handle_agent_profile_save' ] );
    }

    public function render_page() {
        $uid = get_current_user_id();
        $fname = get_user_meta($uid, 'first_name', true);
        $lname = get_user_meta($uid, 'last_name', true);
        $avatar = get_user_meta($uid, 'reyhan_user_avatar', true);
        
        $default_avatar = \REYHAN_URL . 'assets/images/user.png';
        $preview_src = !empty($avatar) ? $avatar : $default_avatar;
        $canned = get_user_meta($uid, 'rp_user_canned_responses', true);
        if(!is_array($canned)) $canned = [];

        ?>
        <div class="wrap reyhanpanel-wrap rp-agent-profile-wrap">
            <h1><span class="dashicons dashicons-id-alt"></span> <?php esc_html_e('ویرایش پروفایل پاسخگو', 'reyhan-panel'); ?></h1>
            
            <?php if(isset($_GET['updated'])): ?>
                <div id="reyhan-toast-msg" class="rp-modern-toast">
                    <span class="dashicons dashicons-yes-alt"></span> 
                    <span><?php esc_html_e('اطلاعات پروفایل با موفقیت بروزرسانی شد.', 'reyhan-panel'); ?></span>
                </div>
            <?php endif; ?>

            <form method="post" action="" enctype="multipart/form-data">
                <?php wp_nonce_field('save_agent_profile', 'rp_agent_profile_nonce'); ?>
                
                <div class="rp-profile-layout">
                    <div class="rp-card-modern">
                        <div class="rp-card-header">
                            <div class="rp-header-icon"><span class="dashicons dashicons-admin-users"></span></div>
                            <h3><?php esc_html_e('اطلاعات نمایش داده شده', 'reyhan-panel'); ?></h3>
                        </div>
                        <div class="rp-card-body">
                            <div class="rp-profile-flex-container">
                                <div class="rp-avatar-upload-section">
                                    <div class="rp-agent-preview-circle" id="trigger-img-click">
                                        <img src="<?php echo esc_url($preview_src); ?>" id="agent-profile-img" data-default="<?php echo esc_url($default_avatar); ?>">
                                        <div class="rp-avatar-overlay">
                                            <span class="dashicons dashicons-camera"></span>
                                        </div>
                                    </div>
                                    <div class="rp-avatar-actions">
                                        <input type="file" name="agent_avatar_file" id="real_file_input" style="display:none;" accept="image/*">
                                        <input type="hidden" name="reyhan_user_avatar_status" id="avatar_status_input" value="kept">
                                        <button type="button" id="btn-trigger-sys-upload" class="button rp-sys-upload-btn">
                                            <span class="dashicons dashicons-upload"></span> <?php esc_html_e('تغییر تصویر', 'reyhan-panel'); ?>
                                        </button>
                                        <button type="button" class="button rp-sys-remove-btn" id="btn-remove-sys-avatar" style="<?php echo empty($avatar) ? 'display:none;' : ''; ?>">
                                            <span class="dashicons dashicons-trash"></span> <?php esc_html_e('حذف', 'reyhan-panel'); ?>
                                        </button>
                                    </div>
                                </div>
                                <div class="rp-fields-section">
                                    <div class="rp-form-row">
                                        <div class="rp-col">
                                            <label><?php esc_html_e('نام کوچک', 'reyhan-panel'); ?></label>
                                            <input type="text" name="first_name" value="<?php echo esc_attr($fname); ?>" class="rp-input-modern">
                                        </div>
                                        <div class="rp-col">
                                            <label><?php esc_html_e('نام خانوادگی', 'reyhan-panel'); ?></label>
                                            <input type="text" name="last_name" value="<?php echo esc_attr($lname); ?>" class="rp-input-modern">
                                        </div>
                                    </div>
                                    <p class="rp-helper-text"><?php esc_html_e('این نام و تصویر در بالای چت تیکت‌ها به کاربر نمایش داده می‌شود.', 'reyhan-panel'); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="rp-card-modern">
                        <div class="rp-card-header">
                            <div class="rp-header-icon blue"><span class="dashicons dashicons-format-chat"></span></div>
                            <h3><?php esc_html_e('پاسخ‌های آماده شخصی', 'reyhan-panel'); ?></h3>
                        </div>
                        <div class="rp-card-body">
                            <p class="rp-helper-text" style="margin-bottom:20px;"><?php esc_html_e('جملات پرکاربرد خود را اینجا ذخیره کنید.', 'reyhan-panel'); ?></p>
                            <div class="rp-repeater-wrap rp-repeater-section" data-id="rp_user_canned_responses">
                                <div class="rp-repeater-list">
                                    <?php foreach($canned as $idx => $item): ?>
                                    <div class="rp-repeater-item">
                                        <div class="rp-repeater-inputs">
                                            <div class="rp-input-group-row">
                                                <label class="rp-input-label"><?php esc_html_e('عنوان کوتاه', 'reyhan-panel'); ?></label>
                                                <input type="text" name="reyhan_options[rp_user_canned_responses][<?php echo $idx; ?>][title]" value="<?php echo esc_attr($item['title']??''); ?>" class="rp-full-width">
                                            </div>
                                            <div class="rp-input-group-row">
                                                <label class="rp-input-label"><?php esc_html_e('متن پاسخ', 'reyhan-panel'); ?></label>
                                                <textarea name="reyhan_options[rp_user_canned_responses][<?php echo $idx; ?>][content]" rows="2" class="rp-full-width"><?php echo esc_textarea($item['content']??''); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="rp-repeater-actions">
                                            <button type="button" class="button rp-remove-row"><span class="dashicons dashicons-no"></span></button>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                                <button type="button" class="button rp-add-row" data-fields='{"title":"<?php esc_attr_e('عنوان', 'reyhan-panel'); ?>","content":"<?php esc_attr_e('متن', 'reyhan-panel'); ?>"}'>
                                    <span class="dashicons dashicons-plus"></span> <?php esc_html_e('افزودن پاسخ جدید', 'reyhan-panel'); ?>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="rp-save-bar-fixed">
                    <div class="rp-save-info"><span class="dashicons dashicons-info"></span> <?php esc_html_e('تغییرات پس از ذخیره اعمال می‌شود.', 'reyhan-panel'); ?></div>
                    <button type="submit" class="button button-primary rp-save-btn"><?php esc_html_e('ذخیره تغییرات پروفایل', 'reyhan-panel'); ?></button>
                </div>
            </form>
        </div>
        <?php
    }

    public function handle_agent_profile_save() {
        if ( isset($_POST['rp_agent_profile_nonce']) && wp_verify_nonce($_POST['rp_agent_profile_nonce'], 'save_agent_profile') ) {
            $uid = get_current_user_id();
            if(isset($_POST['first_name'])) update_user_meta($uid, 'first_name', sanitize_text_field($_POST['first_name']));
            if(isset($_POST['last_name'])) update_user_meta($uid, 'last_name', sanitize_text_field($_POST['last_name']));
            $display_name = trim(sanitize_text_field($_POST['first_name']) . ' ' . sanitize_text_field($_POST['last_name']));
            if(!empty($display_name)) wp_update_user([ 'ID' => $uid, 'display_name' => $display_name ]);

            if ( !empty($_FILES['agent_avatar_file']['name']) ) {
                require_once( ABSPATH . 'wp-admin/includes/image.php' );
                require_once( ABSPATH . 'wp-admin/includes/file.php' );
                require_once( ABSPATH . 'wp-admin/includes/media.php' );
                $attachment_id = media_handle_upload( 'agent_avatar_file', 0 );
                if ( ! is_wp_error( $attachment_id ) ) {
                    $image_url = wp_get_attachment_url( $attachment_id );
                    update_user_meta($uid, 'reyhan_user_avatar', $image_url);
                }
            } elseif ( isset($_POST['reyhan_user_avatar_status']) && $_POST['reyhan_user_avatar_status'] === 'removed' ) {
                delete_user_meta($uid, 'reyhan_user_avatar');
            }

            if ( isset($_POST['reyhan_options']['rp_user_canned_responses']) ) {
                $canned = $_POST['reyhan_options']['rp_user_canned_responses'];
                if(is_array($canned)) update_user_meta($uid, 'rp_user_canned_responses', array_values($canned));
            } else { delete_user_meta($uid, 'rp_user_canned_responses'); }

            do_action( 'reyhan_agent_profile_updated', $uid, $_POST );
            wp_redirect( add_query_arg( 'updated', 'true', admin_url('admin.php?page=reyhan-agent-profile') ) );
            exit;
        }
    }
}