<?php
namespace ReyhanPanel\Services;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class SMS {
    
    public static $last_error = '';

    public static function send_otp( $mobile, $code ) {
        $opts = get_option('reyhan_options');
        if (!$opts || !is_array($opts)) { self::$last_error = 'تنظیمات افزونه پیکربندی نشده است.'; return false; }

        $provider = isset($opts['sms_provider']) ? $opts['sms_provider'] : 'ippanel';
        $api_key  = isset($opts['sms_apikey']) ? trim($opts['sms_apikey']) : '';
        $method   = isset($opts['sms_send_method']) ? $opts['sms_send_method'] : 'pattern';
        $from     = isset($opts['sms_from']) ? trim($opts['sms_from']) : '';
        
        self::$last_error = ''; 

        if ( empty($api_key) && $provider !== 'melli' ) {
            self::$last_error = 'کلید API در تنظیمات وارد نشده است.';
            return false;
        }

        if ( $method === 'pattern' ) {
            $pattern_code = trim($opts['sms_pattern_otp'] ?? '');
            if ( empty($pattern_code) ) { self::$last_error = 'کد پترن وارد نشده است.'; return false; }

            switch ( $provider ) {
                case 'ippanel': 
                    $url = "https://api.ippanel.com/api/v1/messages/patterns/send";
                    $body = [ "pattern_code" => $pattern_code, "originator" => "+983000505", "recipient" => $mobile, "values" => [ "code" => strval($code) ] ];
                    return self::call_api($url, $api_key, $body);
                case 'smsir':
                    $url = 'https://api.sms.ir/v1/send/verify';
                    $body = [ "mobile" => $mobile, "templateId" => (int)$pattern_code, "parameters" => [ ["name" => "Code", "value" => strval($code)] ] ];
                    return self::call_api($url, $api_key, $body, true);
                case 'kaveh': 
                    $url = "https://api.kavenegar.com/v1/$api_key/verify/lookup.json?receptor=$mobile&token=$code&template=$pattern_code";
                    $response = wp_remote_get($url, ['sslverify' => false, 'timeout' => 30]);
                    if (is_wp_error($response)) { self::$last_error = $response->get_error_message(); return false; }
                    $body = json_decode(wp_remote_retrieve_body($response), true);
                    if(isset($body['return']['status']) && $body['return']['status'] == 200) return true;
                    self::$last_error = $body['return']['message'] ?? 'خطای کاوه نگار';
                    return false;
                case 'melli':
                    $u = $opts['sms_username'] ?? ''; $p = $opts['sms_password'] ?? '';
                    if(empty($u) || empty($p)) { self::$last_error = 'نام کاربری/رمز عبور الزامی است.'; return false; }
                    $url = "https://rest.payamak-panel.com/api/SendSMS/BaseServiceNumber";
                    $body = [ "username" => $u, "password" => $p, "text" => strval($code), "to" => $mobile, "bodyId" => (int)$pattern_code ];
                    return self::call_api($url, '', $body);
                default: self::$last_error = "سامانه نامعتبر."; return false;
            }
        } else {
            $msg_tpl = $opts['sms_text_template'] ?? 'کد: %code%';
            $message = str_replace('%code%', $code, $msg_tpl);
            if ( empty($from) ) { self::$last_error = 'شماره فرستنده الزامی است.'; return false; }

            switch ( $provider ) {
                case 'ippanel':
                    $url = "https://api.ippanel.com/api/v1/messages/send";
                    $body = [ "originator" => $from, "recipients" => [$mobile], "message" => $message ];
                    return self::call_api($url, $api_key, $body);
                case 'smsir':
                     $url = 'https://api.sms.ir/v1/send/bulk';
                     $body = [ "lineNumber" => $from, "messageText" => $message, "mobiles" => [$mobile] ];
                     return self::call_api($url, $api_key, $body, true);
                default: self::$last_error = "ارسال معمولی پشتیبانی نمی‌شود."; return false; 
            }
        }
    }

    private static function call_api($url, $key, $data, $is_smsir = false) {
        $args = [ 'body' => json_encode($data), 'headers' => [ 'Content-Type' => 'application/json', 'User-Agent' => 'Mozilla/5.0 Chrome/91.0' ], 'timeout' => 30, 'sslverify' => false ];
        if ($is_smsir) { $args['headers']['X-API-KEY'] = $key; } elseif (!empty($key)) { $args['headers']['Authorization'] = "AccessKey $key"; }
        $response = wp_remote_post($url, $args);
        if ( is_wp_error($response) ) { self::$last_error = 'خطای اتصال: ' . $response->get_error_message(); return false; }
        $body = wp_remote_retrieve_body($response);
        $result = json_decode($body, true);
        if ($is_smsir) { if (isset($result['status']) && $result['status'] == 1) return true; self::$last_error = $result['message'] ?? 'خطای sms.ir'; return false; }
        if(isset($result['RetStatus'])) { if ($result['RetStatus'] == 1) return true; self::$last_error = $result['Value'] ?? 'خطای ملی پیامک'; return false; }
        $code = wp_remote_retrieve_response_code($response);
        if ( $code >= 200 && $code < 300 ) return true;
        self::$last_error = "خطای پنل (کد $code)";
        return false;
    }
}