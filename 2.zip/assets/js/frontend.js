(function ($) {
    "use strict";

    const ReyhanApp = {
        init: function () {
            if (typeof reyhan_front_obj === 'undefined') return;

            // معرفی توابع به ویندو
            window.loadTicketConversation = this.loadSingleTicket.bind(this);
            window.loadUserTickets = this.loadTickets.bind(this);
            window.closeTicketByUser = this.closeTicket.bind(this);

            // *** توابع جدید سفارشات ***
            window.loadSingleOrder = this.loadSingleOrder.bind(this);
            window.backToOrderList = this.backToOrderList.bind(this);

            this.bindEvents();
            this.checkMandatoryFields();
        },

        bindEvents: function () {
            // ... (سایر هندلرها بدون تغییر) ...
            $(document).on('click', '.rp-menu li', this.handleTabSwitch);
            $('#rp-mobile-menu-trigger').click(function () { $('#rp-main-sidebar').addClass('rp-open'); $('#rp-mobile-overlay').addClass('active'); });
            $('#rp-mobile-overlay').click(function () { $('#rp-main-sidebar').removeClass('rp-open'); $(this).removeClass('active'); });
            $('#rp-login-form-sms').on('submit', this.handleSmsLogin);
            $('#rp-step-email-check').on('submit', this.checkEmailStatus);
            $('.rp-change-email').on('click', function (e) { e.preventDefault(); location.reload(); });
            $('#rp-step-login-pass').on('submit', this.doEmailLogin);
            $('#rp-step-register-full').on('submit', this.doFullRegister);
            $('#rp-ticket-submit-form').on('submit', this.handleTicketSubmit);
            $('#rp-popup-save-mobile').on('click', this.saveMandatoryMobile);
            $('#rp-popup-save-name').on('click', this.saveMandatoryName);
            $('#rp-btn-verify-email').on('click', function () { alert('این قابلیت به زودی...'); });
            $('#rp-btn-verify-mobile').on('click', function () { alert('این قابلیت به زودی...'); });
            $('#rp-avatar-input').on('change', this.handleAvatarUpload);
            $(document).on('submit', '#rp-reply-form', this.handleTicketReply);

            // فراموشی رمز
            $('#rp-trigger-fp').on('click', this.startForgotFlow);
            $('#rp-step-fp-otp').on('submit', this.verifyFpOtp);
            $('#rp-step-fp-newpass').on('submit', this.resetPasswordFinal);
            $('#rp-fp-resend-btn').on('click', this.resendFpCode);
            $('.rp-back-login').on('click', function () { $('.rp-login-wrap form').hide(); $('#rp-step-login-pass').fadeIn(); });
        },

        // --- نمایش تک سفارش ---
        loadSingleOrder: function (oid) {
            var listContainer = $('#rp-orders-list-container');
            var singleContainer = $('#rp-single-order-container');

            listContainer.slideUp(300);
            singleContainer.html('<div class="rp-loading-spinner" style="margin:50px auto;"></div>').slideDown(300);

            $.post(reyhan_front_obj.ajax_url, {
                action: 'reyhan_user_view_order',
                security: reyhan_front_obj.nonce,
                order_id: oid
            }, function (res) {
                if (res.success) {
                    singleContainer.html(res.data);
                } else {
                    alert(res.data);
                    ReyhanApp.backToOrderList();
                }
            }).fail(function () {
                alert('خطای سرور');
                ReyhanApp.backToOrderList();
            });
        },

        // --- بازگشت به لیست سفارشات ---
        backToOrderList: function () {
            $('#rp-single-order-container').slideUp(300).empty();
            $('#rp-orders-list-container').slideDown(300);
        },

        // ... (بقیه توابع قبلی تیکت و لاگین عیناً کپی شوند) ...
        // در اینجا برای جلوگیری از تکرار کد طولانی، فرض بر این است که توابع 
        // loadSingleTicket, closeTicket, handleTicketReply, loadTickets, handleTabSwitch, activateTab
        // و غیره که در پاسخ‌های قبلی بودند وجود دارند.

        // فقط تابع loadOrders نیاز به تغییر جزئی برای تارگت کردن wrapper دارد:
        loadOrders: function () {
            $('#rp-orders-table-wrapper').html('...');
            $.post(reyhan_front_obj.ajax_url, { action: 'reyhan_user_list_orders', security: reyhan_front_obj.nonce }, function (res) {
                $('#rp-orders-table-wrapper').html(res.success ? res.data : (res.data || 'یافت نشد'));
            });
        },

        loadSingleTicket: function (tid) { $('#rp-ticket-creation-area').slideUp(); $('.rp-ticket-header').slideUp(); $('#rp-user-tickets-list').html('<div class="rp-loading-spinner"></div>'); $.post(reyhan_front_obj.ajax_url, { action: 'reyhan_user_view', security: reyhan_front_obj.nonce, ticket_id: tid }, function (res) { if (res.success) $('#rp-user-tickets-list').html(res.data); else { alert(res.data); ReyhanApp.loadTickets(); } }); },
        closeTicket: function (tid) { if (!confirm('بستن تیکت؟')) return; $.post(reyhan_front_obj.ajax_url, { action: 'reyhan_user_close', security: reyhan_front_obj.nonce, ticket_id: tid }, function (res) { alert(res.data); if (res.success) ReyhanApp.loadSingleTicket(tid); }); },
        handleTicketReply: function (e) { e.preventDefault(); var btn = $(this).find('button'); var fd = new FormData(this); fd.append('action', 'reyhan_user_reply'); fd.append('security', reyhan_front_obj.nonce); btn.prop('disabled', true).text('...'); $.ajax({ url: reyhan_front_obj.ajax_url, type: 'POST', data: fd, contentType: false, processData: false, success: function (res) { if (res.success) { ReyhanApp.loadSingleTicket(fd.get('ticket_id')); } else { alert(res.data); btn.prop('disabled', false).text('ارسال پاسخ'); } } }); },
        loadTickets: function () { $('.rp-ticket-header').slideDown(); $('#rp-ticket-creation-area').hide(); $('#rp-user-tickets-list').html('...'); $.post(reyhan_front_obj.ajax_url, { action: 'reyhan_user_list', security: reyhan_front_obj.nonce }, function (res) { $('#rp-user-tickets-list').html(res.success ? res.data : res.data); }); },
        handleTicketSubmit: function (e) { e.preventDefault(); var btn = $(this).find('button'); var t = $(this).find('input[name="title"]').val(); if (!/[^\d\s]/.test(t)) { alert('عنوان نامعتبر'); return; } var fd = new FormData(this); fd.append('action', 'reyhan_user_submit'); fd.append('security', reyhan_front_obj.nonce); btn.prop('disabled', true).text('...'); $.ajax({ url: reyhan_front_obj.ajax_url, type: 'POST', data: fd, contentType: false, processData: false, success: function (res) { if (res.success) { alert(res.data); $('#rp-ticket-creation-area').slideUp(); e.target.reset(); ReyhanApp.loadTickets(); } else alert(res.data); btn.prop('disabled', false).text('ارسال تیکت'); } }); },
        handleTabSwitch: function (e) { var item = $(this); var target = item.data('tab'); if (target === 'logout' || target === 'link' || item.attr('onclick')) return; e.preventDefault(); ReyhanApp.activateTab(target); },
        activateTab: function (targetId) { var sectionId = '#rp-section-' + targetId; if ($(sectionId).length === 0) return; $('.rp-menu li').removeClass('active'); $('.rp-menu li[data-tab=\"' + targetId + '\"]').addClass('active'); $('.rp-content .rp-tab-content').hide(); $(sectionId).fadeIn(200); $('#rp-main-sidebar').removeClass('rp-open'); $('#rp-mobile-overlay').removeClass('active'); if (targetId === 'orders') ReyhanApp.loadOrders(); if (targetId === 'tickets') ReyhanApp.loadTickets(); },
        checkMandatoryFields: function () { var mv = $('#rp_prof_mobile').val(); var fv = $('input[name="first_name"]').val(); if ($('#reyhan-app-root').length && !$('#rp-login-form-email').length) { if (!mv) { $('#rp-popup-overlay').show(); $('#rp-popup-mandatory').show(); $('#rp-popup-mobile-form').show(); } else if (!fv) { $('#rp-popup-overlay').show(); $('#rp-popup-mandatory').show(); $('#rp-popup-name-form').show(); } } },
        saveMandatoryMobile: function () { var m = $('#rp_popup_mobile').val(); if (m.length < 10) { alert('نامعتبر'); return; } $.post(reyhan_front_obj.ajax_url, { action: 'reyhan_save_details_final_action', security: reyhan_front_obj.nonce, field: 'mobile', value: m }, function (res) { if (res.success) location.reload(); else alert(res.data); }); },
        saveMandatoryName: function () { var f = $('#rp_popup_fname').val(); var l = $('#rp_popup_lname').val(); if (!f || !l) { alert('الزامی'); return; } $.post(reyhan_front_obj.ajax_url, { action: 'reyhan_save_details_final_action', security: reyhan_front_obj.nonce, field: 'fullname', firstname: f, lastname: l }, function (res) { if (res.success) location.reload(); else alert(res.data); }); },
        handleAvatarUpload: function () { var f = this.files[0]; var fd = new FormData(); fd.append('avatar', f); fd.append('action', 'reyhan_update_avatar'); fd.append('security', reyhan_front_obj.nonce); $.ajax({ url: reyhan_front_obj.ajax_url, type: 'POST', data: fd, contentType: false, processData: false, success: function (res) { if (res.success) location.reload(); } }); },
        checkEmailStatus: function (e) { e.preventDefault(); var btn = $(this).find('button'); var email = $('#rp_flow_email').val(); if (email.length < 5 || !email.includes('@')) { alert('ایمیل معتبر نیست'); return; } btn.prop('disabled', true).text('...'); $.post(reyhan_front_obj.ajax_url, { action: 'reyhan_check_email_status', security: reyhan_front_obj.nonce, email: email }, function (res) { btn.prop('disabled', false).text('ادامه'); if (res.success) { ReyhanApp.currentEmail = email; $('#rp-step-email-check').hide(); if (res.data.exists) { $('#rp-badge-email').text(email); $('#rp-step-login-pass').fadeIn(); } else { $('#rp-reg-email-display').text(email); $('#rp-step-register-full').fadeIn(); } } else alert(res.data); }); },
        doEmailLogin: function (e) { e.preventDefault(); var btn = $(this).find('button'); btn.prop('disabled', true).text('...'); $.post(reyhan_front_obj.ajax_url, { action: 'reyhan_email_login', security: reyhan_front_obj.nonce, log: ReyhanApp.currentEmail, pwd: $('#rp_flow_pass').val() }, function (res) { if (res.success) location.reload(); else { alert(res.data); btn.prop('disabled', false).text('ورود'); } }); },
        doFullRegister: function (e) { e.preventDefault(); var btn = $(this).find('button'); var strongRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#\$%\^&\*])(?=.{8,})"); var p = $('#rp_reg_pass').val(); if (!strongRegex.test(p)) { $('#rp-pass-rules').slideDown(); return; } btn.prop('disabled', true).text('...'); $.post(reyhan_front_obj.ajax_url, { action: 'reyhan_email_register_full', security: reyhan_front_obj.nonce, email: ReyhanApp.currentEmail, fname: $('#rp_reg_fname').val(), lname: $('#rp_reg_lname').val(), pwd: p }, function (res) { if (res.success) location.reload(); else { alert(res.data); btn.prop('disabled', false).text('ثبت نام'); } }); },
        handleSmsLogin: function (e) { e.preventDefault(); var mobile = $('#rp_mobile').val(); if ($('#step-2-box').is(':hidden')) { $.post(reyhan_front_obj.ajax_url, { action: 'reyhan_send_otp', security: reyhan_front_obj.nonce, mobile: mobile }, function (res) { if (res.success) { $('#step-1-box').hide(); $('#step-2-box').show(); } else alert(res.data); }); } else { $.post(reyhan_front_obj.ajax_url, { action: 'reyhan_verify_otp', security: reyhan_front_obj.nonce, mobile: mobile, code: $('#rp_code').val() }, function (res) { if (res.success) location.reload(); else alert(res.data); }); } },
        startForgotFlow: function (e) { e.preventDefault(); if (!confirm('کد ارسال شود؟')) return; $('#rp-step-login-pass').hide(); $.post(reyhan_front_obj.ajax_url, { action: 'reyhan_send_email_otp_fp', security: reyhan_front_obj.nonce, email: ReyhanApp.currentEmail }, function (res) { if (res.success) { $('#rp-step-fp-otp').fadeIn(); ReyhanApp.startTimer(300); } else { alert(res.data); $('#rp-step-login-pass').show(); } }); },
        startTimer: function (duration) { var timer = duration, minutes, seconds; var display = $('#rp-fp-timer'); var resendBtn = $('#rp-fp-resend-btn'); resendBtn.hide(); display.show(); clearInterval(ReyhanApp.timerInterval); ReyhanApp.timerInterval = setInterval(function () { minutes = parseInt(timer / 60, 10); seconds = parseInt(timer % 60, 10); minutes = minutes < 10 ? "0" + minutes : minutes; seconds = seconds < 10 ? "0" + seconds : seconds; display.text(minutes + ":" + seconds); if (--timer < 0) { clearInterval(ReyhanApp.timerInterval); display.hide(); resendBtn.show(); } }, 1000); },
        resendFpCode: function (e) { e.preventDefault(); var btn = $(this); btn.prop('disabled', true).text('...'); $.post(reyhan_front_obj.ajax_url, { action: 'reyhan_send_email_otp_fp', security: reyhan_front_obj.nonce, email: ReyhanApp.currentEmail }, function (res) { btn.prop('disabled', false).text('ارسال مجدد'); if (res.success) { alert('ارسال شد'); ReyhanApp.startTimer(300); } else alert(res.data); }); },
        verifyFpOtp: function (e) { e.preventDefault(); var code = $('#rp_fp_code').val(); var btn = $(this).find('button'); btn.prop('disabled', true).text('...'); $.post(reyhan_front_obj.ajax_url, { action: 'reyhan_check_otp_only', security: reyhan_front_obj.nonce, email: ReyhanApp.currentEmail, code: code }, function (res) { btn.prop('disabled', false).text('بررسی'); if (res.success) { clearInterval(ReyhanApp.timerInterval); $('#rp-step-fp-otp').hide(); $('#rp-step-fp-newpass').fadeIn(); } else alert(res.data); }); },
        resetPasswordFinal: function (e) { e.preventDefault(); var p1 = $('#rp_fp_new_pass').val(); var p2 = $('#rp_fp_new_pass_conf').val(); var code = $('#rp_fp_code').val(); if (p1 !== p2) { alert('یکسان نیست'); return; } var btn = $(this).find('button'); btn.prop('disabled', true).text('...'); $.post(reyhan_front_obj.ajax_url, { action: 'reyhan_reset_password_fp', security: reyhan_front_obj.nonce, email: ReyhanApp.currentEmail, code: code, pass: p1 }, function (res) { if (res.success) { alert('تغییر کرد'); location.reload(); } else { alert(res.data); btn.prop('disabled', false).text('تغییر رمز'); } }); }
    };
    $(document).ready(function () { ReyhanApp.init(); });
})(jQuery);