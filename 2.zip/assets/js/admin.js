jQuery(document).ready(function ($) {
    "use strict";

    /* =======================================================
       مدیریت تب‌ها و UI عمومی
    ======================================================= */
    function safeStorage(key, value = null) {
        try {
            if (value !== null) localStorage.setItem(key, value);
            else return localStorage.getItem(key);
        } catch (e) { return null; }
    }

    function switchTab(targetId) {
        var $target = $('#' + targetId);
        if ($target.length === 0) return false;
        $('.rp-tab-pane').hide().removeClass('active');
        $target.fadeIn(200).addClass('active');
        $('.rp-tabs-nav li').removeClass('active');
        $('.rp-tabs-nav li[data-tab="' + targetId + '"]').addClass('active');
        safeStorage('reyhan_active_tab', targetId);
        return true;
    }

    $(document).on('click', '.rp-tabs-nav li', function (e) {
        e.preventDefault();
        var target = $(this).data('tab');
        if (target) switchTab(target);
    });

    if ($('.rp-tabs-nav').length > 0) {
        var savedTab = safeStorage('reyhan_active_tab');
        if (!savedTab || !switchTab(savedTab)) {
            var firstTabId = $('.rp-tabs-nav li:first-child').data('tab');
            switchTab(firstTabId);
        }
    }

    // تاگل‌های بخش تنظیمات
    $('.rp-section-toggle').change(function () {
        var target = $(this).data('target');
        if (this.checked) $('#' + target).slideDown(); else $('#' + target).slideUp();
    });

    // =======================================================
    // هندلینگ ساخت برگه با AJAX در تنظیمات
    // =======================================================
    $('#rp-create-page-ajax-btn').on('click', function (e) {
        e.preventDefault();

        var $btn = $(this);
        var $spinner = $('#rp-create-page-spinner');
        var $successMsg = $('#rp-create-page-success');
        var $dropdown = $('#rp_login_page_dropdown');

        $btn.prop('disabled', true).addClass('disabled');
        $spinner.addClass('is-active');

        $.post(reyhan_admin_ajax.ajax_url, {
            action: 'reyhan_create_login_page_ajax',
            security: reyhan_admin_ajax.nonce
        }, function (res) {
            $spinner.removeClass('is-active');

            if (res.success) {
                $btn.hide();
                $successMsg.text(res.data.msg || 'ساخته شد!').show().delay(3000).fadeOut();

                if ($dropdown.length > 0) {
                    if ($dropdown.find('option[value="' + res.data.id + '"]').length === 0) {
                        $dropdown.append(new Option(res.data.title, res.data.id));
                    }
                    $dropdown.val(res.data.id);
                }
            } else {
                alert(res.data);
                $btn.prop('disabled', false).removeClass('disabled');
            }
        }).fail(function () {
            $spinner.removeClass('is-active');
            alert('خطای ارتباط با سرور');
            $btn.prop('disabled', false).removeClass('disabled');
        });
    });

    /* =======================================================
       پروفایل ایجنت (Agent Profile Manager)
    ======================================================= */
    $('#btn-trigger-sys-upload, #trigger-img-click').on('click', function (e) {
        e.preventDefault();
        $('#real_file_input').click();
    });

    $('#real_file_input').on('change', function () {
        if (this.files && this.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#agent-profile-img').attr('src', e.target.result);
                $('#btn-remove-sys-avatar').fadeIn();
                $('#avatar_status_input').val('changed');
            }
            reader.readAsDataURL(this.files[0]);
        }
    });

    $('#btn-remove-sys-avatar').on('click', function (e) {
        e.preventDefault();
        var def = $('#agent-profile-img').data('default');
        $('#real_file_input').val('');
        $('#agent-profile-img').attr('src', def);
        $('#avatar_status_input').val('removed');
        $(this).fadeOut();
    });

    /* =======================================================
       سیستم ناتیفیکیشن بیلدر (Notifications)
    ======================================================= */
    var notifData = [];
    var editIndex = -1;
    var $notifJson = $('#rp_notif_data_json');
    var $saveBar = $('.rp-sticky-save-bar');

    if ($('#rp-notif-grid').length > 0) {
        var rawInitData = $('#rp-notif-initial-data').val() || '[]';
        try { notifData = JSON.parse(rawInitData); } catch (e) { notifData = []; }
        renderNotifGrid();
    }

    function renderNotifGrid() {
        var html = '';
        var container = $('#rp-notif-grid');
        var emptyState = $('#rp-empty-state');

        if (notifData.length === 0) {
            container.hide();
            emptyState.fadeIn();
        } else {
            emptyState.hide();
            container.css('display', 'grid');
            $.each(notifData, function (i, item) {
                var title = item.title || '(بدون عنوان)';
                var typeClass = 'rp-card-' + (item.type || 'info');
                var msg = (item.msg || '').substring(0, 80) + '...';
                html += `<div class="rp-notif-card ${typeClass}">
                    <div class="rp-card-header"><span class="rp-card-title">${title}</span></div>
                    <div class="rp-card-msg">${msg}</div>
                    <div class="rp-card-actions">
                        <button type="button" class="rp-btn-sm edit-notif" data-index="${i}">ویرایش</button>
                        <button type="button" class="rp-btn-sm delete-notif" data-index="${i}">حذف</button>
                    </div></div>`;
            });
            container.html(html);
        }
        $notifJson.val(JSON.stringify(notifData));
    }

    $('#rp-btn-add-new').click(function (e) {
        e.preventDefault();
        editIndex = -1;
        $('#edit-title').val(''); $('#edit-msg').val(''); $('#edit-type').val('info');
        $('#rp-editor-title').text('افزودن اطلاعیه جدید');
        $('#rp-editor-wrapper').slideDown();
    });

    $('#rp-btn-cancel').click(function () { $('#rp-editor-wrapper').slideUp(); });

    $(document).on('click', '.edit-notif', function (e) {
        e.preventDefault();
        editIndex = $(this).data('index');
        var item = notifData[editIndex];
        $('#edit-title').val(item.title);
        $('#edit-type').val(item.type);
        $('#edit-msg').val(item.msg);
        $('#rp-editor-title').text('ویرایش اطلاعیه');
        $('#rp-editor-wrapper').slideDown();
    });

    $(document).on('click', '.delete-notif', function (e) {
        e.preventDefault();
        if (confirm('آیا مطمئن هستید؟')) {
            notifData.splice($(this).data('index'), 1);
            renderNotifGrid();
            $saveBar.addClass('visible');
        }
    });

    $('#rp-btn-save-item').click(function (e) {
        e.preventDefault();
        var newItem = {
            title: $('#edit-title').val(),
            type: $('#edit-type').val(),
            msg: $('#edit-msg').val(),
            active: '1'
        };
        if (editIndex === -1) notifData.unshift(newItem);
        else notifData[editIndex] = newItem;
        renderNotifGrid();
        $('#rp-editor-wrapper').slideUp();
        $saveBar.addClass('visible');
    });

    /* =======================================================
       سایر بخش‌ها (منوساز، ریپیتر، ابزارها، کالرپیکر)
    ======================================================= */

    // فعال‌سازی Color Picker وردپرس اگر لود شده باشد
    if ($.fn.wpColorPicker) {
        $('.rp-color-field').wpColorPicker();
    }

    // مدیریت تب‌های پیامک
    $(document).on('click', '.rp-mini-tabs-nav li', function () {
        var $this = $(this);
        var method = $this.data('method');
        var $wrapper = $this.closest('.rp-mini-tabs-wrapper');
        $wrapper.find('.rp-mini-tabs-nav li').removeClass('active');
        $this.addClass('active');
        $wrapper.find('.rp-mini-tab-content').hide();
        $wrapper.find('.content-' + method).fadeIn(200);

        // پیدا کردن اینپوت مخفی و آپدیت آن (چه در ریپیتر باشد چه در صفحه اصلی)
        var hiddenInput = $wrapper.closest('.rp-conditional-block').find('.rp-sms-method-input');
        if (hiddenInput.length === 0) hiddenInput = $('#rp_sms_method_input');
        hiddenInput.val(method);
    });

    // تاگل‌های بخش‌ها (نمایش/مخفی کردن)
    $(document).on('change', '.rp-section-toggle', function () {
        var targetId = $(this).data('target');
        if ($(this).is(':checked')) $('#' + targetId).fadeIn();
        else $('#' + targetId).hide();
    });
    $('.rp-section-toggle').trigger('change');

    // آپلودر مدیا (تنظیمات)
    $(document).on('click', '.rp-upload-btn-modern, .rp-preview-circle, .rp-media-upload-btn', function (e) {
        e.preventDefault();
        var $button = $(this);
        // پشتیبانی از هر دو نوع ساختار آپلودر (مدرن و منوساز)
        var wrap = $button.closest('.rp-media-upload-modern-wrap, .rp-image-uploader-area');

        // پیدا کردن المان‌ها با سلکتورهای عمومی‌تر
        var input = wrap.find('input[type="text"], input[type="hidden"]').first();
        var preview = wrap.find('img');
        var removeBtn = wrap.find('.rp-remove-btn-modern');

        var custom_uploader = wp.media({ title: 'انتخاب تصویر', button: { text: 'استفاده از این تصویر' }, multiple: false });

        custom_uploader.on('select', function () {
            var attachment = custom_uploader.state().get('selection').first().toJSON();
            input.val(attachment.url).trigger('change');

            if (preview.length) preview.attr('src', attachment.url);
            if (removeBtn.length) removeBtn.fadeIn();
            wrap.addClass('has-image');
        });
        custom_uploader.open();
    });

    $(document).on('click', '.rp-remove-btn-modern', function (e) {
        e.preventDefault();
        var wrap = $(this).closest('.rp-media-upload-modern-wrap');
        wrap.find('.rp-media-input').val('').trigger('change');
        var img = wrap.find('.rp-preview-img');
        img.attr('src', img.data('default'));
        $(this).fadeOut();
        wrap.removeClass('has-image');
    });

    // منوساز و ریپیترها
    $(document).on('click', '.rp-add-row', function () {
        var $btn = $(this);
        var wrap = $btn.closest('.rp-repeater-wrap');
        var list = wrap.find('.rp-repeater-list');
        var id = wrap.data('id');
        var fields = $btn.data('fields');
        var idx = new Date().getTime(); // ایندکس یکتا

        var html = '<div class="rp-repeater-item" style="display:none;"><div class="rp-repeater-inputs">';
        $.each(fields, function (key, label) {
            // ساخت نام اینپوت به صورت آرایه
            var name = 'reyhan_options[' + id + '][' + idx + '][' + key + ']';
            html += '<div class="rp-input-group-row"><label class="rp-input-label">' + label + '</label>';
            if (key === 'content' || key === 'a') {
                html += '<textarea name="' + name + '" rows="2" class="rp-full-width"></textarea>';
            } else {
                html += '<input type="text" name="' + name + '" class="rp-full-width">';
            }
            html += '</div>';
        });
        html += '</div><div class="rp-repeater-actions"><button type="button" class="button rp-remove-row"><span class="dashicons dashicons-no"></span></button></div></div>';

        list.append(html);
        list.find('.rp-repeater-item:last').fadeIn();
    });

    $(document).on('click', '.rp-remove-row', function (e) {
        e.preventDefault();
        if (confirm('آیا مطمئن هستید؟')) {
            $(this).closest('.rp-repeater-item').slideUp(200, function () { $(this).remove(); });
        }
    });

    if ($.fn.sortable) {
        $('.rp-menu-list, .rp-repeater-list').sortable({ handle: '.rp-sort-handle, .rp-item-header', placeholder: "ui-state-highlight", opacity: 0.8 });
    }

    // ابزارها (Tools)
    $('.rp-run-tool').click(function () {
        var btn = $(this);
        var action = btn.data('action');
        if (['factory_reset', 'nuke_tickets', 'nuke_users'].includes(action) && !confirm('این عملیات غیرقابل بازگشت است. ادامه می‌دهید؟')) return;

        btn.prop('disabled', true).text('در حال پردازش...');
        var data = { action: 'reyhan_tool_action', security: reyhan_admin_ajax.nonce, tool_action: action };

        if (action === 'test_sms') data.mobile = $('#test_mobile_input').val();
        if (action === 'test_email') data.email = $('#test_email_input').val();

        $.post(reyhan_admin_ajax.ajax_url, data, function (res) {
            btn.prop('disabled', false).text('اجرا');
            if (res.success) {
                alert(res.data);
                if (action === 'factory_reset') location.reload();
                if (action.includes('test')) $('#rp-test-result').html('<strong style="color:green">' + res.data + '</strong>');
            } else {
                alert('خطا: ' + res.data);
                $('#rp-test-result').html('<strong style="color:red">خطا: ' + res.data + '</strong>');
            }
        });
    });

    /* =======================================================
       مدیریت کارشناسان (Agent Search & Modal)
    ======================================================= */
    var agentSearchTimer;
    var agentsData = [];
    var currentEditingAgent = null;

    // لود اولیه داده‌ها
    if ($('#rp_agents_data_json').length > 0) {
        try { agentsData = JSON.parse($('#rp_agents_data_json').val()); } catch (e) { agentsData = []; }
        renderAgentsGrid();
    }

    function renderAgentsGrid() {
        var html = '';
        if (agentsData.length === 0) {
            html = '<div style="grid-column:1/-1; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:40px; color:#999; background:#fff; border-radius:16px; border:2px dashed #e0e0e0;"><span class="dashicons dashicons-admin-users" style="font-size:40px; width:40px; height:40px; margin-bottom:10px; opacity:0.5;"></span><div>هنوز هیچ کارشناسی تعریف نشده است.</div></div>';
        } else {
            $.each(agentsData, function (i, agent) {
                // تعیین متن دسترسی
                var deptText = '';
                if (agent.all_depts) {
                    deptText = '<span style="color:#2e7d32; background:#e8f5e9; padding:2px 8px; border-radius:10px; font-weight:bold;">مدیر کل (دسترسی کامل)</span>';
                } else if (agent.depts && agent.depts.length > 0) {
                    deptText = 'دسترسی به: ' + agent.depts.join('، ');
                } else {
                    deptText = '<span style="color:#c62828;">بدون دسترسی</span>';
                }

                // تعیین کلاس رنگی کنار کارت
                var cardClass = agent.all_depts ? 'full-access' : 'limited';

                // ساخت HTML کارت
                html += `<div class="rp-agent-card ${cardClass}">
                    <div class="rp-agent-avatar">
                        <img src="${agent.avatar || rp_default_avatar}" alt="${agent.name}">
                    </div>
                    <div class="rp-agent-info" style="flex-grow:1;">
                        <h4>${agent.name}</h4>
                        <span class="rp-agent-depts">${deptText}</span>
                    </div>
                    <div class="rp-agent-actions">
                        <button type="button" class="rp-btn-icon edit-agent" data-index="${i}" title="ویرایش دسترسی"><span class="dashicons dashicons-edit"></span></button>
                        <button type="button" class="rp-btn-icon remove-agent" data-index="${i}" title="حذف کارشناس"><span class="dashicons dashicons-trash"></span></button>
                    </div>
                </div>`;
            });
        }
        $('#rp-agents-grid').html(html);

        // ذخیره در اینپوت مخفی برای ارسال با فرم اصلی
        $('#rp_agents_data_json').val(JSON.stringify(agentsData));
    }

    $('#rp-user-search-input').on('keyup', function () {
        var term = $(this).val();
        var resBox = $('#rp-search-results');

        clearTimeout(agentSearchTimer);

        // اگر متن کوتاه است، باکس را ببند و خارج شو
        if (term.length < 2) {
            resBox.hide();
            return;
        }

        agentSearchTimer = setTimeout(function () {
            // نمایش لودینگ
            resBox.show().html('<div style="padding:15px; color:#777; text-align:center;">در حال جستجو... <span class="spinner is-active" style="float:none; margin:0;"></span></div>');

            $.post(reyhan_admin_ajax.ajax_url, {
                action: 'reyhan_search_users', // این نام دقیقاً با PHP یکی شد
                security: reyhan_admin_ajax.nonce,
                term: term
            }, function (res) {
                if (res.success && res.data && res.data.length > 0) {
                    var html = '<ul>';
                    var count = 0;

                    $.each(res.data, function (i, user) {
                        // بررسی تکراری نبودن (اگر قبلاً در لیست باشد)
                        var isAdded = false;
                        if (typeof agentsData !== 'undefined') {
                            isAdded = agentsData.find(function (a) { return a.id == user.id; });
                        }

                        var style = isAdded ? 'opacity:0.6; cursor:default; background:#f5f5f5;' : '';
                        var icon = isAdded ? '<span class="dashicons dashicons-yes" style="color:green"></span>' : '<span class="dashicons dashicons-plus"></span>';
                        var clickAttr = isAdded ? '' : 'class="rp-result-item"';

                        html += '<li ' + clickAttr + ' style="' + style + '" data-id="' + user.id + '" data-text="' + user.text + '" data-avatar="' + user.avatar + '">';
                        html += '<div style="display:flex; align-items:center; gap:10px;">';
                        html += '<img src="' + user.avatar + '" style="width:30px; height:30px; border-radius:50%;">';
                        html += '<span>' + user.text + '</span>';
                        html += '</div>';
                        html += icon;
                        html += '</li>';
                        count++;
                    });

                    html += '</ul>';

                    if (count > 0) {
                        resBox.html(html);
                    } else {
                        resBox.html('<div style="padding:15px; color:#999; text-align:center;">نتیجه‌ای یافت نشد.</div>');
                    }
                } else {
                    resBox.html('<div style="padding:15px; color:#999; text-align:center;">کاربری یافت نشد.</div>');
                }
            }).fail(function () {
                // اگر باز هم خطا داد، این پیام را نشان می‌دهد
                resBox.html('<div style="padding:15px; color:#d32f2f; text-align:center;">خطا در برقراری ارتباط (کد وضعیت سرور).</div>');
            });
        }, 500);
    });

    // =======================================================
    // دکمه ذخیره تغییرات داخل مودال (اصلاح شده)
    // =======================================================
    $('#btn-save-agent').off('click').on('click', function (e) {
        e.preventDefault();

        // 1. ذخیره وضعیت "دسترسی کامل"
        currentEditingAgent.all_depts = $('#dept-all').is(':checked');
        currentEditingAgent.depts = [];

        // 2. اگر دسترسی کامل نبود، دپارتمان‌های تیک خورده را جمع کن
        if (!currentEditingAgent.all_depts) {
            $('.dept-check:checked').each(function () {
                currentEditingAgent.depts.push($(this).val());
            });
        }

        // 3. آپدیت آرایه اصلی داده‌ها
        // اگر کاربر جدید است (از جستجو آمده)
        if (currentEditingAgent.is_new) {
            // حذف فلگ is_new قبل از ذخیره
            delete currentEditingAgent.is_new;
            agentsData.push(currentEditingAgent);
        } else {
            // اگر ویرایش کاربر موجود است
            agentsData[currentEditingAgent.index] = currentEditingAgent;
        }

        // 4. رندر مجدد لیست کارشناسان در صفحه
        renderAgentsGrid();

        // 5. بستن مودال (با متد جدید CSS)
        $('#rp-dept-modal').removeClass('active');
        setTimeout(function () {
            $('#rp-dept-modal').hide();
        }, 300); // صبر برای تمام شدن انیمیشن

        // 6. پاکسازی فیلد جستجو برای استفاده بعدی
        $('#rp-user-search-input').val('');
    });

    $(document).on('click', '.rp-result-item', function () {
        var finalAvatar = $(this).data('avatar') || rp_default_avatar;

        currentEditingAgent = {
            id: $(this).data('id'),
            name: $(this).data('text'),
            avatar: finalAvatar,
            all_depts: false,
            depts: [],
            is_new: true
        };

        $('#modal-agent-avatar').attr('src', finalAvatar);
        openDeptModal();

        $('#rp-search-results').hide();
        $('#rp-user-search-input').val('');
    });

    // بستن لیست اگر بیرون کلیک شد
    $(document).click(function (e) {
        if (!$(e.target).closest('.rp-agent-search-box').length) {
            $('#rp-search-results').hide();
        }
    });

    // بستن لیست جستجو اگر بیرون کلیک شد
    $(document).click(function (e) {
        if (!$(e.target).closest('.rp-agent-search-box').length) {
            $('#rp-search-results').hide();
        }
    });

    $(document).on('click', '#rp-search-results li', function () {
        var finalAvatar = $(this).data('avatar') || rp_default_avatar;
        currentEditingAgent = { id: $(this).data('id'), name: $(this).data('text'), avatar: finalAvatar, all_depts: false, depts: [], is_new: true };
        $('#modal-agent-avatar').attr('src', finalAvatar);
        openDeptModal();
        $('#rp-search-results').hide();
        $('#rp-user-search-input').val('');
    });

    $(document).on('click', '.edit-agent', function () {
        var idx = $(this).data('index');
        currentEditingAgent = JSON.parse(JSON.stringify(agentsData[idx]));
        currentEditingAgent.index = idx;
        currentEditingAgent.is_new = false;
        $('#modal-agent-avatar').attr('src', currentEditingAgent.avatar || rp_default_avatar);
        openDeptModal();
    });

    $(document).on('click', '.remove-agent', function () {
        if (confirm('آیا از حذف این کارشناس اطمینان دارید؟')) {
            agentsData.splice($(this).data('index'), 1);
            renderAgentsGrid();
        }
    });

    function openDeptModal() {
        // تنظیم نام و تصویر
        $('#modal-agent-name').text(currentEditingAgent.name);

        var deptContainer = $('#dept-list-container');
        var deptAllCheckbox = $('#dept-all');
        var deptAllLabel = deptAllCheckbox.closest('.rp-access-option');
        var divider = $('.rp-divider');

        var hasDepts = (typeof rp_departments_list !== 'undefined' && rp_departments_list.length > 0);

        if (hasDepts) {
            // حالت ۱: دپارتمان‌ها وجود دارند
            var html = '';
            rp_departments_list.forEach(function (dept) {
                var checked = (currentEditingAgent.depts && currentEditingAgent.depts.includes(dept)) ? 'checked' : '';
                // استفاده از ساختار مدرن برای هر دپارتمان
                html += `<label class="rp-access-option" style="margin:0;">
                            <input type="checkbox" class="dept-check" value="${dept}" ${checked}> 
                            <span style="margin-right:10px;">${dept}</span>
                         </label>`;
            });
            deptContainer.html(html).show();
            divider.show();

            // فعال کردن چک‌باکس مدیر کل
            deptAllCheckbox.prop('disabled', false);
            if (currentEditingAgent.all_depts) {
                deptAllCheckbox.prop('checked', true);
            } else {
                deptAllCheckbox.prop('checked', false);
            }

        } else {
            // حالت ۲: هیچ دپارتمانی تعریف نشده (اجبار به دسترسی کامل)
            deptContainer.hide();
            divider.hide();

            // تیک زدن و غیرفعال کردن (قفل کردن) گزینه مدیر کل
            deptAllCheckbox.prop('checked', true).prop('disabled', true);
            currentEditingAgent.all_depts = true; // اطمینان از ذخیره صحیح

            // نمایش پیام راهنما
            deptContainer.html('<div style="grid-column:1/-1; text-align:center; color:#e65100; background:#fff3e0; padding:10px; border-radius:8px; font-size:12px;">چون دپارتمانی تعریف نشده است، کاربر به تمام تیکت‌ها دسترسی خواهد داشت.</div>').show();
        }

        // اعمال استایل برای چک‌باکس والد (مدیر کل)
        updateAllAccessStyle();

        // فراخوانی تابع برای غیرفعال کردن زیرمجموعه‌ها در صورت انتخاب مدیر کل
        toggleDeptChecks();

        // نمایش مودال با انیمیشن
        $('#rp-dept-modal').addClass('active').css('display', 'flex');
    }

    // تابع کمکی برای آپدیت استایل چک‌باکس اصلی
    function updateAllAccessStyle() {
        var chk = $('#dept-all');
        if (chk.is(':checked')) chk.closest('.rp-access-option').addClass('checked');
        else chk.closest('.rp-access-option').removeClass('checked');
    }

    // تغییر روی چک‌باکس مدیر کل
    $('#dept-all').change(function () {
        toggleDeptChecks();
        updateAllAccessStyle();
    });

    // تغییر روی چک‌باکس‌های دپارتمان (برای استایل دهی)
    $(document).on('change', '.dept-check', function () {
        if ($(this).is(':checked')) $(this).closest('.rp-access-option').addClass('checked');
        else $(this).closest('.rp-access-option').removeClass('checked');
    });

    function toggleDeptChecks() {
        var isAll = $('#dept-all').is(':checked');
        var hasDepts = (typeof rp_departments_list !== 'undefined' && rp_departments_list.length > 0);

        // اگر دپارتمان داریم و تیک "همه" زده شده، بقیه را غیرفعال کن
        if (hasDepts) {
            $('.dept-check').prop('disabled', isAll);
            if (isAll) {
                $('.dept-check').prop('checked', true).closest('.rp-access-option').addClass('checked').css('opacity', '0.6');
            } else {
                // اگر تیک برداشته شد، چک‌باکس‌های پایین را به حالت ذخیره شده برگردان (یا خالی کن)
                // اینجا فقط اپاسیتی را برمی‌گردانیم، کاربر خودش باید انتخاب کند
                $('.dept-check').closest('.rp-access-option').css('opacity', '1');

                // یک منطق هوشمند: اگر در حال ادیت هستیم و تیک همه را برداشتیم، تیک‌های قبلی کاربر را بازگردانیم؟
                // فعلاً ساده نگه می‌داریم: اگر تیک همه برداشته شد، پایین آزاد شود.
                if (!currentEditingAgent.all_depts && currentEditingAgent.depts.length > 0) {
                    // بازگردانی انتخاب‌های قبلی اگر وجود داشت (اختیاری)
                } else {
                    $('.dept-check').prop('checked', false).closest('.rp-access-option').removeClass('checked');
                }
            }
        }
    }

    // اصلاح دکمه بستن مودال
    $('.close-modal, .rp-modal-close').click(function () {
        $('#rp-dept-modal').removeClass('active');
        setTimeout(function () { $('#rp-dept-modal').hide(); }, 300); // صبر برای انیمیشن
    });

    /* =======================================================
       تیکت‌های سمت ادمین (Admin Tickets)
    ======================================================= */
    var ticketContainer = $('#ticket-list-container');
    if (ticketContainer.length) {
        var chatBox = $('#conversation-content');
        var infoBar = $('#ticket-info-bar');
        var currentTicketId = null;

        function loadAdminTickets(status) {
            $.post(reyhan_admin_ajax.ajax_url, {
                action: 'reyhan_admin_load_tickets', security: reyhan_admin_ajax.nonce, status: status || 'active'
            }, function (res) {
                if (res.success) ticketContainer.html(res.data);
            });
        }

        $('.filter-pill').click(function (e) {
            e.preventDefault();
            $('.filter-pill').removeClass('active');
            $(this).addClass('active');
            loadAdminTickets($(this).data('status'));
        });

        $(document).on('click', '.ticket-list-item', function () {
            $('.ticket-list-item').removeClass('selected');
            $(this).addClass('selected');
            currentTicketId = $(this).data('id');
            var currentStatus = $(this).data('status');

            if (currentStatus === 'closed') $('.rp-reply-area').slideUp(); else $('.rp-reply-area').slideDown();
            chatBox.html('<div class="rp-loading-state">در حال بارگذاری...</div>');
            infoBar.hide().empty();
            $('#delete-ticket-btn').show().data('id', currentTicketId);

            $.post(reyhan_admin_ajax.ajax_url, {
                action: 'reyhan_admin_load_conv', security: reyhan_admin_ajax.nonce, ticket_id: currentTicketId
            }, function (res) {
                if (res.success) {
                    infoBar.html(res.data.info).fadeIn();
                    chatBox.html(res.data.chat);
                    setTimeout(function () { chatBox.scrollTop(chatBox[0].scrollHeight); }, 100);
                }
            });
        });

        $('#send-reply-btn').click(function () {
            if (!currentTicketId) return;
            var msg = $('#reply-text').val();
            var fileInput = $('#reply-file')[0].files[0];
            var isClose = $('#close-ticket-check').is(':checked');
            var btn = $(this);

            if (!msg && !fileInput) { alert('متن یا فایل الزامی است.'); return; }
            btn.prop('disabled', true).text('در حال ارسال...');

            var fd = new FormData();
            fd.append('action', 'reyhan_admin_reply');
            fd.append('security', reyhan_admin_ajax.nonce);
            fd.append('ticket_id', currentTicketId);
            fd.append('message', msg);
            fd.append('status', isClose ? 'closed' : 'answered');
            if (fileInput) fd.append('reply_file', fileInput);

            $.ajax({
                url: reyhan_admin_ajax.ajax_url, type: 'POST', data: fd, contentType: false, processData: false,
                success: function (res) {
                    btn.prop('disabled', false).html('ارسال پاسخ <span class="dashicons dashicons-arrow-left-alt"></span>');
                    if (res.success) {
                        if (isClose) {
                            $('.ticket-list-item[data-id="' + currentTicketId + '"]').fadeOut();
                            $('.rp-reply-area').slideUp();
                            chatBox.empty(); infoBar.hide();
                        } else {
                            $('.ticket-list-item[data-id="' + currentTicketId + '"]').click();
                        }
                        $('#reply-text').val(''); $('#reply-file').val(''); $('#file-name-display').text('');
                    } else { alert(res.data); }
                }
            });
        });

        $('#reply-file').change(function () { $('#file-name-display').text(this.files[0] ? this.files[0].name : ''); });

        $('#delete-ticket-btn').click(function () {
            if (!currentTicketId || !confirm('مطمئن هستید؟')) return;
            $.post(reyhan_admin_ajax.ajax_url, {
                action: 'reyhan_tool_action', security: reyhan_admin_ajax.nonce, tool_action: 'nuke_tickets_single', id: currentTicketId
            }, function () {
                $('.ticket-list-item[data-id="' + currentTicketId + '"]').fadeOut();
                chatBox.empty(); infoBar.hide();
            });
        });

        $('#canned-search-input').on('keyup focus', function () {
            var term = $(this).val().toLowerCase();
            var box = $('#canned-results');
            if (term.length < 1) { box.hide(); return; }
            if (reyhan_admin_ajax.canned_responses) {
                var hits = Object.values(reyhan_admin_ajax.canned_responses).filter(function (r) {
                    return (r.title || '').toLowerCase().includes(term) || (r.content || '').toLowerCase().includes(term);
                });
                if (hits.length) {
                    var html = '';
                    hits.forEach(function (r) {
                        html += `<div class="rp-canned-item" data-content="${(r.content || '').replace(/"/g, '&quot;')}"><strong>${r.title}</strong><br><small>${(r.content || '').substring(0, 50)}...</small></div>`;
                    });
                    box.html(html).show();
                } else { box.hide(); }
            }
        });

        $(document).on('click', '.rp-canned-item', function () {
            var txt = $('#reply-text');
            txt.val(txt.val() + (txt.val() ? '\n' : '') + $(this).data('content'));
            $('#canned-results').hide();
        });

        loadAdminTickets('active');
        setInterval(function () { loadAdminTickets($('.filter-pill.active').data('status')); }, 30000);
    }

    // --- منو ساز (Menu Builder) ---
    if ($('#rp-menu-builder-wrap').length) {
        var $container = $('#rp-menu-builder-wrap');
        var $list = $container.find('.rp-menu-list');

        $list.sortable({
            handle: '.rp-sort-handle',
            placeholder: 'rp-sort-placeholder',
            items: '.rp-menu-item-row:not(.rp-locked-item)',
            cancel: '.rp-locked-item',
            update: function () { }
        });

        // افزودن آیتم جدید در منوساز
        $('.rp-add-menu-item').on('click', function (e) {
            e.preventDefault();

            var $clone = $list.find('.rp-menu-item-row').eq(1).clone();
            if ($clone.length === 0) $clone = $list.find('.rp-menu-item-row').first().clone();

            $clone.removeClass('rp-locked-item closed').addClass('closed');
            $clone.find('.rp-item-title').text('(آیتم جدید)');
            $clone.find('.rp-item-type-badge').text('link');
            $clone.find('input[type="text"], textarea').val('');
            $clone.find('select').val('link').prop('disabled', false).css({ 'pointer-events': 'auto', 'background': '', 'opacity': '1' });
            $clone.find('.rp-icon-input').val('dashicons-marker');
            $clone.find('.preview-icon').attr('class', 'dashicons dashicons-marker preview-icon');
            $clone.find('.rp-sort-handle').remove();
            $clone.find('.rp-lock-icon').remove();
            $clone.find('.rp-item-header').prepend('<span class="dashicons dashicons-move rp-sort-handle"></span>');

            if ($clone.find('.rp-remove-row').length === 0) {
                $clone.find('.rp-header-controls').append('<button type="button" class="rp-remove-row"><span class="dashicons dashicons-trash"></span></button>');
            }

            var newIdx = new Date().getTime();
            $clone.find('input, select, textarea').each(function () {
                var name = $(this).attr('name');
                if (name) {
                    $(this).attr('name', name.replace(/\[\d+\]/, '[' + newIdx + ']'));
                }
            });

            $clone.find('.rp-item-body').hide();

            var $logoutItem = $list.find('.rp-menu-item-row[data-action="logout"]');
            if ($logoutItem.length > 0) {
                $clone.insertBefore($logoutItem);
            } else {
                $list.append($clone);
            }
        });

        $(document).on('click', '.rp-toggle-item', function () {
            $(this).closest('.rp-menu-item-row').find('.rp-item-body').slideToggle();
            $(this).closest('.rp-menu-item-row').toggleClass('closed');
        });

        $(document).on('keyup', '.rp-live-title', function () {
            $(this).closest('.rp-menu-item-row').find('.rp-item-title').text($(this).val());
        });

        $(document).on('change', '.rp-menu-action-select', function () {
            var val = $(this).val();
            var row = $(this).closest('.rp-menu-item-row');
            row.find('.rp-item-type-badge').text(val);
            row.find('.rp-menu-link-row').toggle(val === 'link');
            row.find('.rp-menu-shortcode-row').toggle(val === 'content');
        });
    }

    // ============================================================
    // اصلاحیه نهایی و قطعی: فیکس کردن عرض تمام عناوین و بخش‌های خاص
    // این بخش باعث می‌شود تمام عناوین بخش‌ها و باکس‌های خاص
    // عرض ۱۰۰٪ داشته باشند و دیگر تورفتگی نداشته باشند.
    // ============================================================
    function fixFullWidthElements() {
        var fullWidthClasses = [
            '.rp-section-header',         // عناوین بخش‌ها (مشکل اصلی)
            '.rp-menu-builder-wrap',      // منو ساز
            '.rp-agent-manager-wrapper'   // بخش کارشناسان
        ];

        $.each(fullWidthClasses, function (index, selector) {
            $(selector).each(function () {
                var $el = $(this);
                // پیدا کردن سلول و ردیف جدول والد
                var $td = $el.closest('td');
                var $tr = $td.closest('tr');

                if ($tr.length && $td.length) {
                    // مخفی کردن عنوان کناری (th)
                    $tr.find('th').hide();
                    // گسترش سلول به کل عرض (Colspan 2)
                    $td.attr('colspan', '2');
                    // حذف فاصله‌های پیش‌فرض برای چسبیدن کامل
                    $td.css({ 'padding': '0', 'width': '100%' });
                }
            });
        });
    }

    // اجرای تابع فیکس بلافاصله پس از لود صفحه
    fixFullWidthElements();

});